import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {NgIdleKeepaliveModule} from '@ng-idle/keepalive';
import { CdkTreeModule } from '@angular/cdk/tree';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AppRoutingModule } from './app-routing.module';
import { LayoutModule } from '@angular/cdk/layout';
import { DragDropModule } from '@angular/cdk/drag-drop';
import {
  MatButtonModule, MatToolbarModule, MatSidenavModule, MatIconModule, MatRadioModule,
  MatDialogModule, MatCardModule, MatTableModule, MatSliderModule, MatSortModule,
  MatPaginatorModule, MatNativeDateModule, MatExpansionModule, MatTabsModule, MatAutocompleteModule
} from '@angular/material';
import { MatDatepickerModule } from '@angular/material/datepicker';
import {
  MatTooltipModule, MatListModule, MatProgressSpinnerModule,
  MatSelectModule, MatInputModule, MatCheckboxModule, MatTreeModule
} from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { LeafletModule } from '@asymmetrik/ngx-leaflet';

import { AppComponent } from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { MainNavComponent } from './components/main-nav/main-nav.component';
// tslint:disable-next-line:max-line-length
import { WorksheetsComponent, AddworksheetDialogComponent, AdhocsubmitDialogComponent } from './components/labs/worksheets/worksheets.component';
import { MenuListItemComponent } from './components/menu-list-item/menu-list-item.component';
import { LoaderComponent } from './components/loader/loader.component';
import { LoginComponent } from './components/login/login.component';
import { AlertComponent } from './directives';
import { LabsComponent } from './components/labs/labs.component';
import { EditworksheetComponent } from './components/labs/worksheets/editworksheet/editworksheet.component';
import { AddsamplepointDialogComponent } from './components/labs/worksheets/editworksheet/addsamplepoint/addsamplepoint.component';
import { AddtestDialogComponent } from './components/labs/worksheets/editworksheet/addtest/addtest.component';
import { UnlockworksheetDialogComponent } from './components/labs/worksheets/editworksheet/unlockworksheet/unlockworksheet.component';
import { DeleteworksheetDialogComponent } from './components/labs/worksheets/editworksheet/deleteworksheet/deleteworksheet.component';
import { SubmitworksheetDialogComponent } from './components/labs/worksheets/editworksheet/submitworksheet/submitworksheet.component';
import { MapComponent } from './components/map/map.component';
import { HomeComponent } from './components/home/home.component';
import { CityviewComponent } from './components/cityview/cityview.component';
import { PlantviewComponent } from './components/plantview/plantview.component';
import { RecordsComponent } from './components/labs/records/records.component';
/* Events and Alerts*/
import { EventCategoryListComponent } from './components/events-and-alerts/event-category-list/event-category-list.component';
import { AddEventCategoryComponent } from './components/events-and-alerts/add-event-category/add-event-category.component';
// tslint:disable-next-line:max-line-length
import { EventEscalationEmailAlertSettingsListComponent } from './components/events-and-alerts/event-escalation-email-alert-settings-list/event-escalation-email-alert-settings-list.component';
// tslint:disable-next-line:max-line-length
import { AddEditEventEscalationEmailSettingsComponent } from './components/events-and-alerts/add-edit-event-escalation-email-settings/add-edit-event-escalation-email-settings.component';
import { CancelConfirmationDialogComponent } from './components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { CloseContractDialogComponent } from './components/commercial/renew-contract/confirmation-dialog/cancel-confirmation-dialog';
import { AnalyticsCancelConfirmationDialogComponent } from './components/analytics/confirmation-dialog/cancel-confirmation-dialog';


import { NavService } from './components/main-nav/nav.service';
import { LoaderInterceptorService } from './services/loader-interceptor.service';
import { AuthenticationService } from './services/authentication.service';
import { AlertService } from './services/alert.service';
// import { PreventBack } from './services/preventback.service';

import { AuthGuard } from './components/login/auth.guard';
import { JwtInterceptor, ErrorInterceptor } from './helpers';
import { FilterPipe } from './pipes/filter.pipe';
import { RoundPipe } from './pipes/round.pipe';
import { SamplepointFilterPipe } from './pipes/samplepointfilter.pipe';
import { TestnameFilterPipe } from './pipes/testnamefilter.pipe';
import { SortPipe, OrderBy } from './pipes/sort.pipe';
import { UniqueFilterPipe } from './pipes/uniquearrayfilter.pipe';

import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { RecordviewComponent } from './components/labs/records/recordview/recordview.component';

import { ErrorDialogComponent } from './components/error/error.component';
import { StickyHeaderDirective } from './directives/sticky-header.directive';
import { NumberOnlyDirective } from './directives/numberonly.directive';
import { HasRoleDirective } from './directives/rolepermission.directive';
import { DigitDirective } from './directives/digitonly.directive';
import { DigitDirectiveZero } from './directives/digitonlyzero.directive';
import { environment } from '../environments/environment';

/*ops*/
import { OpsComponent } from './components/ops/ops.component';
import { OpsworksheetComponent } from './components/ops/opsworksheet/opsworksheet.component';
import { EditopsworksheetComponent } from './components/ops/opsworksheet/editopsworksheet/editopsworksheet.component';
import { AddlocationpointComponent } from './components/ops/opsworksheet/editopsworksheet/addlocationpoint/addlocationpoint.component';
// tslint:disable-next-line:max-line-length
import { UnlockopsworksheetComponent } from './components/ops/opsworksheet/editopsworksheet/unlockopsworksheet/unlockopsworksheet.component';
import { AdditemComponent } from './components/ops/opsworksheet/editopsworksheet/additem/additem.component';
import { LocationpointFilterPipe } from './pipes/locationpointfilter.pipe';
import { ItemnameFilterPipe } from './pipes/itemnamefilter.pipe';
import { ActivityFilterPipe } from './pipes/activityfilter.pipe';
import { PlantdataentryComponent } from './components/ops/opsworksheet/editopsworksheet/plantdataentry/plantdataentry.component';
import { OpsmaintenanceComponent } from './components/ops/opsmaintenance/opsmaintenance.component';
import { EditmaintenancewsComponent } from './components/ops/opsmaintenance/editmaintenancews/editmaintenancews.component';
// tslint:disable-next-line:max-line-length
import { SubmitopsworksheetComponent } from './components/ops/opsworksheet/editopsworksheet/submitopsworksheet/submitopsworksheet.component';
import { OpsrecordsComponent } from './components/ops/opsrecords/opsrecords.component';
import { OpsmainrecordsComponent } from './components/ops/opsmainrecords/opsmainrecords.component';
import { AddnonroutineactComponent } from './components/ops/opsmaintenance/editmaintenancews/addnonroutineact/addnonroutineact.component';

import { PfdDialog, PfdComponent, PfdSingleLineChartComponent } from './components/pfd/pfd.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
// tslint:disable-next-line:max-line-length
import { SubmitmaintenancewsComponent } from './components/ops/opsmaintenance/editmaintenancews/submitmaintenancews/submitmaintenancews.component';
// tslint:disable-next-line:max-line-length
import { UnlockmaintenancewsComponent } from './components/ops/opsmaintenance/editmaintenancews/unlockmaintenancews/unlockmaintenancews.component';
import { AnalyticsPrognosisComponent } from './components/analytics/prognosis/analytics-prognosis.component';
import { AnalyticsTroubleshootingComponent } from './components/analytics/troubleshooting/analytics-troubleshooting.component';
import { AnalyticsTagsListComponent } from './components/analytics/analytics-tags-list/analytics-tags-list.component';
import { AnalyticsAddEditPrognosisTagComponent } from './components/analytics/add-edit-prognosis-tag/add-edit-prognosistag.component';
import { AnalyticsAddEditPredictionTagComponent } from './components/analytics/add-edit-prediction-tag/add-edit-predictiontag.component';
import { AnalyticsAddEditPredictTagComponent } from './components/analytics/add-edit-predict-tag/add-edit-predict-tag.component';
import { PredictionMessageListComponent,
  AddeEditRCMsgComponent, MsgcarbonrefDialogComponent
 } from './components/analytics/prediction-message-list/prediction-message-list.component';
import 'hammerjs';
import { DialogComponent } from './components/common/dialog/dialog.component';
// tslint:disable-next-line:max-line-length
import { RemoteMonitoringCheckListComponent } from './components/events-and-alerts/remote-monitoring/remote-monitoring-check-list/remote-monitoring-check-list.component';
// tslint:disable-next-line:max-line-length
import { AddRemoteMonitoringCheckComponent } from './components/events-and-alerts/remote-monitoring/add-remote-monitoring-check/add-remote-monitoring-check.component';
import { ViewAnEventComponent,
  UserDefineDialogComponent,
  AddUserDefineDialogComponent, EditUserDefineDialogComponent } from './components/events-and-alerts/view-an-event/view-an-event.component';
// tslint:disable-next-line:max-line-length
import { SensorFailureCheckListComponent } from './components/events-and-alerts/sensor-failure-check-list/sensor-failure-check-list.component';
// tslint:disable-next-line:max-line-length
import { AddSensorFailureCheckComponent, CancelDialogComponent } from './components/events-and-alerts/add-sensor-failure-check/add-sensor-failure-check.component';
import { EventMessageListComponent } from './components/events-and-alerts/event-message-list/event-message-list.component';
import { AddEditEventMessageComponent } from './components/events-and-alerts/add-edit-event-message/add-edit-event-message.component';
import { EventTypeListComponent } from './components/events-and-alerts/event-type-list/event-type-list.component';
import { NewEventComponent } from './components/events-and-alerts/new-event/new-event.component';

import { CustomerContractComponent } from './components/commercial/customer-contract/customer-contract.component';
import { ContractSpecificationsComponent } from './components/commercial/contract-specifications/contract-specifications.component';
import { RenewContractComponent } from './components/commercial/renew-contract/renew-contract.component';
// tslint:disable-next-line:max-line-length
import { EditCustomerContractComponent } from './components/commercial/renew-contract/edit-customer-contract/edit-customer-contract.component';
// import { EditContractSpecComponent } from './components/commercial/renew-contract/edit-contract-spec/edit-contract-spec.component';
import { CustomerListComponent } from './components/admin/customer-list/customer-list.component';
import { AddCustomerDetailsComponent } from './components/admin/add-customer-details/add-customer-details.component';
import { EditCustomerComponent } from './components/admin/edit-customer/edit-customer.component';
import { CreateNewEventComponent } from './components/events-and-alerts/events-categories/create-new-event/create-new-event.component';
// tslint:disable-next-line:max-line-length
import { ViewAllEventsCategoriesComponent } from './components/events-and-alerts/events-categories/view-all-events-categories/view-all-events-categories.component';
// tslint:disable-next-line:max-line-length
import { AuthCallbackComponent } from './components/login/authcallback/auth-callback.component';
import { CommercialComponent } from './components/commercial/commercial.component';
import { AdalService, AdalInterceptor } from 'adal-angular4';
import { CustomerDetailsComponent } from './components/commercial/customer-details/customer-details.component';
import { LinechartComponent } from './components/linechart/linechart.component';
import { MultiAxesChartComponent } from './components/multi-axes-chart/multi-axes-chart.component';
import { TabsComponent } from './components/tabs/tabs.component';
import { Tab } from './components/tabs/tabs.component';
import { DataAnalysisComponent, NameDialog } from './components/data-analysis/data-analysis.component';
import { DragulaModule } from 'ng2-dragula';
import { LOCALE_ID } from '@angular/core';
import { registerLocaleData, DatePipe } from '@angular/common';
import localeEnGb from '@angular/common/locales/en-gb';
// tslint:disable-next-line:max-line-length
import { ReportsComponent, AddreportDialogComponent, AdhocTemplateComponent, ClonereportDialogComponent } from './components/reports/reports.component';
import { SchedulereportComponent } from './components/reports/schedulereport/schedulereport.component';
import { CreatestandardreportComponent } from './components/reports/createstandardreport/createstandardreport.component';
// import { EmailGroupListComponent } from './components/admin/email-group/email-group-list/email-group-list.component';
// import { AddEditEmailGroupComponent } from './components/admin/email-group/add-edit-email-group/add-edit-email-group.component';

// tslint:disable-next-line:max-line-length
import { AuditComponent, CloneAuditDialogComponent, RunAuditDialogComponent, DeleteAuditDialogComponent } from './components/audit/audit.component';
import { ScheduleauditComponent } from './components/audit/scheduleaudit/scheduleaudit.component';
import { StatusauditComponent } from './components/audit/statusaudit/statusaudit.component';
import { CreateauditpointComponent, TestRunDialogComponent } from './components/audit/createauditpoint/createauditpoint.component';
import { EmailGroupListComponent } from './components/admin/email-group/email-group-list/email-group-list.component';
import { AddEditEmailGroupComponent } from './components/admin/email-group/add-edit-email-group/add-edit-email-group.component';
import { DndModule } from 'ng2-dnd';
import { RoleListComponent } from './components/admin/role/role-list/role-list.component';
import { AddEditRoleComponent } from './components/admin/role/add-edit-role/add-edit-role.component';
import { UserListComponent } from './components/admin/user/user-list/user-list.component';
import { AddEditUserComponent } from './components/admin/user/add-edit-user/add-edit-user.component';
import { PlantListComponent } from './components/admin/plant/plant-list/plant-list.component';
import { AddUpdatePlantComponent } from './components/admin/plant/add-update-plant/add-update-plant.component';
registerLocaleData(localeEnGb);
import { ThreeDigitDecimaNumberDirective } from './directives/three-digit-number.directive';
import { FloatNumberDirective } from './float-number.directive';
import { LatLongDirective } from './directives/latlong.directive';
import { AlphaNumericDirective } from './alpha-numeric.directive';
// import {MatPaginatorIntl} from '@angular/material';
// import {MatPaginatorIntlCustom} from './directives/customMatPaginateIntl';

import { SessiontimeComponent } from './components/common/sessiontimeout/sessiontimeout.component';
import { ChangePasswordDialogComponent, ChangepasswordComponent } from './components/changepassword/changepassword.component';
import { UnlockRequestListComponent } from './components/admin/unlock-a-worksheet/unlock-request-list.component';
import { WaitForSaveComponent } from './components/wait-for-save/wait-for-save.component';
import { CityListComponent } from './components/admin/city/city-list/city-list.component';
import { AddEditCityComponent } from './components/admin/city/add-edit-city/add-edit-city.component';
import { AddLabSampleComponent } from './components/admin/lab-sample/add-lab-sample/add-lab-sample.component';
import { LabSampleListComponent } from './components/admin/lab-sample/lab-sample-list/lab-sample-list.component';
import { EventslistComponent } from './components/events-and-alerts/eventslist/eventslist.component';
import { OpsLocationComponent, AddOpsLocationComponent } from './components/admin/ops/ops-location.component';
import { OpsmeasurementComponent, AddOpsMeasurementComponent } from './components/admin/ops/opsmeasurement/opsmeasurement.component';
import { SampleTestComponent } from './components/admin/sample-test/sample-test.component';

// tslint:disable-next-line:max-line-length
import { SetupRegularLabTemplateComponent, SetupTPartyLabTemplateComponent, AddSampleTestDialogComponent, TestFilterPipe } from './components/admin/worksheet-templates/setup-lab-template/setup-lab-template.component';
// tslint:disable-next-line:max-line-length
import { WorksheetTemplatesComponent, CreateLabThirdPartyTempDialogComponent } from 'src/app/components/admin/worksheet-templates/worksheet-templates.component';
import { LabTestComponent } from './components/admin/lab-test/lab-test.component';
import { AddLabTestComponent } from './components/admin/lab-test/add-lab-test/add-lab-test.component';
import { EquipmentComponent, AddEquipmentComponent } from './components/admin/maintenance/equipment/equipment.component';
import { ActivityComponent, AddActivityComponent } from './components/admin/maintenance/activity/activity.component';
import { AssignopsmiComponent } from './components/admin/ops/assignopsmi/assignopsmi.component';
import { TagsComponent } from './components/admin/tags/tags.component';
import { SetupWSComponent, AddLocationItemDialogComponent } from './components/admin/ops/setup-ws/setup-ws.component';
import { FixedtableheaderDirective } from './directives/fixedtableheader.directive';


export function HttpLoaderFactory(http: HttpClient) {
  if (environment.languageConfig.isLocal === true) {
    return new TranslateHttpLoader(http);
  } else {
    return new TranslateHttpLoader(http, environment.languageConfig.url, '');
  }
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AlertComponent,
    MainNavComponent,
    DashboardComponent,
    WorksheetsComponent,
    MenuListItemComponent,
    LoaderComponent,
    AddworksheetDialogComponent,
    AdhocsubmitDialogComponent,
    LabsComponent,
    EditworksheetComponent,
    AddsamplepointDialogComponent,
    AddtestDialogComponent,
    UnlockworksheetDialogComponent,
    DeleteworksheetDialogComponent,
    SubmitworksheetDialogComponent,
    ErrorDialogComponent,
    MapComponent,
    HomeComponent,
    FilterPipe,
    CityviewComponent,
    PlantviewComponent,
    RoundPipe,
    SortPipe,
    OrderBy,
    UniqueFilterPipe,
    SamplepointFilterPipe,
    TestnameFilterPipe,
    RecordsComponent,
    RecordviewComponent,
    StickyHeaderDirective,
    HasRoleDirective,
    NumberOnlyDirective,
    DigitDirective,
    DigitDirectiveZero,
    OpsComponent,
    OpsworksheetComponent,
    EditopsworksheetComponent,
    AddlocationpointComponent,
    UnlockopsworksheetComponent,
    AdditemComponent,
    LocationpointFilterPipe,
    ItemnameFilterPipe,
    ActivityFilterPipe,
    PlantdataentryComponent,
    OpsmaintenanceComponent,
    EditmaintenancewsComponent,
    SubmitopsworksheetComponent,
    OpsrecordsComponent,
    OpsmainrecordsComponent,
    ReportsComponent,
    AddnonroutineactComponent,
    PfdDialog,
    PfdComponent,
    SubmitmaintenancewsComponent,
    UnlockmaintenancewsComponent,
    AnalyticsPrognosisComponent,
    DialogComponent,
    RemoteMonitoringCheckListComponent,
    AddRemoteMonitoringCheckComponent,
    ViewAnEventComponent,
    UserDefineDialogComponent,
    AddUserDefineDialogComponent,
    EditUserDefineDialogComponent,
    SensorFailureCheckListComponent,
    AddSensorFailureCheckComponent,
    EventMessageListComponent,
    AddEditEventMessageComponent,
    EventCategoryListComponent,
    AddEventCategoryComponent,
    EventEscalationEmailAlertSettingsListComponent,
    AddEditEventEscalationEmailSettingsComponent,
    CancelConfirmationDialogComponent,
    ChangePasswordDialogComponent ,
    CloseContractDialogComponent,
    CancelDialogComponent,
    EventTypeListComponent,
    NewEventComponent,
    UserDefineDialogComponent,
    CustomerContractComponent,
    ContractSpecificationsComponent,
    RenewContractComponent,
    EditCustomerContractComponent,
    // EditContractSpecComponent,
    CustomerListComponent,
    AddCustomerDetailsComponent,
    EditCustomerComponent,
    CreateNewEventComponent,
    ViewAllEventsCategoriesComponent,
    AuthCallbackComponent,
    CustomerDetailsComponent,
    LinechartComponent,
    MultiAxesChartComponent,
    TabsComponent,
    Tab,
    NameDialog,
    DataAnalysisComponent,
    CommercialComponent,
    AddreportDialogComponent,
    ClonereportDialogComponent,
    SchedulereportComponent,
    AdhocTemplateComponent,
    CreatestandardreportComponent,
    EmailGroupListComponent,
    AddEditEmailGroupComponent,
    AuditComponent,
    CloneAuditDialogComponent,
    RunAuditDialogComponent,
    DeleteAuditDialogComponent,
    ScheduleauditComponent,
    StatusauditComponent,
    CreateauditpointComponent,
    TestRunDialogComponent,
    RoleListComponent,
    AddEditRoleComponent,
    UserListComponent,
    AddEditUserComponent,
    PlantListComponent,
    AddUpdatePlantComponent,
    ThreeDigitDecimaNumberDirective,
    FloatNumberDirective,
    LatLongDirective,
    AlphaNumericDirective,
    SessiontimeComponent,
    // CommercialComponent
    AnalyticsTroubleshootingComponent,
    AnalyticsTagsListComponent,
    AnalyticsAddEditPrognosisTagComponent,
    AnalyticsAddEditPredictionTagComponent,
    AnalyticsAddEditPredictTagComponent,
    AnalyticsCancelConfirmationDialogComponent,
    PredictionMessageListComponent,
    AddeEditRCMsgComponent,
    MsgcarbonrefDialogComponent,
    DialogComponent,
    UnlockRequestListComponent,
    WaitForSaveComponent,
    CityListComponent,
    AddEditCityComponent,
    AddLabSampleComponent,
    LabSampleListComponent,
    EventslistComponent,
    OpsLocationComponent,
    AddOpsLocationComponent,
    OpsmeasurementComponent,
    AddOpsMeasurementComponent,
    WorksheetTemplatesComponent,
    CreateLabThirdPartyTempDialogComponent,
    SetupRegularLabTemplateComponent,
    SetupTPartyLabTemplateComponent,
    AddSampleTestDialogComponent,
    LabTestComponent,
    AddLabTestComponent,
    SampleTestComponent,
    EquipmentComponent,
    AddEquipmentComponent,
    ActivityComponent,
    AddActivityComponent,
    ChangepasswordComponent,
    AssignopsmiComponent,
    SetupWSComponent,
    TagsComponent,
    AddLocationItemDialogComponent,
    PfdSingleLineChartComponent,
    TestFilterPipe,
    FixedtableheaderDirective
    // SampleTestComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    CdkTreeModule,
    MatButtonModule,
    MatTreeModule,
    LayoutModule,
    DragDropModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatRadioModule,
    MatListModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    MatSelectModule,
    MatInputModule,
    MatCardModule,
    MatSortModule,
    MatSortModule,
    // NgxPaginationModule,
    AppRoutingModule,
    MatTableModule,
    MatSliderModule,
    AppRoutingModule,
    HttpClientModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    // NgxDnDModule,
    MatSortModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatPaginatorModule,
    MatExpansionModule,
    MatTabsModule,
    MatAutocompleteModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    LeafletModule.forRoot(),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),
    DragulaModule.forRoot(),
    DndModule.forRoot(),
    NgIdleKeepaliveModule.forRoot()
  ],
  entryComponents: [
    PfdDialog,
    AddworksheetDialogComponent,
    AdhocsubmitDialogComponent,
    AddsamplepointDialogComponent,
    AddtestDialogComponent,
    UnlockworksheetDialogComponent,
    DeleteworksheetDialogComponent,
    SubmitworksheetDialogComponent,
    ErrorDialogComponent,
    AddlocationpointComponent,
    UnlockopsworksheetComponent,
    AdditemComponent,
    PlantdataentryComponent,
    SubmitopsworksheetComponent,
    AddnonroutineactComponent,
    PlantviewComponent,
    SubmitmaintenancewsComponent,
    UnlockmaintenancewsComponent,
    DialogComponent,
    CancelConfirmationDialogComponent,
    CancelDialogComponent,
    CloseContractDialogComponent,
    AddreportDialogComponent,
    ClonereportDialogComponent,
    AuditComponent,
    CloneAuditDialogComponent,
    TestRunDialogComponent,
    RunAuditDialogComponent,
    DeleteAuditDialogComponent,
    SessiontimeComponent,
    NameDialog,
    AnalyticsCancelConfirmationDialogComponent,
    ChangePasswordDialogComponent,
    UserDefineDialogComponent,
    AddUserDefineDialogComponent,
    EditUserDefineDialogComponent,
    AddSampleTestDialogComponent,
    CreateLabThirdPartyTempDialogComponent,
    AddLocationItemDialogComponent,
    MsgcarbonrefDialogComponent
  ],
  providers: [
    NavService,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptorService, multi: true },
    AuthGuard,
    AlertService,
    // PreventBack,
    AuthenticationService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    PfdComponent,
    AdalService,
    { provide: LOCALE_ID, useValue: 'en-gb' },
    { provide: HTTP_INTERCEPTORS, useClass: AdalInterceptor, multi: true },
    DatePipe,
    // { provide: MatPaginatorIntl, useClass: MatPaginatorIntlCustom}
  ],
  schemas: [
    NO_ERRORS_SCHEMA
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
