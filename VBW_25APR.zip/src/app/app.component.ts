import { Component, HostListener } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from './services/common.service';
import { AdalService } from 'adal-angular4';
import { environment } from '../environments/environment';
import { Router } from '@angular/router';
import { AuthenticationService } from './services/authentication.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Sembcorp';
  adalreponse: any;
  loadchildcomponent =  true;
  private adalConfig = environment.adalconfig;
  constructor(
    private adal: AdalService,
    
    public router: Router,
    private translate: TranslateService,
    public authservice: AuthenticationService,
    private commonservice: CommonService) {
      this.adal.init(this.adalConfig);
      if (this.commonservice.isLogged() === false) {
        this.adal.handleWindowCallback();
        if (this.adal.userInfo.authenticated) {
          this.loadchildcomponent = false;
          sessionStorage.setItem('token', this.adal.userInfo.token);
          this.adalvalidate().subscribe(
            data => {
              let jwtToken = '';
              this.adalreponse = data;
              if (this.adalreponse.status === 'success') {
                this.loadchildcomponent = true;
                jwtToken = this.adalreponse.data;
                const userInfo = this.commonservice.decodeJWT(jwtToken);
                console.log(userInfo);
                this.commonservice.setUser(userInfo);
                sessionStorage.setItem('token', jwtToken);
                this.setlanguage();
              } else {
                sessionStorage.removeItem('user');
                sessionStorage.removeItem('token');
                this.loadchildcomponent = true;
                if (this.adal.userInfo.authenticated) {
                  this.adal.logOut();
                }
              }
            },
            (err: any) => {
              console.log(err);
              sessionStorage.removeItem('user');
              sessionStorage.removeItem('token');
              this.loadchildcomponent = true;
              if (this.adal.userInfo.authenticated) {
                this.adal.logOut();
              }
            }
          );
        }
      } else {
        if (this.commonservice.isLogged() === true) {
          this.setlanguage();
        }
      }
  }

  adalvalidate() {
    return this.commonservice.httppost(environment.adalvalidateUrl, {});
  }

  setlanguage() {
    const userInfo =  this.commonservice.getUser();
    let defaultlang = '1';
    if (this.commonservice.isLogged() === true) {
      if (userInfo !== null && userInfo !== '') {
        defaultlang = (userInfo.typ) ? userInfo.typ : '1';
      }
    }
    this.translate.setDefaultLang(defaultlang);
    this.translate.use(defaultlang);
  }

  @HostListener('document:keydown', ['$event'])
  onKeyDown(evt: KeyboardEvent) {
    if ( evt.keyCode === 8 || evt.which === 8 ) {

      let doPrevent = true;
      const types = [
        'text', 'password', 'file',
        'search', 'email', 'number',
        'date', 'color', 'datetime',
        'datetime-local', 'month', 'range',
        'search', 'tel', 'time', 'url', 'week'];

      const target = (<HTMLInputElement>evt.target);

      const disabled = target.disabled || (<HTMLInputElement>event.target).readOnly;
      if (!disabled) {
        if (target.isContentEditable) {
          doPrevent = false;
        } else if (target.nodeName === 'INPUT') {
          let type = target.type;
          if (type) {
            type = type.toLowerCase();
          }
          if (types.indexOf(type) > -1) {
            doPrevent = false;
          }
        } else if (target.nodeName === 'TEXTAREA') {
          doPrevent = false;
        }
      }
      if (doPrevent) {
        evt.preventDefault();
        return false;
      }
    }
  }

 @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event) {
    this.authservice.logout();
  }
  
}


