import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiAxesChartComponent } from './multi-axes-chart.component';

describe('MultiAxesChartComponent', () => {
  let component: MultiAxesChartComponent;
  let fixture: ComponentFixture<MultiAxesChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiAxesChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiAxesChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
