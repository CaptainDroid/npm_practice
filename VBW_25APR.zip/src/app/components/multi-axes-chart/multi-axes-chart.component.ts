import { Component, Input, OnInit, ViewChild, Inject } from '@angular/core';
import { DataAnalysisService } from '../../services/data-analysis.service';
import * as Chart from 'chart.js';
import { DatePipe } from '@angular/common';
import { DataAnalysisComponent } from 'src/app/components/data-analysis/data-analysis.component';
import jsPDF from 'jspdf';
import { ExcelService } from 'src/app/services/excel.service';
import { map } from 'rxjs/operators';
import { DOCUMENT } from '@angular/common';
import * as html2canvas from 'html2canvas';
import * as moment from 'moment';
import { ErrorserviceService } from 'src/app/services/errorservice.service';

// declare var jsPDF: any;

// import * as jsPDF from '../../../../node_modules/jspdf/dist/jspdf.debug.js';


@Component({
  selector: 'multi-chart',
  templateUrl: './multi-axes-chart.component.html',
  styleUrls: ['./multi-axes-chart.component.css']
})
export class MultiAxesChartComponent implements OnInit {

  @Input() dataY1: any[];
  @Input() dataY2: any[];
  @Input() labels: any[];
  @Input() elementId: string;
  @Input() range: number;
  @Input() datesMethod: string;
  @Input() y1Label: string;
  @Input() y2Label: string;
  @Input() plantId: number;
  // @ViewChild(DataAnalysisComponent) dataAnalysis: DataAnalysisComponent;

  allLabels = [];
  rawDataLabels = [];
  lineChart;
  canvas: any;
  ctx: any;
  values = {};
  datasets = [];
  options = {};
  scales = {};
  ready:boolean;
  pipe;
  startDate: string;
  endDate: string;
  public maxDate;
  public minDate;
  colors = ['red', 'blue', 'green', 'yellow', 'magenta', 'purple', 'orange', 'maroon', 'cyan', 'pink' ];
  colorIndex = 0;
  today: Date;

  constructor(private _dataAnalysisService: DataAnalysisService,
              private _excelService: ExcelService,
              @Inject(DOCUMENT) document,
              public errorService: ErrorserviceService) { }

  ngOnInit() {
    this.pipe = new DatePipe('en-gb');
    this.ready = true;
    this.today = this.pipe.transform(Date.now(), 'dd/MMM/yy');

    // Setting up the axes for the chart
    this.scales = {
      yAxes: [
        {
          scaleLabel: {
            display: true,
            labelString: this.y1Label ? this.y1Label : ""
          },
          position: 'left',
          display: true,
          id: 'left'
        },
        {
          scaleLabel:{
            display: true,
            labelString: this.y2Label ? this.y2Label : ""
          },
          position: 'right',
          display: true,
          id: 'right'
        }
      ],
      xAxes: [{
        ticks: {
          autoSkip: true
        }
      }],
    };

    // Setting up the chart parameters
    this.options = {
      elements: {
        point: {
          radius: 2
        }
      },
      legend: {
        position: 'bottom'
      },
      scales: this.scales,
      responsive: true,
      display: true,
      maintainAspectRatio: false,
      onAnimationComplete: function() {}
    };

    // Populating the dataset with values
    if(this.ready)
      this.fillValues();

  }

  ngAfterViewInit() {

    this.canvas = document.getElementById(this.elementId);
    this.ctx = this.canvas.getContext('2d');
    this.lineChart = new Chart(this.ctx, {
      type: 'line',
      data: {
        labels: this.labels,
        datasets: this.datasets
      },
      options: this.options
    });

  }

  ngOnChanges(changes) {

    if(this.dataY1 !== undefined)
    for(let i=0; i < this.dataY1.length; i++) {
      if(this.dataY1[i].originalData[0].length == 0) {
        this.ready = false;
        this._dataAnalysisService.getTagValues(this.dataY1[i].id, this.dataY1[i].countryId, this.dataY1[i].cityId, this.dataY1[i].plantId).subscribe(
          data => {
            if(data["data"] && data["data"].country.city.plant.tags[0] === undefined) {
              return;
            }

            //Storing the original values for range manipulation later, and adding values based on current dateRange
            this.dataY1[i]["originalData"] = [[], []];
            let length = data["data"].country.city.plant.tags[0].plots.plotValue.length;
            // this.dataY1[i]["originalData"][0] = data["data"].country.city.plant.tags[0].plots.plotValue;
            /**
             * Experimental code for testing gaps with null values
             */

            var currentDayStart = data["data"].country.city.plant.tags[0].plots.onDate.findIndex(date => {
              return this.today === (this.pipe.transform(date, 'dd/MMM/yy'));
            })
            this.dataY1[i]["originalData"][0] = [];
            var sum = 0;
            var count = 0;
            for(let q = currentDayStart; q < length; q++) {
              let v = data["data"].country.city.plant.tags[0].plots.plotValue[q];
              if(v === null) continue;

              sum += v;
              count += 1;
            }

            var average = count > 0 ? sum / count : null;

            this.dataY1[i]["originalData"][0] = data["data"].country.city.plant.tags[0].plots.plotValue.slice(0, currentDayStart);
            // The slice function in the above line will NOT include the currentDayStart value
            this.dataY1[i]["originalData"][0].push(average);

            /**
             * Setting the raw data (detailed transaction values) for the tag
             */

            this.dataY1[i]["rawData"][0] = data["data"].country.city.plant.tags[0].plots.plotValue.slice(currentDayStart);
            this.dataY1[i]["rawData"][1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(currentDayStart);
            /**
             * Experimental code ends here
             */
            this.dataY1[i]["originalData"][1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(0, currentDayStart + 1);
            // In above line, 1 more than currentDayStart to include that date as well


            let startingIndex;
            let endingIndex;
            if(this.datesMethod === 'dropdown' || this.datesMethod === undefined) {
              if(this.range === undefined) this.range = 7;
              startingIndex = currentDayStart + 1 < this.range ? 0 : currentDayStart + 1 - this.range; // Setting the startIndex to 0 if dateRange > number of values present
              endingIndex = currentDayStart + 1;
            } else if(this.datesMethod === 'range') {
                startingIndex = data["data"].country.city.plant.tags[0].plots.onDate.findIndex( date => {
                  return this.pipe.transform(date, 'dd/MMM/yy') === this.startDate
                })
                if(startingIndex < 0) startingIndex = 0;

                endingIndex = data["data"].country.city.plant.tags[0].plots.onDate.findIndex( date => {
                  return this.pipe.transform(date, 'dd/MMM/yy') === this.endDate
                })
                if(endingIndex < 0) endingIndex = currentDayStart + 1;
                else endingIndex += 1; // end Date has to be inclusive
            }

            if( (this.datesMethod === 'dropdown' && this.range === 1) || (this.datesMethod === 'range' && (this.startDate && ( this.startDate === this.today.toString())) ) ) {
              this.dataY1[i].data[0] = data["data"].country.city.plant.tags[0].plots.plotValue.slice(currentDayStart);
              this.dataY1[i].data[1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(currentDayStart);
            } else {
              this.dataY1[i].data[0] = data["data"].country.city.plant.tags[0].plots.plotValue.slice(startingIndex, endingIndex);
              this.dataY1[i].data[1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(0, currentDayStart + 1);
            }

            // this.dataY1[i].data[1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(0, currentDayStart + 1);


            //Checking if the labels have not been populated yet
            if(this.labels === undefined || this.labels.length === 0 || this.allLabels.length < data["data"].country.city.plant.tags[0].plots.onDate.length) {
              this.allLabels.length = 0;
              this.labels.length = 0;

              // Setting the labels for the x-axis
              for(let p=0; p < data["data"].country.city.plant.tags[0].plots.onDate.length && p < currentDayStart + 1; p++) {
                this.allLabels.push(this.pipe.transform(data["data"].country.city.plant.tags[0].plots.onDate[p], 'dd/MMM/yy'))
                // if(((this.datesMethod === 'range') && (this.startDate !== this.endDate)) || ((this.datesMethod === 'dropdown') && (this.range !== 1))) {
                  // this.labels.push(this.allLabels[p]);
                // }
              };

              // Setting the labels for the raw data
              this.rawDataLabels = [];
              for(let p = currentDayStart; p < data["data"].country.city.plant.tags[0].plots.onDate.length; p++) {
                this.rawDataLabels.push(this.pipe.transform(data["data"].country.city.plant.tags[0].plots.onDate[p], 'dd/MMM/yy h:mm aa'))
              }

              // Setting the limits for the max and min date
              this.minDate = this.pipe.transform(data["data"].country.city.plant.tags[0].plots.onDate[0], 'dd-mm-yyyy');
              this.maxDate = this.pipe.transform(data["data"].country.city.plant.tags[0].plots.onDate[-1], 'dd-mm-yyyy');

              // Setting range depending upon the type of date selection
              if(this.datesMethod === 'dropdown' || this.datesMethod === undefined) {
                if(this.range === undefined) this.range = 7;
                this.updateRange(this.range);
              } else if(this.datesMethod === 'range') {
                this.setDateRange(this.startDate, this.endDate);
              }
            }
            this.ready = true;
            this.updateValues();
          }
        )
      } else {
        //Do something here, if required, for tags that already have data
      }
    }
    if(this.dataY2 !== undefined)
    for(let i=0; i < this.dataY2.length; i++) {
      if(this.dataY2[i].originalData[0].length == 0) {
        this.ready = false;
        this._dataAnalysisService.getTagValues(this.dataY2[i].id, this.dataY2[i].countryId, this.dataY2[i].cityId, this.dataY2[i].plantId).subscribe(
          data => {
            if(data["data"].country.city.plant.tags[0] === undefined) {
              return;
            }

            //Storing the original values for range manipulation later, and adding values based on current dateRange
            this.dataY2[i]["originalData"] = [[], []];
            // this.dataY2[i]["originalData"][0] = data["data"].country.city.plant.tags[0].plots.plotValue;

            let length = data["data"].country.city.plant.tags[0].plots.plotValue.length;
            var currentDayStart = data["data"].country.city.plant.tags[0].plots.onDate.findIndex(date => {
              return this.today === (this.pipe.transform(date, 'dd/MMM/yy'));
            })
            this.dataY2[i]["originalData"][0] = [];
            var sum = 0;
            var count = 0;
            for(let q = currentDayStart; q < length; q++) {
              let v = data["data"].country.city.plant.tags[0].plots.plotValue[q];
              if(v === null) continue;

              sum += v;
              count += 1;
            }
            var average = count > 0 ? sum / count : null;

            this.dataY2[i]["originalData"][0] = data["data"].country.city.plant.tags[0].plots.plotValue.slice(0, currentDayStart);
            // The slice function in the above line will NOT include the currentDayStart value
            this.dataY2[i]["originalData"][0].push(average);

            /**
             * Setting the raw data (detailed transaction values) for the tag
             */

            this.dataY2[i]["rawData"][0] = data["data"].country.city.plant.tags[0].plots.plotValue.slice(currentDayStart);
            this.dataY2[i]["rawData"][1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(currentDayStart);
            /**
             * Experimental code ends here
             */
            this.dataY2[i]["originalData"][1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(0, currentDayStart + 1);
            // In above line, 1 more than currentDayStart to include that date as well


            let startingIndex;
            let endingIndex;
            if(this.datesMethod === 'dropdown' || this.datesMethod === undefined) {
              if(this.range === undefined) this.range = 7;
              startingIndex = currentDayStart + 1 < this.range ? 0 : currentDayStart + 1 - this.range; // Setting the startIndex to 0 if dateRange > number of values present
              endingIndex = currentDayStart + 1;
            } else if(this.datesMethod === 'range') {
                startingIndex = data["data"].country.city.plant.tags[0].plots.onDate.findIndex( date => {
                  return this.pipe.transform(date, 'dd/MMM/yy') === this.startDate
                })
                if(startingIndex < 0) startingIndex = 0;

                endingIndex = data["data"].country.city.plant.tags[0].plots.onDate.findIndex( date => {
                  return this.pipe.transform(date, 'dd/MMM/yy') === this.endDate
                })
                if(endingIndex < 0) endingIndex = currentDayStart + 1;
                else endingIndex += 1; // end Date has to be inclusive
            }


            if( (this.datesMethod === 'dropdown' && this.range === 1) || (this.datesMethod === 'range' && (this.startDate && ( this.startDate === this.today.toString())) ) ) {
              this.dataY2[i].data[0] = data["data"].country.city.plant.tags[0].plots.plotValue.slice(currentDayStart);
              this.dataY2[i].data[1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(currentDayStart);
            } else {
              this.dataY2[i].data[0] = data["data"].country.city.plant.tags[0].plots.plotValue.slice(startingIndex, endingIndex);
              this.dataY2[i].data[1] = data["data"].country.city.plant.tags[0].plots.onDate.slice(0, currentDayStart + 1);
            }

            this.dataY2[i].data[1] = data["data"].country.city.plant.tags[0].plots.onDate;
            //Checking if the labels have not been populated yet
            if(this.labels === undefined || this.labels.length === 0 || this.allLabels.length < data["data"].country.city.plant.tags[0].plots.onDate.length) {
              this.allLabels.length = 0;
              this.labels.length = 0;

              // Setting the labels for the x-axis
              for(let p=0; p < data["data"].country.city.plant.tags[0].plots.onDate.length && p < currentDayStart + 1; p++) {
                this.allLabels.push(this.pipe.transform(data["data"].country.city.plant.tags[0].plots.onDate[p], 'dd/MMM/yy'))
                // this.labels.push(this.allLabels[p]);
              };

              // Setting the labels for the raw data
              this.rawDataLabels = [];
              for(let p = currentDayStart; p < data["data"].country.city.plant.tags[0].plots.onDate.length; p++) {
                this.rawDataLabels.push(this.pipe.transform(data["data"].country.city.plant.tags[0].plots.onDate[p], 'dd/MMM/yy h:mm aa'))
              }

              // Setting the limits for the max and min date
              this.minDate = this.pipe.transform(data["data"].country.city.plant.tags[0].plots.onDate[0], 'dd-mm-yyyy');
              this.maxDate = this.pipe.transform(data["data"].country.city.plant.tags[0].plots.onDate[-1], 'dd-mm-yyyy');

              // Setting range depending upon the type of date selection
              if(this.datesMethod === 'dropdown' || this.datesMethod === undefined) {
                if(this.range === undefined) this.range = 7;
                this.updateRange(this.range);
              } else if(this.datesMethod === 'range') {
                this.setDateRange(this.startDate, this.endDate);
              }
            }
            this.ready = true;
            this.updateValues();
          }
        )
      } else {
        // this.updateRange(this.range);
      }
    }

    // Updating the graph on any changes in the labels
    if(changes && changes.labels && !changes.labels.firstChange) {
      this.lineChart.data.labels = this.labels;
      this.updateValues();
      this.lineChart.update();
    }

    // Updating the graph on any changes in the data

    if( changes && changes.dataY1 ) {
      if( changes.dataY1.firstChange ) return;
      this.updateValues();
    }

    if( changes && changes.dataY2 ) {
      if( changes.dataY2.firstChange ) return;
      this.updateValues();

    }
  }

  fillValues() {

    //Mapping the Y1 dataset values to the Y1 axis
    if(this.dataY1 !== undefined)
    for(let i = 0; i < this.dataY1.length; i++) {

      // Creating one data group
      this.values = {
        label: this.dataY1[i].label, // The label / title / name for the dataset,
        data: this.dataY1[i].data[0], // The values of the dataset,
        yAxisID: 'left', // The axis to be on
        fill: false,
        backgroundColor: this.dataY1[i].color ? this.dataY1[i].color : this.colors[(this.colorIndex) % 10],
        borderColor: this.dataY1[i].color ? this.dataY1[i].color : this.colors[(this.colorIndex++) % 10],
        pointHitRadius: 20,
        borderWidth: this.dataY1[i].dotted ? 1 : 2,
        borderDash: this.dataY1[i].dotted ? [10, 6] : [],
        radius: this.dataY1[i].dotted && !this.dataY1[i].isPrediction ? 0 : 2
      };

      // Assigning the color to the tag if it already didn't have it
      this.dataY1[i]["color"] = this.values["backgroundColor"];
      // this.colorIndex = (this.colorIndex + 1) % 10;

      // Insert this data into the chart dataset
      this.datasets.push(this.values);

      // Resetting "values". Not required as it will be written over, but making sure doing manually
      this.values = {};
    }

    //Mapping the Y2 dataset values to the Y2 axis
    if(this.dataY2 !== undefined)
    for(let i = 0; i < this.dataY2.length; i++) {

      // Creating one data group
      this.values = {
        label: this.dataY2[i].label, // The label / title / name for the dataset,
        data: this.dataY2[i].data[0], // The values of the dataset,
        yAxisID: 'right', // The axis to be on
        fill: false,
        backgroundColor: this.dataY2[i].color ? this.dataY2[i].color : this.colors[(this.colorIndex) % 10],
        borderColor: this.dataY2[i].color ? this.dataY2[i].color : this.colors[(this.colorIndex++) % 10],
        pointHitRadius: 20,
        borderWidth: this.dataY2[i].dotted ? 1 : 2,
        borderDash: this.dataY2[i].dotted ? [10, 6] : [],
        radius: this.dataY2[i].dotted && !this.dataY2[i].isPrediction ? 0 : 2
      };

      // Assigning the color to the tag if it already didn't have it
      this.dataY2[i]["color"] = this.values["backgroundColor"];
      // this.colorIndex = (this.colorIndex + 1) % 10;
      // Insert this data into the chart dataset
      this.datasets.push(this.values);

      // Resetting "values". Not required as it will be written over, but making sure doing manually
      this.values = {};
    }
  }

  updateValues() {
    this.datasets = [];
    this.fillValues();
    this.lineChart.data.datasets = this.datasets;
    this.lineChart.data.labels = this.labels;
    this.lineChart.update();
  }

  downloadChart(fileName: string) {

    // This code is to set the white background to the exported graph
    var tempCanvas = document.createElement('canvas');
    tempCanvas.id = "tempCanvas";
    var tempCtx = tempCanvas.getContext('2d');
    tempCanvas.width = this.ctx.canvas.width;
    tempCanvas.height = this.ctx.canvas.height;
    tempCtx.fillStyle = 'white';
    tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
    tempCtx.drawImage(this.canvas, 0, 0);
    var img = new Image();
    img.src = tempCanvas.toDataURL();
    img.id = "tempImage";

    // converts chart to image
    var image = tempCanvas.toDataURL("image/jpeg", 1.0);

    // creates a new pdf
    var doc = new jsPDF('landscape');
    html2canvas(this.canvas, {
      height: 720,
      width: 1280,
      scale: 3
    }).then(canvas => {
      var imgFile = canvas;
      // doc.addImage(imgFile, "JPEG", 10, 10, 200, 150);
      doc.addImage(imgFile, "JPEG", 10, 10, 350, 250); // PLEASE NOTE: The exported graph in IE will be a little lesser in width than its Chrome counterpart
      doc.save(fileName + '.pdf')

      /**
       * Saving the audit trail
       */
      this.saveAuditTrail('graph');

    });
    // doc.setFillColor(240); // Setting value for background in grayscale
    // doc.rect(0, 0, 400, 400, "F");
    // doc.addImage(image, 'JPEG', 10, 10, 280, 150);
    // doc.save(fileName + '.pdf');
  }

  saveAuditTrail(action: string) {
    const trailData = {
      'plantId' : this.plantId
    };
    this._dataAnalysisService.saveAuditTrail(trailData, action).subscribe(
      data => {}
    );
  }

  //Funcion to update range for data Analysis and graph plot
  updateRange(range) {
    this.labels = [];
    this.labels.length = 0;

    /**
     * This is the code for showing the detailed values when the date range is set to 1 day
     * Could be merged with the code in the else part, but for clarity, and later debugging, both the cases are written separate
     */
    if(range === 1) {
      let count = this.rawDataLabels.length;

      for(let i = 0; i < this.rawDataLabels.length; i++) {
        this.labels.push(this.rawDataLabels[i]);
      }
    } else {
      let count = this.allLabels.length;
      let startingIndex = count - range;
      if(startingIndex < 0) {
        startingIndex = 0;
      }
      for(let i = 0; i < this.allLabels.length && i < range; i++) {
        this.labels.push(this.allLabels[i + startingIndex]);
      }
    }
  }

  exportToExcel(fileName: string) {
    var data = this.prepareToExport(this.dataY1, this.dataY2);
    this._excelService.exportAsExcelFile(data, fileName);
    this.saveAuditTrail('data');
  }

  setDateRange(startDate, endDate) {

    /**
     * If the user chooses the dates with more than one year gap, then doesn't correct it and tries to plot a
     * new tag, it should still not allow to do so
     */


    if(moment(this.endDate, "DD/MMM/YY").diff(moment(this.startDate, "DD/MMM/YY"), 'days') > 364 ) {
    /**
     * Commented this code because it was already showing one pop-up in DA page
    */
      // this.errorService.showerror({
      //   status: "Invalid.",
      //   statusText: "Please select dates within 1 year."
      // });
      return;
    }

    /**
     *  1 year restriction code ends
     */

    this.labels = [];
    this.labels.length = 0;
    let startingIndex;
    let endingIndex;

    if(startDate == undefined) {
      startingIndex = 0;
    } else {
      startingIndex = this.allLabels.findIndex( date => {
        return date === startDate;
      })
      if(startingIndex < 0) {
        startingIndex = 0;
      }
    }
    if(endDate == undefined) {
      endingIndex = this.allLabels.length;
    } else {
      endingIndex = this.allLabels.findIndex( date => {
        return date === endDate;
      })
      if(endingIndex < 0) {
        endingIndex = this.allLabels.length;
      } else endingIndex += 1; // This is because the end date has inclusive
    }

    /**
     * For 1-day Date range
     */
    if((startingIndex === this.allLabels.length - 1) && (endingIndex === this.allLabels.length)) {
      for(let i = 0; i < this.rawDataLabels.length; i++) {
        this.labels.push(this.rawDataLabels[i]);
      }
    } else {

      /**
       * For Date range > 1 day
       */
      for(let i = startingIndex; i < this.allLabels.length && i < endingIndex; i++) {
        this.labels.push(this.allLabels[i]);
      }
    }
  }

  prepareToExport(data1, data2) {
    var data = data1.concat(data2);
    var exportData = this.flattenData(data);
    return exportData;
  }

  flattenData(data) {
    var flatData = [];
    let startingDateIndex, endingDateIndex;
    if(this.datesMethod === 'range') {
      if(this.startDate !== undefined) {
        startingDateIndex = this.allLabels.findIndex( date => {
          return date === this.startDate;
        })
      } else {
        startingDateIndex = 0;
      }

      if(this.endDate !== undefined) {
        endingDateIndex = this.allLabels.findIndex(date => {
          return date === this.endDate;
        })
      } else {
        endingDateIndex =  this.allLabels.length;
      }
    } else if(this.datesMethod === 'dropdown') {
      endingDateIndex = this.allLabels.length;
      startingDateIndex = endingDateIndex - this.range;
    }

    if(startingDateIndex < 0) startingDateIndex = 0;
    if(endingDateIndex < 0 || !endingDateIndex) {
      endingDateIndex = this.allLabels.length;
    } else if(endingDateIndex !== this.allLabels.length){
      endingDateIndex += 1; // To include the last selected day as well
    }

    /**
     *  Code to export the raw data when the Date Range is 1 day
     */

    if( (this.datesMethod === 'dropdown' && this.range === 1) || (this.datesMethod === 'range' && (this.startDate && ( this.startDate === this.today.toString())) ) ) {

      for(let i = 0; i < this.rawDataLabels.length; i++) {
        let date = this.rawDataLabels[i];
        let d = {
          "S.No": i + 1,
          "Date" : date
        };
        // Entering key-values for all elements
        data.forEach(element => {
          let type = element.label;
          // If element is a trend box element, ignore it
          if(type.substring(type.length - 5) === 'trend'){
            return;
          }
          let index = -1;
          if(element.rawData !== undefined){ // If the element does not have data, insert n/a
            index = element.rawData[1].findIndex(dt => {
              return this.pipe.transform(dt, 'dd/MMM/yy h:mm aa') === date
            })
          }
          if(index === -1)
            d[type] = "";
          else d[type] = element.rawData[0][index];

        });
        flatData.push(d);
      }
    } else {
      for(let i = startingDateIndex; i < endingDateIndex; i++) {
        let date = this.allLabels[i];
        let d = {
          "S.No": i - startingDateIndex + 1,
          "Date" : date
        };
        // Entering key-values for all elements
        data.forEach(element => {
          let type = element.label;
          // If element is a trend box element, ignore it
          if(type.substring(type.length - 5) === 'trend'){
            return;
          }
          let index = -1;
          if(element.originalData !== undefined){ // If the element does not have data, insert n/a
            index = element.originalData[1].findIndex(dt => {
              return this.pipe.transform(dt, 'dd/MMM/yy') === date
            })
          }
          if(index === -1)
            d[type] = "";
          else d[type] = element.originalData[0][index];

        });
        flatData.push(d);
      }
    }
    return flatData;
  }

}
