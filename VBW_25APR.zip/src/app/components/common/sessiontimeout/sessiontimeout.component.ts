import { Component, Inject, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-sessiontimeout',
  template: `
  <h2 mat-dialog-title class="customdialog-title">{{"data.L00644" | translate | titlecase }}</h2>
  <div mat-dialog-content class="customdialog-content">
   <p> {{"data.L00645" | translate}}
   {{(countMinutes !== 0 ? + countMinutes+' Minutes'+(countMinutes > 1 ? 's ' : ' ') : '') + countSeconds+' Seconds'}}</p>
  </div>
  <div mat-dialog-actions class="customdialog-actions">
    <button mat-button (click)="continue()"
    class="customdialog-cancelbtn">{{ "data.L00643" | translate | uppercase }}</button>
    <button (click)="logout()" mat-button
    cdkFocusInitial class="customdialog-primarybtn">{{ "data.L00076" | translate | uppercase }}</button>
  </div>
  `,
  styleUrls: ['../dialog/dialog.component.css']
})
export class SessiontimeComponent {

  @Input() countMinutes: number;
  @Input() countSeconds: number;
  @Input() progressCount: number;

  @Output() logoutcallback = new EventEmitter<any>(true);
  @Output() continuecallback = new EventEmitter<any>(true);

  constructor(public dialogRef: MatDialogRef<SessiontimeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  continue() {
    this.continuecallback.emit({});
  }
  logout() {
    this.logoutcallback.emit({});
  }
  closeDialog(): void {
    this.dialogRef.close();
  }
}
