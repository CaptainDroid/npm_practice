import { Component, Inject, OnInit, EventEmitter, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent {

  constructor(
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  @Output() okCallback = new EventEmitter<any>(true);
  @Output() cancelCallback = new EventEmitter<any>(true);

  closeDialog(): void {
      this.dialogRef.close();
  }
  cancel() {
    this.dialogRef.close();
    this.cancelCallback.emit(this.data);
  }
  submit() {
    this.okCallback.emit(this.data);
  }

}
