import { Component, AfterViewChecked, OnInit } from '@angular/core';
import { DashboardService } from '../../services/dashboard.service';
import { PlantdataService } from '../../services/plantdata.service';
import { CitydataService } from '../../services/citydata.service';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import {ErrorserviceService} from '../../services/errorservice.service';
import { CommonService } from '../../services/common.service';
import { DialogComponent } from '../common/dialog/dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Subscription } from 'rxjs';

export class Plant {
  global: Array<Object>;
  local: Array<Object>;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  dashboardData;
  globalData: any;
  countryData: any;
  subscriptions:Subscription[] = [];
  pageaccess = environment.pageaccess.home;
  dashboardaccess = environment.role.dashboard.view;
  isEventsRestricted = false;

  constructor(
    private _dashboardService: DashboardService,
    public errorservice: ErrorserviceService,
    public commonservice: CommonService,
    public dialog: MatDialog,
    private router: Router) {
      const isRestrictDashboard = this.commonservice.isAccess(this.dashboardaccess);
      let userInfo = this.commonservice.getUser();
      userInfo = userInfo.prn.toLowerCase();
      userInfo = userInfo.replace(/\s/g, '');
      if (isRestrictDashboard === true) {
        const navUrl = environment.landingnav[userInfo];
        if (navUrl) {
          this.router.navigate([navUrl]);
        }
      }
      if (this.pageaccess.dashboard === true && isRestrictDashboard === false ) {
        this.getDataboard();
      }
      this.isEventsRestricted = this.commonservice.isAccess(environment.role.alertevents.events);
     }

  ngOnInit() { }

  getDataboard() {
    this.subscriptions.push(this._dashboardService.getDashboardData().subscribe(
      data => {
        if (data.status !== 'success') {
          this.errorservice.showerror({status: data.errorCode, statusText: data.message});
        }
        this.dashboardData = data;
        this._dashboardService.dashboardData = this.dashboardData;
        this.globalData = this.dashboardData.global.data;
        this.countryData = this.dashboardData.global.countries;
      }
    ));
  }

  openCityView(countryId: any): void {
    countryId = 'cityView/' + countryId + '/city';
    this.router.navigate([countryId]);
  }

  viewEvents() {
    if (this.isEventsRestricted === false) {
      this.router.navigate(['/view-all-events-categories']);
      return;
    } else {
      const dialogRef = this.dialog.open(DialogComponent, {
        width: '400px',
        disableClose: true,
        data: {title: 'data.L00224', message: 'data.L00835' }
      });
      this.subscriptions.push(dialogRef.componentInstance.okCallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
      }));
    }
  }
  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
}

}
