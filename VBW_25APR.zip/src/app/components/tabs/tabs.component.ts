import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css']
})
export class TabsComponent {

  tabs: Tab[] = [];

  constructor() { }

  ngOnInit() {
  }

  selectTab(tab: Tab) {
    this.tabs.forEach((tab) => {
      tab.active = false;
    })
    tab.active = true;
  }

  addTab(tab: Tab) {
    if(this.tabs.length === 0) {
      tab.active = true;
    }
    this.tabs.push(tab);
  }

}

@Component({
  selector: 'tab',
  templateUrl: './tab.component.html',
  styleUrls: ['./tab.component.css']
})
export class Tab {
  @Input() tabTitle: string;
  @Input() color: string;
  active: boolean;

  constructor(tabs: TabsComponent) {
    tabs.addTab(this);
  }

}