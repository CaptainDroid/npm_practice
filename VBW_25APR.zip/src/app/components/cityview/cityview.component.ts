import { Component, HostBinding, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DashboardService } from '../../services/dashboard.service';
import { Location } from '@angular/common';
import { environment } from '../../../environments/environment';
import { CommonService } from '../../services/common.service';
import { DialogComponent } from '../common/dialog/dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-cityview',
  templateUrl: './cityview.component.html',
  styleUrls: ['./cityview.component.css']
})

export class CityviewComponent implements OnInit {

  public dashboardData;
  public country: any;
  public countryName: any;
  public cityData: any;
  public url: any[];
  isEventsRestricted = false;

  constructor(private router: Router,
    private _dashboardService: DashboardService,
    public commonservice: CommonService,
    public dialog: MatDialog,
    private location: Location) {
      this.isEventsRestricted = this.commonservice.isAccess(environment.role.alertevents.events);
    }

  ngOnInit() {

    // Getting the selected country
    this.country = this.router.url;
    this.url = this.country.split('/');
    this.country = this.url[this.url.length - 2];

    // Getting the data for the dashboard
    this.dashboardData = this._dashboardService.dashboardData;
    if(this.dashboardData === undefined) { // To minimise server requests
      this._dashboardService.getDashboardData().subscribe(
        data => {
          this.dashboardData = data;
          this.setCountryData(this.country);
        }
      );
    } else {
      this.setCountryData(this.country);
    }
  }

  setCountryData(countryId): void {
    this.cityData = this.dashboardData.global.countries.filter(
      function( country ) {
        // tslint:disable-next-line:triple-equals
        return country.countryId == countryId;
      }
    );
    this.countryName = this.cityData[0].countryName.toUpperCase();
    this.cityData = this.cityData[0].cities;
  }

  openPlantView(cityId : any) : void {
    cityId = 'plantView/' + '/' + this.country + '/' + cityId + '/plant';
    this.router.navigate([cityId]);
  }

  goBack(country: string) {
    // country = '/cityView/' + country + '/city';
    this.router.navigate(['/']);
  }

  viewEvents() {
    if (this.isEventsRestricted === false) {
      this.router.navigate(['/view-all-events-categories']);
      return;
    } else {
      const dialogRef = this.dialog.open(DialogComponent, {
        width: '400px',
        disableClose: true,
        data: {title: 'data.L00224', message: 'data.L00835' }
      });
      const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
      });
    }
  }

}
