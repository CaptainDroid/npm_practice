import { Component, Inject, OnInit, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { OpsassignSetupwsService } from '../../../../services/opsassign-setupws.service';
import { CommonService } from '../../../../services/common.service';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { Router, ActivatedRoute } from '@angular/router';
import { OpsmeasurementService } from '../../../../services/opsmeasurement.service';

@Component({
  selector: 'app-assignopsmi',
  templateUrl: './assignopsmi.component.html',
  styleUrls: ['./assignopsmi.component.css']
})
export class AssignopsmiComponent implements OnInit {

  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  locationList: any;
  locationsResponse: any;
  assignopsmiList: any;
  assignopsmiResponse: any;

  headers: any;
  saveassignopsResponse: any;
  opsMeasurementDataResponse: any;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    private opsassignsetupwsservice: OpsassignSetupwsService,
    private commonservice: CommonService,
    public opsmeasurementservice: OpsmeasurementService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog, @Inject(DOCUMENT) document
  ) { }

  ngOnInit() {
    this.plants = [];
    this.getplants();
  }

  getplants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (this.plants.length > 0) {
            this.selectedPlant = this.plants[0].id;
            this.getmeasurements(this.plants[0].id);
            this.getlocations(this.plants[0].id);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  selectplant(plantid: any) {
    this.getmeasurements(plantid);
  }

  getlocations(plantId: any) {
    this.locationList = [];
    this.opsassignsetupwsservice.getOpsLocationList(plantId).subscribe(
      data => {
        this.locationsResponse = data;
        if (this.locationsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.locationsResponse.status, statusText: this.locationsResponse.message });
        } else {
          this.locationList = this.locationsResponse.data.opsLocations;
          if (this.locationList.length > 0 ) {
            this.headers.forEach(head => {
              this.locationList.forEach(location => {
                head.locations[location.opsLocationId] = false;
                const editenabledkey = 'enable_' + location.locationId;
                head.locations[editenabledkey] = true;
              });
            });
            this.getlocationitemsbyplantid(plantId);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getmeasurements(plantId: any) {
    this.headers = [];
    this.assignopsmiList = [];
    this.locationList = [];
    this.opsmeasurementservice.getMeasurements().subscribe(
      data => {
        this.opsMeasurementDataResponse = data;
        if (this.opsMeasurementDataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.opsMeasurementDataResponse.status,
            statusText: this.opsMeasurementDataResponse.message });
        } else {
            if (this.opsMeasurementDataResponse.data.opsMItems !== null &&
              this.opsMeasurementDataResponse.data.opsMItems !== '') {
                this.opsMeasurementDataResponse.data.opsMItems.forEach(opsmeasuremet => {
                  const opsmsobj = {
                    'opsMSItemId' : opsmeasuremet.opsMsitemId,
                    'opsMSItemName': opsmeasuremet.opsMsitemName,
                    'locations': {}
                  };
                  this.headers.push(opsmsobj);
                });
              if (this.headers.length > 0) {
                this.getlocations(plantId);
              }
            }
        }
      }
    );
  }

  getlocationitemsbyplantid(plantid: any) {
    this.assignopsmiList = [];
    this.opsassignsetupwsservice.getLocationItemsByPlantId(plantid).subscribe(
      data => {
        this.assignopsmiResponse = data;
        if (this.assignopsmiResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.assignopsmiResponse.status, statusText: this.assignopsmiResponse.message });
        } else {
          this.assignopsmiResponse.data.forEach(mitems => {
            this.assignopsmiList.push(mitems);
          });

          this.assignopsmiList.forEach(mitems => {
            mitems.miassoc.forEach(assocdata => {
                let checkedbox = false;
                if (assocdata.checked === true) {
                  checkedbox = true;
                }
                const headCol = this.headers.filter(head => {
                  return head.opsMSItemId === assocdata.opsMSItemId;
                });
                if (headCol.length > 0) {
                    headCol[0].locations[mitems.locationId] = checkedbox;
                    const editenabledkey = 'enable_' + mitems.locationId;
                    headCol[0].locations[editenabledkey] = assocdata.editEnabled;
                }
            });
          });
        }
      }
    );
  }

  cancelAssignment() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: { type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.getlocationitemsbyplantid(this.selectedPlant);
    });
  }

  saveAssignment() {
    const reqObj = this.preparereq();
    reqObj.plantId = this.selectedPlant;
    reqObj.locationmeasurementitems = [];
    this.locationList.forEach(location => {
      const measurementsCollection = [];
      this.headers.forEach(head => {
        if (head.locations[location.opsLocationId] === true) {
          if (measurementsCollection.indexOf(head.opsMSItemId) < 0) {
            measurementsCollection.push(head.opsMSItemId);
          }
        }
      });
      if (measurementsCollection.length > 0) {
        const locobj = {
          'locationid': location.opsLocationId,
          'measurementitems': measurementsCollection
        };
        reqObj.locationmeasurementitems.push(locobj);
      }
    });

    this.opsassignsetupwsservice.assignopsomi(reqObj).subscribe(
      data => {
        this.saveassignopsResponse = data;
        if (this.saveassignopsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.saveassignopsResponse.status, statusText: this.saveassignopsResponse.message });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            disableClose: true,
            data: { title: 'data.L00224', message: 'data.L01161' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  preparereq() {
    const reqObj = {
      'plantId': 0,
      'locationmeasurementitems': [
        {
          'locationid': 0,
          'measurementitems': [
            0
          ]
        }
      ]
    };
    return reqObj;
  }

}
