import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpsmeasurementComponent } from './opsmeasurement.component';

describe('OpsmeasurementComponent', () => {
  let component: OpsmeasurementComponent;
  let fixture: ComponentFixture<OpsmeasurementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpsmeasurementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpsmeasurementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
