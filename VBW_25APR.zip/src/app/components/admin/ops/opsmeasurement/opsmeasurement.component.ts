import { Component, Inject, OnInit, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { OpsmeasurementService } from '../../../../services/opsmeasurement.service';
import { CommonService } from 'src/app/services/common.service';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { Router, ActivatedRoute } from '@angular/router';
import { ItemnameFilterPipe } from 'src/app/pipes/itemnamefilter.pipe';

@Component({
  selector: 'app-opsmeasurement',
  templateUrl: './opsmeasurement.component.html',
  styleUrls: ['./opsmeasurement.component.css']
})
export class OpsmeasurementComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['acronym', 'opsMsitemName', 'descriptionen', 'descriptioncn', 'uomdesc', 'opsitemtype', 'action'];
  dataSource: any;
  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  opsMeasurementList: any;
  opsMeasurementFinalList: any;
  opsMeasurementResponse: any;
  selectedPlantObj: any;
  searchValue: any;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    private opsmeasurementservice: OpsmeasurementService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    this.plants = [];
    this.opsMeasurementList = [];
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.getplants(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.getplants(this.selectedPlant);
      }
    });
  }

  getplants(plantId: any) {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (plantId === 0) {
            this.opsMeasurementList = [];
            this.selectedPlant = 0;
            this.getopsmeasurements(this.plants[0]);
          } else {
              const plantobj = this.plants.filter(plnt => {
              return plnt.id === plantId;
            });
           // this.selectedPlantObj = plantobj[0];
            this.selectedPlant = plantId;
            this.getmeasurementsbyplantid(this.selectedPlant);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getopsmeasurements(plantobj) {
    this.searchValue = '';
    this.opsMeasurementList = [];
    this.opsmeasurementservice.getMeasurements().subscribe (
      data => {
        this.opsMeasurementResponse = data;
        if (this.opsMeasurementResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.opsMeasurementResponse.status, statusText: this.opsMeasurementResponse.message });
        } else {
          this.opsMeasurementResponse.data.opsMItems.forEach(mitems => {
            const obj = {
              'opsMsitemId': mitems.opsMsitemId,
              'opsMsitemName': mitems.opsMsitemName,
              'paramId': mitems.paramId,
              'paramVal' : mitems.paramVal,
              'assocPlantId': '',
              'acronym' : '',
              'uomId' : '',
              'uomdesc' : '',
              'minValue' : '',
              'maxValue' : '',
              'descriptionen': mitems.description.en,
              'descriptioncn': mitems.description.cn
            };
            mitems.opsMIPlantAssoc.forEach(assocdata => {
              obj.assocPlantId = assocdata.plantId;
              obj.acronym = assocdata.acronym;
              obj.uomId = assocdata.uomId;
              obj.uomdesc = assocdata.uomdesc;
              obj.minValue = assocdata.minValue;
              obj.maxValue = assocdata.maxValue;
            });
            this.opsMeasurementList.push(obj);
          });
          this.sortOMITable();
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.opsMeasurementList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.opsMsitemName.toLowerCase().includes(filter) ||
            data.acronym.toString().toLowerCase().includes(filter) ||
            (data.uomdesc !== null ? data.uomdesc.toString().toLowerCase().includes(filter) : null) ||
            (data.descriptionen !== null ? data.descriptionen.toString().toLowerCase().includes(filter) : null) ||
            (data.descriptioncn !== null ? data.descriptioncn.toString().toLowerCase().includes(filter) : null) ||
            (data.uomdesc !== null ? data.uomdesc.toString().toLowerCase().includes(filter) : null) ||
            (data.paramVal !== null ? data.paramVal.toString().toLowerCase().includes(filter) : null);
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  selectplant(plantid: any) {
    // this.selectedPlantObj = plantObj;
    if (plantid === 0) {
      this.getopsmeasurements(plantid);
    } else {
      this.getmeasurementsbyplantid(plantid);
    }
  }

  getmeasurementsbyplantid(plantid) {
    this.searchValue = '';
    this.opsMeasurementList = [];
    this.opsmeasurementservice.getMeasurementsByPlant(plantid).subscribe(
      data => {
        this.opsMeasurementResponse = data;
        if (this.opsMeasurementResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.opsMeasurementResponse.status, statusText: this.opsMeasurementResponse.message });
        } else {
          this.opsMeasurementResponse.data.opsMItems.forEach(mitems => {
            const obj = {
              'opsMsitemId': mitems.opsMsitemId,
              'opsMsitemName': mitems.opsMsitemName,
              'paramId': mitems.paramId,
              'paramVal' : mitems.paramVal,
              'assocPlantId': '',
              'acronym' : '',
              'uomId' : '',
              'uomdesc' : '',
              'minValue' : '',
              'maxValue' : '',
              'descriptionen': mitems.description.en,
              'descriptioncn': mitems.description.cn
            };
            mitems.opsMIPlantAssoc.forEach(assocdata => {
              obj.assocPlantId = assocdata.plantId;
              obj.acronym = assocdata.acronym;
              obj.uomId = assocdata.uomId;
              obj.uomdesc = assocdata.uomdesc;
              obj.minValue = assocdata.minValue;
              obj.maxValue = assocdata.maxValue;
            });
            this.opsMeasurementList.push(obj);
          });
          this.sortOMITable();
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.opsMeasurementList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.opsMsitemName.toLowerCase().includes(filter) ||
            data.acronym.toString().toLowerCase().includes(filter) ||
            (data.uomdesc !== null ? data.uomdesc.toString().toLowerCase().includes(filter) : null) ||
            (data.descriptionen !== null ? data.descriptionen.toString().toLowerCase().includes(filter) : null) ||
            (data.descriptioncn !== null ? data.descriptioncn.toString().toLowerCase().includes(filter) : null) ||
            (data.uomdesc !== null ? data.uomdesc.toString().toLowerCase().includes(filter) : null)||
            (data.paramVal !== null ? data.paramVal.toString().toLowerCase().includes(filter) : null);
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  editMeasurement(actionType, plantId, measurementId): void {
    if (actionType === 'edit') {
       this.router.navigate(['editMeasurement/' + (plantId !== '' ? plantId : 0) + '/' + measurementId]);
    }
  }

  sortOMITable() {
    this.opsMeasurementList.sort((a, b) => {

      const aPlant = a.acronym.toString().toLowerCase();
      const bPlant = b.acronym.toString().toLowerCase();
      const aItem = a.opsMsitemName.toString().toLowerCase();
      const bItem = b.opsMsitemName.toString().toLowerCase();
      return (aPlant < bPlant ? -1 : ( aPlant > bPlant ? 1 : ( aItem < bItem ? -1 : ( aItem > bItem ? 1 : 0 ))));
    });
  }

}

@Component({
  selector: 'app-addopsmeasurement',
  templateUrl: './addopsmeasurement.component.html',
  styleUrls: ['./opsmeasurement.component.css']
})

export class AddOpsMeasurementComponent implements OnInit {

  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  selectedPlantObj: any;
  measurementData: any;
  addMeasurementData: any;
  opsMeasurementDataResponse: any;
  pageParams: any;
  mode: any;
  uoms: any;
  uomresponse: any;
  errorMessage: any;
  saveMeasurementResponse: any;
  numeric = 'numeric';
  freeText = 'freeText';
  descriptionCNError: any;
  validateDescCN: any;
  invalidMinMaxValue = false;
  minOOL = false;
  maxOOL = false;
  measurementObj: any;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    public opsmeasurementservice: OpsmeasurementService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog
  ) {
    this.route.params.subscribe(params => {
      this.mode = 'new';
      this.addMeasurementData = this.preparereq();
      this.pageParams = params;
      if (this.pageParams.plantid) {
        this.addMeasurementData.plantId = parseInt(this.pageParams.plantid, 10);
      } else {
        this.addMeasurementData.plantId = 0;
      }
      if (this.pageParams.measurementid) {
        this.mode = 'edit';
        this.getMeasurementData(this.addMeasurementData.plantId, this.pageParams.measurementid);
      }
    });
  }

  getMeasurementData(plantId, measurementId) {
    this.addMeasurementData = [];
    this.measurementObj = [];
    this.opsmeasurementservice.getMeasurementsById(plantId, measurementId).subscribe(
      data => {
        this.opsMeasurementDataResponse = data;
        if (this.opsMeasurementDataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.opsMeasurementDataResponse.status,
            statusText: this.opsMeasurementDataResponse.message });
        } else {
            this.measurementObj = {
              'opsMsitemId': this.opsMeasurementDataResponse.data.opsMItem.opsMsitemId,
              'opsMsitemName': this.opsMeasurementDataResponse.data.opsMItem.opsMsitemName,
              'paramId': this.opsMeasurementDataResponse.data.opsMItem.paramId,
              'paramVal' : this.opsMeasurementDataResponse.data.opsMItem.paramVal,
              'assocPlantId': '',
              'acronym' : '',
              'uomId' : '',
              'uomdesc' : '',
              'minValue' : '',
              'maxValue' : '',
              'descriptionen': this.opsMeasurementDataResponse.data.opsMItem.description.en,
              'descriptioncn': this.opsMeasurementDataResponse.data.opsMItem.description.cn
            };
            this.opsMeasurementDataResponse.data.opsMItem.opsMIPlantAssoc.forEach(assocdata => {
              this.measurementObj.assocPlantId = [assocdata.plantId];
              this.measurementObj.acronym = assocdata.acronym;
              this.measurementObj.uomId = assocdata.uomId;
              this.measurementObj.uomdesc = assocdata.uomdesc;
              this.measurementObj.minValue = assocdata.minValue;
              this.measurementObj.maxValue = assocdata.maxValue;
            });
            this.addMeasurementData.push(this.measurementObj);
            this.addMeasurementData = this.addMeasurementData[0];
         // console.log(this.addMeasurementData);
        }
      }
    );
  }

  ngOnInit() {
    this.getPlants();
    this.getuoms();
  }

  getPlants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (this.plants.length > 0) {
           // this.selectedPlantObj =  this.plants[0];
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getuoms () {
    this.opsmeasurementservice.alluoms().subscribe(
      data => {
        this.uomresponse = data;
        this.uoms = [];
        if (this.uomresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.uomresponse.status, statusText: this.uomresponse.message });
        } else {
          this.uoms = this.uomresponse.data;
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'data.L00228';
      }
    );
  }

  cancelAddMeasurement(){
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: {type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      if (this.mode !== 'edit') {
        this.router.navigate(['ops-measurement/' + this.addMeasurementData.opsMIPlantAssocs[0].plantId]);
      } else {
        this.router.navigate(['ops-measurement/' + this.addMeasurementData.assocPlantId]);
      }
    });
  }

  validateDescriptionCN(model: any) {
    const isValidLang = model.match(/^[\x00-\x7F]*$/);
    this.descriptionCNError = (isValidLang) ? true : false;
    return this.descriptionCNError;
  }

  removeChinese(propName) {
    this.addMeasurementData[propName] = this.addMeasurementData[propName].replace(/[^\x00-\x7F]/g, '');
  }

  public validateMinMaxValue() {

    /**
     * Show invalid message only when values in both fields are present
     */
    if (this.addMeasurementData.minValue === null || this.addMeasurementData.maxValue === null) {
      this.invalidMinMaxValue = false;
    }

    /**
     * Check if minValue is greater than or equal to maxValue
     */
    if (this.addMeasurementData.minValue !== ''
        && this.addMeasurementData.minValue !== null
        && this.addMeasurementData.maxValue !== null
        && this.addMeasurementData.maxValue !== '') {
      if (this.addMeasurementData.minValue >= this.addMeasurementData.maxValue) {
        this.invalidMinMaxValue = true;
      } else  {
        this.invalidMinMaxValue = false;
      }
    }

    /**
     * Checking if the minimum or maximum values are out of limit
     */
    if (this.addMeasurementData.minValue !== null
      && this.addMeasurementData.minValue !== ''
      && (this.addMeasurementData.minValue < -999999999.999 || this.addMeasurementData.minValue > 999999999.999)) {
      this.minOOL = true;
    } else  {
      this.minOOL = false;
    }
    if (this.addMeasurementData.maxValue !== null
      && this.addMeasurementData.maxValue !== ''
      && (this.addMeasurementData.maxValue < -999999999.99 || this.addMeasurementData.maxValue > 999999999.99)) {
      this.maxOOL = true;
    } else  {
      this.maxOOL = false;
    }
  }

  changeItemType(paramId) {
    if (paramId === 83) {
      this.addMeasurementData.minValue = '';
      this.addMeasurementData.maxValue = '';
      this.addMeasurementData.uomId = 0;
    }
  }

  restrictSpace(e) {
    if (e.which === 32) {
      e.preventDefault();
      return false;
    }
  }

  saveMeasurement(action) {
    let displayMessage = '';
    this.measurementData = this.prepareFinalReq(this.addMeasurementData);
    this.measurementData.action = action;
    this.measurementData.opsMsitemName = this.measurementData.opsMsitemName.replace(/\s/g, '');
    this.validateDescCN = this.validateDescriptionCN(this.measurementData.description.en);

    if (this.invalidMinMaxValue || this.minOOL || this.maxOOL) {
      return;
    }

    if (!this.validateDescCN) {
      this.descriptionCNError = true;
    } else {
    this.descriptionCNError = false;
    this.opsmeasurementservice.saveMeasurementData(this.measurementData).subscribe(
      data => {
        this.saveMeasurementResponse = data;
        if (this.saveMeasurementResponse.status !== 'success') {
          this.errorservice.showerror({
            status: this.saveMeasurementResponse.errorCode, statusText: this.saveMeasurementResponse.message
         });
      } else {
        if (this.measurementData.action === 'create') {
          displayMessage = 'Measurement saved successfully';
        } else if (this.measurementData.action === 'update') {
          displayMessage = 'Measurement updated successfully';
        } else {
          displayMessage = 'Measurement deleted successfully';
        }
        const dialogRef = this.dialog.open(DialogComponent, {
          width: '400px',
          data: {title: 'data.L00224', message: displayMessage }
        });
        const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
          dialogRef.componentInstance.closeDialog();
          this.router.navigate(['ops-measurement/' + this.addMeasurementData.assocPlantId]);
        });
      }
  },
  (err: any) => {
     console.log(err);
  }
  );
}
  }

  prepareFinalReq(data) {
    const editassocId = [];
    if (data.assocPlantId.length === undefined) {
      editassocId.push(data.assocPlantId);
    }
    const finalReqObj = {
      'action': '',
      'opsMsitemId': (data.opsMsitemId !== undefined ? data.opsMsitemId : 0),
      'opsMsitemName': data.opsMsitemName,
      'miitemId': (data.paramId !== undefined ? data.paramId : 0),
      'uomid': (data.uomId !== 0 ? data.uomId : null),
      'uomdesc': data.uomdesc,
      'minValue': (data.minValue !== '' ? data.minValue : null),
      'maxValue': (data.maxValue !== '' ? data.maxValue : null),
      'opsMIPlantAssocs': {
        'plantId': (data.assocPlantId.length !== undefined ? data.assocPlantId : editassocId)
      },
      'description': {
        'en': data.descriptionen,
        'cn': data.descriptioncn
      }
    };
    return finalReqObj;
  }

  preparereq() {
    const reqObj = {
      'action': '',
      'opsMsitemId': 0,
      'opsMsitemName': '',
      'miitemId': 0,
      'assocPlantId': 0,
      'opsMIPlantAssocs': [
        {
          'plantId': 0
        }
      ],
      'description': {
        'en': '',
        'cn': ''
      },
      'uomId': 0,
      'uomdesc': '',
      'paramId': 0,
      'paramVal': '',
      'itemType': '',
      'minValue': '',
      'maxValue': ''
    };
    return reqObj;
  }
 }
