import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetupWSComponent } from './setup-ws.component';

describe('SetupWSComponent', () => {
  let component: SetupWSComponent;
  let fixture: ComponentFixture<SetupWSComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetupWSComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupWSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
