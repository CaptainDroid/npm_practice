import { Component, Inject, OnInit, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { OpsassignSetupwsService } from '../../../../services/opsassign-setupws.service';
import { CommonService } from 'src/app/services/common.service';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-setup-ws',
  templateUrl: './setup-ws.component.html',
  styleUrls: ['./setup-ws.component.css']
})
export class SetupWSComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['Location', 'OpsMeasurementItems', 'action'];
  dataSource: any;
  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  selectedPlantObj: any;
  setupWSList: any;
  showDeleteitem: any;
  worksheetTemplateResponse: any;
  saveOpsTemplateResponse: any;
  templateList: any;
  locationOmiResponse: any;
  locationOmiList: any;
  searchValue: any;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    private opsassignsetupwsservice: OpsassignSetupwsService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog, @Inject(DOCUMENT) document
  ) { }

  ngOnInit() {
    this.plants = [];
    this.setupWSList = [];
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.getplants(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.getplants(this.selectedPlant);
      }
    });
  }

  getplants(plantId: any) {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (plantId === 0) {
            this.setupWSList = [];
            this.selectedPlant = 0;
            if (this.plants.length > 0) {
              this.selectedPlantObj =  this.plants[0];
              this.selectedPlant =  this.plants[0].id;
              this.getOpsWorksheetList(this.plants[0]);
              this.getLocationOmis(this.plants[0]);
            }
          } else {
              const plantobj = this.plants.filter(plnt => {
              return plnt.id === plantId;
            });
            this.selectedPlantObj = plantobj[0];
            this.selectedPlant = plantId;
            if (plantobj[0]) {
              this.getOpsWorksheetList(plantobj[0]);
              this.getLocationOmis(plantobj[0]);
            }
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  selectplant(plantObj: any) {
    this.selectedPlantObj = plantObj;
    this.getOpsWorksheetList(plantObj);
    this.getLocationOmis(plantObj);
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  getOpsWorksheetList(plantObj: any) {
    this.searchValue = '';
    this.opsassignsetupwsservice.getOpsWorksheetTemplate(plantObj.id).subscribe(
      data => {
        this.worksheetTemplateResponse = data;
        if (this.worksheetTemplateResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.worksheetTemplateResponse.status,
             statusText: this.worksheetTemplateResponse.message });
        } else {
          this.templateList = this.worksheetTemplateResponse.data.wsTemplate;
          this.setupWSList = this.worksheetTemplateResponse.data.wsTemplate.templateDetails;
        }
        this.dataSource = new MatTableDataSource(this.setupWSList);
        this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
          return data.opsLocationName.toLowerCase().includes(filter) ||
          data.opsMsitemName.toString().toLowerCase().includes(filter);
        };
        this.dataSource.paginator = this.paginator;
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getLocationOmis(plantObj) {
    this.locationOmiList = [];
    this.opsassignsetupwsservice.getLocationItemsByPlant(plantObj.id).subscribe(
      data => {
        this.locationOmiResponse = data;
        if (this.locationOmiResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.locationOmiResponse.status, statusText: this.locationOmiResponse.message });
        } else {
          this.locationOmiList = this.locationOmiResponse.data;
        }
      }
    );
  }

 // openLocationOmiDialog
  deleteLocationOmi(deleteItem: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {type: 'yesno', title: 'data.L00187', message: 'data.L00226'}
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      const index = this.setupWSList.indexOf(deleteItem);
      if (index > -1) {
        this.setupWSList.splice(index, 1);
        this.dataSource = new MatTableDataSource(this.setupWSList);
        this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
          return data.opsLocationName.toLowerCase().includes(filter) ||
          data.opsMsitemName.toString().toLowerCase().includes(filter);
        };
        this.dataSource.paginator = this.paginator;
      }
      dialogRef.componentInstance.closeDialog();
    });

  }

  saveOpsTemplate() {
    const requestObj = this.preparereqobj(this.templateList);
    requestObj.action = 'update';
    this.opsassignsetupwsservice.saveOpsWorksheetTemplate(requestObj).subscribe(
      data => {
        this.saveOpsTemplateResponse = data;
        if (this.saveOpsTemplateResponse.status !== 'success') {
          this.errorservice.showerror({
            status: this.saveOpsTemplateResponse.errorCode, statusText: this.saveOpsTemplateResponse.message
         });
      } else {
        const dialogRef = this.dialog.open(DialogComponent, {
          width: '400px',
          data: {title: 'data.L00224', message: 'data.L01162' }
        });
        const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
          dialogRef.componentInstance.closeDialog();
        });
      }
      },
      (err: any) => {
        console.log(err);
     }
    );
  }

  preparereqobj(data) {
    const reqObj = {
      'action' : '',
      'opsWstemplateId': data.opsWstemplateId,
      'plantId': this.selectedPlant,
      'wTypeId': 1,
      'opsWstemplateName': data.templateName,
      'acronym': data.plantAcronym,
      'isDeleted': false,
      'wsTemplateDetails': []
    };
    if (data.templateDetails.length > 0) {
      reqObj.wsTemplateDetails = [];
      for (let i = 0; i < data.templateDetails.length; i++ ) {
        reqObj.wsTemplateDetails.push({
        'opsWstemplateDetailId': 0,
        'opsWstemplateId': data.opsWstemplateId,
        'locMiassocId': data.templateDetails[i].locMiassocId,
        'isDeleted': data.templateDetails[i].isDeleted
        });
      }
    }
    return reqObj;
  }

  openLocationMeasurementDialog(): void {

    this.locationOmiList = [];
    this.opsassignsetupwsservice.getLocationItemsByPlant(this.selectedPlant).subscribe(
      serverresponse => {
        this.locationOmiResponse = serverresponse;
        if (this.locationOmiResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.locationOmiResponse.status, statusText: this.locationOmiResponse.message });
        } else {
          const dialogRef = this.dialog.open(AddLocationItemDialogComponent, {
            width: '400px',
            data:  serverresponse['data']
        });
      
        const sub = dialogRef.componentInstance.addlocationomi.subscribe(result => {
          if (result.selectedLocation.locationId && result.selectedOmi) {
          dialogRef.componentInstance.closeDialog();
          this.addlocationomis(result);
          }
        });
  
        }
      }
    );

  }

  addlocationomis(locationOmi: any) {
    const index = this.setupWSList.findIndex( wsLocationOmi => {
      return wsLocationOmi.opsLocationId === locationOmi.selectedLocation.locationId &&
      wsLocationOmi.opsMsitemId === locationOmi.selectedOmi.opsMSItemId;
    });

    if (index === -1) {
      this.setupWSList.unshift( {
        opsLocationId: locationOmi.selectedLocation.locationId,
        opsLocationName: locationOmi.selectedLocation.locationName,
        opsMsitemId: locationOmi.selectedOmi.opsMSItemId,
        locMiassocId: locationOmi.selectedOmi.assocId,
        opsMsitemName: locationOmi.selectedOmi.opsMSItemName
      } );
      this.dataSource = new MatTableDataSource(this.setupWSList);
        this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
          return data.opsLocationName.toLowerCase().includes(filter) ||
          data.opsMsitemName.toString().toLowerCase().includes(filter);
        };
        this.dataSource.paginator = this.paginator;
    } else {
      this.errorservice.showerror({ statusText: 'data.L01163' });
    }
  }

}

@Component({
  selector: 'app-addlocationitemdialogcomponent',
  templateUrl: './addOpsLocationOmiDialog.component.html',
  styleUrls: ['./setup-ws.component.css']
})

export class AddLocationItemDialogComponent {

  @Output() addlocationomi = new EventEmitter<any>(true);

  selectedLocation: any;
  searchitempoint: any;
  selectedOmi: any;
  locationList: any;

  constructor(
    public dialogRef: MatDialogRef<AddLocationItemDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      this.locationList = [];
        this.locationList = data;
      this.selectedLocation = { locationName: '', miassoc: [] };
     }

  closeDialog(): void {
    this.dialogRef.close();
  }

  selectlocationOmi(selectedpoint: any){
    this.selectedOmi = selectedpoint;
  }

  addLocationOmi() {
    this.addlocationomi.emit({selectedLocation: this.selectedLocation, selectedOmi: this.selectedOmi});
    console.log(this.selectedLocation + ',' + this.selectedOmi);
  }

}

