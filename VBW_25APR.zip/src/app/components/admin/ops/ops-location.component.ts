import { Component, Inject, OnInit, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { OpslocationsService } from '../../../services/opslocations.service';
import { CommonService } from 'src/app/services/common.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ops-location',
  templateUrl: './ops-location.component.html',
  styleUrls: ['./ops-location.component.css']
})
export class OpsLocationComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['plantAcronym', 'opsLocationName', 'description', 'descriptioncn', 'actions'];
  dataSource: any;
  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  opsLocationList: any;
 // selectedPlantObj: any;
  opsLocationsResponse: any;
  locationbyplant: any;
  searchValue: any;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    private opslocationservice: OpslocationsService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    this.plants = [];
    this.opsLocationList = [];
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.getplants(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.getplants(this.selectedPlant);
      }
    });
  }

  getplants(plantId: any) {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (plantId === 0) {
            this.opsLocationList = [];
            this.selectedPlant = 0;
            this.getopslocations(this.plants[0]);
          } else {
              const plantobj = this.plants.filter(plnt => {
              return plnt.id === plantId;
            });
           // this.selectedPlantObj = plantobj[0];
            this.selectedPlant = plantId;
            this.getlocationsbyplantid(this.selectedPlant);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getopslocations(plantobj) {
    this.searchValue = '';
    this.opsLocationList = [];
    this.opslocationservice.getLocations().subscribe (
      data => {
        this.opsLocationsResponse = data;
        if (this.opsLocationsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.opsLocationsResponse.status, statusText: this.opsLocationsResponse.message });
        } else {
          this.opsLocationList = this.opsLocationsResponse.data.opsLocations;
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.opsLocationList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.opsLocationName.toLowerCase().includes(filter) ||
            data.plantAcronym.toString().toLowerCase().includes(filter) ||
            (data.description.en !== null ? data.description.en.toString().toLowerCase().includes(filter) : null) ||
            (data.description.cn !== null ? data.description.cn.toString().toLowerCase().includes(filter) : null);
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );

  }

 applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  selectplant(plantid: any) {
    // this.selectedPlantObj = plantObj;
    if (plantid === 0) {
      this.getopslocations(plantid);
    } else {
      this.getlocationsbyplantid(plantid);
    }
  }

  getlocationsbyplantid(plantid) {
    this.searchValue = '';
    this.opsLocationList = [];
    this.opslocationservice.getLocationsByPlant(plantid).subscribe(
      data => {
        this.opsLocationsResponse = data;
        if (this.opsLocationsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.opsLocationsResponse.status, statusText: this.opsLocationsResponse.message });
        } else {
          this.opsLocationList = this.opsLocationsResponse.data.opsLocations;
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.opsLocationList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.opsLocationName.toLowerCase().includes(filter) ||
            data.plantAcronym.toString().toLowerCase().includes(filter) ||
            (data.description.en !== null ? data.description.en.toString().toLowerCase().includes(filter) : null) ||
            (data.description.cn !== null ? data.description.cn.toString().toLowerCase().includes(filter) : null);
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );

  }

  editLocation(actionType, locationId): void {
    if (actionType === 'edit') {
       this.router.navigate(['editLocation/' + this.selectedPlant + '/' + locationId]);
    }
  }

}

@Component({
  selector: 'app-addopslocation',
  templateUrl: './addopslocation.component.html',
  styleUrls: ['./ops-location.component.css']
})

export class AddOpsLocationComponent implements OnInit {

  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  descriptionCNError: any;
  validateDescCN: any;
  addLocationData: any;
  opsLocationDataResponse: any;
  saveLocationResponse: any;
  pageParams: any;
  mode: any;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    private opslocationservice: OpslocationsService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog
  ) {
    this.route.params.subscribe(params => {
      this.mode = 'new';
      this.addLocationData = this.preparereq();
      this.pageParams = params;
      if (this.pageParams.plantid) {
        this.addLocationData.plantId = parseInt(this.pageParams.plantid, 10);
      } else {
        this.addLocationData.plantId = 0;
      }
      if (this.pageParams.locationid) {
        this.mode = 'edit';
        this.getLocationData(this.addLocationData.plantId, this.pageParams.locationid);
      }
    });
   }

   getLocationData(plantId, locationId) {
    this.opslocationservice.getLocationsById(locationId).subscribe(
      data => {
        this.opsLocationDataResponse = data;
        if (this.opsLocationDataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.opsLocationDataResponse.status, statusText: this.opsLocationDataResponse.message });
        } else {
          this.addLocationData = this.opsLocationDataResponse.data.opsLocation;
        }
      }
    );

  }

  ngOnInit() {
    // this.descriptionCNError = false;
    this.getPlants();
  }

  getPlants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (this.plants.length > 0) {
           // this.selectedPlantObj =  this.plants[0];
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  cancelAddLocation() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: {type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.router.navigate(['ops-location/' + this.addLocationData.plantId]);
    });
  }

  validateDescriptionCN(model: any) {
    const isValidLang = model.match(/^[\x00-\x7F]*$/);
    this.descriptionCNError = (isValidLang) ? true : false;
    return this.descriptionCNError;
  }

  removeChinese(propName) {
    this.addLocationData[propName] = this.addLocationData[propName].replace(/[^\x00-\x7F]/g, '');
  }

  saveLocation(action) {
    let displayMessage = '';
    this.addLocationData.action = action;
    this.addLocationData.opsLocationName = this.addLocationData.opsLocationName.replace(/\s/g, '');
    this.validateDescCN = this.validateDescriptionCN(this.addLocationData.description.en);
    // this.validateDescCN = true;
    if (!this.validateDescCN) {
      this.descriptionCNError = true;
    } else {
    this.descriptionCNError = false;
    this.opslocationservice.saveLocationData(this.addLocationData).subscribe(
      data => {
        this.saveLocationResponse = data;
        if (this.saveLocationResponse.status !== 'success') {
          this.errorservice.showerror({
            status: this.saveLocationResponse.errorCode, statusText: this.saveLocationResponse.message
         });
      } else {
        if (this.addLocationData.action === 'create') {
          displayMessage = 'data.L01149';
        } else if (this.addLocationData.action === 'update') {
          displayMessage = 'data.L01150';
        } else {
          displayMessage = 'data.L01151';
        }
        const dialogRef = this.dialog.open(DialogComponent, {
          width: '400px',
          data: {title: 'data.L00224', message: displayMessage }
        });
        const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
          dialogRef.componentInstance.closeDialog();
          this.router.navigate(['ops-location/' + this.addLocationData.plantId]);
        });
      }
  },
  (err: any) => {
     console.log(err);
  }
  );
}
  }

  preparereq() {
    const reqObj = {
      'action': '',
      'opsLocationId': 0,
      'plantId': '',
      'opsLocationName': '',
      'description': {
        'en': '',
        'cn': ''
      }
    };
    return reqObj;
  }

}
