import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpsLocationComponent } from './ops-location.component';

describe('OpsLocationComponent', () => {
  let component: OpsLocationComponent;
  let fixture: ComponentFixture<OpsLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpsLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpsLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
