import { Component, OnInit, Inject } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { DOCUMENT } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
//import { customer } from '../../admin/customer.model';
import { Router, Params } from "@angular/router";
import { CommercialService } from '../../../services/commercial.service';

@Component({
  selector: 'app-edit-customer',
  templateUrl: './edit-customer.component.html',
  styleUrls: ['./edit-customer.component.css']
})
export class EditCustomerComponent implements OnInit {
  customerId1: any[];
  //customer: customer[];
  name: string;
  country: number;
  customerName: string;
  custId: number;

  constructor(private commercialService: CommercialService, private fb: FormBuilder, private router: Router, private route: ActivatedRoute) {
    this.route.params.subscribe(params => {
      this.custId = params.id;
      // const countryid = params.countryid;
      // const cityId = params.cityId;
      // const plantid = params.plantid;
    });
  }

  ngOnInit() {
    this.createForms();
    //   get customerId(): any {
    //     return localStorage.getItem('editUserId');
    // };
    //let customerId = localStorage.getItem("editUserId");
    // if(!customerId) {
    //   alert("Invalid action.")
    //   this.router.navigate(['customerList']);
    //   return;
    // }

    this.route.params.subscribe((params: Params) => {
      // const countryid = params['countryid'];
      // const cityId = params['cityId'];
      // const plantid = params['plantid'];
      const id = params['id'];

      console.log('id', id);
      //this.customerId = id;
      // this.getplants();
      
    });
    // this.commercialService.getcustomerData().subscribe(data => {
    //   const result: any = data;
    //   let dataArray = result.data.country[0].cities[0].plants[0].customers[0];
    //   dataArray.countryName = result.data.country[0].id;
    //   dataArray.plant = result.data.country[0].cities[0].plants[0].id;
    //   dataArray.processId = result.data.country[0].cities[0].plants[0].processId;
    //   console.log('get-data', dataArray);
    //   // const peopleArray = Object.keys(dataArray).map(i => dataArray[i]);
    //   const peopleArray = Object.keys(dataArray).map(key => ({ type: key, value: dataArray[key] }));
    //   console.log('array', peopleArray);
    //   this.customerDetailsForm.setValue(dataArray);
    // });
  }

  get customerId(): any {
    return localStorage.getItem('editUserId');
  };
  customerDetailsForm: FormGroup;

  resultsLength = 0;
  customerDataresponce: any;
  customerData = [];
  plant1: string;

  tasks = [];
  selectedCountry: string = '';
  countries = [
    { id: 1, countryName: 'India' },
    { id: 21, countryName: 'Pakistan' },
    { id: 3, countryName: 'US' }
  ];
  companyProduct = [
    { id: 2, name: 'Pakistan' },
    { id: 3, name: 'BSTW' },
    { id: 1, name: 'US' }
  ];
  plants = [
    { id: 2, name: 'Pakistan' },
    { id: 3, name: 'BSTW' },
    { id: 1, name: 'US' }
  ];
  mainPollutant = [
    { id: 0, name: 'Pakistan' },
    { id: 1, name: 'BSTW' },
    { id: 2, name: 'US' }
  ];



 
  validation_messages = {
    'customerName': [
      { type: 'minLength', message: 'Company name should be minimum of 3 letters long' },
      { type: 'maxlength', message: 'Company name cannot be more than 5 characters long' },
      { type: 'minlength', message: 'Company name should be minimum of 3 letters long' },
      { type: 'required', message: 'This field is required' },
    ],
    'companyProduct': [
      { type: 'required', message: 'Please select a company product' },
    ],
    'countryName': [
      { type: 'required', message: 'Please select a Country Name ' },
    ],
    'plant': [
      { type: 'required', message: 'Please select a Plant ' },
    ],
    'description': [
      { type: 'minLength', message: 'Description should be minimum of 3 letters long' },
      { type: 'maxlength', message: 'Description cannot be more than 5 characters long' },
      { type: 'minlength', message: 'Description should be minimum of 3 letters long' },
      { type: 'required', message: 'This field is required' },
    ],
    'descriptionCn': [
      { type: 'minLength', message: 'Description should be minimum of 3 letters long' },
      { type: 'maxlength', message: 'Description cannot be more than 5 characters long' },
      { type: 'minlength', message: 'Description should be minimum of 3 letters long' },
      { type: 'required', message: 'This field is required' },
    ],
    'mainPollutant': [
      { type: 'required', message: 'Please select an option' },
    ],
    'productionCapacity': [
      { type: 'required', message: 'This field is required' },
      { type: 'pattern', message: 'Please enter a positive value' }
    ],
    'processId': [
      { type: 'required', message: 'Please select an option ' },
    ],
    'preTreatment': [
      { type: 'minLength', message: 'Minimum of 3 letters required' },
      { type: 'maxlength', message: 'Max limit is 250 letters' },
      { type: 'minlength', message: 'Minimum of 3 letters required' },
      { type: 'required', message: 'This field is required' },
    ],
    'rawMaterials': [
      { type: 'required', message: 'Please select an option ' },
    ],
    'mncOrLocal': [
      { type: 'required', message: 'Please select an option ' },
    ],
    'production': [
      { type: 'required', message: 'Please select an option ' },
    ],
    'remark': [
      { type: 'minLength', message: 'Minimum of 3 letters required' },
      { type: 'maxlength', message: 'Max limit is 250 letters' },
      { type: 'minlength', message: 'Minimum of 3 letters required' },
      { type: 'required', message: 'This field is required' },
    ],
    'waterVolume': [
      { type: 'required', message: 'This field is required' },
      { type: 'pattern', message: 'Please enter a positive value' }
    ],
    'concentrationOfMainComponents': [
      { type: 'required', message: 'This field is required' },
      { type: 'pattern', message: 'Please enter a positive value' }
    ],
  };

  public createForms() {
    this.customerDetailsForm = this.fb.group({
      id: '',
      custProdInBatch: '',
      industry: '',
      otherComponents: '',
      contractId: '',
      contract: '',
      contractEndDate: '',
      customerName: new FormControl('', Validators.compose([Validators.maxLength(250), Validators.minLength(3), Validators.min(3), Validators.required])),
      companyProduct: new FormControl('', [Validators.required]),
      countryName: new FormControl('', [Validators.required]),
      plant: new FormControl('', [Validators.required]),
      description: new FormControl('', Validators.compose([Validators.maxLength(250), Validators.minLength(3), Validators.min(3), Validators.required])),
      descriptionCn: new FormControl('', Validators.compose([Validators.maxLength(250), Validators.minLength(3), Validators.min(3), Validators.required])),
      mainPollutant: new FormControl('', [Validators.required]),
      productionCapacity: new FormControl('', Validators.compose([Validators.required, Validators.pattern(/^[1-9]\d*$/)])),
      processId: new FormControl('', [Validators.required]),
      preTreatment: new FormControl('', Validators.compose([Validators.maxLength(250), Validators.minLength(3), Validators.min(3), Validators.required])),
      rawMaterials: new FormControl('', [Validators.required]),
      mncOrLocal: new FormControl('', [Validators.required]),
      production: new FormControl('', [Validators.required]),
      remark: new FormControl('', Validators.compose([Validators.maxLength(250), Validators.minLength(3), Validators.min(3), Validators.required])),
      waterVolume: new FormControl('', Validators.compose([Validators.required, Validators.pattern(/^[1-9]\d*$/)])),
      concentrationOfMainComponents: new FormControl('', Validators.compose([Validators.required, Validators.pattern(/^[1-9]\d*$/)])),
    });
  }


  onSubmitUserDetails() {
    this.tasks.push({ customerName: this.customerDetailsForm, strike: false });
    console.log("tasks" + this.tasks);
    console.log(this.customerDetailsForm.value);
  }

  next() {
    console.log('id ****', this.custId);
    this.router.navigate(['/edit-customer-contract/' + this.custId]);
  }


  // onClickSave(){
  //   this.tasks.push(this.customerData.customerName);
  //   console.log("item="+ this.tasks);
  //   this.router.navigate(['citiesList']); 
  // }

}
