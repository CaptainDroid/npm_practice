import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorksheetTemplatesComponent } from './worksheet-templates.component';

describe('WorksheetTemplatesComponent', () => {
  let component: WorksheetTemplatesComponent;
  let fixture: ComponentFixture<WorksheetTemplatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorksheetTemplatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorksheetTemplatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
