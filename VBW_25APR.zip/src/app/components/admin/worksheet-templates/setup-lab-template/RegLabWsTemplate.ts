export interface RegLabWsTemplate {
    country?: number;
    city?: number;
    plant?: number;
    plantAcronym?: string;
    assocId: number;
    sampleId: number;
    testId: number;
    sample: string;
    test: string;
}
