import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetupRegularLabTemplateComponent } from './setup-lab-template.component';

describe('SetupRegularLabTemplateComponent', () => {
  let component: SetupRegularLabTemplateComponent;
  let fixture: ComponentFixture<SetupRegularLabTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetupRegularLabTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupRegularLabTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
