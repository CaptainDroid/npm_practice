import { Component, OnInit, ViewChild, Inject, EventEmitter, Output } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CommonService } from '../../../../services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { RegLabWsTemplate } from './RegLabWsTemplate';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';

@Component({
  selector: 'app-setup-reg-lab-template',
  templateUrl: './setup-reg-lab-template.component.html',
  styleUrls: ['./setup-lab-template.component.css']
})
export class SetupRegularLabTemplateComponent implements OnInit {

  public template;
  public allSampleTests = [];
  public allSamples = [];
  public testsPerSample = [];
  public worksheetSampleTests: RegLabWsTemplate[];
  public dataSource: MatTableDataSource<RegLabWsTemplate>;
  public displayedColumns = ['sample', 'test', 'action'];
  public filterString = '';
  prevPlantId = 0;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor( private _adminService: AdminService,
               private _errorService: ErrorserviceService,
               private _route: ActivatedRoute,
               private _router: Router,
              public dialog: MatDialog ) { }

  ngOnInit() {

    this.prevPlantId = this._route.params['value'].plantid;

    // Retrieving the worksheet from the session storage
    this.template = JSON.parse(sessionStorage.getItem('regTemplate'));

    /**
     * Getting data for said worksheet
     */
    this._adminService.getLabWorksheetTemplateData(this.template).subscribe(
      data => {
        if (data['status'] !== 'success') {
          this._errorService.showerror({ status: data['status'], statusText: data['message'] });
          return;
        }
        this.worksheetSampleTests = [];
        const ws = data['data']['wsTemplate'];
        ws.templateDetails.forEach(sample => {
            // Insert the sample-test combinations in the sampleTests array
            this.worksheetSampleTests.push({
              assocId: sample.sampleTestAssocId,
              sampleId: sample.sampleId,
              sample: sample.sampleName,
              testId: sample.testId,
              test: sample.testName
            }); // push ends
        }); // sample ends

        // Initialise the dataSource with the sampleTests combination data
        this.initializeDataSource();
      }
    ); // GetLabWorksheetTemplateData ends


    /**
     * Get list of all sample tests for respective plant, and respective worksheetType
     */
    this._adminService.getSampleTests(this.template).subscribe(
      data => {
        if (data['status'] !== 'success') {
          this._errorService.showerror({ status: data['status'], statusText: data['message'] });
          return;
        }
        const samples = data['data']['sample'];
        /**
         *  Do some processing here with samples, if needed
         */
        this.allSampleTests = data['data']['sample'];
      }
    ); // GetSampleTests ends
  }


  /**
   * Delete Confirmation Dialog
   */
  openConfirmationDialog(sampleTest) {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: null, type: 'delete' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.deleteSampleTest(sampleTest);
      }
    });
  }


  /**
   * Save the template with the sample-test combinations
   */
  saveTemplate() {
    const formData = {
      action: 'Update',
      plantId: this.template.plantId,
      acronym: this.template.plant,
      labWstemplateId: this.template.templateId,
      wTypeId: 1,
      wsTemplateDetails: []
    };
    this.worksheetSampleTests.forEach(item => {
      formData.wsTemplateDetails.push({
        labWstemplateId: formData.labWstemplateId,
        sampleTestAssocId: item.assocId
      });
    });

    this._adminService.saveLabTemplateDetails(formData).subscribe(
      (data: any) => {
        if (data.status === 'success') {
          this._errorService.showerror({ type: 'Info', status: '', statusText: 'Saved Successfully' });
          this._router.navigate(['worksheet-templates-list', this.prevPlantId]);
        } else {
          this._errorService.showerror({ status: data.status, statusText: data.message });
        }
      },
      (err: any) => {
        console.log('Failed');
      }
    );

  }


  /**
   * Open dialog to select a sample-test combination from all sampleTests, and get the result
   */
  openSampleTestDialog() {
    const dialogRef = this.dialog.open(AddSampleTestDialogComponent, {
      width: '400px',
      data: { sampleTests: this.allSampleTests }
    });
    const res = dialogRef.componentInstance.addSampleTestEvent.subscribe(
      result => {
        if (result.selectedSample.sampleId && result.selectedTest) {
          dialogRef.componentInstance.closeDialog();
          this.addSampleTest(result);
        }
      }
    );
  }

  /**
   * Add a sample-test combination to the worksheet template
   */
  addSampleTest(sampleTest: any) {
    const index = this.worksheetSampleTests.findIndex( wsSampleTest => {
      return wsSampleTest.sampleId === sampleTest.selectedSample.sampleId && wsSampleTest.testId === sampleTest.selectedTest.testId;
    });

    if (index === -1) {
      this.worksheetSampleTests.unshift( {
        sampleId: sampleTest.selectedSample.sampleId,
        sample: sampleTest.selectedSample.sampleName,
        testId: sampleTest.selectedTest.testId,
        assocId: sampleTest.selectedTest.assocId,
        test: sampleTest.selectedTest.testName
      } );
      this.initializeDataSource();
    } else {
      this._errorService.showerror({ statusText: 'Sample-Test combination already exists!' });
    }
  }


  /**
   * Delete the sample-test combination from the worksheet template
   */
  deleteSampleTest(sampleTest) {
    const index = this.worksheetSampleTests.findIndex( wsSampleTest => {
      return wsSampleTest.sampleId === sampleTest.sampleId && wsSampleTest.testId === sampleTest.testId;
    });
    if (index !== -1) {
      this.worksheetSampleTests.splice(index, 1);
      this.initializeDataSource();
    }
  }


  applyFilterPredicate() {
    this.dataSource.filterPredicate = function(data: any, filter: string): boolean {
      return data.sample.toLowerCase().includes(filter) || data.test.toLowerCase().includes(filter);
    };
  }

  applyFilter() {
    this.dataSource.filter = this.filterString.toLowerCase();
  }

  initializeDataSource() {
    this.dataSource = new MatTableDataSource(this.worksheetSampleTests);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.applyFilterPredicate();
    this.applyFilter();
  }

  /**
   * Please remember to remove the item from the Session Storage when the component is destroyed, or other similar cases
   */
  ngOnDestroy() { //tslint:disable-line
    sessionStorage.removeItem('regTemplate');
  }

}


@Component({
  selector: 'app-setup-tparty-lab-template',
  templateUrl: './setup-tparty-lab-template.component.html',
  styleUrls: ['./setup-lab-template.component.css']
})
export class SetupTPartyLabTemplateComponent implements OnInit {

  public template;
  public allSampleTests = [];
  public allSamples = [];
  public testsPerSample = [];
  public worksheetSampleTests: RegLabWsTemplate[];
  public dataSource: MatTableDataSource<RegLabWsTemplate>;
  public displayedColumns = ['sample', 'test', 'action'];
  public filterString = '';
  public isDelete = false;
  prevPlantId = 0;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor( private _adminService: AdminService,
               private _errorService: ErrorserviceService,
               private _route: ActivatedRoute,
               private _router: Router,
              public dialog: MatDialog ) { }

  ngOnInit() {

    this.prevPlantId = this._route.params['value'].plantid;

    // Retrieving the worksheet from the session storage
    this.template = JSON.parse(sessionStorage.getItem('tPartyTemplate'));

    /**
     * Getting data for said worksheet
     */
    this._adminService.getLabWorksheetTemplateData(this.template).subscribe(
      data => {
        if (data['status'] !== 'success') {
          this._errorService.showerror({ status: data['status'], statusText: data['message'] });
          return;
        }
        this.worksheetSampleTests = [];
        const ws = data['data']['wsTemplate'];
        ws.templateDetails.forEach(sample => {
            // Insert the sample-test combinations in the sampleTests array
            this.worksheetSampleTests.push({
              assocId: sample.sampleTestAssocId,
              sampleId: sample.sampleId,
              sample: sample.sampleName,
              testId: sample.testId,
              test: sample.testName
            }); // push ends
        }); // sample ends

        // Initialise the dataSource with the sampleTests combination data
        this.initializeDataSource();
      }
    ); // GetLabWorksheetTemplateData ends


    /**
     * Get list of all sample tests for respective plant, and respective worksheetType
     */
    this._adminService.getSampleTests(this.template).subscribe(
      data => {
        if (data['status'] !== 'success') {
          this._errorService.showerror({ status: data['status'], statusText: data['message'] });
          return;
        }
        const samples = data['data']['sample'];
        /**
         *  Do some processing here with samples, if needed
         */
        this.allSampleTests = data['data']['sample'];
      }
    ); // GetSampleTests ends
  }


  /**
   * Delete Confirmation Dialog
   */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route:  null, type: this.isDelete ? 'delete' : null }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === true && this.isDelete) {
        this.saveTemplate();
      }
    });
  }


  /**
   * Save the template with the sample-test combinations
   */
  saveTemplate() {
    const formData = {
      action: this.isDelete ? 'Delete' : 'Update',
      plantId: this.template.plantId,
      acronym: this.template.plant,
      labWstemplateId: this.template.templateId,
      isDeleted: this.isDelete ? true : false,
      wTypeId: 2,
      wsTemplateDetails: []
    };
    this.worksheetSampleTests.forEach(item => {
      formData.wsTemplateDetails.push({
        labWstemplateId: formData.labWstemplateId,
        sampleTestAssocId: item.assocId,
        isDeleted: this.isDelete ? true : false
      });
    });

    this._adminService.saveLabTemplateDetails(formData).subscribe(
      (data: any) => {
        if (data.status === 'success') {
          if (this.isDelete) {
            this._errorService.showerror({ type: 'Info', status: '', statusText: 'Deleted Successfully' });
          } else {
            this._errorService.showerror({ type: 'Info', status: '', statusText: 'Saved Successfully' });
          }
          this._router.navigate(['worksheet-templates-list', this.prevPlantId]);
        } else {
          this.isDelete = false;
          this._errorService.showerror({ status: data.status, statusText: data.message });
        }
      },
      (err: any) => {
        this.isDelete = false;
        console.log('Failed');
      }
    );
  }

  deleteTemplate() {
    this.isDelete = true;
    this.openConfirmationDialog();
  }


  /**
   * Open dialog to select a sample-test combination from all sampleTests, and get the result
   */
  openSampleTestDialog() {
    const dialogRef = this.dialog.open(AddSampleTestDialogComponent, {
      width: '400px',
      data: { sampleTests: this.allSampleTests }
    });
    const res = dialogRef.componentInstance.addSampleTestEvent.subscribe(
      result => {
        if (result.selectedSample.sampleId && result.selectedTest) {
          dialogRef.componentInstance.closeDialog();
          this.addSampleTest(result);
        }
      }
    );
  }

  /**
   * Add a sample-test combination to the worksheet template
   */
  addSampleTest(sampleTest: any) {
    const index = this.worksheetSampleTests.findIndex( wsSampleTest => {
      return wsSampleTest.sampleId === sampleTest.selectedSample.sampleId && wsSampleTest.testId === sampleTest.selectedTest.testId;
    });

    if (index === -1) {
      this.worksheetSampleTests.unshift( {
        sampleId: sampleTest.selectedSample.sampleId,
        sample: sampleTest.selectedSample.sampleName,
        testId: sampleTest.selectedTest.testId,
        assocId: sampleTest.selectedTest.assocId,
        test: sampleTest.selectedTest.testName
      } );
      this.initializeDataSource();
    } else {
      this._errorService.showerror({ statusText: 'Sample-Test combination already exists!' });
    }
  }


  /**
   * Delete the sample-test combination from the worksheet template
   */
  deleteSampleTest(sampleTest) {
    const index = this.worksheetSampleTests.findIndex( wsSampleTest => {
      return wsSampleTest.sampleId === sampleTest.sampleId && wsSampleTest.testId === sampleTest.testId;
    });
    if (index !== -1) {
      this.worksheetSampleTests.splice(index, 1);
      this.initializeDataSource();
    }
  }


  applyFilterPredicate() {
    this.dataSource.filterPredicate = function(data: any, filter: string): boolean {
      return data.sample.toLowerCase().includes(filter) || data.test.toLowerCase().includes(filter);
    };
  }

  applyFilter() {
    this.dataSource.filter = this.filterString.toLowerCase();
  }

  initializeDataSource() {
    this.dataSource = new MatTableDataSource(this.worksheetSampleTests);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.applyFilterPredicate();
    this.applyFilter();
  }

  /**
   * Please remember to remove the item from the Session Storage when the component is destroyed, or other similar cases
   */
  ngOnDestroy() { //tslint:disable-line
    sessionStorage.removeItem('tPartyTemplate');
  }

}


@Component({
  selector: 'app-add-sample-test-dialog',
  templateUrl: './add-sample-test.html',
  styleUrls: ['./setup-lab-template.component.css']
})

export class AddSampleTestDialogComponent {

  public searchSampleTest = '';
  public selectedSample = { sampleName: undefined, testAssoc: [] };
  public selectedTest;

  @Output() addSampleTestEvent = new EventEmitter<any>(true);

  constructor(public dialogRef: MatDialogRef<AddSampleTestDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  closeDialog() {
    this.dialogRef.close();
  }

  addSampleTest() {
    this.addSampleTestEvent.emit({
      selectedSample: this.selectedSample,
      selectedTest: this.selectedTest
    });
  }

  selectSampleTest(sampleTest: any) {
    this.selectedTest = sampleTest;
  }

}

export interface DialogData {

  sample: string;
  sampleTests;

}

import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'testFilter'
})
export class TestFilterPipe implements PipeTransform {
  transform(items: any[], searchText: string): any[] {
    if (!items) {
      return [];
    }
    if (!searchText) {
      return items;
    }
    searchText = searchText.toLowerCase();
    return items.filter(it => {
        return it.testName.toLowerCase().includes(searchText);
    });
  }
}

