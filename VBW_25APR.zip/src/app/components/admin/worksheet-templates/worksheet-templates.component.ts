import { Component, OnInit, ViewChild, EventEmitter, Inject, Output } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CommonService } from '../../../services/common.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-worksheet-templates',
  templateUrl: './worksheet-templates.component.html',
  styleUrls: ['./worksheet-templates.component.css']
})

export class WorksheetTemplatesComponent implements OnInit {
  displayedColumns: string[] = ['plant', 'templateName', 'templateType' , 'action'];
  @ViewChild('wspaginator') wspaginator: MatPaginator;
  @ViewChild('opspaginator') opspaginator: MatPaginator;
  show = [false, false];

  dataSource: any;
  OpsdataSource: any;
  plants: any;
  selectedPlant = '';
  selectedType: any;
  wsList: any;
  opswsList: any;
  ttype = [ '3PTY', 'REGR'];
  searchStr = '';
  prevPlantId: any;

  constructor(
    private errorservice: ErrorserviceService,
    public adminService: AdminService,
    private commonservice: CommonService,
    private _router: Router,
    private _route: ActivatedRoute,
    public dialog: MatDialog ) {
      this.commonservice.getplants().subscribe(
        (val: any) => {
          const plantsresponse = val['data'];
          const countries = plantsresponse['countries'];
          const plantCodeList = [];
          countries.forEach(country => {
            const cities = country['cities'];
            cities.forEach(city => {
              const plants = city['plants'];
              plants.forEach(plant => {
                const plantCode = {
                  id: plant.id,
                  value: plant.acronym,
                  plantName: plant.name,
                  countryId: country.id,
                  countryName: country.name,
                  cityId: city.id
                };
                plantCodeList.push(plantCode);
              });
            });
          });
          this.plants = plantCodeList;
        });


    }

  ngOnInit() {
    this.prevPlantId = this._route.params['value'].plantid;
    this.show[0] = true;
    this.selectedType = '';
    this.selectedPlant = '';
    this.searchStr = '';
    this.getLabTemplates();
    // this.getOpsTemplates();
  }

  public getLabTemplates() {
    this.adminService.getWorksheetTemplateList().subscribe(
      (res: any) => {
        if (res['status'] !== 'success') {
          this.errorservice.showerror({ status: res['status'], statusText: res['message'] });
        }
        if (res['status']) {
          this.wsList = res['data'];
          const wsList = [];
          this.wsList.forEach(wsheet => {
                const worksheet = wsheet['wstemplates'];
                worksheet.forEach(ws => {
                  const worksheetData = {
                    'templateType' : ws.templateType,
                    'plantId' : wsheet['id'],
                    'plant': wsheet['acronym'] != null ? wsheet['acronym'] : '',
                    'templateName' : ws.templateName,
                    'templateId' : ws.id
                };
                wsList.push(worksheetData);
                });
                this.wsList = wsList;
          });
        }
        // const plantid = this._route.params['value'].plantid;
        if (this.prevPlantId !== undefined) {
          this.selectedPlant = this.prevPlantId;
          this.filterTemplate('plant', this.prevPlantId);
          if (this.dataSource) {
            this.dataSource.paginator = this.wspaginator;
          }
        } else {
          this.dataSource = new MatTableDataSource(this.wsList);
          if (this.dataSource) {
            this.dataSource.paginator = this.wspaginator;
          }
        }
      });
    }

    public getOpsTemplates() {
      // this.adminService.getOpsWorksheetTemplateList().subscribe(
      //   (res: any) => {
      //     if (res['status'] !== 'success') {
      //       this.errorservice.showerror({ status: res['status'], statusText: res['message'] });
      //     }
      //     if (res['status']) {
      //       this.opswsList = res['data'];
      //       const opswsList = [];
      //       this.opswsList.forEach(opswsheet => {
      //         const opsworksheet = opswsheet['wstemplates'];
      //         opsworksheet.forEach(ws => {
      //           const opsworksheetData = {
      //             'templateType' : ws.templateType,
      //             'plantId' : opswsheet['id'],
      //             'plant': opswsheet['acronym'] != null ? opswsheet['acronym'] : '',
      //             'templateName' : ws.templateName,
      //             'templateId' : ws.id
      //          };
      //          opswsList.push(opsworksheetData);
      //         });
      //         this.opswsList = opswsList;
      //       });
      //     }
      //     this.OpsdataSource = new MatTableDataSource(this.opswsList);
      //     if (this.OpsdataSource) {
      //       this.OpsdataSource.paginator = this.opspaginator;
      //     }
      //   });
    }
  toggleShow(tabIndex) {
        if (tabIndex === 0) {
          this.show[0] = true;
          this.show[1] = false;
          this.selectedPlant = '';
          this.selectedType = '';
          this.dataSource = new MatTableDataSource(this.wsList);
          this.dataSource.paginator = this.wspaginator;
        } else if (tabIndex === 1) {
          this.show[1] = true;
          this.show[0] = false;
          this.selectedPlant = '';
          this.selectedType = '';
          this.OpsdataSource = new MatTableDataSource(this.opswsList);
          this.OpsdataSource.paginator = this.opspaginator;
        }
  }


  applyFilter(filterValue: string) {
    if (this.show[0]){
      this.searchStr = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches

      if (this.selectedPlant === '' && this.selectedType === '' ) {
        if (this.dataSource) {
          this.dataSource.filter = filterValue.trim().toLowerCase();
        }
        if (this.dataSource.paginator) {
          this.dataSource.paginator.firstPage();
        }
      } else {
        this.filterTemplate('', '');
      }
    } else if (this.show[1]){
      this.searchStr = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches

          if (this.selectedPlant === '' && this.selectedType === '' ) {
            if (this.OpsdataSource) {
              this.OpsdataSource.filter = filterValue.trim().toLowerCase();
            }
            if (this.OpsdataSource.paginator) {
              this.OpsdataSource.paginator.firstPage();
            }
          } else {
            this.filterTemplate('', '');
          }
    }
  }

  filterTemplate(filtertype: any, filtervalue: any) {
    if (this.show[0]){
      const self = this;
      const filteredData = this.wsList.filter(data => {
        try {
            return (
                  data.plant.toLowerCase().includes(self.searchStr)
                || data.templateType.toLowerCase().includes(self.searchStr)
                || data.templateName.toLowerCase().includes(self.searchStr))
            && (self.selectedPlant === '' ? true : data.plant === self.selectedPlant)
            && (self.selectedType === '' ? true : data.templateType === this.selectedType);
        } catch (e) {
          return false;
        }
      });
      this.dataSource = new MatTableDataSource(filteredData);
      this.dataSource.paginator = this.wspaginator;
    } else if (this.show[1]){
      const self = this;
      const filteredData = this.opswsList.filter(data => {
        try {
            return (
                  data.plant.toLowerCase().includes(self.searchStr)
                || data.templateType.toLowerCase().includes(self.searchStr)
                || data.templateName.toLowerCase().includes(self.searchStr))
            && (self.selectedPlant === '' ? true : data.plant === self.selectedPlant)
            && (self.selectedType === '' ? true : data.templateType === this.selectedType);
        } catch (e) {
          return false;
        }
      });
      this.OpsdataSource = new MatTableDataSource(filteredData);
      this.OpsdataSource.paginator = this.opspaginator;
    }
  }

  editTemplate(template: any) {
    const index = this.plants.findIndex( plant => {
      return plant.id === template.plantId;
    });
    template.countryId = this.plants[index].countryId;
    template.cityId = this.plants[index].cityId;

    if (template.templateType.toLowerCase() === 'regr') {
      template.tTypeId = 1;
      sessionStorage.setItem('regTemplate', JSON.stringify(template));
      this._router.navigate(['setup-reg-lab-template', this.selectedPlant]);
      return;
    } else {
      template.tTypeId = 2;
      sessionStorage.setItem('tPartyTemplate', JSON.stringify(template));
      this._router.navigate(['setup-tparty-lab-template', this.selectedPlant]);
      return;
    }
  }

  openCreateNewLabDialog(): void {
    let selectedPId = 0;
    if (this.selectedPlant) {
      const selected = this.plants.find((element) => {
        if (element.value === this.selectedPlant) {
          return element.id;
        }
      });
      selectedPId = selected.id;
    }
    const dialogRef = this.dialog.open(CreateLabThirdPartyTempDialogComponent, {
        width: '400px',
        data: {
          plants: this.plants,
          selectedPlant: selectedPId
        }
    });
    const sub = dialogRef.componentInstance.createTPartyEvent.subscribe(
      res => {
        dialogRef.componentInstance.closeDialog();
        if (res.tempName && res.selectedPlant) {
          if (res.tempName.trim() !== '') {
            this.saveTemplate(res.tempName, res.selectedPlant);
          }
        }
      }
    );
  }

  public saveTemplate(name, plant) {
    const formData = {
      action : 'Create',
      labWstemplateId: 0,
      plantId: plant,
      templateName: name,
      templateType: '3PTY'
    };
    // this.selectedPlant = plant;
    // this.filterTemplate('plant', plant);
    this.adminService.createTPartyLabTemplate(formData).subscribe(
      (data: any) => {
        if (data.status === 'success') {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: 'Third Party Template created successfully' });
          this.getLabTemplates();
          const selected = this.plants.find((element) => {
            if (element.id === plant) {
              return element.value;
            }
          });
          this.prevPlantId = selected.value;
        } else {
          this.errorservice.showerror({ status: data.status, statusText: data.message });
        }
      },
      (err: any) => {
        console.log('Failed');
      }
    );

  }
}


// Create New lab 3rd party template
@Component({
  selector: 'app-create-lab-third-party-temp-dialog',
  templateUrl: './createlabthirdpartytemp-dialog.component.html',
  styleUrls: ['../../common/dialog/dialog.component.css', './worksheet-templates.component.css']
})

export class CreateLabThirdPartyTempDialogComponent implements OnInit {
  plants: any;
  selectedPlant: any;

  @Output() createTPartyEvent = new EventEmitter<any>(true);

  constructor(
    public dialogRef: MatDialogRef<CreateLabThirdPartyTempDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData ) {  }

    ngOnInit () {
      this.plants = this.data['plants'];
      this.data['selectedPlant'] = this.data['selectedPlant'];
    }

    closeDialog(): void {
      this.dialogRef.close();
    }

    removeChinese() {
      this.data['tempName'] = this.data['tempName'].replace(/[^\x00-\x7F]/g, '');
    }

    createTName() {
      if (this.data['tempName'] && this.data['tempName'].trim() !== '') {
        if (this.data['selectedPlant']) {
          this.createTPartyEvent.emit(this.data);
        }
      }
     }
}


export interface DialogData {
  tempName: string;
  plantAcr: string;
  selectedPlant;
}
