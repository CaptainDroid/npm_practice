import { Component, OnInit, ViewChild } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CommonService } from '../../../../services/common.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css' ]
})
export class UserListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: any;
  plants: any;
  roles: any;
  selectedPlant: any;
  selectedRole: any;
  selectedStatus: any;
  userslist: any;
  filterString;
  displayedColumns: string[] = ['user', 'plant', 'language', 'regDate', 'status', 'timeZone', 'role', 'emailGroup', 'action'];
  paramPlant: any;

  constructor(
    public adminService: AdminService,
    private commonservice: CommonService,
    private router: ActivatedRoute,
  ) {
    this.commonservice.getplants().subscribe(
      (val: any) => {
        const plantsresponse = val['data'];
        const countries = plantsresponse['countries'];
        const plantCodeList = [];
        countries.forEach(country => {
          const cities = country['cities'];
          cities.forEach(city => {
            const plants = city['plants'];
            plants.forEach(plant => {
              const plantCode = {
                id: plant.id,
                value: plant.acronym,
                plantName: plant.name,
                countryId: country.id,
                countryName: country.name,
                cityId: city.id
              };
              plantCodeList.push(plantCode);
            });
          });
        });
        this.plants = plantCodeList;
        // this.preSelectPlant();
      });
    // Get Roles
    this.adminService.getRoles()
      .subscribe((response: any) => {
        this.roles = response.data;
      });
  }

  ngOnInit() {
    const self = this;
    self.selectedRole = '';
    self.selectedStatus = '';
    self.filterString = '';
    this.adminService.getUsers()
      .subscribe((data: any) => {
        data.data.users.forEach( user => {
          user.userPlant.sort((a, b) => a.toString().toLowerCase() < b.toString().toLowerCase() ? -1 :
          (a.toString().toLowerCase() > b.toString().toLowerCase() ? 1 : 0));
        });
        this.userslist =  data.data.users;
        const users = data.data.users;
        if (this.router.params['value'].plantid) {
          self.selectedPlant = this.router.params['value'].plantid;
        } else {
          self.selectedPlant = '';
        }
        this.filterusers('', '');
        // this.dataSource = new MatTableDataSource(users);
        // if (this.dataSource) {
        //   this.dataSource.paginator = this.paginator;
        // }
        // this.preSelectPlant();
      });
  }

  applyFilter(filterValue: string) {
    this.filterString = filterValue.toLowerCase();
    if (this.selectedPlant === '' && this.selectedRole === '' && this.selectedStatus === '') {
      if (this.dataSource) {
        this.dataSource.filter = filterValue.trim().toLowerCase();
      }
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    } else {
      this.filterusers('', '');
    }
  }

  filterusers(filtertype: any, filtervalue: any) {
    const self = this;
    const filteredData = this.userslist.filter(data => {
      try {
          return (
                data.userName.toLowerCase().includes(self.filterString)
              || data.roleName.toLowerCase().includes(self.filterString)
              || data.status.toLowerCase().includes(self.filterString)
              || data.userPlant.some(plant => plant.toLowerCase().includes(self.filterString))
              || data.language.toLowerCase().includes(self.filterString)
              || data.regDate.toLowerCase().includes(self.filterString)
              || data.userTypeName.toLowerCase().includes(self.filterString)
              || data.userEmailGroup.some(email => email.toLowerCase().includes(self.filterString)))
          && (self.selectedPlant === '' ? true : data.userPlant.indexOf(self.selectedPlant) !== -1)
          && (self.selectedRole === '' ? true : data.roleName.toLowerCase() === self.selectedRole.toLowerCase())
          && (self.selectedStatus === '' ? true : data.status.toLowerCase() === self.selectedStatus.toLowerCase());
      } catch (e) {
        return false;
      }
    });
    this.dataSource = new MatTableDataSource(filteredData);
    this.dataSource.paginator = this.paginator;
    // this.applyFilter(self.filterString);
  }


  /**
   * Function to show the users belonging to the first plant in the list
   */
  preSelectPlant(): void {
    if (this.plants && this.plants.length) {
      if (this.dataSource) {
        this.selectedPlant = this.plants[0].value;
        this.filterusers('', '');
      }
    }
  }

}
