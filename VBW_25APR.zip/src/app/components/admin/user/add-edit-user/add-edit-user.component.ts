import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatDialog, DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { FormControl, FormGroupDirective, FormGroup, NgForm, Validators, FormBuilder, FormArray } from '@angular/forms';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { AdminService } from '../../../../services/admin.service';
import { CommonService } from '../../../../services/common.service';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { AppDateAdapter, APP_DATE_FORMATS } from '../../../commercial/customer-contract/date.adapter';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrls: ['./add-edit-user.component.css',
    '../../../../../assets/css/events.css'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
  ]
})
export class AddEditUserComponent implements OnInit {

  plants: any;
  roles: any;
  emailGroups: any;
  cities: any;
  userId: any;
  userData: any;
  mode = 'create';
  submitted = false;
  userTypes: any;
  invalidInput = false;
  pipe = new DatePipe('en-gb');
  offset = new Date().getTimezoneOffset();
  selectedPlant: any;
  paramPlant: any;
  selectedUserType: any;

  constructor(
    private router: ActivatedRoute,
    public navigaterouter: Router,
    public dialog: MatDialog,
    private route: Router,
    private errorservice: ErrorserviceService,
    public adminService: AdminService,
    public commonservice: CommonService,
    private datePipe: DatePipe
  ) {
    this.userData = this.prepareuserobj();
    this.router.params.subscribe((params: Params) => {
      this.userId = params['id'];
      if (this.userId !== '' && this.userId !== null &&  this.userId !== undefined) {
        this.mode = 'update';
      }
    });
    this.commonservice.getplants().subscribe(
      (plantresponse: any) => {
        this.plants = [];
        for (let i = 0; i < plantresponse.data.countries.length; i++) {
          for (let j = 0; j < plantresponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < plantresponse.data.countries[i].cities[j].plants.length; k++) {
                  const plantobj = plantresponse.data.countries[i].cities[j].plants[k];
                  plantobj.countryId = plantresponse.data.countries[i].id;
                  plantobj.citiId = plantresponse.data.countries[i].cities[j].id;
                  plantobj.checked = false;
                  this.plants.push(plantobj);
              }
          }
      }
      if (this.router.params['value'].plantid) {
        this.paramPlant = this.router.params['value'].plantid;
        const selected = this.plants.find((element) => {
          if (element.acronym === this.router.params['value'].plantid) {
            return element.checked = true;
          }
        });
        this.selectedPlant =  selected.id;
      }
      this.plants.sort((a, b) => a.acronym.toString().toLowerCase() < b.acronym.toString().toLowerCase() ?
      -1 : (a.acronym.toString().toLowerCase() > b.toString().toLowerCase() ? 1 : 0));
      if (this.mode === 'update' && this.userId !== '' && this.userId !== null &&  this.userId !== undefined) {
        this.getuserdata(this.userId);
      } else {
        this.userData.regDate = new Date();
      }
    });
  }

  getuserdata(userid: any) {
    if (userid) {
      this.adminService.getUserDetails(this.userId).subscribe((data: any) => {
        const userObj = data.data.user;
        this.plants.forEach(plant => {
          userObj.userPlant.forEach(usplant => {
            if (usplant === plant.id) {
              plant.checked = true;
            }
          });
        });
        this.userData.userId = userObj.id;
        this.userData.cityId = userObj.city.cityId;
        this.userData.userName = userObj.userName;
        this.userData.userType = userObj.userType;
        this.userData.prefLanguageId = userObj.language.id.toString();
        this.userData.regDate = userObj.regDate;
        this.userData.roleId = userObj.roles.id;
        this.userData.userEmailGroup = userObj.userEmailGroup;
        this.userData.userPlant = userObj.userPlant;
        this.userData.status = userObj.status;

        if (this.userTypes.parameters) {
            const userType = this.userTypes.parameters.filter( typ => {
              return typ.paramID === this.userData.userType;
            });
            if(userType.length > 0) {
              this.selectedUserType = userType[0].paramVal;
            }
        }
      });
    }
  }

  // Prevent blank space to enter intially
  onKeydown(e) {
    if (e.target.value.length == 0) {
      if (e.keyCode == 32) {
          e.preventDefault();
      }
    }
  }

  handleText() {
    this.userData.userName = this.userData.userName.trim()
    var format = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (this.userData.userName && (!format.test(this.userData.userName))) {
      this.invalidInput = true;
    } else {
      this.invalidInput = false;
    }
  }

  clearDate(val) {
    this.userData[val] = null;
  }

  validateInput(event) {
    var format = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (this.userData.userName && (!format.test(this.userData.userName))) {
      this.invalidInput = true;
    } else {
      this.invalidInput = false;
    }
  }

  ngOnInit() {
    // const loggedInUser = JSON.parse(localStorage.getItem('user'));
    // this.userId = loggedInUser.amr;

    this.adminService.getCities(26)
      .subscribe((response: any) => {
        this.cities = response.data.country.cities;
      });

    this.adminService.getEmailGroups()
      .subscribe((response: any) => {
        const emailGroupArray = response.data.emailgroups;
        this.emailGroups = emailGroupArray;
      });

    this.adminService.getRoles()
      .subscribe((response: any) => {
        this.roles = response.data;
      });

      this.commonservice.getUserTypes()
      .subscribe((response: any) => {
        this.userTypes = response.data;
        if (this.userTypes.parameters && this.mode === 'update') {
          if (this.userData.userType) {
            const userType = this.userTypes.parameters.filter( typ => {
              return typ.paramID === this.userData.userType;
            });
            if(userType.length > 0) {
              this.selectedUserType = userType[0].paramVal;
            }
          }
        }
      });
  }

  onSubmit() {
    this.submitted = true;
    const userPlant = [];
    this.plants.forEach(plant => {
        if (plant.checked) {
          userPlant.push(plant.id);
        }
    });
    if (!userPlant.length) {
      this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00286' });
      return;
    }
    this.userData.userPlant = userPlant;
    const userReq = {...this.userData};
    userReq.regDate = this.datePipe.transform(userReq.regDate, 'dd/MMM/yy');
    userReq.prefLanguageId = parseInt(userReq.prefLanguageId, 10);
    if (!this.invalidInput) {
      if (this.mode === 'create') {
        userReq.action = 'Create';
          this.adminService.postUser(userReq)
            .subscribe((response: any) => {
              if (response.status !== 'success') {
                this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
                return;
              } else {
                this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00488' });
                if (this.paramPlant) {
                  this.route.navigate(['/user-list/' + this.paramPlant]);
                } else {
                  this.route.navigate(['/user-list/']);
                }
              }
            });
      } else {
        userReq.action = 'Update';
        userReq.userId = parseInt(this.userId, 10);
        this.adminService.postUser(userReq)
          .subscribe((response: any) => {
            if (response.status !== 'success') {
              this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
              return;
            } else {
              this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00795' });
              if (this.paramPlant) {
                this.route.navigate(['/user-list/' + this.paramPlant]);
              } else {
                this.route.navigate(['/user-list/']);
              }
            }
          });
      }
    }
    }

  /**
  * Cancel Confirmation Dialog
  */
  openConfirmationDialog() {
    const message =  this.commonservice.gettranslate('Are you sure want to discard changes?');
        const dialogRef = this.dialog.open(DialogComponent, {
            width: '500px',
            data: {
                'type': 'yesno',
                'title': 'data.L00224',
                'message': 'data.L00366'
            }
        });
        const sub = dialogRef.componentInstance.okCallback.subscribe( result => {
            dialogRef.componentInstance.closeDialog();
            let userlistUrl = 'user-list/'
            if (this.paramPlant) {
              userlistUrl = 'user-list/' + this.paramPlant;
            } else {
              userlistUrl = 'user-list/';
            }
            this.navigaterouter.navigate([userlistUrl]);
        });
  }

  prepareuserobj() {
    return {
    'action': 'create',
    'userId' : 0,
    'cityId': 0,
    'userName': '',
    'userType': '',
    'prefLanguageId': 0,
    'status': 'New',
    'regDate': '',
    'roleId': 0,
    'userEmailGroup': [],
    'userPlant': []
   };
  }
}

