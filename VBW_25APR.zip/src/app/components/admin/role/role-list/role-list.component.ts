import { Component, OnInit, ViewChild } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-role-list',
  templateUrl: './role-list.component.html',
  styleUrls: ['./role-list.component.css']
})
export class RoleListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: any;
  displayedColumns: string[] = ['emailgroup', 'description', 'action'];
  searchFilter: any;

  constructor(public adminService: AdminService,
    private errorservice: ErrorserviceService,
    private route: Router,
    private dialog: MatDialog) { }

  ngOnInit() {
    this.getRoleList();
  }

  getRoleList() {
    this.adminService.getRoles()
    .subscribe((response: any) => {
      this.dataSource = new MatTableDataSource(response.data);
      if (this.dataSource) {
        this.dataSource.paginator = this.paginator;
      }
    });
  }

  /**
   * Delete Confirmation Dialog
   */
  openConfirmationDialog(role) {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'roles', type: 'delete' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.deleteEventEscalation(role);
      }
    });
  }

  /**
   * Delete Role
   */
  deleteEventEscalation(role) {
    role.action = 'Delete';
    this.adminService.postRole(role)
    .subscribe((response: any) => {
      if (response.status !== 'success') {
        this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
        return;
      } else {
        this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00810' });
        this.searchFilter = '';
        this.getRoleList();
      }
    });

  }

  applyFilter(filterValue: string) {
    if (this.dataSource) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}
