import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from "@angular/material";
import { FormControl, FormGroupDirective, FormGroup, NgForm, Validators, FormBuilder } from '@angular/forms';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-add-edit-role',
  templateUrl: './add-edit-role.component.html',
  styleUrls: ['./add-edit-role.component.css', '../../../../../assets/css/events.css']
})
export class AddEditRoleComponent implements OnInit {
  userId: any;
  singleRoleId: any;
  submitted: boolean = false;
  actionGroupArray: any;
  selectedGroupArray: any = [];
  index: number;
  addEditRoleForm: FormGroup;
  roleTypes: any;
  actionList: any = [];
  newActionGroup: any = [];
  roleData: any;
  valid: boolean = true;
  invalidDesc: boolean = false;
  invalidName: boolean = false;

  constructor(
    private router: ActivatedRoute,
    public dialog: MatDialog,
    private route: Router,
    private errorservice: ErrorserviceService,
    public adminService: AdminService,
    private formBuilder: FormBuilder
  ) {
    this.roleData = this.prepareuserobj();
    this.router.params.subscribe((params: Params) => {
      this.singleRoleId = params['id'];      
    });
    this.adminService.getActionGroup(26, 1, 4)
    .subscribe((data: any) => {
      let result = data.data.country.city.plant.result;
      this.actionGroupArray = [];
      for (let m = 0; m < result.length; m++) {                 
        const roleobj = result[m];
        roleobj.checked = false;
        this.actionGroupArray.push(roleobj);
      }
      if (this.singleRoleId) {
        this.getRoleDetail()
      }
    })
  }

  getRoleDetail(){
    this.adminService.getSingleRole(this.singleRoleId).subscribe((val: any) => {
      this.roleData.roleName = val.data.roleName;
      this.roleData.roleDescription = val.data.roleDescription;
      this.roleData.roleTypeId = val.data.roleTypeId;
      val.data.roleActiongroups.forEach((key, index) => {
        this.actionList.push(key.actionGroupId)
      })
      if(this.roleData.roleTypeId == 1 || this.roleData.roleTypeId == 2){
        for (var i in this.actionGroupArray) {
          this.actionGroupArray[i].checked = false;
        }
      }
      else{
        for (var i in this.actionGroupArray) {
          if (this.actionList.indexOf(this.actionGroupArray[i].actionGroupId) != -1) {  
            this.actionGroupArray[i].checked = true;
          }
        }
      }
    });
  }

  
  ngOnInit() {
    let loggedInUser = JSON.parse(localStorage.getItem('user'));
    this.userId = loggedInUser.amr;
    
    this.adminService.getRoleType()
      .subscribe((data: any) => {
        this.roleTypes = data.data.roletypes;
    })
  }

  // Prevent blank space to enter intially
  onKeydown(e){
    if (e.target.value.length == 0) {
      if (e.keyCode == 32) {
          e.preventDefault();
      }
    }
  }

  validateInput(field){
    var format = /^[a-zA-Z][a-zA-Z0-9-_\s!@#$%^&*(),.?"';:{}|<>+=]*$/;
    if(field === "name"){
      if (this.roleData.roleName && (!format.test(this.roleData.roleName))) {
        this.invalidName = true;
      } else {
        this.invalidName = false;
      }
    }
    else{
      if (this.roleData.roleDescription && (!format.test(this.roleData.roleDescription))) {
        this.invalidDesc = true;
      } else {
        this.invalidDesc = false;
      }
    }
  }

  handleText(event, field){
    if(field === "name"){
      this.roleData.roleName = this.roleData.roleName.trim();
    }
    else{
      this.roleData.roleDescription = this.roleData.roleDescription.trim()
    }
  }

  handleSelect(id){
    console.log(id,this.actionGroupArray)
    if(id == 1 || id == 2){
      for (var i in this.actionGroupArray) {
        this.actionGroupArray[i].checked = false;
      }
    }
  }

  prepareuserobj() {
    return {
    'action': 'create',
    'roleTypeId' : '',
    'roleId': 0,
    'tenantId': 1,
    'roleName': '',
    'roleDescription': '',
    'roleActiongroups': ''
   };
  }

  onChange(event) {
  }

  onSubmit() {
    console.log(this.invalidDesc, this.invalidName)
    this.submitted = true;
    this.valid = true;
    const roleList = [];
    this.actionGroupArray.forEach(role => {
      if (role.checked) {
        role.tenantId = 0;
        role.roleId = this.singleRoleId;
        roleList.push(role);
      }
    });
    if(!roleList.length){
      if (this.roleData.roleTypeId && (this.roleData.roleTypeId != 1 && this.roleData.roleTypeId !=2)) {
        this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00799' });
        return;
      }
    }
    if(!this.roleData.roleName || !this.roleData.roleDescription || !this.roleData.roleTypeId){
      this.valid = false
    }
    else{
      this.valid = true
    }
    const userReq = this.roleData;
    var message = ""
    userReq.roleActiongroups = roleList;
    if(this.singleRoleId){
      userReq.action = "Update"
      userReq.updatedAt = ""
      userReq.updatedBy = 1
      userReq.roleId = this.singleRoleId
      message = "data.L00795"
    }
    else{
      userReq.action = "Create"
      userReq.createdBy = 1
      userReq.createdAt = ""
      message = "data.L00488"
    }
    if((this.valid) && !(this.invalidDesc) && !(this.invalidName)){
      this.adminService.postRole(userReq)
      .subscribe((response: any) => {
        if (response.status !== 'success') {
          this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
          return;
        } else {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: message });
          this.route.navigate(['/roles']);
        }
      });
    }
  }

  /**
* Cancel Confirmation Dialog
*/
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'roles' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

}
