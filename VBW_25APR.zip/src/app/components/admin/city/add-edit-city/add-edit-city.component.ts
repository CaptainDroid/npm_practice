import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material';
import { FormControl, FormGroupDirective, FormGroup, NgForm, Validators } from '@angular/forms';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { AdminService } from 'src/app/services/admin.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-edit-city',
  templateUrl: './add-edit-city.component.html',
  styleUrls: ['./add-edit-city.component.css', '../../../../../assets/css/events.css']
})
export class AddEditCityComponent implements OnInit {

  public selectedCity;
  public cityId;
  public countries = [];
  public cityDetails;
  public isEdit = false;
  public submitted = false;
  /**
   * Declare and initialize the form
   */
  public addCityForm = new FormGroup({
    cityName: new FormControl('', Validators.compose([Validators.required, Validators.pattern(/^(?!\s*$).+/)])),
    countryId: new FormControl({value: '', disabled: this.isEdit}, Validators.compose([Validators.required]))
  });

  constructor(private _router: Router,
              private _route: ActivatedRoute,
              private _adminService: AdminService,
              private _errorService: ErrorserviceService,
              public dialog: MatDialog,
              private _datePipe: DatePipe) { }

  ngOnInit() {
    /**
     * Get list of all the countries
     */
    this._adminService.getCountries().subscribe(
      data => {
        if (data['status'] !== 'success') {
          this._errorService.showerror({status: data['status'], statusText: data['message'] });
          return;
        }
        const res = data['data'];
        res.countries.forEach(country => {
          this.countries.push({
            id: country.id,
            name: country.name
          });
        });
      });


    /**
     * Check if editing a city, and load respsective data
     */
    this.selectedCity = JSON.parse(sessionStorage.getItem('selectedCity'));
    this._route.params.subscribe((params: Params) => {
      const id = params['id'];
      this.cityId = id;
      if (id) {
        this.isEdit = true;
        this.addCityForm.controls['cityName'].setValue(this.selectedCity.name);
        this.addCityForm.controls['countryId'].setValue(this.selectedCity.countryId);
      }
    });
  }


  // convenience getter for easy access to form fields
  get f() { return this.addCityForm.controls; }

  // Restrict blank spaces in the beginning
  onKeydown(e) {
    if (e.target.value.trim().length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  onSubmit() {
    this.submitted = true;
    const now: any = new Date();
    const date_now: any = this._datePipe.transform(now, `yyyy-MM-dd'T'HH:mm:ss.SSS'Z'`);
    this.cityDetails = {...this.addCityForm.value};
    if (this.addCityForm.invalid) {
      return;
    }

    const action = this.isEdit ? 'Update' : 'Create';
    let msg;

    this.cityDetails.action = action;
    this.cityDetails.cityId = this.isEdit ? this.selectedCity.id : 0;
    if (!this.isEdit) {
      this.cityDetails.createdAt = date_now;
      this.cityDetails.createdBy = 0;
      msg = 'data.L00488';
    } else {
      this.cityDetails.updatedBy = 0;
      this.cityDetails.updatedAt = date_now;
      msg = 'data.L00795';
    }
    this.cityDetails.tenantId = 1;
    this._adminService.postCity(this.cityDetails, this.cityDetails.countryId).subscribe(
      (data: any) => {
        if (data['status'] !== 'success') {
          this._errorService.showerror({status: data['status'], statusText: data['message'] });
          return;
        } else {
          this._errorService.showerror({ type: 'Info', status: data['status'], statusText: msg});
          this._router.navigate(['cities']);
        }
      });
  }

  /**
* Cancel Confirmation Dialog
*/
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'cities' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  ngOnDestroy() { // tslint:disable-line
    sessionStorage.removeItem('selectedCity');
  }

}
