export interface City {
    id: number;
    countryName: string;
    countryId: number;
    cityName: string;
    acronym: string;
}