import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { AdminService } from 'src/app/services/admin.service';
import {ErrorserviceService} from 'src/app/services/errorservice.service';
import { Router } from '@angular/router';
import { City } from './city';

@Component({
  selector: 'app-city-list',
  templateUrl: './city-list.component.html',
  styleUrls: ['./city-list.component.css','../../../../../assets/css/events.css']
})
export class CityListComponent implements OnInit {

  @ViewChild(MatTableDataSource) dataSource: MatTableDataSource<City>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  public cities: City[];
  public displayedColumns = ["countryName", "cityName", "action"];
  public pageSize = 10;

  constructor( private _adminService: AdminService,
               private _errorService: ErrorserviceService,
               private _router: Router) { }

  ngOnInit() {

    /**
     * Get list of all cities
     */
    this._adminService.getCityList().subscribe(
      data => {
        this.cities = [];
        if(data["status"] !== 'success') {
          this._errorService.showerror({status: data["status"], message: data["message"]});
          return;
        }
        let res = data["data"];
          res.cities.forEach(city => {
            this.cities.push({
              id: city.id,
              countryName: city.countryname ? city.countryname : '',
              countryId: city.countryId,
              cityName: city.name,
              acronym: city.acronym
            })
        });

        this.dataSource = new MatTableDataSource(this.cities);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
        this.dataSource.filterPredicate = function(data: any, filter: string): boolean {
          return data.countryName.toLowerCase().includes(filter) 
              || data.cityName.toLowerCase().includes(filter);
        }
      }
    );
  }

  editCity(element) {
    const cityData = {
      id: element.id,
      acronym: element.acronym,
      name: element.cityName,
      countryId: element.countryId,
      countryName: element.countryName
    };
    sessionStorage.setItem('selectedCity', JSON.stringify(cityData));
    this._router.navigate(['/edit-city/' + cityData.id]);
    return;
  }

  /**
   * plant Search
   * @param filterValue 
   */
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
