import { Component, OnInit, ViewChild } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CommonService } from '../../../services/common.service';

export interface Tags {
  tagId: number;
  plantAcronym: string;
  plantId: number;
  tagname: string;
  tagtypeName: string;
  tagtypeCode: string;
  tagDesc: {
    en: string;
    cn: string;
  };
}


@Component({
  selector: 'app-tags',
  templateUrl: './tags.component.html',
  styleUrls: ['./tags.component.css']
})
export class TagsComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: any;
  plants: any;
  roles: any;
  selectedPlant: any;
  selectedSource: any;
  tagsList: any;
  filterString;
  displayedColumns: string[] = ['plantAcronym', 'tagname', 'tagtypeName', 'desc_en', 'desc_ch', 'isActive'];
  tagTypes = [
    {tagTypeName: 'SEST', tagTypeCode: 'SEST'},
    {tagTypeName: 'LABT', tagTypeCode: 'LABT'},
    {tagTypeName: 'OPST', tagTypeCode: 'OPST'},
    {tagTypeName: 'PRED', tagTypeCode: 'PRED'}
  ];
  saveTagList = [];

  constructor(
    public adminService: AdminService,
    private _commonService: CommonService,
    private _errorService: ErrorserviceService
  ) {
    this._commonService.getplants().subscribe(
      (val: any) => {
        const plantsresponse = val['data'];
        const countries = plantsresponse['countries'];
        const plantCodeList = [];
        countries.forEach(country => {
          const cities = country['cities'];
          cities.forEach(city => {
            const plants = city['plants'];
            plants.forEach(plant => {
              const plantCode = {
                id: plant.id,
                value: plant.acronym,
                plantName: plant.name,
                countryId: country.id,
                countryName: country.name,
                cityId: city.id
              };
              plantCodeList.push(plantCode);
            });
          });
        });
        this.plants = plantCodeList;
        // this.preSelectPlant();
      });

  }

  ngOnInit() {
    const self = this;
    self.selectedPlant = '';
    self.selectedSource = '';
    self.filterString = '';
    this.adminService.getAllTags().subscribe((data: any) => {
        this.tagsList = data.data.tags;
        const tags = data.data.tags;
        this.dataSource = new MatTableDataSource(tags);
        if (this.dataSource) {
          this.dataSource.paginator = this.paginator;
        }
        // this.preSelectPlant();
      });
  }

  applyFilter(filterValue: string) {
    this.filterString = filterValue.toLowerCase();
    /**
     * This piece of code had an edge case where the search would not work properly
     * Simply calling filterTags would give the expected result. Could be a LITTLE slower, but negligible.
     * Fix here if needed.
     * Just change filterTags to return only by the selected dropdowns, and then filter according to the searchString
     */

    // if (this.selectedPlant === '' && this.selectedSource === '') {
    //   if (this.dataSource) {
    //     this.dataSource.filter = filterValue.trim().toLowerCase();
    //   }
    //   if (this.dataSource.paginator) {
    //     this.dataSource.paginator.firstPage();
    //   }
    // } else {
    //   this.filterTags('', '');
    // }
    this.filterTags('', '');
  }

  filterTags(filtertype: any, filtervalue: any) {
    const self = this;
    const filteredData = this.tagsList.filter(data => {
      try {
          return (
                data.tagname.toLowerCase().includes(self.filterString)
              || data.acronym.toLowerCase().includes(self.filterString)
              || data.tagTypeCode.toLowerCase().includes(self.filterString)
              || data.tagDesc.cn.toLowerCase().includes(self.filterString)
              || data.tagDesc.en.toLowerCase().includes(self.filterString))
          && (self.selectedPlant === '' ? true : data.acronym.toLowerCase() === self.selectedPlant.toLowerCase())
          && (self.selectedSource === '' ? true : data.tagTypeCode.toLowerCase() === self.selectedSource.toLowerCase());
      } catch (e) {
        return false;
      }
    });
    this.dataSource = new MatTableDataSource(filteredData);
    this.dataSource.paginator = this.paginator;
    // this.applyFilter(self.filterString);
  }


  /**
   * Function to show the users belonging to the first plant in the list
   */
  preSelectPlant(): void {
    if (this.plants && this.plants.length) {
      if (this.dataSource) {
        this.selectedPlant = this.plants[0].value;
        this.filterTags('', '');
      }
    }
  }

  /**
   * Function to store the elements whose status has been changed
   */
  public toggleActive(element) {
    element.isActive = element.isActive ? false : true;
    const index = this.saveTagList.findIndex(tag => {
      return tag.sensorTagNameVbw === element.tagname;
    });
    if (index === -1) {
      this.saveTagList.push({
        sensorTagNameVbw: element.tagname,
        tagTypeCode: element.tagTypeCode,
        isActive: element.isActive,
        isDeleted: !element.isActive
      });
    } else {
      this.saveTagList[index].isActive = element.isActive;
      this.saveTagList[index].isDeleted = !element.isActive;
    }
  }

  /**
   * Save the tags
   */
  public saveTags() {
    this.adminService.saveSensorTags(this.saveTagList).subscribe(
      (data: any) => {
        if (data.status === 'success') {
          this._errorService.showerror({ type: 'Info', status: '', statusText: 'Saved Successfully' });
          this.saveTagList = [];
        } else {
          this._errorService.showerror({ status: data.status, statusText: data.message });
        }
      },
      (err: any) => {
        console.log('Failed');
      }
    );
  }
}
