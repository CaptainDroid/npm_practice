import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material';
import { FormControl, FormGroupDirective, FormGroup, NgForm, Validators } from '@angular/forms';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { AdminService } from 'src/app/services/admin.service';

function alphanumericValidation(control: FormControl) {
  const format = /^[a-zA-Z][a-zA-Z0-9-_\s!@#$%^&*(),.?"';:{}|<>+=]*$/;
  if (control.value.trim().length > 0) {
    if (!format.test(control.value)) {
      return {
        alpha: true
      };
    }
  }
  return null;
}

@Component({
  selector: 'app-add-update-plant',
  templateUrl: './add-update-plant.component.html',
  styleUrls: ['./add-update-plant.component.css', '../../../../../assets/css/events.css']
})
export class AddUpdatePlantComponent implements OnInit {

  submitted = false;
  processArray: any;
  timeZones: any;
  plantDetails: any;
  plantId: number;
  selectedPlant: any;
  cities: any;
  addPlantForm: FormGroup;
  invalidLat = false;
  invalidLong = false;
  invalidInput = false;

  constructor(
    private router: ActivatedRoute,
    public dialog: MatDialog,
    private route: Router,
    private errorservice: ErrorserviceService,
    public adminService: AdminService
  ) {
    this.selectedPlant = JSON.parse(sessionStorage.getItem('selectedPlant'));
    this.router.params.subscribe((params: Params) => {
      const id = params['id'];
      this.plantId = id;
      if (id) {
        this.adminService.getSinglePlant(id, this.selectedPlant.countryId, this.selectedPlant.cityId).subscribe((data: any) => {
          const result: any = data.data.country.city.plant;
          this.addPlantForm.controls['plantName'].setValue(result.name);
          this.addPlantForm.controls['acronym'].setValue(result.acronym );
          this.addPlantForm.controls['cityId'].setValue(result.cityId);
          this.addPlantForm.controls['latitude'].setValue(result.latitude);
          this.addPlantForm.controls['longitude'].setValue(result.longitude);
          this.addPlantForm.controls['processId'].setValue(result.processId);
          this.addPlantForm.controls['timezoneId'].setValue(result.timezoneId);
          this.addPlantForm.controls['installedCapacity'].setValue(result.installedCapacity);
        });
      }
    });
   }

  // convenience getter for easy access to form fields
  get f() { return this.addPlantForm.controls; }

  ngOnInit() {

    this.addPlantForm = new FormGroup({
      plantName: new FormControl('', [Validators.pattern(/^(?!\s*$).+/), alphanumericValidation]),
      acronym: new FormControl({value: '', disabled: this.plantId }, [Validators.pattern(/^(?!\s*$).+/), alphanumericValidation]),
      cityId: new FormControl(''),
      latitude: new FormControl(''),
      longitude: new FormControl(''),
      processId: new FormControl(''),
      timezoneId: new FormControl(''),
      installedCapacity: new FormControl(),

      plantId: new FormControl(0),
      tenantId: new FormControl(1),
      isDeleted: new FormControl(0),
    });

    /* Process drop down service*/
    this.adminService.getProcesses().subscribe((data: any) => {
      this.processArray = data.data.processes;
    });

    /* Process drop down service*/
    this.adminService.getTimeZone().subscribe((data: any) => {
      this.timeZones = data.data.timezones;
    });

    /* City drop down service*/
    this.adminService.getCityList().subscribe((data: any) => {
      this.cities = data.data.cities;
    });
  }

  handleFloat(event) {
    const format = /^[\.\d]{1,9}(\.[\d]{1,3})?$/,
        val = event.target.value;
    if (val && (!format.test(val) || val === '.')) {
      this.invalidInput = true;
    } else {
      this.invalidInput = false;
    }
    if (this.countDecimals(event.target.value) > 3) {
      this.addPlantForm.controls[event.target.attributes.formcontrolname.nodeValue].setValue(parseFloat(event.target.value).toFixed(3));
    }
  }

  handleText(event, field) {
    if (field === 'name') {
      this.addPlantForm.controls['plantName'].setValue(event.target.value.trim());
    } else {
      this.addPlantForm.controls['acronym'].setValue(event.target.value.trim());
    }
  }

  // Prevent blank space to enter intially
  onKeydown(e) {
    if (e.target.value.length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  countDecimals(value) {
    if ((value % 1) !== 0) {
        return value.toString().split('.')[1].length;
    }
    return 0;
  }

  handleLatitude(event) {
    const format = /^(\+|-)?(?:90(?:(?:\.0{1,12})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,12})?))$/;
    const lat = event.target.value;
    if (lat && !format.test(lat)) {
      this.invalidLat = true;
    } else {
      this.invalidLat = false;
    }
  }
  handleLongitude(event) {
    const format = /^(\+|-)?(?:180(?:(?:\.0{1,12})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,12})?))$/;
    const long = event.target.value;
    if (long && !format.test(long)) {
      this.invalidLong = true;
    } else {
      this.invalidLong = false;
    }
  }
  onSubmit() {
    this.submitted = true;
    this.plantDetails = this.addPlantForm.value;
    if (this.addPlantForm.invalid) {
      return;
    }
    let action = '', message = '';
    if (this.plantId) {
      action = 'Update';
      this.plantDetails.updatedAt = '';
      this.plantDetails.updatedBy = 1;
      this.plantDetails.plantId = this.plantId;
      message = 'data.L00795';
    } else {
      action = 'Create';
      this.plantDetails.createdAt = '';
      this.plantDetails.createdBy = 1;
      message = 'data.L00488';
    }
    this.plantDetails.action = action;
    if (!this.invalidLat && !this.invalidLong && !this.invalidInput) {
      this.adminService.postPlant(this.plantDetails).subscribe(
        (data: any) => {
          if (data['status'] !== 'success') {
            this.errorservice.showerror({status: data['status'], statusText: data['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: data['status'], statusText: message});
            this.route.navigate(['plants']);
          }
        });
    }
  }

  /**
* Cancel Confirmation Dialog
*/
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'plants' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

}


