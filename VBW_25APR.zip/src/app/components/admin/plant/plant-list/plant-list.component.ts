import { Component, OnInit , ViewChild } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-plant-list',
  templateUrl: './plant-list.component.html',
  styleUrls: ['./plant-list.component.css', '../../../../../assets/css/events.css']
})
export class PlantListComponent implements OnInit {

  displayedColumns: string[] = ['country', 'city', 'plant', 'process', 'installedCapacity', 'timezone', 'action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  dataSource: MatTableDataSource<{}>;
  limit = 10;
  pageLimit: number[] = [10, 25, 100];
  totalLength: number;
  plantList: any;

  constructor(
    private errorservice: ErrorserviceService,
    private adminService: AdminService,
    private router: Router
  ) {

    this.adminService.getPlantsList().subscribe(
      (res: any) => {
        if (res['status'] !== 'success') {
          this.errorservice.showerror({ status: res['status'], statusText: res['message'] });
        }
        if (res['status']) {
          this.plantList = res['data'];
          const plantList = [];
          const countries = this.plantList['countries'];
          countries.forEach(country => {
            const cities = country['cities'];
            cities.forEach(city => {
              const plants = city['plants'];
              plants.forEach(plant => {
                  const plantData = {
                    'id': plant.id,
                    'process': plant.process != null ? plant.process : '' ,
                    'plant': plant.acronym != null ? plant.acronym : '',
                    'installedCapacity': plant.installedCapacity != null ? plant.installedCapacity : '',
                    'timezone': plant.timeZone != null ? plant.timeZone : '',
                    'country': country.name,
                    'city': city.name,
                    'countryId': country.id,
                    'cityId': city.id
                  };
                  plantList.push(plantData);
                });
            });
          });
          this.plantList = plantList;
        }
        this.dataSource = new MatTableDataSource(this.plantList);
        this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
          return data.process.toLowerCase().includes(filter) || data.plant.toLowerCase().includes(filter) ||
           data.installedCapacity.toString().toLowerCase().includes(filter) || data.timezone.toLowerCase().includes(filter) ||
           data.country.toLowerCase().includes(filter) || data.city.toLowerCase().includes(filter);
        };
        this.dataSource.paginator = this.paginator;
        this.totalLength = this.dataSource.data.length;
      }
    );

   }

  ngOnInit() {
  }

  editUser(row: any): void {
    const plantData = {
      countryId: row.countryId,
      cityId: row.cityId
    };
    sessionStorage.setItem('selectedPlant', JSON.stringify(plantData));
    this.router.navigate(['/edit-plant/' + row.id]);
  }

  changePage(event) {
    // sort and define paginator on page change event
    // only if the page size selected by the user is less than the total data length.
    if (this.dataSource.data.length > event['pageSize']) {
      this.dataSource.paginator = this.paginator;
    }
  }

  /**
   * plant Search
   * @param filterValue
   */
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
