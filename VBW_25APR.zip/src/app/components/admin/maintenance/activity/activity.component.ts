import { Component, Inject, OnInit, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { ActivityService } from '../../../../services/activity.service';
import { CommonService } from 'src/app/services/common.service';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.css']
})
export class ActivityComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['plantname', 'equipmentname', 'activityname', 'descriptionen', 'descriptioncn', 'isroutine', 'actions'];
  dataSource: any;
  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  activityList: any;
  selectedPlantObj: any;
  activityResponse: any;
  searchValue: any;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    public activityservice: ActivityService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    this.plants = [];
    this.activityList = [];
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.getplants(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.getplants(this.selectedPlant);
      }
    });
  }

  getplants(plantId: any) {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (plantId === 0) {
            this.activityList = [];
            this.selectedPlant = 0;
            this.getmaintenanceactivity(this.plants[0]);
          } else {
              const plantobj = this.plants.filter(plnt => {
              return plnt.id === plantId;
            });
            // this.selectedPlantObj = plantobj[0];
            this.selectedPlant = plantId;
            this.getactivitybyplantid(this.selectedPlant);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getmaintenanceactivity(plantobj) {
    this.searchValue = '';
    this.activityList = [];
    this.activityservice.getActivities().subscribe (
      data => {
        this.activityResponse = data;
        if (this.activityResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.activityResponse.status, statusText: this.activityResponse.message });
        } else {
          this.activityList = this.activityResponse.data.maintenanceActivity;
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.activityList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.activityName.toString().toLowerCase().includes(filter) ||
            data.plantAcronym.toString().toLowerCase().includes(filter) ||
            data.equipmentName.toString().toLowerCase().includes(filter) ||
            data.isRoutine.toString().toLowerCase().includes(filter) ||
            (data.description.descriptionEn !== null ? data.description.descriptionEn.toString().toLowerCase().includes(filter) : null) ||
            (data.description.descriptionCn !== null ? data.description.descriptionCn.toString().toLowerCase().includes(filter) : null);
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  selectplant(plantid: any) {
    // this.selectedPlantObj = plantObj;
    if (plantid === 0) {
      this.getmaintenanceactivity(plantid);
    } else {
      this.getactivitybyplantid(plantid);
    }
  }

  getactivitybyplantid(plantid) {
    this.searchValue = '';
    this.activityList = [];
    this.activityservice.getActivititesByPlant(plantid).subscribe(
      data => {
        this.activityResponse = data;
        if (this.activityResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.activityResponse.status, statusText: this.activityResponse.message });
        } else {
          this.activityList = this.activityResponse.data.maintenanceActivity;
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.activityList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.activityName.toString().toLowerCase().includes(filter) ||
            data.plantAcronym.toString().toLowerCase().includes(filter) ||
            data.equipmentName.toString().toLowerCase().includes(filter) ||
            data.isRoutine.toString().toLowerCase().includes(filter) ||
            (data.description.descriptionEn !== null ? data.description.descriptionEn.toString().toLowerCase().includes(filter) : null) ||
            (data.description.descriptionCn !== null ? data.description.descriptionCn.toString().toLowerCase().includes(filter) : null);
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  editActivity(actionType, activityId): void {
     if (actionType === 'edit') {
        this.router.navigate(['editActivity/' + this.selectedPlant + '/' + activityId]);
     }
   }

}

@Component({
  selector: 'app-addActivity',
  templateUrl: './addActivity.component.html',
  styleUrls: ['./activity.component.css']
})

export class AddActivityComponent implements OnInit {

  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  selectedPlantObj: any;
  addActivityData: any;
  activityData: any;
  activityDataResponse: any;
  saveActivityResponse: any;
  equipmentDataResponse: any;
  equipmentData: any;
  pageParams: any;
  mode: any;
  descriptionCNError: any;
  validateDescCN: any;


  constructor(
    private route: ActivatedRoute,
    public router: Router,
    public activityservice: ActivityService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog
  ) {
    this.route.params.subscribe(params => {
      this.mode = 'new';
      this.addActivityData = this.preparereq();
      this.pageParams = params;
      if (this.pageParams.plantid) {
        this.addActivityData.plantId = parseInt(this.pageParams.plantid, 10);
      } else {
        this.addActivityData.plantId = 0;
      }
      if (this.pageParams.activityId) {
        this.mode = 'edit';
        this.getActivityData(this.addActivityData.plantId, this.pageParams.activityId);
      }
    });
   }

   getActivityData(plantId, activityId) {
    this.activityservice.getActivitiesById(activityId).subscribe(
      data => {
        this.activityDataResponse = data;
        if (this.activityDataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.activityDataResponse.status, statusText: this.activityDataResponse.message });
        } else {
          this.addActivityData = this.activityDataResponse.data;
          console.log(this.addActivityData);
        }
      }
    );

  }

  getEquipments() {
    this.equipmentData = [];
    this.activityservice.getEquipmentList().subscribe(
      data => {
        this.equipmentDataResponse = data;
        if (this.equipmentDataResponse.status !== 'success') {
          this.errorservice.showerror({status: this.equipmentDataResponse.status, statusText: this.equipmentDataResponse.message});
        } else {
          this.equipmentData = this.equipmentDataResponse.data;
        }
      }
    );

  }

  equipmentChange(event, equipment) {
    const equipmentId = event.value;

    for (let i = 0; i < equipment.length; i++) {
      if (equipment[i].equipmentId === equipmentId) {
        // this.equipmentPlant = equipment[i].plantAcronym;
         this.addActivityData.plantId = equipment[i].plantId;
         this.addActivityData.plantAcronym = equipment[i].plantAcronym;
      }
    }
    return this.addActivityData.plantAcronym;
  }

  ngOnInit() {
    this.getPlants();
    this.getEquipments();
  }

  getPlants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (this.plants.length > 0) {
           // this.selectedPlantObj =  this.plants[0];
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }  

  cancelAddActivity() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: {type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.router.navigate(['activitylist/' + this.addActivityData.plantId]);
    });
  }

  validateDescriptionCN(model: any) {
    const isValidLang = model.match(/^[\x00-\x7F]*$/);
    this.descriptionCNError = (isValidLang) ? true : false;
    return this.descriptionCNError;
  }

  removeChinese(propName) {
    this.addActivityData[propName] = this.addActivityData[propName].replace(/[^\x00-\x7F]/g, '');
  }

  saveActivity(action) {
    let displayMessage = '';
    this.activityData = this.prepareFinalReq(this.addActivityData);
    this.activityData.action = action;
    this.validateDescCN = this.validateDescriptionCN(this.activityData.descriptionEn);
    if (!this.validateDescCN) {
      this.descriptionCNError = true;
    } else {
    this.descriptionCNError = false;
    this.activityservice.saveActivityData(this.activityData).subscribe(
      data => {
        this.saveActivityResponse = data;
        if (this.saveActivityResponse.status !== 'success') {
          this.errorservice.showerror({
            status: this.saveActivityResponse.errorCode, statusText: this.saveActivityResponse.message
         });
      } else {
        if (this.activityData.action === 'create') {
          displayMessage = 'data.L01155';
        } else if (this.activityData.action === 'update') {
          displayMessage = 'data.L01156';
        } else {
          displayMessage = 'data.L01157';
        }
        const dialogRef = this.dialog.open(DialogComponent, {
          width: '400px',
          data: {title: 'data.L00224', message: displayMessage }
        });
        const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
          dialogRef.componentInstance.closeDialog();
          this.router.navigate(['activitylist/' + this.addActivityData.plantId]);
        });
      }
  },
  (err: any) => {
     console.log(err);
  }
  );
}
  }

  prepareFinalReq(data) {
    const finalObj = {
      'action': '',
      'assocId': (data.assocId !== '' ? data.assocId : 0),
      'activityName': data.activityName,
      'equipmentId': data.equipmentId,
      'isRoutine': data.isRoutine,
      'descriptionEn': data.description.descriptionEn,
      'descriptionCn': data.description.descriptionCn
    };
    return finalObj;
  }

  preparereq() {
    const reqObj = {
      'activityName': '',
      'assocId' : 0,
      'equipmentId': 0,
      'plantId': '',
      'plantAcronym': '',
      'description': {
        'descriptionEn': '',
        'descriptionCn': ''
      },
      'isRoutine': 0
    };
    return reqObj;
  }

}

