import { Component, Inject, OnInit, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { EquipmentService } from '../../../../services/equipment.service';
import { CommonService } from 'src/app/services/common.service';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-equipment',
  templateUrl: './equipment.component.html',
  styleUrls: ['./equipment.component.css']
})
export class EquipmentComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns = ['plantname', 'equipmentname', 'descriptionen', 'descriptioncn', 'status', 'actions'];
  dataSource: any;
  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  equipmentList: any;
  equipmentResponse: any;
  searchValue: any;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    public equipmentservice: EquipmentService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    this.plants = [];
    this.equipmentList = [];
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.getplants(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.getplants(this.selectedPlant);
      }
    });
  }

  getplants(plantId: any) {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (plantId === 0) {
            this.equipmentList = [];
            this.selectedPlant = 0;
            this.getequipments(this.plants[0]);
          } else {
              const plantobj = this.plants.filter(plnt => {
              return plnt.id === plantId;
            });
            this.selectedPlant = plantId;
            this.getequipmentsbyplantid(this.selectedPlant);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getequipments(plantobj) {
    this.searchValue = '';
    this.equipmentList = [];
    this.equipmentservice.getEquipments().subscribe (
      data => {
        this.equipmentResponse = data;
        if (this.equipmentResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.equipmentResponse.status, statusText: this.equipmentResponse.message });
        } else {
          this.equipmentList = this.equipmentResponse.data;
          this.equipmentList.forEach(eq => {
            eq.status = (eq.isDeleted === true) ? 'Active' : 'Inactive';
          });
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.equipmentList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.equipmentName.toLowerCase().includes(filter) ||
            (data.plantAcronym !== null ? data.plantAcronym.toString().toLowerCase().includes(filter) : null) ||
            (data.description.en !== null ? data.description.en.toString().toLowerCase().includes(filter) : null) ||
            (data.description.cn !== null ? data.description.cn.toString().toLowerCase().includes(filter) : null) ||
            (data.status !== null ? data.status.toString().toLowerCase().includes(filter) : null);
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );

  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  selectplant(plantid: any) {
    // this.selectedPlantObj = plantObj;
    if (plantid === 0) {
      this.getequipments(plantid);
    } else {
      this.getequipmentsbyplantid(plantid);
    }
  }

  getequipmentsbyplantid(plantid) {
    this.searchValue = '';
    this.equipmentList = [];
    this.equipmentservice.getEquipmentsByPlant(plantid).subscribe (
      data => {
        this.equipmentResponse = data;
        if (this.equipmentResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.equipmentResponse.status, statusText: this.equipmentResponse.message });
        } else {
          this.equipmentList = this.equipmentResponse.data;
          this.equipmentList.forEach(eq => {
            eq.status = (eq.isDeleted === true) ? 'Active' : 'Inactive';
          });
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.equipmentList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.equipmentName.toLowerCase().includes(filter) ||
            (data.plantAcronym !== null ? data.plantAcronym.toString().toLowerCase().includes(filter) : null) ||
            (data.description.en !== null ? data.description.en.toString().toLowerCase().includes(filter) : null) ||
            (data.description.cn !== null ? data.description.cn.toString().toLowerCase().includes(filter) : null) ||
            (data.status !== null ? data.status.toString().toLowerCase().includes(filter) : null);
          };
          this.dataSource.paginator = this.paginator;
          this.applyFilter(plantid);
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  editEquipment(actionType, equipment): void {
     if (actionType === 'edit') {
        this.router.navigate(['editEquipment/' + this.selectedPlant + '/' + equipment]);
     }
   }
}

@Component({
  selector: 'app-addEquipment',
  templateUrl: './addEquipment.component.html',
  styleUrls: ['./equipment.component.css']
})

export class AddEquipmentComponent implements OnInit {

  plants: any;
  selectedPlant: any;
  plantsResponse: any;
  addEquipmentData: any;
  equipmentDataResponse: any;
  saveEquipmentResponse: any;
  pageParams: any;
  mode: any;
  descriptionCNError: any;
  validateDescCN: any;
 // isChecked: any = false;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    public equipmentservice: EquipmentService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog
  ) {
    this.route.params.subscribe(params => {
      this.mode = 'new';
      this.addEquipmentData = this.preparereq();
      this.pageParams = params;
      if (this.pageParams.plantid) {
        this.addEquipmentData.plantId = parseInt(this.pageParams.plantid, 10);
      } else {
        this.addEquipmentData.plantId = 0;
      }
      if (this.pageParams.equipmentId) {
        this.mode = 'edit';
        this.getEquipmentData(this.addEquipmentData.plantId, this.pageParams.equipmentId);
      }
    });
   }

   getEquipmentData(plantId, equipmentId) {
    this.equipmentservice.getEquipmentsById(equipmentId).subscribe(
      data => {
        this.equipmentDataResponse = data;
        if (this.equipmentDataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.equipmentDataResponse.status, statusText: this.equipmentDataResponse.message });
        } else {
          this.addEquipmentData = this.equipmentDataResponse.data;
        }
        console.log(this.addEquipmentData);
      }
    );
   }

  ngOnInit() {
    this.getPlants();
    this.addEquipmentData.status = false;
  }

  getPlants(){
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (this.plants.length > 0) {
           // this.selectedPlantObj =  this.plants[0];
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  cancelAddEquipment() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: {type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.router.navigate(['equipmentlist/' + this.addEquipmentData.plantId]);
    });
  }

  validateDescriptionCN(model: any) {
    const isValidLang = model.match(/^[\x00-\x7F]*$/);
    this.descriptionCNError = (isValidLang) ? true : false;
    return this.descriptionCNError;
  }

  removeChinese(propName) {
    this.addEquipmentData[propName] = this.addEquipmentData[propName].replace(/[^\x00-\x7F]/g, '');
  }

  saveEquipment($event: Event, action) {
    let displayMessage = '';
    this.addEquipmentData.action = action;
    this.validateDescCN = this.validateDescriptionCN(this.addEquipmentData.description);
    if (!this.validateDescCN) {
      this.descriptionCNError = true;
    } else {
    this.descriptionCNError = false;
    this.equipmentservice.saveEquipmentData(this.addEquipmentData).subscribe(
      data => {
        this.saveEquipmentResponse = data;
        if (this.saveEquipmentResponse.status !== 'success') {
          this.errorservice.showerror({
            status: this.saveEquipmentResponse.errorCode, statusText: this.saveEquipmentResponse.message
         });
      } else {
        if (this.addEquipmentData.action === 'create') {
          displayMessage = 'data.L01158';
        } else if (this.addEquipmentData.action === 'update') {
          displayMessage = 'data.L01159';
        } else {
          displayMessage = 'data.L01160';
        }
        const dialogRef = this.dialog.open(DialogComponent, {
          width: '400px',
          data: {title: 'data.L00224', message: displayMessage }
        });
        const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
          dialogRef.componentInstance.closeDialog();
          this.router.navigate(['equipmentlist/' + this.addEquipmentData.plantId]);
        });
      }
  },
  (err: any) => {
     console.log(err);
  }
  );
}

  }

  preparereq() {
    const reqObj = {
      'action': '',
      'equipmentId': 0,
      'equipmentName': '',
      'showEquipmentNameOnPfd': false,
      'plantId': 0,
      'showPlantOnPfd': false,
      'sapnumber': '',
      'showSapnumberOnPfd': false,
      'description': '',
      'descriptionCn': '',
      'showDescriptionOnPfd': false,
      'showDescriptionCnOnPfd': false,
      'installation': '',
      'showInstallationOnPfd': false,
      'installationDate': '',
      'showInstallationDateOnPfd': false,
      'lastInspectionDate': '',
      'showLastInspectionDateOnPfd': false,
      'remarks': '',
      'showRemarksOnPfd': false,
      'equipmentType': '',
      'showEquipmentTypeOnPfd': false,
      'manufacturer': '',
      'showManufacturerOnPfd': false,
      'model': '',
      'showModelOnPfd': false,
      'specifications1': '',
      'showSpecifications1OnPfd': false,
      'specifications2': '',
      'showSpecifications2OnPfd': false,
      'specifications3': '',
      'showSpecifications3OnPfd': false,
      'runningTimeIndicatorConnectedToDcs': false,
      'showRunningTimeIndicatorConnectedToDcsonPfd': false,
      'status': false
    };
    return reqObj;
  }
}
