import { Component, OnInit, HostListener } from '@angular/core';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { CommercialService } from '../../../services/commercial.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CancelConfirmationDialogComponent } from '../../events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';

function alphanumericValidation(control: FormControl) {
  const format = /^[a-zA-Z0-9-_\s!@#$%^&*(),.?"';:{}|<>+=]*$/;
  if (control.value.trim().length > 0) {
    if (!format.test(control.value)) {
      return {
        alpha: true
      };
    }
  }
  return null;
}

@Component({
  selector: 'app-add-customer-details',
  templateUrl: './add-customer-details.component.html',
  styleUrls: ['./add-customer-details.component.css', '../../../../assets/css/events.css'],

})


export class AddCustomerDetailsComponent implements OnInit {
  submitted = false;
  plantDataresponce: any;
  countryDataresponce: any;
  MainPollutantDataresponce: any;
  companyproductDataresponce: any;
  CustomerProcessDataresponce: any;
  rawmaterialsDataresponce: any;
  industrieDataresponce: any;

  customerDetailsForm: FormGroup;
  name: string;
  cityIdValue: any;
  country: number;
  tasks = [];
  selectedCountry = '';
  plants = [];
  validation_messages = {
    'customerName': [
      { type: 'required', message: 'data.L00502' },
      { type: 'minLength', message: 'data.L00711' },
      { type: 'maxlength', message: 'data.L00712' },
      { type: 'pattern', message: 'data.L00502' },
      { type: 'alpha', message: 'data.L00520' },
    ],
    'countryId': [
      { type: 'required', message: 'data.L00479' },
    ],
    'plantId': [
      { type: 'required', message: 'data.L00286' },
    ],
    'descriptionEn': [
      { type: 'minlength', message: 'data.L00452' },
      { type: 'maxlength', message: 'data.L00714' },
      { type: 'required', message: 'data.L00502' },
      { type: 'pattern', message: 'data.L00502' },
      { type: 'alpha', message: 'data.L00520' },
    ],
    'descriptionCn': [
      { type: 'minlength', message: 'data.L00452' },
      { type: 'maxlength', message: 'data.L00714' },
      { type: 'required', message: 'data.L00502' },
      { type: 'pattern', message: 'data.L00502' },
    ],
    'productionCapacity': [
      // { type: 'pattern', message: 'Please enter a positive value' },
      { type: 'required', message: 'data.L00502' },
      { type: 'maxlength', message: 'data.L00716' },
      { type: 'float', message: 'data.L00520' },
    ],

    'preTreatment': [
      { type: 'minlength', message: 'data.L00466' },
      { type: 'maxlength', message: 'data.L00717' },
      { type: 'required', message: 'data.L00502' },
      { type: 'pattern', message: 'data.L00502' },

    ],
    'remark': [
      { type: 'minlength', message: 'data.L00466' },
      { type: 'maxlength', message: 'data.L00718' },
      { type: 'required', message: 'data.L00502' },
      { type: 'pattern', message: 'data.L00502' },
    ],
    'waterVolumeM3Day': [
      // { type: 'pattern', message: 'Please enter a positive value' },
      { type: 'required', message: 'data.L00502' },
      { type: 'maxlength', message: 'data.L00721' },
      { type: 'float', message: 'data.L00520' },
    ],
    'concentrationOfMainComponents': [
      // { type: 'pattern', message: 'Please enter a positive value' },
      { type: 'required', message: 'data.L00502' },
      { type: 'maxlength', message: 'data.L00721' },
      { type: 'float', message: 'data.L00520' },
    ],
    'companyProducts': [
      { type: 'required', message: 'data.L00502' },
    ],
    'mainpollutants': [
      { type: 'required', message: 'data.L00502' },
    ],
    'mncLocal': [
      { type: 'required', message: 'data.L00502' },
    ],
    'industry': [
      { type: 'required', message: 'data.L00502' },
    ],
    'rawMaterials': [
      { type: 'required', message: 'data.L00502' },
    ],
    'production': [
      { type: 'required', message: 'data.L00502' },
    ],
    'acronym': [
      { type: 'required', message: 'data.L00502' },
      { type: 'pattern', message: 'data.L00502' },
      { type: 'alpha', message: 'data.L00520' },
    ],
    'customerProcesses': [
      { type: 'required', message: 'data.L00502' },
    ]
  };

  constructor(private fb: FormBuilder,
    private commercialService: CommercialService,
    private errorservice: ErrorserviceService,
    private router: Router,
    private dialog: MatDialog, ) {

    /* Plant drop down service*/
    this.commercialService.getPlants().subscribe(data => {
      this.plantDataresponce = data;
      this.plants = [];
      if (this.plantDataresponce.status !== 'success') {
        this.errorservice.showerror({ status: this.plantDataresponce.status, statusText: this.plantDataresponce.message });
      } else {
        for (let i = 0; i < this.plantDataresponce.data.countries.length; i++) {
          for (let j = 0; j < this.plantDataresponce.data.countries[i].cities.length; j++) {
            for (let k = 0; k < this.plantDataresponce.data.countries[i].cities[j].plants.length; k++) {
              const plantobjList = this.plantDataresponce.data.countries[i].cities[j].plants[k];
              plantobjList.cityId = this.plantDataresponce.data.countries[i].cities[j].id;
              plantobjList.id = this.plantDataresponce.data.countries[i].cities[j].plants[k].id;
              plantobjList.acronymName = this.plantDataresponce.data.countries[i].cities[j].plants[k].acronym;
              this.plants.push(plantobjList);
            }
          }
        }
      }
    });
    /* Country drop down service*/
    this.commercialService.getCountries().subscribe((data: any) => {
      this.countryDataresponce = [];
      data.data.countries.forEach(country =>
        this.countryDataresponce.push(country)
      );

    });
    /* Get parameter service*/
    this.commercialService.getParameters().subscribe((data: any) => {
      this.MainPollutantDataresponce = data.data.mainPollutants;
      this.companyproductDataresponce = data.data.companyProduct;
      this.CustomerProcessDataresponce = data.data.customerProcess;
      this.rawmaterialsDataresponce = data.data.rawMaterials;
      this.industrieDataresponce = data.data.industry;
    });

  }

  floatNumber(control: FormControl) {
    const format = /^[\.]?[\d]{1,9}(\.[\d]{1,})?$/;
    if (control.value.length > 0) {
      if (control.value === '.' || control.value === '.0' || !format.test(control.value)) {
        return {
          float: true
        };
      }
    }
    return null;
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
  }

  handleFloat(event) {
    if (this.countDecimals(event.target.value) > 3) {
      this.customerDetailsForm.controls[event.target.attributes.formcontrolname.nodeValue].
      setValue(parseFloat(event.target.value).toFixed(3));
    }
  }

  countDecimals(value) {
    if ((value % 1) !== 0) {
        return value.toString().split('.')[1].length;
    }
    return 0;
  }

  ngOnInit() { this.createForms(); }

  public createForms() {
    this.customerDetailsForm = this.fb.group({
      customerId: 0,
      industry: new FormControl(''),
      otherComponents: 'string',
      action: 'Create',
      createdBy: 2,
      createdAt: '2018-12-03T04:37:15.047Z',
      updatedAt: '2018-12-03T04:37:15.047Z',
      tenantId: 1,
      updatedBy: 0,
      acronym: new FormControl('', [alphanumericValidation, Validators.pattern(/^(?!\s*$).+/), Validators.required]),
      customerName: new FormControl('', Validators.compose([alphanumericValidation, Validators.pattern(/^(?!\s*$).+/),
        Validators.maxLength(100), Validators.minLength(3), Validators.required])),
      companyProducts: new FormControl('', [Validators.required]),
      countryId: new FormControl('', [Validators.required]),
      plantId: new FormControl('', [Validators.required]),
      descriptionEn: new FormControl('', Validators.compose([alphanumericValidation, Validators.pattern(/^(?!\s*$).+/),
        Validators.maxLength(255), Validators.minLength(3), Validators.required])),
      descriptionCn: new FormControl('', Validators.compose([Validators.pattern(/^(?!\s*$).+/), Validators.maxLength(255),
        Validators.minLength(3), Validators.required])),
      mainpollutants: new FormControl('', [Validators.required]),
      productionCapacity: new FormControl('', Validators.compose([this.floatNumber,
        // Validators.pattern(/^[1-9]\d*$/),
        Validators.required])),
      customerProcesses: new FormControl('', [Validators.required]),
      preTreatment: new FormControl('', Validators.compose([Validators.pattern(/^(?!\s*$).+/),
        Validators.maxLength(200), Validators.minLength(3), Validators.required])),
      rawMaterials: new FormControl('', [Validators.required]),
      mncLocal: new FormControl('', [Validators.required]),
      production: new FormControl('', [Validators.required]),
      remark: new FormControl('', Validators.compose([Validators.pattern(/^(?!\s*$).+/),
        Validators.maxLength(255), Validators.minLength(3), Validators.required])),
      waterVolumeM3Day: new FormControl('', Validators.compose([this.floatNumber, Validators.required])),
      concentrationOfMainComponent: new FormControl('', Validators.compose([this.floatNumber, Validators.required]))
    });
  }

  getCity(cityId) {
    this.cityIdValue = cityId;
  }

  // Prevent blank space to enter intially
  onKeydown(e) {
    if (e.target.value.length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  onSubmitUserDetails() {
    this.submitted = true;
    if (this.customerDetailsForm.invalid) {
      return;
    } else {
      this.customerDetailsForm.controls['customerName'].setValue(this.customerDetailsForm.value.customerName.trim());
      this.customerDetailsForm.controls['acronym'].setValue(this.customerDetailsForm.value.acronym.trim());
      this.customerDetailsForm.controls['descriptionEn'].setValue(this.customerDetailsForm.value.descriptionEn.trim());
      this.customerDetailsForm.controls['descriptionCn'].setValue(this.customerDetailsForm.value.descriptionCn.trim());
      this.customerDetailsForm.controls['preTreatment'].setValue(this.customerDetailsForm.value.preTreatment.trim());
      this.customerDetailsForm.controls['remark'].setValue(this.customerDetailsForm.value.remark.trim());
      const formValue = this.customerDetailsForm.value;
      this.commercialService.editCustomer(formValue.countryId, this.cityIdValue, formValue.plantId, formValue).subscribe(
        (data: any) => {
          if (data['status'] !== 'success') {
            this.errorservice.showerror({status: data['status'], statusText: data['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: data['status'], statusText: 'data.L00488'});
            this.router.navigate(['customerList']);
          }
        }
      );
    }
  }

  openConfirmationDialog() {
    this.submitted = false;
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'customerList' }
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

}
