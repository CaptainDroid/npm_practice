import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { AdminService } from 'src/app/services/admin.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';

function alphanumericValidation(control: FormControl) {
  const format = /^[a-zA-Z0-9-_\s\\/!@#$%^&*(),.?"';:{}|<>+=]*$/;
  if (control.value.trim().length > 0) {
    if (!format.test(control.value)) {
      return {
        alpha: true
      };
    }
  }
  return null;
}

@Component({
  selector: 'app-add-lab-sample',
  templateUrl: './add-lab-sample.component.html',
  styleUrls: ['./add-lab-sample.component.css', '../../../../../assets/css/events.css']
})

export class AddLabSampleComponent implements OnInit {
  plants: any;
    submitted = false;
    labId: number;
    invalidInput = false;
    regularList: any;
    // regularList = [{ id: 1, name: 'Regualr', code: 'REGR'},
    //               { id: 2, name: '3rd Party', code: '3rd'},
    //               { id: 3, name: 'Adhoc', code: 'Adhoc'}
    //               ];
    sampleForm: any;
    deleteFlag = true;
    isEdit = false;
    addLabSampleForm: FormGroup;
    sampleData: any;
    routePlantId: any;


  constructor(
    private commonService: CommonService,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private adminService: AdminService,
    private errorservice: ErrorserviceService,
  ) {
    this.route.params.subscribe(params => {
      this.labId = params.id;
      if (params.id) {
        this.isEdit = true;
      }
      if (params.plantid) {
        this.routePlantId = params.plantid;
      }
    });
   }

  setPlant(event) {
    this.routePlantId = event;
  }

  ngOnInit() {

    this.addLabSampleForm = new FormGroup({
      sampleName: new FormControl({value: '', disabled: this.isEdit}, [Validators.pattern(/^(?!\s*$).+/), alphanumericValidation]),
      plantId: new FormControl({disabled: this.isEdit}, [Validators.min(1)]),
      descriptionEn: new FormControl('', [Validators.minLength(3), Validators.pattern(/^[a-zA-Z0-9-_\s\\/!@#$%^&*(),.?"';:{}|<>+=]*$/)]),
      descriptionCn: new FormControl('', [Validators.minLength(3)]),
      sampleTypeId: new FormControl({value: '', disabled: this.isEdit}),
      tenantId: new FormControl(1)
    });

    if (!this.isEdit) {
      const plantId = parseInt(this.routePlantId, 10);
      this.addLabSampleForm.controls['plantId'].setValue(plantId);
    }

    /** Get plant dropdown values */
    this.commonService.getplants().subscribe(( data: any ) => {
      const plants = [];
      if (data.data.countries) {
        data.data.countries.forEach(element => {
          if (element.cities) {
            element.cities.forEach(item => {
              if (item.plants) {
                item.plants.forEach(plantItem => {
                  const plantObj = {
                    'id': plantItem.id,
                    'acronym': plantItem.acronym,
                    'name': plantItem.name
                  };
                  plants.push(plantObj);
                });
              }
            });
          }
        });
        this.plants = plants;
      }
    },
    (err: any) => {
      console.log('There are no plants pulled from the server!');
    });

    /** Get sapmle type dropdown values */
    this.adminService.getSampleTypes().subscribe(( data: any) => {
      this.regularList = data.data.sampleTypes;
    }, (err) => {});

    if (this.labId) {
      this.adminService.singleLabSample(this.labId).subscribe((data: any) => {
        this.addLabSampleForm.patchValue(data.data.labsample);
        this.sampleData = data.data.labsample;
      },
      (err) => {});
    }
  }

  handleSpace(event) {
    this.addLabSampleForm.controls[event.target.attributes.formcontrolname.nodeValue].
      setValue(event.target.value.trim());
  }

  // Prevent blank space to enter intially
  onKeydown(e) {
    if (e.target.value.length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  noSpace(e) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
  }

  removeSpace(event) {
    // First one to remove Chinese characters
    this.addLabSampleForm.controls[event.target.attributes.formcontrolname.nodeValue].
    setValue(event.target.value.replace(/[^\x00-\x7F]/g, ''));
    // This one to remove spaces
    this.addLabSampleForm.controls[event.target.attributes.formcontrolname.nodeValue].
    setValue(event.target.value.replace(/[\s]/g, ''));
  }

  onSubmit() {
    this.submitted = true;
    const LabData = this.addLabSampleForm.value;
    if (this.addLabSampleForm.invalid) {
      return;
    }
    // let LabData = {};
    let message;
    if (this.labId) {
      LabData.action = 'Update';
      LabData.updatedAt =  '';
      LabData.updatedBy = 1;
      LabData.sampleId = this.labId;
      message = 'data.L00795';
      LabData.sampleName = this.sampleData.sampleName;
      LabData.plantId = this.sampleData.plantId;
      LabData.sampleType = this.sampleData.sampleTypeId;
    } else {
      LabData.action = 'Create';
      LabData.createdAt =  '';
      LabData.createdBy = 1;
      LabData.sampleId = 0;
      message = 'data.L00488';
      LabData.sampleType = LabData.sampleTypeId;
    }
    LabData.description = {
      descriptionEn : LabData.descriptionEn,
      descriptionCn : LabData.descriptionCn
    };
    delete LabData.descriptionEn;
    delete LabData.descriptionCn;
    delete LabData.sampleTypeId;
    if (!this.addLabSampleForm.invalid) {
      this.adminService.postLabSample(LabData).subscribe(
        (data: any) => {
          if (data['status'] === 'success') {
            this.errorservice.showerror({ type: 'Info', status: data['status'], statusText: message});
            this.router.navigate(['lab-sample-list', this.routePlantId]);
          } else {
            this.errorservice.showerror({status: data['status'], statusText: data['message'] });
            return;
          }
      });
    }
  }

  /**
   * Delete Confirmation Dialog
   */
  deleteConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: null, type: 'delete' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        const LabData = {
          'action': 'Delete',
          'sampleId': this.labId
        };
        // if (this.deleteFlag) {
          this.adminService.postLabSample(LabData).subscribe(
            (data: any) => {
              if (data['status'] === 'success') {
                this.errorservice.showerror({ type: 'Info', status: data['status'], statusText: 'data.L00855'});
                this.router.navigate(['lab-sample-list', this.routePlantId]);
              } else {
                this.errorservice.showerror({status: data['status'], statusText: data['message'] });
                return;
              }
          });
        // }
      }
    });
  }

  onDelete() {
    const LabData = {
      'action': 'Delete',
      'sampleId': this.labId
    };
    if (this.deleteFlag) {
      this.adminService.postLabSample(LabData).subscribe(
        (data: any) => {
          if (data['status'] === 'success') {
            this.errorservice.showerror({ type: 'Info', status: data['status'], statusText: 'data.L00855'});
            this.router.navigate(['/lab-sample-list', this.routePlantId]);
          } else {
            this.errorservice.showerror({status: data['status'], statusText: data['message'] });
            return;
          }
      });
    }
  }

   /**
* Cancel Confirmation Dialog
*/
openConfirmationDialog() {
  const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
    width: '400px',
    data: { route: 'lab-sample-list/' + this.routePlantId}
  });

  dialogRef.afterClosed().subscribe(result => {
    // console.log('The dialog was closed');
  });
}
}
