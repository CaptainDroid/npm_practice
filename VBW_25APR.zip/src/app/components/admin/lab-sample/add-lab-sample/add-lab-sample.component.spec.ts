import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddLabSampleComponent } from './add-lab-sample.component';

describe('AddLabSampleComponent', () => {
  let component: AddLabSampleComponent;
  let fixture: ComponentFixture<AddLabSampleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddLabSampleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddLabSampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
