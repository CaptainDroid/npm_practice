import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabSampleListComponent } from './lab-sample-list.component';

describe('LabSampleListComponent', () => {
  let component: LabSampleListComponent;
  let fixture: ComponentFixture<LabSampleListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabSampleListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabSampleListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
