import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AdminService } from 'src/app/services/admin.service';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-lab-sample-list',
  templateUrl: './lab-sample-list.component.html',
  styleUrls: ['./lab-sample-list.component.css', '../../../../../assets/css/events.css']
})

export class LabSampleListComponent implements OnInit {

  displayedColumns: string[] = ['plant', 'sample', 'description', 'descriptioncn', 'sampleType', 'customer', 'action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  dataSource: MatTableDataSource<{}>;
  limit = 10;
  pageLimit: number[] = [10, 25, 100];
  totalLength: number;
  labList: any;
  plantFilter: any = 0;
  searchFilter: any;
  searchResult: any[] = [];
  selectResult: any[] = [];
  plants: any;
  pramPlantId: any;

  constructor(
    private commonService: CommonService,
    private router: Router,
    private route: ActivatedRoute,
    private adminService: AdminService,
    private errorservice: ErrorserviceService
  ) {

   }

  ngOnInit() {

    this.route.params.subscribe(params => {
      this.pramPlantId = params.plantid;
    });

    /** Get plant dropdown values */
    this.commonService.getplants().subscribe(( data: any ) => {
      const plants = [];
      if (data.data.countries) {
        data.data.countries.forEach(element => {
          if (element.cities) {
            element.cities.forEach(item => {
              if (item.plants) {
                item.plants.forEach(plantItem => {
                  const plantObj = {
                    'id': plantItem.id,
                    'acronym': plantItem.acronym,
                    'name': plantItem.name
                  };
                  plants.push(plantObj);
                });
              }
            });
          }
        });
        this.plants = plants;
      }
    },
    (err: any) => {
      console.log('There are no plants pulled from the server!');
    });

    this.adminService.getLabSampleList().subscribe((data: any) => {
      if (data.data.labsamples) {
        const labList = [];
        data.data.labsamples.forEach(element => {
          const labObj = {
            'id': element.sampleId,
            'plant': element.plantAcronym,
            'plantId': element.plantId,
            'sample': element.sampleName,
            'description': element.descriptionEn,
            'descriptioncn': element.descriptionCn,
            'sampleType': element.sampleType,
            'customer': element.customerName
          };
          labList.push(labObj);
        });
        this.labList = labList;
        if (!this.pramPlantId ) {
          this.plantFilter = 0;
        } else {
          this.plantFilter = parseInt(this.pramPlantId , 10);
        }
        this.applyFilter(this.plantFilter);
      }
      // this.dataSource = new MatTableDataSource(this.labList);
      // this.dataSource.paginator = this.paginator;
      // this.totalLength = this.dataSource.data.length;
    },
    (err: any) => {

    });
  }

  editSample(row: any) {
    this.router.navigate(['/edit-lab-sample/' + this.plantFilter + '/' + row.id]);
  }

  /**
   * plant Search
  //  * @param filterValue
   */
  // applyFilter(filterValue: string) {
  //   this.dataSource.filter = filterValue.trim().toLowerCase();
  // }

  applyFilter(filterValue: string) {
    if (this.plantFilter === 0) {
      if (this.searchFilter) {
        this.filterSearch(this.labList, this.searchFilter);
      } else {
        this.dataSource = new MatTableDataSource(this.labList);
      }
      if (filterValue === this.searchFilter) {
        this.filterSearch(this.labList, filterValue);
      }
    } else {
      if (this.searchFilter && this.plantFilter) {
        this.searchAndSelectFilter(filterValue);
      } else {
        if (this.searchFilter && !this.plantFilter) {
          filterValue = this.searchFilter;
          this.filterSearch(this.labList, filterValue);
        } else if (!this.searchFilter && this.plantFilter) {
          filterValue = this.plantFilter;
          this.filterSelect(this.labList, filterValue);
        }
      }
    }
    // this.tableShow = true;
    this.dataSource.paginator = this.paginator;
    this.dataSource.paginator.firstPage();
    // this.dataSource.sort = this.sort;
  }

  filterSearch(data, filterValue) {
    this.searchResult = data.filter(item => {
      return (
      (item.plant.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
      (item.sample.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
      (item.description !== null ? item.description.toString().toLowerCase().includes(filterValue.toLowerCase()) : null) ||
      (item.descriptioncn !== null ? item.descriptioncn.toString().toLowerCase().includes(filterValue.toLowerCase()) : null) ||
      (item.sampleType.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
      (item.customer !== null ? item.customer.toString().toLowerCase().includes(filterValue.toLowerCase()) : null));
    });
    this.dataSource = new MatTableDataSource(this.searchResult);
  }

  searchAndSelectFilter(filterValue) {
    if (filterValue === this.searchFilter) {
      this.filterSelect(this.labList, this.plantFilter);
      this.filterSearch(this.selectResult, filterValue);
    } else {
      this.filterSearch(this.labList, this.searchFilter);
      this.filterSelect(this.searchResult, filterValue);
    }
  }

  filterSelect(data, filterValue) {
    this.selectResult = data.filter(item => item.plantId === filterValue);
    this.dataSource = new MatTableDataSource(this.selectResult);
  }

  changePage(event) {
    // sort and define paginator on page change event
    // only if the page size selected by the user is less than the total data length.
    if (this.dataSource.data.length > event['pageSize']) {
      this.dataSource.paginator = this.paginator;
    }
  }

}
