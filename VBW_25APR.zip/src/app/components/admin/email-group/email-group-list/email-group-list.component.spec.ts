import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailGroupListComponent } from './email-group-list.component';

describe('EmailGroupListComponent', () => {
  let component: EmailGroupListComponent;
  let fixture: ComponentFixture<EmailGroupListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmailGroupListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailGroupListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
