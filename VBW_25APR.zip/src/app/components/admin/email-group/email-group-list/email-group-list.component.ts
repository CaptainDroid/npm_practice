import { Component, OnInit, ViewChild } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';

@Component({
  selector: 'app-email-group-list',
  templateUrl: './email-group-list.component.html',
  styleUrls: ['./email-group-list.component.css']
})
export class EmailGroupListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  loggedInUserDetails: any;
  dataSource: any;
  displayedColumns: string[] = ['emailgroup', 'description','action'];

  constructor(public adminService: AdminService) { }

  ngOnInit() {
    this.loggedInUserDetails = JSON.parse(localStorage.getItem('user'));

    this.adminService.getEmailGroups()
    .subscribe((response: any) => {
      let emailGroupArray = response.data.emailgroups;
      this.dataSource = new MatTableDataSource(emailGroupArray);
      if (this.dataSource) {
        this.dataSource.paginator = this.paginator;
      }
    });
  } 

  applyFilter(filterValue: string) {
    if (this.dataSource) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}
