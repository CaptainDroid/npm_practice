import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from "@angular/material";
import { FormControl, FormGroupDirective, FormGroup, NgForm, Validators } from '@angular/forms';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { AdminService } from 'src/app/services/admin.service';

function alphanumericValidation(control: FormControl) { 
  var format = /^[a-zA-Z][a-zA-Z0-9-_\s!@#$%^&*(),.?"';:{}|<>+=]*$/;
  if(control.value.trim().length > 0){
    if(!format.test(control.value)){
      return {
        alpha: true
      }
    }
  }
  return null; 
}

@Component({
  selector: 'app-add-edit-email-group',
  templateUrl: './add-edit-email-group.component.html',
  styleUrls: ['./add-edit-email-group.component.css', '../../../../../assets/css/events.css']
})
export class AddEditEmailGroupComponent implements OnInit {
  submitted: boolean = false;
  emailGroupId: any;
  userId: any;

  addEmailGroupForm = new FormGroup({
    emailGroupId: new FormControl(''),
    updatedBy: new FormControl(''),
    tenantId: new FormControl(''),
    createdAt: new FormControl(''),
    createdBy: new FormControl(''),
    updatedAt: new FormControl(''),
    emailGroupName: new FormControl('', [alphanumericValidation]),
    emailGroupDescription: new FormControl(''),
  });

  constructor(
    private router: ActivatedRoute,
    public dialog: MatDialog,
    private route: Router,
    private errorservice: ErrorserviceService,
    public adminService: AdminService
  ) {
    this.router.params.subscribe((params: Params) => {
      const id = params['id'];
      this.emailGroupId = id;
      if (id) {
        this.adminService.getSingleEmailGroup(id).subscribe(data => {
          const result: any = data;
          this.addEmailGroupForm.setValue(result.data);
        });
      }
    });
   } 

  // convenience getter for easy access to form fields
  get f() { return this.addEmailGroupForm.controls; }

  // Restrict blank spaces in the beginning
  onKeydown(e){
    if (e.target.value.trim().length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  handleText(event, field){
    if(field === "name"){
      this.addEmailGroupForm.controls['emailGroupName'].setValue(this.addEmailGroupForm.value.emailGroupName.trim());
    }
    else{
      this.addEmailGroupForm.controls['emailGroupDescription'].setValue(this.addEmailGroupForm.value.emailGroupDescription.trim());
    }
  }

  ngOnInit() { 
    let loggedInUser = JSON.parse(localStorage.getItem('user'));
    this.userId = loggedInUser.amr;
  }

  onSubmit() {
    this.submitted = true;
    if (this.addEmailGroupForm.invalid) {
      return;
    }
    
    if(this.addEmailGroupForm.valid && !this.emailGroupId) {
      let dataArray = { "tenantId": 1, "action": "Create", "emailGroupId": 0, "createdBy": parseInt(this.userId), "emailGroupName": this.addEmailGroupForm.value.emailGroupName.trim(), "emailGroupDescription": this.addEmailGroupForm.value.emailGroupDescription.trim()};

      if (!dataArray.emailGroupName.length || !dataArray.emailGroupDescription.length) { 
        this.errorservice.showerror({ type: 'Info', status: '', statusText: 'Please fill the form correctly' });
        return;
      }
      this.adminService.postEmailGroup(dataArray)
      .subscribe((response: any) => {
        if (response.status == 'Failed') {
          this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
          return;
        } else {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00488' });
          this.route.navigate(['/email-groups']);
        }
      });
    } else if (this.addEmailGroupForm.valid && this.emailGroupId) {
      let dataArray = { "tenantId": 1, "action": "Update", "emailGroupId": this.emailGroupId, "updatedBy": parseInt(this.userId), "emailGroupName": this.addEmailGroupForm.value.emailGroupName.trim(), "emailGroupDescription": this.addEmailGroupForm.value.emailGroupDescription.trim()};

      if (!dataArray.emailGroupName.length || !dataArray.emailGroupDescription.length) { 
        this.errorservice.showerror({ type: 'Info', status: '', statusText: 'Please fill the form correctly' });
        return;
      }
      
      this.adminService.postEmailGroup(dataArray)
      .subscribe((response: any) => {
        if (response.status == 'Failed') {
          this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
          return;
        } else {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00795' });
          this.route.navigate(['/email-groups']);
        }
      });
    }
  }

  /**
* Cancel Confirmation Dialog
*/
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'email-groups' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

}
