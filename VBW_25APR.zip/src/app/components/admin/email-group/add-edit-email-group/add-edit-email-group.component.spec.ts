import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditEmailGroupComponent } from './add-edit-email-group.component';

describe('AddEditEmailGroupComponent', () => {
  let component: AddEditEmailGroupComponent;
  let fixture: ComponentFixture<AddEditEmailGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditEmailGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditEmailGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
