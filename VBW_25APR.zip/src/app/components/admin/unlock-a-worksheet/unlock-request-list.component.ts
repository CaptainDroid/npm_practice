
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { AdminService } from '../../../services/admin.service';
import { CommonService } from '../../../services/common.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogComponent } from '../../common/dialog/dialog.component';

@Component({
  selector: 'app-unlock-request-list',
  templateUrl: './unlock-request-list.component.html',
  styleUrls: ['./unlock-request-list.component.css', '../../../../assets/css/events.css']
})

export class UnlockRequestListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  displayedColumns: any[] = [
    'plant', 'module', 'worksheetName',
    'worksheetDate', 'reason', 'requestDate',
    'requestBy', 'status', 'isActionEnabled'];
  dataSource: MatTableDataSource<any>;
  modules = ['LAB', 'OPS', 'MAINT'];
  requestlistResponse: any;
  requestlist: any;
  selectedModule: any;
  userInfo: any;
  unlockrequestactionResponse: any;


  constructor(private adminService: AdminService,
    private errorservice: ErrorserviceService,
    public commonservice: CommonService,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private router: Router) {
    this.selectedModule = 'LAB';
    this.requestlist = [];
    this.userInfo = this.commonservice.getUser();
  }

  ngOnInit() {
    this.getunlockrequestlist();
  }

  getunlockrequestlist() {
    this.requestlist = [];
    this.adminService.getUnlockWorksheetRequestList(this.selectedModule).subscribe(
      (data: any) => {
        this.requestlistResponse = data;
        if (this.requestlistResponse.status !== 'success') {
          this.errorservice.showerror(
            {
              status: this.requestlistResponse.errorCode,
              statusText: this.requestlistResponse.message,
              type: 'error'
            });
        } else {
          this.requestlist = this.requestlistResponse.data;
          this.dataSource = new MatTableDataSource(this.requestlist);
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }
  switchmodule() {
    this.getunlockrequestlist();
  }

  requestaction(actiontype: any, worksheetid: any) {
    const warningmsg = (actiontype === 'approve') ? 'data.L01137' : 'data.L01138';
    const warndialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: { type: 'yesno', title: 'data.L00224', message: warningmsg }
    });
    const warningokcallbak = warndialogRef.componentInstance.okCallback.subscribe(result => {
      warndialogRef.componentInstance.closeDialog();
      this.adminService.unlockrequestaction(actiontype, worksheetid, this.selectedModule).subscribe(
        (data: any) => {
          this.unlockrequestactionResponse = data;
          if (this.unlockrequestactionResponse.status !== 'success') {
            this.errorservice.showerror(
              {
                status: this.unlockrequestactionResponse.errorCode,
                statusText: this.unlockrequestactionResponse.message,
                type: 'error'
              });
          } else {
            const successmsg = (actiontype === 'approve') ? 'data.L01139' : 'data.L01140';
            const dialogRef = this.dialog.open(DialogComponent, {
              width: '400px',
              disableClose: true,
              data: { title: 'data.L00224', message: successmsg }
            });
            const successokcallback = dialogRef.componentInstance.okCallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
              this.getunlockrequestlist();
            });
          }
        },
        (err: any) => {
          console.log(err);
        }
      );
    });
  }
}



