import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { AdminService } from 'src/app/services/admin.service';
import { CommonService } from 'src/app/services/common.service';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { Router } from '@angular/router';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';

@Component({
  selector: 'app-sample-test',
  templateUrl: './sample-test.component.html',
  styleUrls: ['./sample-test.component.css', '../../../../assets/css/events.css']
})
export class SampleTestComponent implements OnInit {

  // displayedColumns: string[] = ['plant', 'sample', 'description', 'descriptioncn', 'sampleType', 'customer', 'action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  // dataSource: MatTableDataSource<{}>;
  limit = 10;
  pageLimit: number[] = [10, 25, 100];
  totalLength: number;
  testList: any;

  names: any;
  cols: any;
  checked_boxes: any;
  checkboxes: any;
  regularList: any;
  plants: any;
  tests: any;
  sampleFilter = '';
  plantFilter: any;
  testsList: any;
  samples: any;
  fullData: any;
  newTag: any;
  ready: any;
  newone = [];

  constructor( private adminService: AdminService,
    private errorservice: ErrorserviceService,
    private route: Router,
    public dialog: MatDialog,
    private commonService: CommonService) {
     }

  ngOnInit() {
      let sampleList;
      /** Get sapmle type dropdown values */
       this.adminService.getSampleTypes().subscribe(( data: any) => {
        this.regularList = data.data.sampleTypes;

        sampleList = data.data.sampleTypes;

        const plants = [];
        /** Get plant dropdown values */
        this.commonService.getplants().subscribe(( pdata: any ) => {

          if (pdata.data.countries) {
            pdata.data.countries.forEach(element => {
              if (element.cities) {
                element.cities.forEach(item => {
                  if (item.plants) {
                    item.plants.forEach(plantItem => {
                      const plantObj = {
                        'id': plantItem.id,
                        'acronym': plantItem.acronym,
                        'name': plantItem.name
                      };
                      plants.push(plantObj);
                    });
                  }
                });
              }
            });
            this.plants = plants;
            this.plantFilter = plants[0].id;
            this.regularList.forEach(type => {
              if (type.wTypeCode === "REGR") {
                this.sampleFilter = type.wTypeId;
              }
            });
            this.getSampleTestMatrix();
          }
        },
        (err: any) => {
          console.log('There are no plants pulled from the server!');
        });
      }, (err) => {});

  }


  applyFilter(value, field) {
    if (field === 'plant') {
      this.plantFilter = value;
    } else {
      this.sampleFilter = value;
    }
    if (this.sampleFilter !== '') {
      this.getSampleTestMatrix();
    }
  }

  getSampleTestMatrix() {
     this.newone = [];
     /** Get sapmle tests */
     let tests;
      const sampleArray = [];
      // if (this.regularList === undefined) {
      //   this.applyFilter(this.plantFilter, 'plant');
      // }
      this.regularList.forEach(element => {
        sampleArray.push(element.wTypeId);
      });
     this.adminService.getLabTestList(this.plantFilter).subscribe(( ldata: any) => {
      // this.testsList = ldata.data.labtests;
      const tempTest = [], all = ldata.data.labtests;
      all.forEach(element => {
        if (element.labPlantTest.length > 0) {
          tempTest.push(element);
        }
      });
      this.testsList = tempTest;
       tests = ldata.data.labtests;

       /** Get lab sapmle all values */
       let samples;
       this.adminService.getLabSamples(this.plantFilter, this.sampleFilter).subscribe(( sdata: any) => {
       this.samples = sdata.data.labsamples;
       this.samples.sort((a, b) => {
        return a.sampleName.toLowerCase() < b.sampleName.toLowerCase() ? -1 :
        (a.sampleName.toLowerCase() > b.sampleName.toLowerCase() ? 1 : 0);
      });
       // this.samples = sdata.data.labsamples.slice(0, 50).map(i => {
       //   return i;
       // });
       samples = sdata.data.labsamples;

       this.getData();

     }, (err) => {});

     }, (err) => {});
  }

  getData() {
    if (this.samples !== undefined && this.testsList !== undefined) {
      const sample = this.samples;
      // .slice(0, 50).map(i => {
      //   return i;
      // });
      const tests = this.testsList;
      // this.checkboxes = sample.map( function(x) {
      //   // return tests.map( function(y) {
      //     return {'sampleId': x.sampleId, 'checked': false, 'editEnabled': false};
      //   // });
      // });
      /** Get Sample tests values */
      this.adminService.getLabSampleTests(this.plantFilter, this.sampleFilter).subscribe(( data: any ) => {
        this.fullData = data.data.sample;

        // const full = this.fullData.slice(1).slice(-50);

        const full = this.fullData;
        if (full.length > 0) {
          this.ready = false;
          const self = this;
          this.testsList = [];
          // this.samples = [];
          full[0].testAssoc.sort((a, b) => {
            return a.testName.toLowerCase() < b.testName.toLowerCase() ? -1 :
            (a.testName.toLowerCase() > b.testName.toLowerCase() ? 1 : 0);
          });
          full[0].testAssoc.forEach(test => {
            this.testsList.push({
              testName: test.testName,
              testId: test.testId
            });
          });
          this.samples.forEach(sample => {
            // ch.forEach(c => {
              full.forEach(f => {
                if(sample.sampleId === f.sampleId) {
                const a = [];
                self.ready = false;
                this.testsList.forEach(test => {
                  f.testAssoc.forEach(t => {
                    if(t.testId === test.testId) {
                      a.push({testId: t.testId, sampleId: f.sampleId, sampleType: f.sampleTypeId, checked: t.checked, editEnabled: t.editEnabled});
                      // if (t.testId === c.testId) {
                      // a[a.length - 1].checked = t.assocId !== 0 ? true : false;
                      // a[a.length - 1].editEnabled = t.editEnabled;
                      self.ready = true;
                    }
                    // }
                  });
                });
                // }
              // });
                this.newone.push(a);
              }
            });
          });

          this.checkboxes = this.newone;
        } else {
        this.newone = this.checkboxes ;
        }
        },
        (err: any) => {
          console.log('There are sample tests pulled from the server!');
        });
    }

  }

  onSubmit() {
    const finalArray = [];
    this.checkboxes.forEach(ch => {
      const a = [];
      ch.forEach(c => {
        if (c.checked) {
          a.push(c.testId);
        }
      });
      finalArray.push({'sampleId': ch[0].sampleId, 'testId': a });
    });
    const apiData = {
      // 'acronym': 'cz',
      'plantId': this.plantFilter,
      'sampleType': this.sampleFilter,
      // 'sampleType': 1,
      'sampletests': finalArray
    };
    this.adminService.postSampleTest(apiData)
      .subscribe((response: any) => {
        if (response.status !== 'Success') {
          this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
          return;
        } else {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00488' });
        }
      });
  }

   /**
* Cancel Confirmation Dialog
*/
/*openConfirmationDialog() {
  const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
    width: '400px',
    data: { route: '/' }
  });

  dialogRef.afterClosed().subscribe(result => {
    // console.log('The dialog was closed');
  });
}*/

cancelAssignment() {
  const dialogRef = this.dialog.open(DialogComponent, {
    width: '400px',
    disableClose: true,
    data: { type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
  });
  const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
    dialogRef.componentInstance.closeDialog();
   // this.ngOnInit();
   this.getSampleTestMatrix();
  });
}

  changeCheckbox(i, j) {
    this.newone[i][j].checked = !this.newone[i][j].checked;
  }

}
