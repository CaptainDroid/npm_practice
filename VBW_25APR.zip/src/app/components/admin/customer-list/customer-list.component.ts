import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommercialService } from '../../../services/commercial.service';
import { ContractService } from '../../../services/contract.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css', '../../../../assets/css/events.css']
})
export class CustomerListComponent implements OnInit {
  // [x: string]: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  plants = [];
  resultsLength = 0;
  customerDataresponce: any;
  plantDataresponce: any;
  displayedColumns: any[] = ['plant', 'customerName', 'industry', 'description', 'citiId', 'countryId', 'customerId', 'id'];
  //];
  customerData = [];
  dataSource: MatTableDataSource<any>;
  industries: any;
  searchFilter: any;
  plantFilter: any = 'selectPlant';
  selectResult: any[] = [];
  searchResult: any[] = [];
  isLoading = true;
  tableShow: boolean = false;

  constructor(
    private commercialService: CommercialService,
    // tslint:disable-next-line:no-shadowed-variable
    private ContractService: ContractService,
    private errorservice: ErrorserviceService,
    private route: ActivatedRoute,
    private datePipe: DatePipe,
    private router: Router) {

    /* customer list service */

    this.commercialService.getcustomerDataList().subscribe(
      (res: any) => {
        this.customerDataresponce = res;
        if (this.customerDataresponce.status !== 'success') {
          this.errorservice.showerror({
              status: this.customerDataresponce.errorCode,
              statusText: this.customerDataresponce.message
            });
        } else {
        const dataResponce: any = res;
        this.customerData = [];

        for (let i = 0; i < this.customerDataresponce.data.countries.length; i++) {
          for (let j = 0; j < this.customerDataresponce.data.countries[i].cities.length; j++) {
            for (let k = 0; k < this.customerDataresponce.data.countries[i].cities[j].plants.length; k++) {
              for (let l = 0; l < this.customerDataresponce.data.countries[i].cities[j].plants[k].customer.length; l++) {
                let plantobj = this.customerDataresponce.data.countries[i].cities[j].plants[k].customer[l];
                plantobj.countryId = (this.customerDataresponce.data.countries[i].id != null || this.customerDataresponce.data.countries[i].id != undefined) ? this.customerDataresponce.data.countries[i].id : "";
                plantobj.citiId = (this.customerDataresponce.data.countries[i].cities[j].id != null || this.customerDataresponce.data.countries[i].cities[j].id != undefined) ? this.customerDataresponce.data.countries[i].cities[j].id : "";
                plantobj.plant = (this.customerDataresponce.data.countries[i].cities[j].plants[k].plantAcronym != null || this.customerDataresponce.data.countries[i].cities[j].plants[k].plantAcronym != undefined) ? this.customerDataresponce.data.countries[i].cities[j].plants[k].plantAcronym : "";
                plantobj.plantId = this.customerDataresponce.data.countries[i].cities[j].plants[k].id;
                plantobj.customerId = this.customerDataresponce.data.countries[i].cities[j].plants[k].customer[l].customerId;
                plantobj.industry = this.customerDataresponce.data.countries[i].cities[j].plants[k].customer[l].industryName;
                // for (let item of this.industries) {
                //   if (item.paramid === plantobj.industry) {
                //     plantobj.industry = item.paramvalue
                //   }
                // }
                plantobj.customerName = (plantobj.customerName != null && plantobj.customerName !== undefined) ? plantobj.customerName : "";
                plantobj.industry = ((plantobj.industry !== null) && (plantobj.industry !== undefined) && (plantobj.industry !== -1)) ? plantobj.industry : "";
                plantobj.description.en = (plantobj.description.en !== null && plantobj.description.en !== undefined) ? plantobj.description.en : "";
                plantobj.description.cn = (plantobj.description.cn !== null && plantobj.description.cn !== undefined) ? plantobj.description.cn : "";
                plantobj.contractName = (plantobj.contractName !== null && plantobj.contractName !== undefined) ? plantobj.contractName : "";
                plantobj.endDate = this.customerDataresponce.data.countries[i].cities[j].plants[k].customer[l].expire_Date;
                plantobj.expire_Date =  plantobj.expire_Date === "1900-01-01T00:00:00" ? null : this.datePipe.transform(plantobj.expire_Date, 'dd/MMM/yy');


                this.customerData.push(plantobj);
                this.resultsLength = this.resultsLength + 1;
              }
            }
          }
        }
        this.customerData.sort(function(a: any, b: any) {
          // let aExpire_Date: any = new Date(a.expire_Date);
          // let bExpire_Date: any = new Date(b.expire_Date);
          // return aExpire_Date - bExpire_Date;
          let keyA = new Date(a.endDate),
          keyB = new Date(b.endDate);
          // Compare the 2 dates
          if (keyA < keyB) return -1;
          if (keyA > keyB) return 1;
          return 0;
        });
        this.isLoading = false;
        this.dataSource = new MatTableDataSource(this.customerData);
        this.dataSource.paginator = this.paginator;
        if(this.plants && this.plants.length) {
          this.plantFilter = this.plants[0].acronymName;
          this.applyFilter(this.plantFilter);          
        }
        // this.dataSource._updatePaginator(this.dataSource.filteredData.length);
      }
    });

    /* Plant drop down service*/

    this.commercialService.getPlants().subscribe(data => {
      this.plantDataresponce = data;
      const result: any = data;
      this.plants = [];
      if (this.plantDataresponce.status !== 'success') {
        this.errorservice.showerror({ status: this.plantDataresponce.status, statusText: this.plantDataresponce.message });
      } else {
        for (let i = 0; i < this.plantDataresponce.data.countries.length; i++) {
          for (let j = 0; j < this.plantDataresponce.data.countries[i].cities.length; j++) {
            for (let k = 0; k < this.plantDataresponce.data.countries[i].cities[j].plants.length; k++) {
              let plantobjList = this.plantDataresponce.data.countries[i].cities[j].plants[k];
              plantobjList.id = this.plantDataresponce.data.countries[i].cities[j].plants[k].id;
              plantobjList.acronymName = this.plantDataresponce.data.countries[i].cities[j].plants[k].acronym;
              this.plants.push(plantobjList);
            }
          }
        }

        /**
         *  Pre-selecting a plant by default
         */
        if(this.plants && this.plants.length) {
          this.plantFilter = this.plants[0].acronymName;
          if(this.customerData && this.customerData.length) {
            this.applyFilter(this.plantFilter);
          }
        }

      }
    });
  }

  ngOnInit() { 
    this.ContractService.goBack = "false";
  }

  applyFilter(filterValue: string) {
    if (this.plantFilter === 'selectPlant') {
      if (this.searchFilter) {
        this.filterSearch(this.customerData, this.searchFilter);
      }
      else{
        this.dataSource = new MatTableDataSource(this.customerData);
      }
      if (filterValue === this.searchFilter) {
        this.filterSearch(this.customerData, filterValue);
      }
    } else {
      if (this.searchFilter && this.plantFilter) {
        this.searchAndSelectFilter(filterValue);
      } else {
        if (this.searchFilter && !this.plantFilter) {
          filterValue = this.searchFilter;
          this.filterSearch(this.customerData, filterValue);
        } else if (!this.searchFilter && this.plantFilter) {
          filterValue = this.plantFilter;
          this.filterSelect(this.customerData, filterValue);
        }
      }
    }
    // this.tableShow = true;
    this.dataSource.paginator = this.paginator;
    this.dataSource.paginator.firstPage();
    this.dataSource.sort = this.sort;
  }

  filterSearch(data, filterValue) {
    this.searchResult = data.filter(item => {
      return (item.expire_Date ? (item.expire_Date.toString().toLowerCase().includes(filterValue.toLowerCase())): '') ||
      (item.plant.toString().toLowerCase().includes(filterValue.toLowerCase())) || (item.customerName.toString().toLowerCase().includes(filterValue.toLowerCase())) || (item.industry.toString().toLowerCase().includes(filterValue.toLowerCase())) || (item.description.en.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
        (item.description.cn.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
        (item.contractName.toString().toLowerCase().includes(filterValue.toLowerCase()))
    });
    this.dataSource = new MatTableDataSource(this.searchResult);
  }

  filterSelect(data, filterValue) {
    this.selectResult = data.filter(item => item.plant === filterValue);
    this.dataSource = new MatTableDataSource(this.selectResult);
  }

  searchAndSelectFilter(filterValue) {
    if (filterValue === this.searchFilter) {
      this.filterSelect(this.customerData, this.plantFilter);
      this.filterSearch(this.selectResult, filterValue);
    } else {
      this.filterSearch(this.customerData, this.searchFilter);
      this.filterSelect(this.searchResult, filterValue);
    }
  }

  onClickAdd() {
    this.router.navigate(['addCustomer']);
  }

  edit(row: any): void {
    const customerData = {
      customerName: row.customerName,
      plant: row.plant,
      contract: row.contractName,
      country: row.countryId,
      city: row.citiId,
      plantId: row.plantId,
      customerId: row.customerId,
      customerAcronym: row.customerAcronym,
      contractId: row.customerContractId
    }
    sessionStorage.setItem('selectedCustomer', JSON.stringify(customerData));
    this.ContractService.customerId = row.customerId;
    this.ContractService.contract = row.customerContractId;
    this.router.navigate(['/edit-customer-contract/' + row.customerId]);
  }

  editUser(row: any): void {
    const customerData = {
      customerName: row.customerName,
      plant: row.plant,
      contract: row.contractName,
      country: row.countryId,
      city: row.citiId,
      plantId: row.plantId,
      customerId: row.customerId,
      customerAcronym: row.customerAcronym
    }
    sessionStorage.setItem('selectedCustomer', JSON.stringify(customerData));
    this.ContractService.customerId = row.customerId;
    this.ContractService.contract = row.customerContractId;
    if (!row.customerContractId) {
      this.router.navigate(['/customer-contract']);
    } else {
      this.router.navigate(['/edit-contract/' + this.ContractService.customerId]);
    }

  };
}



