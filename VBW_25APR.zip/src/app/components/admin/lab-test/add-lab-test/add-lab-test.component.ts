import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { EventsService } from 'src/app/services/events.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CancelConfirmationDialogComponent } from '../../../events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { LabTest } from '../lab-test.component';
import { CommonService } from 'src/app/services/common.service';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-add-lab-test',
  templateUrl: './add-lab-test.component.html',
  styleUrls: ['./add-lab-test.component.css', '../../../../../assets/css/events.css']
})
export class AddLabTestComponent implements OnInit {

  validation_messages = {
    'testName': [
      { type: 'required', message: 'data.L00329' },
      { type: 'pattern', message: 'data.L00520' },
      { type: 'alpha', message: 'data.L00520' }
    ],
    'plants': [
      { type: 'required', message: 'data.L00329'},
      { type: 'min', message: 'data.L00329'}
    ],
    'maxValue': [
      { type: 'invalid', message: 'Maximum value should be greater than minimum value'}
    ],
    'minValue': [
      { type: 'invalid', message: 'Minimum value should be greater than maximum value'}
    ],
    'uom': [
      { type: 'required', message: 'data.L00329'}
    ]
  };

  addNewLabTestForm: FormGroup;
  isEdit = false;
  isDelete = false;
  isSubmitted = false;
  invalidMax = false;
  invalidMin = false;
  invalidLimit = false;
  labTestId;
  minValue;
  maxValue;
  plants = JSON.parse(sessionStorage.getItem('plants'));
  uoms = [];
  selectedPlants = [];
  prevPlantId = 0;
  plantId;

  constructor(private _adminService: AdminService,
              private _formBuilder: FormBuilder,
              private _router: Router,
              private _dialog: MatDialog,
              private _route: ActivatedRoute,
              private _errorService: ErrorserviceService,
              private _commonService: CommonService) { }



  ngOnInit() {
    if (this._route.params['value'].hasOwnProperty('labTestId')) {
      this.isEdit = true;
      this.labTestId = this._route.params['value'].labTestId;
      this.plantId = this._route.params['value'].plantId;
    }

    if (!this.plants || !this.plants.length) {
      this.getPlants();
    }

    this.getUoms();

    this.addNewLabTestForm = this._formBuilder.group({
      testName: new FormControl({value: '', disabled: this.isEdit}, [Validators.required]),
      // plants: new FormControl('', [Validators.required, Validators.min(1)]),
      plants: new FormControl(''),
      minValue: [{ value: '' }],
      maxValue: [{ value: '' }],
      uom: new FormControl({value: '', disabled: this.isEdit}, [Validators.required]),
    });

    if (this.isEdit) {
      const selectedPlantId = JSON.parse(sessionStorage.getItem('labTestPlant'));
      this.getLabTestData(this.labTestId, this.plantId);
      this.prevPlantId = parseInt(this._route.params['value'].plantId, 10);
    } else {
      this.selectedPlants.push((parseInt(this._route.params['value'].plantid, 10)));
      this.prevPlantId = parseInt(this._route.params['value'].plantid, 10);
      this.addNewLabTestForm.controls['plants'].setValue(this.selectedPlants);
    }
  }

  public getLabTestData(labTestId, plantId) {
    this._adminService.getLabTestData(labTestId, plantId).subscribe(
      data => {
        if (data['status'] !== 'success') {
          this._errorService.showerror({status: data['status'], message: data['message']});
          return;
        }
        const res = data['data']['labtest']['labPlantTest'];
        const selectedPlants = [];
        res.forEach(test => {
          selectedPlants.push(test.plantId);
        });
        this.selectedPlants = selectedPlants;
        console.log('selected', selectedPlants, this.plants);
        this.addNewLabTestForm.setValue({
          testName: data['data']['labtest'].testName,
          plants: selectedPlants,
          minValue: res && res.length ? res[0].minValue : '',
          maxValue: res && res.length ? res[0].maxValue : '',
          uom: data['data']['labtest'].uomid
        });
      }
    );
  }

  public getPlants() {
    this._commonService.getplants().subscribe(
      (val: any) => {
        const plantsresponse = val['data'];
        const countries = plantsresponse['countries'];
        const plantCodeList = [];
        countries.forEach(country => {
          const cities = country['cities'];
          cities.forEach(city => {
            const plants = city['plants'];
            plants.forEach(plant => {
              const plantCode = {
                id: plant.id,
                acronym: plant.acronym,
                plantName: plant.name,
                countryId: country.id,
                countryName: country.name,
                cityId: city.id
              };
              plantCodeList.push(plantCode);
            });
          });
        });
        this.plants = plantCodeList;
      });
  }

  selectingPlant(event) {
    this.prevPlantId = event[0];
  }

  setDisable(id) {
    if (this.isEdit) {
      if (this.selectedPlants.indexOf(id) !== -1) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  public getUoms() {
    this._commonService.getuoms().subscribe(
      data => {
        this.uoms = [];
        if (data['status'] !== 'success') {
          this._errorService.showerror({ status: data['status'], statusText: data['message'] });
          return;
        }
        const res = data['data'];
        res.forEach(uom => {
          let uomobj: {
            uomId: any, uomName: any
          };
          uomobj = {
            uomId: uom.uomid,
            uomName: uom.uomdesc
          };
          this.uoms.push(uomobj);
        });
      }
    );
  }

  removeNonDigits(event) {
    this.validate(event);
    this.addNewLabTestForm.controls[event.target.attributes.formcontrolname.nodeValue].
    setValue(event.target.value.replace(/[^\d.\-]/g, ''));
  }

  handleFloat(event) {
    if (this.countDecimals(event.target.value) > 3) {
      // tslint:disable-next-line:max-line-length
      this.addNewLabTestForm.controls[event.target.attributes.formcontrolname.nodeValue].setValue(parseFloat(event.target.value).toFixed(3));
    }
  }

  countDecimals(value) {
    if ((value % 1) !== 0) {
        return value.toString().split('.')[1].length;
    }
    return 0;
  }

  // Prevent blank space to enter intially
  handleInitialSpace(e) {
    if (e.target.value.length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  noSpace(e) {
    if (e.keyCode === 32) {
        e.preventDefault();
    }
  }

removeSpace(event) {
  // First one to remove Chinese characters
  this.addNewLabTestForm.controls[event.target.attributes.formcontrolname.nodeValue].
  setValue(event.target.value.replace(/[^\x00-\x7F]/g, ''));
  // This one to remove spaces
  this.addNewLabTestForm.controls[event.target.attributes.formcontrolname.nodeValue].
  setValue(event.target.value.replace(/[\s]/g, ''));
  }


  validate(event) {
        /**** Pattern validation - STARTS */
        const format = /^-?[0-9\.]\d*(\.\d+)?$/;
        if (event.target.attributes.formcontrolname.nodeValue === 'maxValue') {
          const limit = this.addNewLabTestForm.value.maxValue;
          if (limit && (!format.test(limit) || (limit === '.') || (limit === '-.'))) {
            this.invalidMax = true;
          } else {
            this.invalidMax = false;
          }
        }
        if (event.target.attributes.formcontrolname.nodeValue === 'minValue') {
          const limit = this.addNewLabTestForm.value.minValue;
          if (limit && (!format.test(limit) || (limit === '.') || (limit === '-.'))) {
            this.invalidMin = true;
          } else {
            this.invalidMin = false;
          }
        }
        /** Pattern validation - ENDS */

        if ((this.addNewLabTestForm.value.maxValue != null &&
          this.addNewLabTestForm.value.minValue !== null) &&
          (Number(this.addNewLabTestForm.value.minValue) >= Number(this.addNewLabTestForm.value.maxValue))) {
          this.invalidLimit = true;
        } else {
          this.invalidLimit = false;
        }
  }


  public onSubmit() {
    this.isSubmitted = true;
    if (this.addNewLabTestForm.valid && !this.invalidLimit) {
      const formValue = { ...this.addNewLabTestForm.getRawValue() };
      formValue.action = this.isEdit ? 'Update' : 'Create';
      formValue.action = this.isDelete ? 'Delete' : formValue.action;

      const formData = this.prepareLabData(formValue);
      /**
       * Add/Edit Form Data - POST
       */
      this._adminService.addLabTest(formData).subscribe(
        (data: any) => {
          if (data.status === 'success') {
            if (this.isEdit) {
              if(this.isDelete) {
                this._errorService.showerror({ type: 'Info', status: '', statusText: 'data.L01205' });
              } else {
              this._errorService.showerror({ type: 'Info', status: '', statusText: 'data.L01204' });
              }
            } else {
              this._errorService.showerror({ type: 'Info', status: '', statusText: 'data.L01202' });
            }

            this._router.navigate(['/lab-test-list', this.prevPlantId]);
          } else {
            this.isDelete = false;
            this._errorService.showerror({ status: data.status, statusText: data.message });
          }
        },
        (err: any) => {
          this.isDelete = false;
          console.log('Failed');
        }
      );
    } else {
      this.isDelete = false;
    }
  }

  public prepareLabData(data) {
    const labPlantTest = [];
    data.plants.forEach(plant => {
      labPlantTest.push({
        plantId: plant,
        testId: this.isEdit ? this.labTestId : 0,
        minValue: data.minValue,
        maxValue: data.maxValue,
        isDeleted: this.isDelete
      });
    });
    const res = {
      action: data.action,
      testId: this.isEdit ? this.labTestId : 0,
      testName: data.testName,
      uomid: data.uom,
      labPlantTest: labPlantTest
    };
    return res;
  }

  openConfirmationDialog() {
    const dialogRef = this._dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route:  this.isDelete ? null : 'lab-test-list/' + this.prevPlantId, type: this.isDelete ? 'delete' : null }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === true && this.isDelete) {
        this.onSubmit();
      }
    });
  }

  deleteLabTest() {
    this.isDelete = true;
    this.openConfirmationDialog();
  }

  removeNonEnglish(event) {
    // tslint:disable-next-line:max-line-length
    this.addNewLabTestForm.controls[event.target.attributes.formcontrolname.nodeValue].setValue(event.target.value.replace(/[^\x00-\x7F]/g, '').trim());
  }

}
