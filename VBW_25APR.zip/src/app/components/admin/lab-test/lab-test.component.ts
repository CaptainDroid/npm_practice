import { Component, OnInit, ViewChild } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { CommonService } from 'src/app/services/common.service';
import { MatPaginator, MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-lab-test',
  templateUrl: './lab-test.component.html',
  styleUrls: ['./lab-test.component.css']
})
export class LabTestComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  labTests: LabTest[] = [];
  allTests = [];
  plants = [];
  dataSource: any;
  displayedColumns: string[] = ['plantAcronym', 'testName', 'minimum', 'maximum', 'action'];
  filterString = '';
  selectedPlant: any;
  selectedTest = '';
  pramPlantId: any;

  constructor( public adminService: AdminService,
              private _commonService: CommonService,
              private _errorService: ErrorserviceService,
              private _router: Router,
              private route: ActivatedRoute,
              private _dialog: MatDialog ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.pramPlantId = params.plantid;
    });
    this.getLabTestList();
    this.getPlants();
  }

  public getLabTestList() {
    this.adminService.getLabTests().subscribe(
      (data: any) => {
        if (data['status'] !== 'success') {
          this._errorService.showerror({status: data['status'], message: data['message']});
          return;
        }
        const labTestsData = data['data']['labtests'];
        labTestsData.forEach(labTest => {
          this.allTests.push({
            testId: labTest.testId,
            testName: labTest.testName
          });
          if (labTest.labPlantTest && labTest.labPlantTest.length) {
            labTest.labPlantTest.forEach( test => {
              this.labTests.push( this.createRow(labTest, test) );
            });
          } else {
            this.labTests.push( this.createRow(labTest, {}) );
          }
        });

        this.sortListByPlantThenTest();

        if (!this.pramPlantId ) {
          this.selectedPlant = 0;
        } else {
          this.selectedPlant = parseInt(this.pramPlantId , 10);
        }
        this.applyFilter();

        // this.dataSource = new MatTableDataSource(this.labTests);
        // this.dataSource.paginator = this.paginator;
        // this.dataSource.sort = this.sort;
    });
  }

  public getPlants() {
    this._commonService.getplants().subscribe(
      (val: any) => {
        const plantsresponse = val['data'];
        const countries = plantsresponse['countries'];
        const plantCodeList = [];
        countries.forEach(country => {
          const cities = country['cities'];
          cities.forEach(city => {
            const plants = city['plants'];
            plants.forEach(plant => {
              const plantCode = {
                id: plant.id,
                acronym: plant.acronym,
                plantName: plant.name,
                countryId: country.id,
                countryName: country.name,
                cityId: city.id
              };
              plantCodeList.push(plantCode);
            });
          });
        });
        this.plants = plantCodeList;
      });
  }

  public applyFilter() {
    this.dataSource = new MatTableDataSource(this.labTests);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    if (this.selectedPlant === 0 && this.selectedTest === '') {
      if (this.dataSource) {
        this.dataSource.filter = this.filterString.toLowerCase();
      }
      if (this.dataSource.paginator) {
        this.dataSource.paginator.firstPage();
      }
    } else {
      this.filterUsers();
    }
  }

  filterUsers() {
    const self = this;
    const filteredData = this.labTests.filter(data => {
      try {
          return (
                 data.plantAcronym.toLowerCase().includes(self.filterString)
              || data.testName.toLowerCase().includes(self.filterString)
              || data.minimum.toString().toLowerCase().includes(self.filterString)
              || data.maximum.toString().toLowerCase().includes(self.filterString) )
          && (self.selectedPlant === 0 ? true : data.plantId.toString() === self.selectedPlant.toString())
          && (self.selectedTest === '' ? true : data.testName.toLowerCase() === self.selectedTest.toLowerCase());
      } catch (e) {
        return false;
      }
    });
    this.dataSource = new MatTableDataSource(filteredData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.paginator.firstPage();
  }

  public createRow(labTest, test) {
    const row = {
      testId: labTest.testId,
      testName: labTest.testName,
      plantId: test.plantId ? test.plantId : '',
      plantAcronym: test.acronym ? test.acronym : '',
      minimum: test.minValue ? test.minValue : '',
      maximum: test.maxValue ? test.maxValue : ''
    };

    return row;
  }

  public addLabTest() {
    this._router.navigate(['add-lab-test', this.selectedPlant]);
  }

  public editLabTest(labTest) {
    this._router.navigate(['edit-lab-test/' + labTest.testId + '/' + (labTest.plantId !== '' ? labTest.plantId : 0)]);
  }

  public sortListByPlantThenTest() {
    this.labTests.sort((a, b) => {

      const aPlant = a.plantAcronym.toString().toLowerCase();
      const bPlant = b.plantAcronym.toString().toLowerCase();
      const aTest = a.testName.toString().toLowerCase();
      const bTest = b.testName.toString().toLowerCase();

      /**
       * This statement will sort the List of Tests first by Plant, and then by Test Name
       */
      return (aPlant < bPlant ? -1 : ( aPlant > bPlant ? 1 : ( aTest < bTest ? -1 : ( aTest > bTest ? 1 : 0 ))));
    });
  }

}

export interface LabTest {
  plantAcronym: string;
  plantId: number;
  testId: number;
  testName: string;
  minimum: number;
  maximum: number;
}
