import { Component, Input, AfterViewInit } from '@angular/core';
import * as Chart from 'chart.js';


@Component({
  selector: 'app-linechart',
  templateUrl: './linechart.component.html',
  styleUrls: ['./linechart.component.css']
})
export class LinechartComponent implements AfterViewInit {

  @Input() data: any;
  @Input() elementId: string;
  @Input() color: string;
  @Input() name: string;

  lineChart;
  canvas: any;
  ctx: any;
  label: string; // The label/title/name for the dataset
  labels: any[]; // The x-axis values
  values: any[];
  
  constructor() { }

  ngOnInit() {

    // if(this.data === undefined) return;
    
    if(this.data !== undefined) {
      this.labels = this.data.data[1];
      this.label = this.data.label;
      this.values = this.data.data[0];
    }
    else  {
      this.label = this.name;
    }

  }
  ngAfterViewInit() {
 
    this.canvas = document.getElementById(this.elementId);
    if(this.canvas == null) return;
    this.ctx = this.canvas.getContext('2d');
    this.lineChart = new Chart(this.ctx, {
      type: 'line',
      data: {
        labels: this.labels,
        datasets: [{
          label: this.label,
          data: this.values,
          fill: false,
          backgroundColor: this.color,
          borderColor: this.color,
          borderWidth: 2,
          pointHitRadius: 20
        }]
      },
      options: {
        elements: {
          point:{
              radius: 2
          }
        },
        legend: {
          position: 'bottom'
        },
        responsive: true,
        display: true,
        maintainAspectRatio: false
      }
    })
  }
  ngOnChanges(changes) {
    if(changes === undefined) return;
    if( changes && changes.data && !changes.data.firstChange) {
      // console.log('CHAAAAANGE', JSON.stringify(changes));
      this.lineChart.data = {
        labels: changes.data.currentValue.data[1],
        datasets: [{
          label: this.label,
          data: changes.data.currentValue.data[0],
          fill: false,
          backgroundColor: this.color,
          borderColor: this.color,
          borderWidth: 2,
          pointHitRadius: 20
        }]
      }
      this.lineChart.update();
    }
  }

  update(data) {
    this.labels = data.data[1];
    this.label = data.label;
    this.values = data.data[0];

    this.lineChart.data = {
      labels: this.labels,
      datasets: [{
        label: this.label,
        data: this.values,
        fill: false,
        backgroundColor: this.color,
        borderColor: this.color,
        borderWidth: 2,
        pointHitRadius: 20
      }]
    }
    this.lineChart.update();
  }
  
}
