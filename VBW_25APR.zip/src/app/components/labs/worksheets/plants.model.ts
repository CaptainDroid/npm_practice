export class Plants {
  public id: number;
  public value: string;

  constructor(
      id: number,
      value: string ) {
          this.id = id;
          this.value = value;
      }

}
