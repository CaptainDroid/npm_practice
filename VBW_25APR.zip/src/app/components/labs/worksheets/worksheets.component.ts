import { Component, OnInit, Inject, HostListener, EventEmitter, Output } from '@angular/core';
import { WorksheetService } from '../../../services/worksheet.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { Worksheet } from './worksheet.model';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { SubmitworksheetDialogComponent } from './editworksheet/submitworksheet/submitworksheet.component';
import { CommonService } from '../../../services/common.service';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { environment } from '../../../../environments/environment';
export interface AddworksheetData {
    id: any;
    name: string;
}

@Component({
    selector: 'app-worksheets',
    templateUrl: './worksheets.component.html',
    styleUrls: ['./worksheets.component.css']
})
export class WorksheetsComponent implements OnInit {

    worksheetresponse: any;
    worksheets = [];
    position = 'after';
    errorMessage: any;

    sworksheetresonse: any;
    sworksheetData: any;

    plantsresponse: any;
    plants = [];
    selectedPlant = 0;
    selectedPlantObj: any;

    wstemplatesresponse: any;
    wstemplates: any;
    selectedwstemplate: any;

    newworksheetResonse: any;
    submitworksheetResponse: any;
    reasons: any;

    pageaccess =  environment.role.lab;

    isEdit = false;

    constructor(public route: ActivatedRoute,
        public router: Router,
        private worksheetService: WorksheetService,
        private errorservice: ErrorserviceService,
        private commonservice: CommonService,
        public dialog: MatDialog, @Inject(DOCUMENT) document) {
          // this.commonservice.setTitle('Lab - Worksheets');
          this.isEdit = this.commonservice.isAccess(this.pageaccess.edit);
        }

    ngOnInit() {
        this.plants = [];
        this.route.params.subscribe(params => {
            if (!params.plantid) {
                this.selectedPlant = 0;
                this.getplants(this.selectedPlant);
            } else {
                this.selectedPlant = parseInt(params.plantid, 10);
                this.getplants(this.selectedPlant);
            }
        });
    }

    getplants(plantId: any) {
        this.worksheetService.getplants().subscribe(
            data => {
                this.plantsresponse = data;
                this.plants = [];
                if (this.plantsresponse.status !== 'success') {
                    this.errorservice.showerror({ status: this.plantsresponse.status, statusText: this.plantsresponse.message });
                } else {
                    for (let i = 0; i < this.plantsresponse.data.countries.length; i++) {
                        for (let j = 0; j < this.plantsresponse.data.countries[i].cities.length; j++) {
                            for (let k = 0; k < this.plantsresponse.data.countries[i].cities[j].plants.length; k++) {
                                const plantobj = this.plantsresponse.data.countries[i].cities[j].plants[k];
                                plantobj.countryId = this.plantsresponse.data.countries[i].id;
                                plantobj.citiId = this.plantsresponse.data.countries[i].cities[j].id;
                                this.plants.push(plantobj);
                            }
                        }
                    }
                    if (plantId === 0) {
                        this.worksheets = [];
                        this.selectedPlant = 0;
                        if (this.plants.length > 0) {
                            this.getWorksheets(this.plants[0]);
                        }
                    } else {
                        const plantobj = this.plants.filter(plant => {
                            return plant.id === plantId;
                        });
                        this.selectedPlant = plantId;
                        if (plantobj[0]) {
                            this.getWorksheets(plantobj[0]);
                        }
                    }
                }
            },
            (err: any) => {
                console.log(err);
                this.errorMessage = 'data.L00235';
            }
        );
    }

    getWorksheets(plantobj: any) {
        this.selectedPlant = plantobj.id;
        this.selectedPlantObj = plantobj;
        this.worksheets = [];
        const info = {
            'countryId': plantobj.countryId,
            'citiId': plantobj.citiId,
            'acro': plantobj.acronym
        };
        this.worksheetService.setworksheetUserinfo(info);
        if (plantobj.id === 0) {
            this.worksheets = [];
            this.wstemplates = [];
        } else {
            // this.getworksheettemplates(plantobj.id);
            this.worksheetService.worksheets(plantobj.id).subscribe(
                data => {
                    this.worksheetresponse = data;
                    if (this.worksheetresponse.status !== 'success') {
                        this.errorservice.showerror(
                          { status: this.worksheetresponse.errorCode,
                            statusText: this.worksheetresponse.message
                          });
                    } else {
                        for (let i = 0; i < this.worksheetresponse.data.country.city.plant.worksheets.length; i++) {
                            const worksheetobj = this.worksheetresponse.data.country.city.plant.worksheets[i];
                            if (worksheetobj.worksheetStatus) {
                              worksheetobj.worksheetStatus = worksheetobj.worksheetStatus.toLowerCase();
                              if (worksheetobj.worksheetStatus === 'new') {
                                worksheetobj.displayStatus = 'data.L00007';
                              } else if (worksheetobj.worksheetStatus === 'active') {
                                worksheetobj.displayStatus = 'data.L00008';
                              } else if (worksheetobj.worksheetStatus === 'unlocked') {
                                worksheetobj.displayStatus = 'data.L00010';
                              } else if (worksheetobj.worksheetStatus === 'locked') {
                                worksheetobj.displayStatus = 'data.L00011';
                              }
                            }
                            this.worksheets.push(worksheetobj);
                        }
                    }
                },
                (err: any) => {
                    this.errorMessage = 'data.L00235';
                }
            );
        }
    }

    getworksheettemplates(plantid: any) {
        this.worksheetService.getwstemplates(plantid).subscribe(
            data => {
                this.wstemplatesresponse = data;
                this.wstemplates = [];
                if (this.wstemplatesresponse.status !== 'success') {
                    this.errorservice.showerror(
                      { status: this.wstemplatesresponse.errorCode,
                        statusText: this.wstemplatesresponse.message
                      });
                } else {
                    for (let i = 0; i < this.wstemplatesresponse.data.countries.length; i++) {
                        for (let j = 0; j < this.wstemplatesresponse.data.countries[i].cities.length; j++) {
                            for (let k = 0; k < this.wstemplatesresponse.data.countries[i].cities[j].plants.length; k++) {
                                // tslint:disable-next-line:max-line-length
                                for (let l = 0; l < this.wstemplatesresponse.data.countries[i].cities[j].plants[k].wstemplates.length; l++) {
                                    const templateObj = this.wstemplatesresponse.data.countries[i].cities[j].plants[k].wstemplates[l];
                                    templateObj.plantId = this.wstemplatesresponse.data.countries[i].cities[j].plants[k].id;
                                    templateObj.countryId = this.wstemplatesresponse.data.countries[i].id;
                                    templateObj.citiId = this.wstemplatesresponse.data.countries[i].cities[j].id;
                                    this.wstemplates.push(templateObj);
                                }
                            }
                        }
                    }
                    this.showaddworksheetDialog();
                }
            },
            (err: any) => {
                this.errorMessage = 'There are no wstemplates pulled from the server!';
            }
        );
    }

    openAddworksheetDiaog() {
        if (this.selectedPlant === 0) {
            const errorMsg = 'data.L00162';
            this.errorservice.showerror({status: '', statusText: errorMsg});
        } else  {
            this.getworksheettemplates(this.selectedPlant);
        }
    }

    showaddworksheetDialog(): void {
      const dialogRef = this.dialog.open(AddworksheetDialogComponent, {
        width: '400px',
        data: this.wstemplates,
        disableClose: true
    });

    /*dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.addworksheetname = result;
      this.addworksheet();
    });*/

    const sub = dialogRef.componentInstance.addworksheetcallback.subscribe(result => {
        this.selectedwstemplate = result;
        this.newworksheet();
    });
    }

    newworksheet() {
        let wsType = '3PTY';
        let tempId = 0;
        if (this.selectedwstemplate.worksheetType === 'adhoc') {
            tempId = 0;
            wsType = 'ADHO';
        } else {
            tempId = this.selectedwstemplate.id;
            wsType = '3PTY';
        }
        const createworksheetReq = {
            worksheetType: wsType,
            action: 'Create',
            id: 0,
            templateId: tempId,
            worksheetName: '',
            worksheetDate: new Date(),
            reason: '',
            remarks: '',
            samples: []
        };
        this.worksheetService.addworksheet(createworksheetReq, this.selectedPlant).subscribe(
            serviceResponse => {
                this.newworksheetResonse = serviceResponse;
                if (this.newworksheetResonse.status !== 'success') {
                    this.errorservice.showerror(
                      { status: this.newworksheetResonse.errorCode,
                        statusText: this.newworksheetResonse.message
                      });
                } else {
                    this.getWorksheets(this.selectedPlantObj);
                }
            },
            (err: any) => {
                console.log(err);
                this.errorMessage = 'Failed to save worksheet';
            }
        );
    }

    opensubmitworksheetDialog(worksheet) {
      if (worksheet.type === 'ADHO' && (worksheet.remarks === null || worksheet.remarks === '')) {
          this.getreasons(worksheet);
      } else {
          this.getworksheetinfo(worksheet,{});
      }
    }

    getworksheetinfo(worksheet: any, adhocinfo: any) {
        const worksheetInfo = {
            'plantid': this.selectedPlant,
            'worksheetid': worksheet.id
        };
        this.worksheetService.editworksheetdata(worksheetInfo).subscribe(
            data => {
                this.sworksheetresonse = data;
                this.sworksheetData = this.sworksheetresonse.data.country.city.plant.worksheet;
                if (adhocinfo.remarks !== '') {
                    this.sworksheetData.remarks = adhocinfo.remarks;
                }
                if (adhocinfo.reason !== '') {
                    this.sworksheetData.remarkTypeId = adhocinfo.reason;
                }
                const dialogRef = this.dialog.open(SubmitworksheetDialogComponent, {
                    width: '90%',
                    data: { 'mode': 'submit', 'samples': this.sworksheetData.samples }
                });
                const sub = dialogRef.componentInstance.submitworksheetcallback.subscribe(result => {
                    dialogRef.componentInstance.closeDialog();
                    this.submitws();
                });
            },
            (err: any) => {
                this.errorMessage = err;
            }
        );
    }
    submitws() {
        const requestObj = this.preparereqobj(this.sworksheetData);
        requestObj.action = 'Submit-MSUB';
        if (requestObj.remarkTypeId === null) {
            requestObj.remarks = '';
        }
        this.worksheetService.submitworksheet(requestObj, this.sworksheetresonse).subscribe(
            data => {
                this.submitworksheetResponse = data;
                if (this.submitworksheetResponse.status !== 'success') {
                    this.errorservice.showerror(
                      { status: this.submitworksheetResponse.errorCode,
                        statusText: this.submitworksheetResponse.message
                      });
                } else {
                    this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00221' });
                    this.getplants(this.selectedPlant);
                }
            },
            (err: any) => {
                this.errorMessage = err;
            }
        );
    }

    preparereqobj(data) {
        const reqObj = {
          'action': '',
          'id':  data.id,
          'templateId': 0,
          'worksheetName': data.worksheetName,
          'worksheetType': '',
          'worksheetDate': '',
          'reason': '',
          'remarkTypeId': (data.remarkTypeId !== 0) ? data.remarkTypeId : null,
          'remarks': (data.remarks) ? data.remarks : '' ,
          'samples': []
        };
        if  (data.samples.length > 0) {
            reqObj.samples = [];
            for (let i = 0; i < data.samples.length; i++ ) {
            if (data.samples[i].hasOwnProperty('dotexpand') === true) {
                delete data.samples[i].dotexpand;
            }
            if (data.samples[i].hasOwnProperty('isShow') === true) {
                delete data.samples[i].isShow;
            }
            reqObj.samples.push(data.samples[i]);
            }
        }
        return reqObj;
      }

    /* multiuseralert(emailid: any, plantid: any, worksheetid: any) {
        const multiuserMsg = emailid + ' ' + this.commonservice.gettranslate('data.L00578');
        const dialogRef = this.dialog.open(DialogComponent, {
            width: '500px',
            data: {
                'type':'yesno',
                'title': 'data.L00224',
                'message': multiuserMsg
            }
        });
        const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
            const worksheetUrl = 'viewworksheet/' + plantid + '/' + worksheetid;
            this.router.navigate([worksheetUrl]);
        });
    } */

    getreasons(worksheet: any) {
    this.commonservice.getreasons('lab').subscribe(
      data => {
        this.reasons = data;
        if (this.reasons.status !== 'success') {
            this.errorservice.showerror({ status: this.reasons.status, statusText: this.reasons.message });
        } else {
           if(!this.reasons.data) {
             this.reasons.data = [];
           }
            const errorMsg = 'data.L00166';
            const dialogRef = this.dialog.open(AdhocsubmitDialogComponent, {
                width: '400px',
                data: { type: 'yesno', title: 'data.L00224', message: errorMsg, reasons: this.reasons }
            });
            const sub = dialogRef.componentInstance.adhocsubmitokcallback.subscribe(result => {
                dialogRef.componentInstance.closeDialog();
                this.getworksheetinfo(worksheet, result);
            });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }
}

// Dialog box for add worksheet
@Component({
    selector: 'app-addworksheet-dialog-component',
    templateUrl: 'addworksheet.dialog.html',
    styleUrls: ['./addworksheet.dialog.css']
})
export class AddworksheetDialogComponent {
    @Output() addworksheetcallback = new EventEmitter<any>(true);
    selectedItem: any;
    adhocworksheet = {
        action: 'create',
        id: '',
        templateId: '',
        worksheetType: 'adhoc'
    };
    constructor(
        public dialogRef: MatDialogRef<AddworksheetDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: AddworksheetData) { }

    closeDialog(): void {
        this.dialogRef.close();
    }

    selectworksheet(selectedwstemp: any) {
        this.selectedItem = selectedwstemp;
    }
    add() {
        this.addworksheetcallback.emit(this.selectedItem);
    }
}

// Dialog box for adhoc worksheet submit remarks
@Component({
    selector: 'app-adhocsubmit-dialog-component',
    templateUrl: 'adhocsubmit.dialog.html',
    styleUrls: ['../../common/dialog/dialog.component.css']
})
export class AdhocsubmitDialogComponent {
    @Output() adhocsubmitokcallback = new EventEmitter<any>(true);
    reqobj = {
      reason: 0,
      remarks: ''
    };
    constructor(
        public dialogRef: MatDialogRef<AdhocsubmitDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any) { }

    closeDialog(): void {
        this.dialogRef.close();
    }
    addremark() {
        this.adhocsubmitokcallback.emit(this.reqobj);
    }
}


