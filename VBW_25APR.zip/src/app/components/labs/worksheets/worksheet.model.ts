export class Worksheet {
    public id: number;
    public title: string;
    public status: string;
    public remainingdays: string;
    public updatedby: string;
    public lastupdated: string;
    public remarks: string;

    constructor(
        id: number,
        title: string,
        status: string,
        remainingdays: string,
        lastupdated: string,
        updatedby: string,
        remarks: string ) {

            this.id = id;
            this.title = title;
            this.status = status;
            this.remainingdays = remainingdays;
            this.lastupdated = lastupdated;
            this.updatedby = updatedby;
            this.remarks = remarks;

        }

}
