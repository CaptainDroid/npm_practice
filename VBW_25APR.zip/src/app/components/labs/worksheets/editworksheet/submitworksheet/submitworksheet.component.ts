import { Component, Inject, EventEmitter, Output  } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component ( {
  templateUrl: './submitworksheet.component.html',
  styleUrls: ['./submitworksheet.dialog.css']
})
export class SubmitworksheetDialogComponent {
 @Output() submitworksheetcallback = new EventEmitter<any>(true);
  mode: any;
  tests: any;
  samples: any;
  constructor(
      public dialogRef: MatDialogRef<SubmitworksheetDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any) {
         this.mode = data.mode;
         this.tests = [];
         this.samples = [];
         for (let i = 0; i < data.samples.length; i++ ) {
            if (this.samples.indexOf(data.samples[i].name) < 0) {
                this.samples.push(data.samples[i].name);
             }
             if (data.samples[i].tests) {
                for (let j = 0; j < data.samples[i].tests.length; j++) {
                    if (this.tests.indexOf(data.samples[i].tests[j].name) < 0) {
                        this.tests.push(data.samples[i].tests[j].name);
                    }
                 }
             }
         }
       }

  closeDialog(): void {
      this.dialogRef.close();
  }

  gettestrecords (sample, testname) {
      let testdata = [];
      for (let  i = 0; i < sample.tests.length; i++) {
          if (testname ===  sample.tests[i].name) {
            testdata = sample.tests[i].labRecords;
          }
      }
      return testdata;
  }
  gettime(date: any) {
    const testhours = new Date(date);
    return ('0' + testhours.getUTCHours()).slice(-2) + ':' + ('0' + testhours.getUTCMinutes()).slice(-2);
  }

  submitworksheet() {
    this.submitworksheetcallback.emit(this.mode);
  }

}
