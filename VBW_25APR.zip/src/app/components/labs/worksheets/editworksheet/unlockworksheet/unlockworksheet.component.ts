import { Component, Inject, EventEmitter, Output  } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface UnlockworksheetData {
    value: any;
    name: string;
}
@Component ( {
  templateUrl: './unlockworksheet.component.html',
  styleUrls: ['./unlockworksheet.dialog.css']
})
export class UnlockworksheetDialogComponent {
 @Output() unlockworksheetCallback = new EventEmitter<any>(true);

  selectedreason = 0 ;
  remarks = '';
  unlockworksheetData: any;
  constructor(
      public dialogRef: MatDialogRef<UnlockworksheetDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: UnlockworksheetData) { }

  closeDialog(): void {
      this.dialogRef.close();
  }
  selectreason(reason) {
    this.selectedreason = reason;
  }
  unlockworksheet() {
    let unlockinfo = {
        'remarks':this.remarks
    }
    this.unlockworksheetCallback.emit(unlockinfo);
  }
}
