import { startWith, map, switchMap, tap } from 'rxjs/operators';
import { merge, Subscription } from 'rxjs';
import { Component, OnInit, Inject, HostListener, ViewChild, ViewChildren
  , ElementRef, QueryList, AfterViewInit, OnDestroy
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WorksheetService } from '../../../../services/worksheet.service';
import { DOCUMENT } from '@angular/common';
import { MatDialog } from '@angular/material';
import { AddsamplepointDialogComponent } from './addsamplepoint/addsamplepoint.component';
import { AddtestDialogComponent } from './addtest/addtest.component';
import { UnlockworksheetDialogComponent } from './unlockworksheet/unlockworksheet.component';
import { DeleteworksheetDialogComponent } from './deleteworksheet/deleteworksheet.component';
import { SubmitworksheetDialogComponent } from './submitworksheet/submitworksheet.component';
import {ErrorserviceService} from '../../../../services/errorservice.service';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { CdkDragDrop, moveItemInArray, CdkDrag, CdkDragMove } from '@angular/cdk/drag-drop';
import { CommonService } from '../../../../services/common.service';

import { TranslateService } from '@ngx-translate/core';
const speed = 10;

@Component({
  selector: 'app-editworksheet',
  templateUrl: './editworksheet.component.html',
  styleUrls: ['./editworksheet.component.css'],
  // tslint:disable-next-line:use-host-property-decorator
  host: {
    '(document:click)': 'onClick($event)',
    }

})
export class EditworksheetComponent implements OnInit, OnDestroy {

  worksheetParams: any;
  worksheetResponse: any;
  worksheetData: any;
  worksheetSamples = [];
  plantId: any;
  errorMessage: any;
  saveworksheetResponse: any;
  deletewsResponse: any;
  unlockwsResponse: any;
  submitwsResponse: any;
  timeInterval: any;

  reorder = false;
  reorderparent = false;
  reorderchild = false;
  reorderchilddata: any;
  stickheaderID = 'editworksheetheader';

  selectedSamplepoint = 0;
  filtersamplepoint = '';
  filtertest: any;
  selectedtest = 0;
  filtertestname = '';

  reasons: any;

  currentSamplePoint: any;

  deleteTestData: any;
  showDeletetest = false;
  hidedata = false;
  disableunlock = false;

  sampletestresponse: any;
  testfilters: any;

  selectedlang = 'EN';
  bc = 'worksheets';

  endworksheetSessionResponse: any;

  constructor(public dialog: MatDialog, private worksheetService: WorksheetService,
    private errorservice: ErrorserviceService,
    private route: ActivatedRoute, @Inject(DOCUMENT) document, private router: Router,
    public commonservice: CommonService,
    public translate: TranslateService) {
    this.route.params.subscribe(params => {
      this.worksheetParams = params;
      this.plantId = this.worksheetParams.plantid;
    });

    this.route.queryParams.subscribe(params => {
      this.bc = params['bc'] || 'worksheets';
    });

    if (this.translate.currentLang) {
    const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
       if (parseInt(language.lang,10) === 1) {
         this.selectedlang = 'EN';
       } else {
          this.selectedlang = 'CN';
       }
    });
  }
  ngOnInit() {
    this.worksheetData = {};
    this.worksheetData.remarks = '';
    this.getworksheetData('init');
    this.getreasons();
  }

  ngOnDestroy() {
    const endworksheetSession = {
      module: 'Lab',
      worksheetid: this.worksheetParams.worksheetid
    };
    this.commonservice.endworksheetsession(endworksheetSession).subscribe(
      data => {
        this.endworksheetSessionResponse = data;
        if (this.endworksheetSessionResponse.status !== 'success') {
          console.log(this.endworksheetSessionResponse.message);
          /* this.errorservice.showerror({
              status: this.endworksheetSessionResponse.errorCode,
              statusText: this.endworksheetSessionResponse.message}); */
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  getworksheetData(calltype: any) {
    this.filtertest = [];
    this.testfilters = [];
    const pageparams =  this.worksheetService.getworksheetUserInfo();
    if (pageparams.countryId !== '' && pageparams.citiId !== '' && this.worksheetParams.plantid && this.worksheetParams.worksheetid) {
      this.worksheetService.editworksheetdata(this.worksheetParams).subscribe(
        data => {
          this.worksheetResponse = data;
          if (this.worksheetResponse.status !== 'success') {
            this.errorservice.showerror({status: this.worksheetResponse.errorCode, statusText: this.worksheetResponse.message});
          } else {
            this.worksheetData =  this.worksheetResponse.data.country.city.plant.worksheet;
            this.plantId = this.worksheetResponse.data.country.city.plant.id;
            if (this.worksheetData.isReadOnly === true) {
              this.multiuserprompt(this.plantId, this.worksheetData.id, this.worksheetData.activeUserName);
            }
            this.worksheetSamples = this.worksheetResponse.data.country.city.plant.worksheet.samples;
            if (this.worksheetData.worksheetStatus) {
              this.worksheetData.worksheetStatus = this.worksheetData.worksheetStatus.toUpperCase();
            }
            if (!this.worksheetData.remarkTypeId) {
              this.worksheetData.remarkTypeId = 0;
            }
            for ( let i = 0; i < this.worksheetSamples.length; i++ ) {
              this.worksheetSamples[i].isShow = true;
              if (this.worksheetSamples[i].tests !== null) {
                for ( let j = 0; j < this.worksheetSamples[i].tests.length; j++ ) {
                  this.worksheetSamples[i].tests[j].timeInterval = this.commonservice.getTime();
                  this.hidetimeonload(this.worksheetSamples[i].tests[j].labRecords, this.worksheetSamples[i].tests[j].timeInterval);
                  const testIndex =  this.testfilters.indexOf(this.worksheetSamples[i].tests[j]);
                  if (testIndex < 0) {
                    this.testfilters.push(this.worksheetSamples[i].tests[j]);
                  }
                }
              } else {
                this.worksheetSamples[i].tests = [];
              }
            }
            this.testfilters = this.removeDuplicates(this.testfilters, 'id');
            if (calltype === 'init') {
              this.sampletests(this.worksheetParams.plantid, this.worksheetData.wTypeId);
            }
          }
        },
        (err: any) => {
          this.errorMessage = err;
        }
      );
  } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00170'});
    }
  }

multiuserprompt(plantid: any, worksheetid: any, sessionuser: any) {
    const multiuserMsg = sessionuser + ' ' + this.commonservice.gettranslate('data.L00578');
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        'type': 'yesno',
        'title': 'data.L00224',
        'message': multiuserMsg
      }
    });
    dialogRef.componentInstance.cancelCallback.subscribe(result => {
      let worksheetlistUrl = 'worksheets/' + plantid;
      if (this.bc === 'records') {
        worksheetlistUrl = 'records/' + plantid;
      }
      this.router.navigate([worksheetlistUrl]);
    });
    dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
    });
  }

  removeDuplicates( arr: any, prop: any ) {
    const obj = {};
    return Object.keys(arr.reduce((prev, next) => {
      if (!obj[next[prop]]) {
        obj[next[prop]] = next;
      }
      return obj;
    }, obj)).map((i) => obj[i]);
  }

  sampletests(plantid: any, typeid: any) {
    this.worksheetService.sampletests(plantid, typeid).subscribe(
      data => {
        this.sampletestresponse = data;
        if (this.sampletestresponse.status !== 'success') {
          this.errorservice.showerror({status: this.sampletestresponse.errorCode, statusText: this.sampletestresponse.message});
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  toggledot(model: any) {
    this.worksheetSamples.map(sample => (sample.dotexpand = false));
    if (!model.dotexpand) {
      model.dotexpand = true;
      this.hidedata = true;
    } else {
      model.dotexpand = false;
    }
  }

  addtestresults(model: any) {
    model.push(
      { id: '',
        testValue: '',
        testTime: '',
        isFinal: false,
        outOfRange: false
      });
  }

  reorderworksheet(reorderflag: any) {
    if (this.worksheetSamples.length > 1) {
      window.scroll(0, 0);
      this.reorder = true;
      this.stickheaderID = (reorderflag) ? '' : 'editworksheetheader';
      this.reorderparent = reorderflag;
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00168'});
    }
  }
  reordertests(flag: any, data: any) {
    if (data.tests.length > 1) {
      this.reorder = true;
      window.scroll(0, 0);
      this.stickheaderID = (flag) ? '' : 'editworksheetheader';
      this.reorderchild = flag;
      this.reorderchilddata = data;
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00167'});
    }
  }

  cancelreorder(flag: any) {
    this.stickheaderID = (flag) ? '' : 'editworksheetheader';
    this.reorder = false;
    this.reorderchild = flag;
    this.reorderparent = flag;
    this.getworksheetData('refresh');
  }

  saveworksheet() {
    if (!this.validateentries()) {
      this.errorservice.showerror({status: '', statusText: 'data.L00229'});
      return false;
    }
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'Save';
    if (requestObj.remarkTypeId === null) {
      requestObj.remarks = '';
    }
    this.worksheetService.saveworksheet(requestObj, this.worksheetResponse).subscribe(
      data => {
        this.saveworksheetResponse = data;
        if (this.saveworksheetResponse.status !== 'success') {
          this.errorservice.showerror({status: this.saveworksheetResponse.errorCode, statusText: this.saveworksheetResponse.message});
        } else {
          this.refreshworksheet('data.L00219');
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  userpreference() {
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'Reorder';
    this.worksheetService.reorder(requestObj, this.worksheetResponse).subscribe(
      data => {
        this.saveworksheetResponse = data;
        if (this.saveworksheetResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.saveworksheetResponse.errorCode, statusText: this.saveworksheetResponse.message });
        } else {
          this.stickheaderID ='';
          this.reorder = false;
          this.reorderchild = false;
          this.reorderparent = false;
          this.refreshworksheet('data.L00231');
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  validateentries() {
    let isValid = true;
    this.worksheetSamples.filter(sample => {
      if (sample.tests) {
        sample.tests.filter( test => {
          if (test.labRecords) {
              test.labRecords.filter( labrecord => {
                  if (labrecord.testValue !== '' && labrecord.testValue !== null) {
                    labrecord.testValue = labrecord.testValue.toString().replace(/\s/g, '');
                  }
                  if (labrecord.testValue === '' || labrecord.testValue === null || labrecord.testTime === '') {
                    isValid = false;
                  } else if (/^[-+]?[0-9]*\.?[0-9]+$/.test(labrecord.testValue) === false) {
                    isValid = false;
                  }
              });
          }
        });
      }
    });
    return isValid;
  }

  refreshworksheet(dialogMsg: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {title: 'data.L00224', message: dialogMsg }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.getworksheetData('refresh');
    });
  }

  opensamplepointDialog(): void {
    if (this.sampletestresponse.data.country.city.plant.samples.length > 0 ) {
      const dialogRef = this.dialog.open(AddsamplepointDialogComponent, {
        width: '400px',
        data: this.sampletestresponse.data.country.city.plant.samples
      });
      const sub = dialogRef.componentInstance.addsamplepoint.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
        this.addsamplepoint(result);
      });
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00172'});
    }
  }

  addsamplepoint(newsamplepoint: any) {
    const newsamplepointObj = {
       'id': newsamplepoint.id,
       'name': newsamplepoint.name,
       'dec': newsamplepoint.dec,
       'deleteformUI': true,
       'tests': []
    };
    const sampleobj = this.worksheetSamples.filter(sample => {
      return newsamplepointObj.id === sample.id;
    });
    if (sampleobj.length < 1) {
      this.worksheetSamples.push(newsamplepointObj);
      /*
        // JIRA issue 753 commented due to impact on other functionalities (Reorder)
        this.worksheetSamples.sort((a, b) => {
        const aName = a.name.toString().toLowerCase();
        const bName = b.name.toString().toLowerCase();
        return  (aName < bName ? -1 : (aName > bName ? 1 : 0));
      }); */
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00173'});
    }
  }

  openaddtestDialog(samplepoint: any) {
    this.currentSamplePoint = samplepoint;
    this.openTestDialog();
  }

  openTestDialog(): void {
    const samplepoint = this.sampletestresponse.data.country.city.plant.samples.filter( sample  => {
      return sample.id === this.currentSamplePoint.id;
    });
    if (samplepoint.length > 0 ) {
      if (samplepoint[0]) {
          if (samplepoint[0].tests.length > 0) {
            const dialogRef = this.dialog.open(AddtestDialogComponent, {
              width: '400px',
              data: samplepoint[0].tests
            });
            const sub = dialogRef.componentInstance.addtestcallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
              this.addtest(result);
            });
          } else {
            this.errorservice.showerror({status: '', statusText: 'data.L00223'});
          }
      }
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00223'});
    }
   }

   addtest(newtest: any) {

      const newtestobj = {
        'id' : newtest.id,
        'name' : newtest.name,
        'minValue': null,
        'maxValue': null,
        'deleteformUI': true,
        'assocId': newtest.assocId,
        'timeInterval': this.commonservice.getTime(),
        'uom': newtest.uom,
        'labRecords' : []
      };
      const testobj = this.currentSamplePoint.tests.filter(test => {
        return test.id === newtest.id;
      });
      if (testobj.length < 1) {
        this.currentSamplePoint.tests.push(newtestobj);
      } else {
        this.errorservice.showerror({status: '', statusText: 'data.L00174'});
      }
   }

   openunlockworksheetDialog(): void {
     const dialogRef = this.dialog.open(UnlockworksheetDialogComponent, {
         width: '400px',
         data: this.reasons
     });
     const sub = dialogRef.componentInstance.unlockworksheetCallback.subscribe(result => {
       dialogRef.componentInstance.closeDialog();
       this.unlockws(result);
     });
   }

   openDeleteWorksheetDialog(): void {
    const dialogRef = this.dialog.open(DeleteworksheetDialogComponent, {
      width: '400px',
      data: {}
    });
    const sub = dialogRef.componentInstance.deleteworksheetcallback.subscribe(result => {
      this.deletews();
      dialogRef.componentInstance.closeDialog();
    });
   }

   deletews() {
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'DEL';
    this.worksheetService.deleteworksheet(this.worksheetResponse, requestObj).subscribe(
      data => {
        this.deletewsResponse = data;
        if (this.deletewsResponse.status !== 'success') {
          this.errorservice.showerror({status: this.deletewsResponse.errorCode, statusText: this.deletewsResponse.message});
        } else {
          this.router.navigate(['/worksheets/' + this.worksheetResponse.data.country.city.plant.id]);
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

   }

   unlockws(unlockinfo: any) {
    if (unlockinfo.reason) {
      this.worksheetData.reason = unlockinfo.reason;
    }
    if (unlockinfo.remarks) {
      this.worksheetData.remarks = unlockinfo.remarks;
    }
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'RFUL';

    this.worksheetService.unlockworksheet(this.worksheetResponse, requestObj).subscribe(
      data => {
        this.unlockwsResponse = data;
        if (this.unlockwsResponse.status !== 'success') {
          this.errorservice.showerror({status: this.unlockwsResponse.errorCode, statusText: this.unlockwsResponse.message});
        } else {
          this.disableunlock = true;
          // this.errorservice.showerror({type: 'data.L00224', status: '', statusText: 'data.L00220'});
          this.refreshworksheet('data.L00220');
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

   }

   deletetest(deleteitem: any) {
      this.showDeletetest = true;
      this.deleteTestData = deleteitem;
      window.scroll(0, 0);
   }

   closedeletepopup() {
    this.showDeletetest = false;
   }

   deletesamplepoint(deleteItem: any) {
      const dialogRef = this.dialog.open(DialogComponent, {
        width: '400px',
        data: {type: 'yesno', title: 'data.L00040', message: 'data.L00226'}
      });
      const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
        const index = this.worksheetSamples.indexOf(deleteItem);
        if (index > -1) {
          this.worksheetSamples.splice(index, 1);
          this.closedeletepopup();
        }
        dialogRef.componentInstance.closeDialog();
      });
  }

  deletetestitem(testitem: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {type: 'yesno', title: 'data.L00039', message: 'data.L00226'}
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      const index = this.deleteTestData.tests.indexOf(testitem);
      if (index > -1) {
        this.deleteTestData.tests.splice(index, 1);
      }
      const findtests = [];
      for (let i = 0; i < this.worksheetSamples.length; i++) {
        const test = this.worksheetSamples[i].tests.filter( tes => {
          return tes.id === testitem.id;
        });
        if (test.length > 0) {
          findtests.push(test[0]);
        }
      }
      if (findtests.length < 1) {
        this.filtertest.splice(index, 1);
      }
      dialogRef.componentInstance.closeDialog();
    });
  }

  deletetestvalues(testItem: any, testvalue: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {type: 'yesno', title: 'data.L00225', message: 'data.L00226'}
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      const index = testItem.indexOf(testvalue);
      if (index > -1) {
        testItem.splice(index, 1);
      }
      dialogRef.componentInstance.closeDialog();
    });
  }

  filtersamples(sampleobj: any, samplename: any) {
    this.filtersamplepoint = samplename;
    this.filtertestname = '';
    if (samplename !== '' && samplename !== undefined) {
        this.testfilters = [];
        this.testfilters = sampleobj.tests;
        this.selectedtest = 0;
    } else {
        this.testfilters = [];
        for ( let i = 0; i < this.worksheetSamples.length; i++ ) {
          if (this.worksheetSamples[i].tests !== null) {
            for ( let j = 0; j < this.worksheetSamples[i].tests.length; j++ ) {
              const testIndex =  this.testfilters.indexOf(this.worksheetSamples[i].tests[j]);
              if (testIndex < 0) {
                this.testfilters.push(this.worksheetSamples[i].tests[j]);
              }
            }
          }
        }
       this.selectedtest = 0;
       this.testfilters = this.removeDuplicates(this.testfilters, "id");
    }
  }

  filtertestdata(testname: any) {
    this.filtertestname = testname;
  }

  submitworksheetDialog() {
    if (!this.validateentries()) {
      this.errorservice.showerror({status: '', statusText: 'data.L00229'});
      return false;
    }
    if ( this.worksheetData.type === 'ADHO' &&  (this.worksheetData.remarks === null || this.worksheetData.remarks === '')) {
      this.errorservice.showerror({ type: 'data.L00177', status: '', statusText: 'data.L00166' });
    } else {
      const dialogRef = this.dialog.open(SubmitworksheetDialogComponent, {
        width: '90%',
        data: { 'mode': 'submit', 'samples': this.worksheetSamples, 'tests': []}
      });
      const sub = dialogRef.componentInstance.submitworksheetcallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
        this.submitws();
      });
    }
  }

  gettime(date: any) {
    const testhours = new Date(date);
    return ('0' + testhours.getUTCHours()).slice(-2) + ':' + ('0' + testhours.getUTCMinutes()).slice(-2);
  }

  onClick(event: any) {
    if (event.target.id === 'ellipsesbtn') {
      this.hidedata = true;
    } else {
      this.hidedata = false;
    }
  }

  checktimeexist(index: any, collection: any, model: any) {
    const testdataCollection = [];
    for (let  i = 0; i < collection.length; i++) {
      if (i !== index) {
      testdataCollection.push(collection[i]);
      }
    }
    const checkexist = testdataCollection.filter(testdata => {
      return testdata.testTime === model;
    });
    if (checkexist.length > 0) {
      setTimeout(function() {
        collection[index].testTime = '';
      }, 500);
      this.errorservice.showerror({status: '', statusText: 'data.L00169'});
    }
  }

  hideexisttime(labrecords: any, timecollection: any, timeobj: any) {
    timeobj.isShow = false;
    const testtimeCollection = [];
    labrecords.filter(labrecord => {
      testtimeCollection.push(labrecord.testTime);
    });
    timecollection.filter(timecoll => {
       if (testtimeCollection.indexOf(timecoll.time) > -1){
        timecoll.isShow = false;
       } else {
        timecoll.isShow = true;
       }
    });
  }

  hidetimeonload(labrecords: any, timecollection: any) {
    const testtimeCollection = [];
    labrecords.filter(labrecord => {
      testtimeCollection.push(labrecord.testTime);
    });
    timecollection.filter(timecoll => {
       if (testtimeCollection.indexOf(timecoll.time) > -1){
        timecoll.isShow = false;
       } else {
        timecoll.isShow = true;
       }
    });
  }
  submitws() {
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'Submit-MSUB';
    if (requestObj.remarkTypeId === null) {
      requestObj.remarks = '';
    }
    this.worksheetService.submitworksheet(requestObj, this.worksheetResponse).subscribe(
      data => {
        this.submitwsResponse = data;
        if (this.submitwsResponse.status !== 'success') {
          this.errorservice.showerror({status: this.submitwsResponse.errorCode, statusText: this.submitwsResponse.message});
        } else {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00221' });
          const info = {
            'countryId': this.worksheetResponse.data.country.id,
            'citiId': this.worksheetResponse.data.country.city.id
          };
          this.worksheetService.setworksheetUserinfo(info);
          this.router.navigate(['/worksheets/' + this.worksheetResponse.data.country.city.plant.id]);
        }
        },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  preparereqobj(data: any) {
    const reqObj = {
      'action': '',
      'id': data.id,
      'templateId': (data.templateId) ? data.templateId : 0,
      'worksheetName': data.worksheetName,
      'worksheetType': '',
      'worksheetDate': '',
      'reason': '',
      'remarkTypeId': (data.remarkTypeId !== 0) ? data.remarkTypeId : null,
      'remarks': (data.remarks) ? data.remarks : '',
      'samples': []
    };
    if (data.samples.length > 0) {
      reqObj.samples = [];
      for (let i = 0; i < data.samples.length; i++ ) {
      if (data.samples[i].hasOwnProperty('dotexpand') === true) {
          delete data.samples[i].dotexpand;
      }
      if (data.samples[i].hasOwnProperty('isShow') === true) {
          delete data.samples[i].isShow;
      }
      if (data.samples[i].hasOwnProperty('hide') === true ) {
        delete data.samples[i].hide;
      }
      if (data.samples[i].tests) {
        for (let j = 0; j < data.samples[i].tests.length; j++) {
          if (data.samples[i].tests[j].hasOwnProperty('hide') === true) {
            delete data.samples[i].tests[j].hide;
          }
        }
      }
      reqObj.samples.push(data.samples[i]);
      }
    }
    return reqObj;
  }

  checkoutofrange(test: any, records: any, model: any) {
     let modelvalue = null;
     let outofrange = false;
     modelvalue = parseFloat(model);
     let minIsrange = true;
     let maxIsrange = true;
     if (modelvalue === null || modelvalue === '') {
        outofrange = false;
     }
     if (test.minValue !== null) {
            minIsrange = (test.minValue <= modelvalue) ? true : false;
      }
     if (test.maxValue !== null) {
                maxIsrange = (test.maxValue >= modelvalue) ? true : false;
      }
      if (minIsrange && maxIsrange) {
        records.outOfRange = false;
      } else {
        records.outOfRange = true;
      }
  }

  // Angular material drag and drop

  dropsamples(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.worksheetSamples, event.previousIndex, event.currentIndex);
  }

  droptests(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.reorderchilddata.tests, event.previousIndex, event.currentIndex);
  }

  getreasons() {
    this.commonservice.getreasons('lab').subscribe(
      data => {
        this.reasons = data;
        if (this.reasons.status !== 'success') {
            this.errorservice.showerror({ status: this.reasons.status, statusText: this.reasons.message });
        } else {
           if (!this.reasons.data) {
             this.reasons.data = [];
           }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }
}

