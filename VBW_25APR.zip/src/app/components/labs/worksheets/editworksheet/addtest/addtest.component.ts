import { Component, Inject, EventEmitter, Output  } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface AddtestData {
    id: any;
    name: string;
}
@Component ( {
  templateUrl: './addtest.component.html',
  styleUrls: ['./addtest.dialog.css']
})
export class AddtestDialogComponent {
 @Output() addtestcallback = new EventEmitter<any>(true);
  selectedtest: any;
  searchtest: any;
  constructor(
      public dialogRef: MatDialogRef<AddtestDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: AddtestData) { }

  closeDialog(): void {
      this.dialogRef.close();
  }

  selecttest(selecttest: any) {
      this.selectedtest = selecttest;
  }
  addtest() {
    this.addtestcallback.emit(this.selectedtest);
  }
}
