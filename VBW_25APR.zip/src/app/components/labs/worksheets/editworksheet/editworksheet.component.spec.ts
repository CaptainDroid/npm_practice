import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditworksheetComponent } from './editworksheet.component';

describe('EditworksheetComponent', () => {
  let component: EditworksheetComponent;
  let fixture: ComponentFixture<EditworksheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditworksheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditworksheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
