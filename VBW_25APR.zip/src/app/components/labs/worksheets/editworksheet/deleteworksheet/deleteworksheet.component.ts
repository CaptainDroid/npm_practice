import { Component, Inject, EventEmitter, Output  } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface DeleteworksheetData {
    value: any;
}
@Component ( {
  templateUrl: './deleteworksheet.component.html',
  styleUrls: ['./deleteworksheet.dialog.css']
})
export class DeleteworksheetDialogComponent {

 @Output() deleteworksheetcallback = new EventEmitter<any>(true);
  delws = true;
  constructor(
      public dialogRef: MatDialogRef<DeleteworksheetDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: DeleteworksheetData) { }

  closeDialog(): void {
      this.dialogRef.close();
  }
  deleteworksheet() {
    this.deleteworksheetcallback.emit(this.delws);
  }
}
