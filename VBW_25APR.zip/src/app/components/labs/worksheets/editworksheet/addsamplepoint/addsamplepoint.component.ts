import { Component, Inject, EventEmitter, Output  } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface AddsamplepointtData {
    id: any;
    name: string;
}
@Component ( {
  templateUrl: './addsamplepoint.component.html',
  styleUrls: ['./addsamplepoint.dialog.css']
})
export class AddsamplepointDialogComponent {
 @Output() addsamplepoint = new EventEmitter<any>(true);
  selectedsamplepoint: any;
  searchtestpoint: any;
  constructor(
      public dialogRef: MatDialogRef<AddsamplepointDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: AddsamplepointtData) { }

  closeDialog(): void {
      this.dialogRef.close();
  }

  selectsamplepoint(selectedpoint: any) {
      this.selectedsamplepoint = selectedpoint;
  }
  addsample() {
    this.addsamplepoint.emit(this.selectedsamplepoint);
  }
}
