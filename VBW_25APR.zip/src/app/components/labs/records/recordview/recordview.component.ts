import { map } from 'rxjs/operators';
import { Component, OnInit, Inject, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WorksheetService } from '../../../../services/worksheet.service';
import {ErrorserviceService} from '../../../../services/errorservice.service';
import { DOCUMENT } from '@angular/common';
import { MatDialog } from '@angular/material';
import { UnlockworksheetDialogComponent } from '../../worksheets/editworksheet/unlockworksheet/unlockworksheet.component';
import { SubmitworksheetDialogComponent } from '../../worksheets/editworksheet/submitworksheet/submitworksheet.component';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { TranslateService } from '@ngx-translate/core';
import { CommonService } from '../../../../services/common.service';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-recordview',
  templateUrl: './recordview.component.html',
  styleUrls: ['./recordview.component.css']
})
export class RecordviewComponent implements OnInit {

  worksheetParams: any;
  worksheetResponse: any;
  worksheetData: any;
  worksheetSamples = [];
  plantId: any;
  errorMessage: any;

  stickheaderID = 'editworksheetheader';

  unlockwsRepsonse: any;


  selectedSamplepoint = 0;
  filtersamplepoint = '';
  testfilters = [];
  selectedtest = 0;
  filtertestname = '';

  reasons: any;

  currentSamplePoint: any;
  disableunlock = false;

  selectedlang = 'EN';
  bc = 'worksheets';

  pageaccess = environment.role.lab;
  isEdit = false;
  constructor(
    public translate: TranslateService,
    public commonservice: CommonService,
    public dialog: MatDialog, private worksheetService: WorksheetService,
    private errorservice: ErrorserviceService,
    private route: ActivatedRoute, @Inject(DOCUMENT) document, private router: Router) {
    this.route.params.subscribe(params => {
      this.worksheetParams = params;
      this.plantId = this.worksheetParams.plantid;
    });
    this.route.queryParams.subscribe(params => {
      this.bc = params['bc'] || 'worksheets';
     });
    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
      if (parseInt(language.lang, 10) === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    });
    this.worksheetData = {
      'remarkTypeId': 0
    };

    this.isEdit = this.commonservice.isAccess(this.pageaccess.edit);
  }
  ngOnInit() {
    this.getworksheetData('init');
  }

  getworksheetData(calltype: any) {
    this.testfilters = [];
    const pageparams =  this.worksheetService.getworksheetUserInfo();
    if (pageparams.countryId !== '' && pageparams.citiId !== '' && this.worksheetParams.plantid && this.worksheetParams.worksheetid) {
      this.worksheetService.editworksheetdata(this.worksheetParams).subscribe(
        data => {
          this.worksheetResponse = data;
          if (this.worksheetResponse.status !== 'success') {
            this.errorservice.showerror({status: this.worksheetResponse.errorCode, statusText: this.worksheetResponse.message});
          } else {
          this.worksheetData =  this.worksheetResponse.data.country.city.plant.worksheet;
          if (!this.worksheetData.remarkTypeId) {
            this.worksheetData.remarkTypeId = 0;
          }
          this.plantId =  this.worksheetResponse.data.country.city.plant.id;
          this.worksheetSamples =  this.worksheetResponse.data.country.city.plant.worksheet.samples;
          if (this.worksheetData.worksheetStatus) {
            this.worksheetData.worksheetStatus = this.worksheetData.worksheetStatus.toUpperCase();
          }
          for ( let i = 0; i < this.worksheetSamples.length; i++ ) {
            this.worksheetSamples[i].isShow = true;
            this.worksheetSamples[i].tests.filter( test => {
              const testIndex =  this.testfilters.indexOf(test);
              if (testIndex < 0) {
                this.testfilters.push(test);
              }
            });
            if (this.worksheetSamples[i].tests === null) {
              this.worksheetSamples[i].tests = [];
            }
          }
          this.testfilters = this.removeDuplicates(this.testfilters, 'id');
          if (calltype === 'init') {
            this.getreasons();
          }
        }
        },
        (err: any) => {
          this.errorMessage = err;
        }
      );
      } else {
        this.errorservice.showerror({status: '', statusText: 'data.L00170'});
      }
  }

  removeDuplicates(arr, prop) {
    const obj = {};
    return Object.keys(arr.reduce((prev, next) => {
      if (!obj[next[prop]]) { obj[next[prop]] = next; }
      return obj;
    }, obj)).map((i) => obj[i]);
  }

  openunlockworksheetDialog(): void {
    if (this.disableunlock === false) {
      const dialogRef = this.dialog.open(UnlockworksheetDialogComponent, {
        width: '400px',
        data: this.reasons
      });
      const sub = dialogRef.componentInstance.unlockworksheetCallback.subscribe(result => {
        this.unlockws(result);
        dialogRef.componentInstance.closeDialog();
      });
    } else {
      this.errorservice.showerror({ type: 'data.L00224', status: '', statusText: 'data.L00171' });
    }
  }

  unlockws(unlockinfo) {
    if (unlockinfo.reason) {
      this.worksheetData.reason = unlockinfo.reason;
    }
    if (unlockinfo.remarks) {
      this.worksheetData.remarks = unlockinfo.remarks;
    }
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'RFUL';

    this.worksheetService.unlockworksheet(this.worksheetResponse, requestObj).subscribe(
      data => {
        this.unlockwsRepsonse = data;
        if (this.unlockwsRepsonse.status !== 'success') {
          this.errorservice.showerror({status: this.unlockwsRepsonse.errorCode, statusText: this.unlockwsRepsonse.message});
        } else {
          this.disableunlock = true;
          // this.errorservice.showerror({ type: 'data.L00224', status: '', statusText: 'data.L00220' });
          this.refreshworksheet('data.L00220');
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

   }

   refreshworksheet(dialogMsg: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {title: 'data.L00224', message: dialogMsg }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.getworksheetData('refresh');
    });
  }

  filtersamples(sampleobj: any, samplename: any) {
    this.filtersamplepoint = samplename;
    this.filtertestname = '';
    if (samplename !== '') {
        this.testfilters = [];
        this.testfilters = sampleobj.tests;
        this.selectedtest = 0;
    } else {
        this.testfilters = [];
        for ( let i = 0; i < this.worksheetSamples.length; i++ ) {
          if (this.worksheetSamples[i].tests !== null) {
            for ( let j = 0; j < this.worksheetSamples[i].tests.length; j++ ) {
              const testIndex =  this.testfilters.indexOf(this.worksheetSamples[i].tests[j]);
              if (testIndex < 0) {
                this.testfilters.push(this.worksheetSamples[i].tests[j]);
              }
            }
          }
        }
       this.selectedtest = 0;
    }
  }

  filtertestdata(testname: any) {
    this.filtertestname = testname;
  }

  printworksheet() {
    const dialogRef = this.dialog.open(SubmitworksheetDialogComponent, {
      width: '90%',
      data: { 'mode': 'print', 'samples': this.worksheetSamples , 'tests': []}
    });
    const sub = dialogRef.componentInstance.submitworksheetcallback.subscribe(result => {
      let printContents;
      if (this.worksheetData.samples.length > 0 ) {
        printContents = document.getElementById('print-section').outerHTML;
      } else {
        printContents = document.getElementById('no-data-table').outerHTML;
      }
      // dialogRef.componentInstance.closeDialog();
      this.print(printContents);
    });
  }

  print(printcontents: any): void {
    let printContents, popupWin;
    printContents = printcontents;
    if (printContents) {
    popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
          <title>Worksheet</title>
          <style>
          table {
            margin:2em 0 0 0;
            padding:10px;
			      width:auto;
            overflow:visible;
            height:auto;
          }
          table td {
            padding:10px;
          }
          table th {
            padding:10px;
          }
          table,
          table th,
          table td {
            border:1px solid #CCC;
            border-collapse: collapse;
          }
          table thead {
            border-bottom:1px solid #CCC;
          }
          table thead th:not(:first-child) {
            border-left:1px solid #CCC;
          }
          .submitworksheet-content  .mat-button-focus-overlay {
            opacity: 0 !important;
          }
          .submitworksheet-content  .nodata-table {
            width: 95%;
            margin: 1em;
            padding: 1em;
            font-size: 15px;
          }
          </style>
        </head>
        <body onload="window.print();window.close()">${printContents}</body>
      </html>`
    );
    }
    popupWin.document.close();
    //window.print();
 }

 preparereqobj(data) {
  const reqObj = {
    'action': '',
    'id': data.id,
    'templateId': 0,
    'worksheetName': data.worksheetName,
    'worksheetType': '',
    'worksheetDate': '',
    'reason': '',
    'remarkTypeId': (data.remarkTypeId !== 0) ? data.remarkTypeId : null,
    'remarks': (data.remarks) ? data.remarks : '',
    'samples': []
  };
  if (data.samples.length > 0) {
    reqObj.samples = [];
    for (let i = 0; i < data.samples.length; i++ ) {
    if (data.samples[i].hasOwnProperty('dotexpand') === true) {
        delete data.samples[i].dotexpand;
    }
    if (data.samples[i].hasOwnProperty('isShow') === true) {
        delete data.samples[i].isShow;
    }
    if (data.samples[i].hasOwnProperty('hide') === true ) {
      delete data.samples[i].hide;
    }
    if (data.samples[i].tests) {
      for (let j = 0; j < data.samples[i].tests.length; j++) {
        if (data.samples[i].tests[j].hasOwnProperty('hide') === true) {
          delete data.samples[i].tests[j].hide;
        }
      }
    }

    reqObj.samples.push(data.samples[i]);
    }
  }
  return reqObj;
}

  getreasons() {
    this.commonservice.getreasons('lab').subscribe(
      data => {
        this.reasons = data;
        if (this.reasons.status !== 'success') {
          this.errorservice.showerror({ status: this.reasons.status, statusText: this.reasons.message });
        } else {
          if (!this.reasons.data) {
            this.reasons.data = [];
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

}

