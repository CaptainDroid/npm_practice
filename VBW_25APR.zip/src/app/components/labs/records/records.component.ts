import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewEncapsulation } from '@angular/core';
import { CalendarEvent } from 'angular-calendar';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { WorksheetService } from '../../../services/worksheet.service';
import {ErrorserviceService} from '../../../services/errorservice.service';
import { Subject } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { CommonService } from '../../../services/common.service';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-records',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './records.component.html',
  styleUrls: ['./records.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class RecordsComponent implements OnInit {

  plantsresponse: any;
  plants = [];
  selectedPlant = 0;
  selectedPlantObj: any;
  worksheetresponse: any;

  displayMonth: any;
  displayYear: any;

  recordsInput = [];
  showrecords = false;

  months = [
    { 'id' : 1 , 'name': 'January'},
    { 'id' : 2 , 'name': 'February'},
    { 'id' : 3 , 'name': 'March'},
    { 'id' : 4 , 'name': 'April'},
    { 'id' : 5 , 'name': 'May'},
    { 'id' : 6 , 'name': 'June'},
    { 'id' : 7 , 'name': 'July'},
    { 'id' : 8 , 'name': 'August'},
    { 'id' : 9 , 'name': 'September'},
    { 'id' : 10 , 'name': 'October'},
    { 'id' : 11 , 'name': 'November'},
    { 'id' : 12 , 'name': 'December'}
  ];

  selectedMonth = 0;
  selectedYear = 0;
  years = [];

  view: String = 'month';
  viewDate: Date = new Date();
  events: CalendarEvent[] = [];
  refresh: Subject<any> = new Subject();

  pageaccess = environment.role.lab;
  viewaccess = false;

  constructor(private worksheetService: WorksheetService,  private errorservice: ErrorserviceService,
    public route: ActivatedRoute, private router: Router,
    public commonservice: CommonService,
    public dialog: MatDialog, @Inject(DOCUMENT) document) {
      this.viewaccess = this.commonservice.isAccess(this.pageaccess.edit);
  }

  ngOnInit() {
    this.selectedPlantObj = { acronym: '' };
    this.selectedMonth = this.viewDate.getMonth() + 1;
    this.selectedYear = this.viewDate.getFullYear();
    this.recordsInput.push({'month': this.selectedMonth});
    this.recordsInput.push({'year': this.selectedYear});
    this.generateyears();
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.getplants(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.getplants(this.selectedPlant);
      }
    });
  }

  generateyears() {
    const currentTime = new Date();
    const year = currentTime.getFullYear();
    for (let i = 2000; i <= year; i++) {
      this.years.push(i);
    }
  }

  getworksheetrecords() {
    const selectedmonthview = this.selectedYear + '/' + this.selectedMonth + '/01';
    this.viewDate = new Date(selectedmonthview);
    this.events = [];
    let month = 0;
    let year = 0;

    for (let i = 0; i < this.recordsInput.length; i++ ) {
      if (this.recordsInput[i].hasOwnProperty('month')) {
        month = this.recordsInput[i].month;
      }
      if (this.recordsInput[i].hasOwnProperty('year')) {
        year = this.recordsInput[i].year;
      }
    }
    this.worksheetService.getrecords(this.selectedPlant, month, year).subscribe(
      data => {
        this.worksheetresponse = data;
        if (this.worksheetresponse.status !== 'success') {
          this.errorservice.showerror({status: this.worksheetresponse.errorCode, statusText: this.worksheetresponse.message});
        } else {
            if (this.worksheetresponse.data.country.city.plant.worksheets) {
              for ( let i = 0; i < this.worksheetresponse.data.country.city.plant.worksheets.length; i++ ) {
                for (let j = 0; j < this.worksheetresponse.data.country.city.plant.worksheets[i].worksheets.length; j++) {
                  const wsstatus = this.worksheetresponse.data.country.city.plant.worksheets[i].worksheets[j].worksheetStatus.toLowerCase();
                  const eventsobj = {
                    title : this.worksheetresponse.data.country.city.plant.worksheets[i].worksheets[j].worksheetName,
                    start: new Date(this.worksheetresponse.data.country.city.plant.worksheets[i].recordDate),
                    status: wsstatus,
                    date: this.worksheetresponse.data.country.city.plant.worksheets[i].worksheets[j].date,
                    id: this.worksheetresponse.data.country.city.plant.worksheets[i].worksheets[j].id,
                    draggable: false,
                    activeUserName: this.worksheetresponse.data.country.city.plant.worksheets[i].worksheets[j].activeUserName,
                    isReadOnly: this.worksheetresponse.data.country.city.plant.worksheets[i].worksheets[j].isReadOnly
                  };
                  this.events.push(eventsobj);
                }
              }
              this.showrecords = true;
              this.refresh.next();
            }
      }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getplants(plantId:any) {
    this.worksheetService.getplants().subscribe(
      data => {
          this.plantsresponse = data;
          this.plants = [];
          if (this.plantsresponse.status !== 'success') {
            this.errorservice.showerror({status: this.plantsresponse.errorCode, statusText: this.plantsresponse.message});
          } else {
          for ( let i = 0; i < this.plantsresponse.data.countries.length; i++) {
              for ( let j = 0; j < this.plantsresponse.data.countries[i].cities.length; j++ ) {
                  for ( let k = 0; k < this.plantsresponse.data.countries[i].cities[j].plants.length; k++ ) {
                      const plantobj = this.plantsresponse.data.countries[i].cities[j].plants[k];
                      plantobj.countryId = this.plantsresponse.data.countries[i].id;
                      plantobj.citiId = this.plantsresponse.data.countries[i].cities[j].id;
                      this.plants.push(plantobj);
                  }
              }
            }
            if (plantId === 0) {
              this.selectedPlant = 0;
              if(this.plants.length>0) {
                this.selectInputs(this.plants[0]);
              }
            } else {
              const plantobj = this.plants.filter(plnt => {
                return plnt.id === plantId;
              });
              this.selectedPlant = plantId;
              if (plantobj[0]) {
                this.selectInputs(plantobj[0]);
              }
            }
          }
      },
      (err: any) => {
          console.log(err);
      }
  );
  }

  selectInputs(data: any) {
    if (data.field) {
      if (data.field === 'month') {
        this.selectedMonth = data.value;
        this.displayMonth = data.name;
        for (let i = 0; i < this.recordsInput.length; i++ ) {
          if (this.recordsInput[i].hasOwnProperty('month')) {
            const index = this.recordsInput.indexOf(this.recordsInput[i]);
            this.recordsInput.splice(index, 1);
          }
        }
        if (data.name !== '') {
          if (this.recordsInput.indexOf({'month': data.value}) < 0 ) {
            this.recordsInput.push({'month': data.value});
          }
        } else {
          this.showrecords = false;
        }
        console.log(this.recordsInput.length);
      } else {
        this.selectedYear = data.value;
        this.displayYear = data.name;
        for (let i = 0; i < this.recordsInput.length; i++ ) {
          if (this.recordsInput[i].hasOwnProperty('year')) {
            this.recordsInput.splice(this.recordsInput.indexOf(this.recordsInput[i]), 1);
          }
        }
        if (data.name !== '') {
          if (this.recordsInput.indexOf({'year': data.value}) < 0 ) {
            this.recordsInput.push({'year': data.value});
          }
        } else {
          this.showrecords = false;
        }
      }
    } else {
      const info = {
        'countryId': data.countryId,
        'citiId': data.citiId
      };
      this.selectedPlant = data.id;
      this.selectedPlantObj = data;
      this.worksheetService.setworksheetUserinfo(info);
      for (let i = 0; i < this.recordsInput.length; i++ ) {
        if (this.recordsInput[i].hasOwnProperty('plantid') === true){
          this.recordsInput.splice(this.recordsInput.indexOf(this.recordsInput[i]), 1);
        }
      }
      if (data.id !== 0) {
        if (this.recordsInput.indexOf({'plantid': data.id}) < 0 ) {
          this.recordsInput.push({'plantid': data.id});
        }
      }
    }
   if (this.recordsInput.length === 3) {
      this.getworksheetrecords();
    } else {
      this.viewDate = new Date();
    }
  }
  nagivateworksheet(worksheet: any) {
    if (this.viewaccess === true) {
      this.router.navigate(['/viewworksheet/' + this.selectedPlant + '/' + worksheet.id], { queryParams: { bc: 'records' } });
    } else {
        if (worksheet.status === 'locked') {
          this.router.navigate(['/viewworksheet/' + this.selectedPlant + '/' + worksheet.id], { queryParams: { bc: 'records' } });
        } else {
          this.router.navigate(['/worksheet/' + this.selectedPlant + '/' + worksheet.id], { queryParams: { bc: 'records' } });
        }
    }
  }

  multiuseralert(emailid: any, plantid: any, worksheetid: any) {
    const multiuserMsg = emailid + ' ' + this.commonservice.gettranslate('data.L00578');
    const dialogRef = this.dialog.open(DialogComponent, {
        width: '500px',
        data: {
            'type': 'yesno',
            'title': 'data.L00224',
            'message': multiuserMsg
        }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
        const worksheetUrl = 'viewworksheet/' + plantid + '/' + worksheetid;
        this.router.navigate([worksheetUrl]);
    });
}

  navrecords() {
    const date = new Date(this.viewDate);
    const month = date.getMonth();
    const year = date.getFullYear();
    const currentTime = new Date();
    const currentYear = currentTime.getFullYear();
    if (year <= currentYear) {
      this.selectedMonth = month + 1;
      this.selectedYear = year;
    for (let i = 0; i < this.recordsInput.length; i++ ) {
      if (this.recordsInput[i].hasOwnProperty('month') === true) {
        this.recordsInput[i].month = this.selectedMonth;
      }
      if (this.recordsInput[i].hasOwnProperty('year') === true) {
        this.recordsInput[i].year = this.selectedYear;
      }
    }
    if ( this.recordsInput.length === 3) {
      this.getworksheetrecords();
    }
    }
  }
}
