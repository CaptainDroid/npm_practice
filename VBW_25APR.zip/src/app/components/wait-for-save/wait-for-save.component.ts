import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wait-for-save',
  templateUrl: './wait-for-save.component.html',
  styleUrls: ['./wait-for-save.component.css']
})
export class WaitForSaveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
