import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WaitForSaveComponent } from './wait-for-save.component';

describe('WaitForSaveComponent', () => {
  let component: WaitForSaveComponent;
  let fixture: ComponentFixture<WaitForSaveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WaitForSaveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WaitForSaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
