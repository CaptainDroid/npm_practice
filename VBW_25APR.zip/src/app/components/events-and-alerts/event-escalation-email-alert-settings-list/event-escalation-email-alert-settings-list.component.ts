import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog } from '@angular/material';
import { EventsService } from 'src/app/services/events.service';
import { Router } from '@angular/router';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CancelConfirmationDialogComponent } from '../confirmation-dialog/cancel-confirmation-dialog';
export interface IEmailEscalationSettings {
  action: string;
  eventEmailSettingId: number;
  eventCategoryId: number;
  noOfDays: number;
  createdBy: any;
  createdAt: any;
  updatedBy: any;
  updatedAt: any;
  tenantId: number;
  eventEmailMessage: string;
  eventEmailgroup: any;
}
@Component({
  selector: 'app-event-escalation-email-alert-settings-list',
  templateUrl: './event-escalation-email-alert-settings-list.component.html',
  styleUrls: ['./event-escalation-email-alert-settings-list.component.css', '../../../../assets/css/events.css']
})
export class EventEscalationEmailAlertSettingsListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns: string[] = ['eventCategory', 'emailGroup', 'numberOfDays', 'action'];
  eventEscalationEmailData: any = [];
  dataSource: any;
  eventescalationemailsettingsData: IEmailEscalationSettings;
  constructor(private eventService: EventsService,
    private router: Router,
    private errorservice: ErrorserviceService,
    private dialog: MatDialog) {
    this.eventEscalationListing();
  }

  /**
   * Event Search
   * @param filterValue
   */
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  /**
   * Delete Event Escalation Setting
   */
  deleteEventEscalation(eventEmailSettingId) {
    this.eventescalationemailsettingsData = {
      action: 'Delete',
      eventEmailSettingId: eventEmailSettingId,
      eventCategoryId: 0,
      noOfDays: 0,
      createdBy: 2,
      createdAt: '',
      updatedBy: 2,
      updatedAt: '',
      tenantId: 1,
      eventEmailMessage: '',
      eventEmailgroup: ''
    };
    this.eventService.addEventEscalationEmailSettings(this.eventescalationemailsettingsData).subscribe(
      (data: any) => {
        if (data.status === 'success') {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00855' });
          this.eventEscalationListing();
        } else {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: data['message'] });
        }

      },
      (err: any) => {
        console.log('Failed to fetch Event Escalation Email Settings List');
      });
  }

  /**
      * Get Event Ecsalation Email Settings List
      */
  eventEscalationListing() {
    this.eventService.getEventEscalations().subscribe(
      (res: any) => {
        this.eventEscalationEmailData = res.data.eventescalationemailsettings;
        this.dataSource = new MatTableDataSource(this.eventEscalationEmailData);
        this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
          return data.eventCategoryName.toLowerCase().includes(filter) || data.emailGroupName.toString().toLowerCase().includes(filter) ||
          data.noOfDays.toString().toLowerCase().includes(filter);
        };
        this.dataSource.paginator = this.paginator;
      },
      (err: any) => {
        console.log('Event Ecsalation Email Settings List Failed');
      });
  }

  /**
   * Cancel Confirmation Dialog
   */
  openConfirmationDialog(eventEmailSettingId) {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'event-escalation-email-alert-settings-list', type: 'delete' }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === true) {
        this.deleteEventEscalation(eventEmailSettingId);
      }
    });
  }

  ngOnInit() {
  }

}
