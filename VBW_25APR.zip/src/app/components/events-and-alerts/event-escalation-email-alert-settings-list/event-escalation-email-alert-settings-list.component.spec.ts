import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventEscalationEmailAlertSettingsListComponent } from './event-escalation-email-alert-settings-list.component';

describe('EventEscalationEmailAlertSettingsListComponent', () => {
  let component: EventEscalationEmailAlertSettingsListComponent;
  let fixture: ComponentFixture<EventEscalationEmailAlertSettingsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventEscalationEmailAlertSettingsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventEscalationEmailAlertSettingsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
