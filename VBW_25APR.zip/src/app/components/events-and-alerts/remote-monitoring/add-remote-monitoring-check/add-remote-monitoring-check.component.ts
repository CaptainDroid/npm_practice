import { Component, OnInit } from '@angular/core';
import { EventsService } from 'src/app/services/events.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CancelConfirmationDialogComponent } from '../../confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { WorksheetService } from 'src/app/services/worksheet.service';


@Component({
  selector: 'app-add-remote-monitoring-check',
  templateUrl: './add-remote-monitoring-check.component.html',
  styleUrls: ['./add-remote-monitoring-check.component.css',
    '../../../../../assets/css/events.css']
})
export class AddRemoteMonitoringCheckComponent implements OnInit {
  addRemoteMonitorngCheckForm: FormGroup;
  plants: any;
  tags: any;
  dataToAppend: any = '';
  selectedTagTypeId: any;
  selectedTagTypeCode: any;
  selectedTagName: any;
  errorMessage: any;
  submitted = false;
  isEdit = false;
  rmcid = 0;
  remoteMonitoringValueId = 0;
  isInvalidLowerLimitValue = false;
  remoteMonitoringList: any;
  selectedData: any;
  action: any;
  plantId: any;
  updatedby = 0;
  upperAlertEngInvalid = false;
  upperAlertChnInvalid = false;
  lowerAlertEngInvalid = false;
  lowerAlertChnInvalid = false;
  singleTag: any;
  invalidInput = false;
  invalidLower = false;
  invalidUpper = false;
  eventtypes: any;
  eventTypeIds: any;
  paramPlantId = 0;

  constructor(
    private eventsService: EventsService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog,
    private errorservice: ErrorserviceService,
    private worksheetService: WorksheetService
  ) {
    if (this.route.params['value'].hasOwnProperty('checkValueId')) {
      this.isEdit = true;
    }
    this.selectedData = {
      'rmcid': sessionStorage.getItem('remoteData.rmcid'),
      'countryId': sessionStorage.getItem('remoteData.countryId'),
      'cityId': sessionStorage.getItem('remoteData.cityId'),
      'plantId': sessionStorage.getItem('remoteData.plantId')
    };

    this.worksheetService.getplants().subscribe(data => {
      const plantsresponse = data['data'];
      const countries = plantsresponse['countries'];
      const plantCodeList = [];
      countries.forEach(country => {
        const cities = country['cities'];
        cities.forEach(city => {
          const plants = city['plants'];
          plants.forEach(plant => {
            const plantCode = {
              'id': plant.id,
              'value': plant.acronym,
              'countryId': country.id,
              'cityId': city.id
            };
            plantCodeList.push(plantCode);
          });
        });
      });
      this.plants = plantCodeList;
      if (this.route.params['value'].plantid) {
        const plantid = parseInt(this.route.params['value'].plantid, 10);
        this.paramPlantId = plantid;
        if (plantid > 0 && !this.isEdit) {
          this.addRemoteMonitorngCheckForm.controls['plantName'].setValue(plantid);
          const selected = this.plants.find((element) => {
            if (element.id === plantid) {
              return element;
            }
          });
          this.getTagList(selected);
        }
      }
      if (data['status'] !== 'success') {
        this.errorservice.showerror({ status: data['status'], statusText: data['message'] });
      }
    });
  }

  ngOnInit() {
    this.eventsService.eventType().subscribe((data: any) => {
      const eventtypes = [], ids = [];
      if (data.data.eventtypes) {
        data.data.eventtypes.forEach(element => {
          if (element.eventType === 'Effluent Remote Monitoring' || element.eventType === 'Influent Remote Monitoring') {
            const eventObj = {
              'id': element.eventTypeId,
              'name': element.eventDescription === 'Effluent Remote Monitoring' ? 'data.L00372' : 'data.L00373'
            };
            eventtypes.push(eventObj);
            ids.push(element.eventTypeId);
          }
        });
      }
      this.eventtypes = eventtypes;
      this.eventTypeIds = ids;
    },
    (err: any) => {
      console.log(err);
    });

    this.addRemoteMonitorngCheckForm = this.formBuilder.group({
      plantName: [{ value: '', disabled: this.isEdit }, [Validators.required, Validators.min(1)]],
      tagName: [{ value: '', disabled: this.isEdit }],
      upperLimit: [''],
      upperAlertEng: this.dataToAppend,
      upperAlertChn: this.dataToAppend,
      lowerLimit: [''],
      lowerAlertEng: this.dataToAppend,
      lowerAlertChn: this.dataToAppend,
      eventType: 8,
      eventDelay: 0
    });
    if (this.route.params['value'].hasOwnProperty('checkValueId')) {
      this.remoteMonitoringValueId = parseInt(this.route.params['value'].checkValueId, 10);
      this.eventsService.getSelectedRemoteMonitoringCheckValues(this.selectedData).subscribe(
        (data: any) => {
          if (data['status'] !== 'success') {
            this.errorservice.showerror({ status: data['status'], statusText: data['message'] });
          }
          if (data['status']) {
            this.remoteMonitoringList = data['data'].country.city.plant;
            if (this.remoteMonitoringList.length !== 0) {
            //    let parameters = {
            //   country: data['data'].country.id,
            //   city: data['data'].country.city.id,
            //   plant: this.remoteMonitoringList.id
            // }
            // this.getTagForSelectedPlant(parameters);
          }

            this.addRemoteMonitorngCheckForm.setValue({
              plantName: this.remoteMonitoringList.id,
              tagName: this.remoteMonitoringList.remotemonitoringcheck.tagName,
              upperLimit: this.remoteMonitoringList.remotemonitoringcheck.upperLimitVal,
              lowerLimit: this.remoteMonitoringList.remotemonitoringcheck.lowerLimitVal,
              lowerAlertEng: this.remoteMonitoringList.remotemonitoringcheck.lowerLimitMsg.en ?
              this.remoteMonitoringList.remotemonitoringcheck.lowerLimitMsg.en : '',
              lowerAlertChn: this.remoteMonitoringList.remotemonitoringcheck.lowerLimitMsg.cn,
              upperAlertEng: this.remoteMonitoringList.remotemonitoringcheck.upperLimitMsg.en,
              upperAlertChn: this.remoteMonitoringList.remotemonitoringcheck.upperLimitMsg.cn,
              eventType: this.remoteMonitoringList.remotemonitoringcheck.eventTypeId,
              eventDelay: this.remoteMonitoringList.remotemonitoringcheck.eventDelayHrs
            });
            this.singleTag = this.remoteMonitoringList.remotemonitoringcheck.tagName;
          }
        },
        (error: any) => {

        }
      );
    }
  }

  getTagList(plant) {
    this.plantId = plant.id;
    const parameters = {
      country: plant.countryId,
      city: plant.cityId,
      plant: this.plantId
    };
    this.getTagForSelectedPlant(parameters);
  }

  numberOnly(event): boolean {
    let limit = 0;
    if (event.target.value != null) {
      limit = event.target.value.toString().length;
    }
    if (limit >= 15) {
      return false;
    } else {
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode === 46 || event.key === '.' || event.key === '.') {
        if (event.target.value.toString().indexOf(String.fromCharCode(charCode)) !== -1) {
          event.preventDefault();
          return false;
        }
      }
      if (charCode !== 45 && charCode !== 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
  }

  getTagForSelectedPlant(parameters) {

    this.eventsService.getTagsForGivenPlant(parameters).subscribe(
      data => {
        // let response = data['data'];
        /**
         * Commented out because the response structure changed all of a sudden
         * Not deleted, because the response structure changed all of a sudden, and what if it gets reverted?! ;)
         */
        // let countries = response['countries'];
        //   let tagList = [];
        //   countries.forEach(country => {
        //     let cities = country['cities'];
        //     cities.forEach(city => {
        //       let plants = city['plants'];
        //       plants.forEach(plant => {
        //         let tags = plant['tags'];
        //         tags.forEach(tag => {
        //           tagList.push(tag);
        //         });
        //       });
        //     });
        //   });
        // this.tags = tagList;
      this.tags = data['data']['tags'];
      if (data['status'] !== 'success') {
        this.errorservice.showerror({ status: data['status'], statusText: data['message'] });
      }
    });

  }

  validInput(event) {

  }

  validateLowerLimit(event) {
    /**** Pattern validation - STARTS */
    const format = /^-?[0-9\.]\d*(\.\d+)?$/;
    if (event.target.attributes.formcontrolname.nodeValue === 'upperLimit') {
      const limit = this.addRemoteMonitorngCheckForm.value.upperLimit;
      if (limit && (!format.test(limit) || (limit === '.') || (limit === '-.'))) {
        this.invalidUpper = true;
      } else {
        this.invalidUpper = false;
      }
    }
    if (event.target.attributes.formcontrolname.nodeValue === 'lowerLimit') {
      const limit = this.addRemoteMonitorngCheckForm.value.lowerLimit;
      if (limit && (!format.test(limit) || (limit === '.') || (limit === '-.'))) {
        this.invalidLower = true;
      } else {
        this.invalidLower = false;
      }
    }

    /** Pattern validation - ENDS */

    if (((this.addRemoteMonitorngCheckForm.value.upperLimit != null && this.addRemoteMonitorngCheckForm.value.upperLimit) &&
      (this.addRemoteMonitorngCheckForm.value.lowerLimit !== null && this.addRemoteMonitorngCheckForm.value.lowerLimit)) &&
      (Number(this.addRemoteMonitorngCheckForm.value.lowerLimit) >= Number(this.addRemoteMonitorngCheckForm.value.upperLimit))) {
      this.isInvalidLowerLimitValue = true;
    } else if (this.addRemoteMonitorngCheckForm.value.upperLimit == null && this.addRemoteMonitorngCheckForm.value.lowerLimit != null) {
      this.isInvalidLowerLimitValue = true;
    } else {
      this.isInvalidLowerLimitValue = false;
    }
    this.removeNonDigits(event);
  }

  removeNonDigits(event) {
    this.addRemoteMonitorngCheckForm.controls[event.target.attributes.formcontrolname.nodeValue].
    setValue(event.target.value.replace(/[^\d.\-]/g, ''));
  }

  handleFloat(event) {
    const format = /^[\.\d]{1,9}(\.[\d]{1,3})?$/,
        val = event.target.value;
    if (val && (!format.test(val) || val === '.')) {
      this.invalidInput = true;
    } else {
      this.invalidInput = false;
    }
  }

  onSubmit() {
    this.isInvalidLowerLimitValue = false;
    this.submitted = true;
    let eventtype = null;

    if ((this.addRemoteMonitorngCheckForm.value.eventType) &&
      (this.eventTypeIds.indexOf(this.addRemoteMonitorngCheckForm.value.eventType) !== -1)) {
        eventtype = this.addRemoteMonitorngCheckForm.value.eventType;
    }
    this.addRemoteMonitorngCheckForm.controls['eventType'].setValue(eventtype);
    const upper = this.addRemoteMonitorngCheckForm.value.upperLimit,
        lower = this.addRemoteMonitorngCheckForm.value.lowerLimit;
    if ( lower !== null && lower !== '' && (upper !== '') && Number(upper) <= Number(lower)) {
      this.isInvalidLowerLimitValue = true;
    }

    /**
     * Validating the upper and lower alert messages entered
     */
    let upperEngLength, lowerEngLength, upperChnLength, lowerChnLength;
    if (this.addRemoteMonitorngCheckForm.value.upperAlertEng) {
      upperEngLength = this.addRemoteMonitorngCheckForm.value.upperAlertEng.toString().trim().length;
    }
    if (this.addRemoteMonitorngCheckForm.value.lowerAlertEng) {
      lowerEngLength = this.addRemoteMonitorngCheckForm.value.lowerAlertEng.toString().trim().length;
    }
    if (this.addRemoteMonitorngCheckForm.value.upperAlertChn) {
      upperChnLength = this.addRemoteMonitorngCheckForm.value.upperAlertChn.toString().trim().length;
    }
    if (this.addRemoteMonitorngCheckForm.value.lowerAlertChn) {
      lowerChnLength = this.addRemoteMonitorngCheckForm.value.lowerAlertChn.toString().trim().length;
    }

    this.upperAlertEngInvalid = upperEngLength === 0 ? true : false;
    this.lowerAlertEngInvalid = lowerEngLength === 0 ? true : false;
    this.upperAlertChnInvalid = upperChnLength === 0 ? true : false;
    this.lowerAlertChnInvalid = lowerChnLength === 0 ? true : false;
    if (this.upperAlertEngInvalid || this.lowerAlertEngInvalid || this.upperAlertChnInvalid || this.lowerAlertChnInvalid) {
      return;
    }
    // Validation ends

    if (this.addRemoteMonitorngCheckForm.invalid) {
      return;
    }
    // var msg;
    if (this.addRemoteMonitorngCheckForm.valid && !this.isInvalidLowerLimitValue && !this.invalidLower && !this.invalidUpper) {
      this.action = 'Create';
      let msg = 'data.L00488';

      if (this.isEdit) {
        this.action = 'Update';
        msg = 'data.L00795';
        this.rmcid = this.remoteMonitoringValueId;
        this.updatedby = 2;
        this.plantId = this.remoteMonitoringList.id;
        this.selectedTagTypeId = this.remoteMonitoringList.remotemonitoringcheck.tagTypeId;
        this.selectedTagName = this.remoteMonitoringList.remotemonitoringcheck.tagName;
      }
      const data = {
        action: this.action,
        rmcid: this.rmcid,
        plantId: this.plantId,
        tagName: this.selectedTagName,
        tagTypeId: this.selectedTagTypeId,
        tagTypeCode: this.selectedTagTypeCode,
        upperLimitVal: this.addRemoteMonitorngCheckForm.value.upperLimit,
        lowerLimitVal: this.addRemoteMonitorngCheckForm.value.lowerLimit,
        eventDelayHrs: this.addRemoteMonitorngCheckForm.value.eventDelay,
        eventTypeId: eventtype,
        createdBy: 2,
        createdAt: '',
        updatedBy: this.updatedby,
        updatedAt: '',
        tenantId: 1,
        upperLimitMsg: {
          en: this.addRemoteMonitorngCheckForm.value.upperAlertEng,
          cn: this.addRemoteMonitorngCheckForm.value.upperAlertChn
        },
        lowerLimitMsg: {
          en: this.addRemoteMonitorngCheckForm.value.lowerAlertEng,
          cn: this.addRemoteMonitorngCheckForm.value.lowerAlertChn
        }
      };

      const essentials = {
        'countryId': 26,
        'cityId': 8,
        'plantId': this.plantId
      };
      /**
      * Add/Edit Form Data
      */
      if (!this.invalidInput) {
        this.eventsService.addRemoteMonitoringValue(data, essentials).subscribe(
          // tslint:disable-next-line:no-shadowed-variable
          (data: any) => {
            if (data['status'] !== 'success') {
              this.errorservice.showerror({ status: data['status'], statusText: data['message'] });
              return;
            } else {
              this.router.navigate(['/remote-monitoring-check-list', this.paramPlantId]);
              this.errorservice.showerror({ type: 'Info', status: data['status'], statusText: msg });
            }
          }
        );
      }
    }
  }

  /**
   * Cancel Confirmation Dialog
   */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'remote-monitoring-check-list/' + this.paramPlantId }
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

  getTagDetails(tagData) {
    this.selectedTagTypeId = tagData.tagtypeId;
    this.selectedTagTypeCode = tagData.tagtypeCode;
    this.selectedTagName = tagData.tagname;
    this.dataToAppend = '$#' + tagData.tagname;
    this.addRemoteMonitorngCheckForm.controls.upperAlertEng.setValue(this.dataToAppend);
    this.addRemoteMonitorngCheckForm.controls.upperAlertChn.setValue(this.dataToAppend);
    this.addRemoteMonitorngCheckForm.controls.lowerAlertChn.setValue(this.dataToAppend);
    this.addRemoteMonitorngCheckForm.controls.lowerAlertEng.setValue(this.dataToAppend);
  }

  /**
   *  Function to restrict entering only white spaces
   */
  restrictBlankSpaces(e) {
    if (e.target.value.toString().trim().length === 0) {
      if (e.keyCode === 32) {
        e.preventDefault();
      }
    }
  }


  /**
   * Function that restricts blank spaces, and also restricts language to English only
   * Made a separate function as only some fields required this feature
   */
  restrictBlankSpacesEnglish(e) {
    if (e.target.value.toString().trim().length === 0) {
      if (e.keyCode === 32  || e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
      }
    }
    /**
     * The Angular '(paste)' event does not fire in IE, so manually handling it for IE and checking if text is pasted
     *
     * Also, this is a potential security vulnerability in IE that the browser can access what's on somebody's
     * clipboard without them knowing; We're not doing anything, but it should not be allowed anyway.
     * But, to support IE.., oh well.
     */
    if (e.ctrlKey === true && (e.keyCode === 86 || e.code === 'keyV')) {
     if ((window as any).clipboardData && (window as any).clipboardData.getData) {
      e['copiedText'] = (window as any).clipboardData.getData('Text');
     }
    }
    this.englishOnly(e);
  }


  /**
   * Function to retrict input language to English
   */
  englishOnly($event) {
    let message;
    if ($event.copiedText) { // pasted text using IE
      message = $event.copiedText;
    } else if ($event.clipboardData) { // pasted text using Chrome and other browsers
      message = $event.clipboardData.getData('Text');
    } else { // Single text input
      message = $event.key;
    }
    message = message.toString().trim();

    const re = /^[\x00-\x7F]+$/;
    const isValid = re.test(message);
    if (!isValid) {
      $event.preventDefault();
    }
  }
  /**
   * If clipboard access is not allowed by the user in IE, the above function will not work
   * To handle this situation, this function manually removes all the Non-English-Non-Digit-Non-Special-Characters
   * from the input field.
   *
   * It is not that graceful, as you'll be able to see the Non-valid stuff being pasted in IE,
   * but it'll vanish on moving away; but handling 231 billion cases for IE is already such a pain!
   */
  removeNonEnglish(event) {
    this.addRemoteMonitorngCheckForm.controls[event.target.attributes.formcontrolname.nodeValue].
    setValue(event.target.value.replace(/[^\x00-\x7F]/g, ''));
  }

  /**
   * Function to disable the right click menu
   * Disabling to prevent pasting through the right click context menu
   */
  disableRightClick($event) {
    $event.preventDefault();
  }
}
