import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRemoteMonitoringCheckComponent } from './add-remote-monitoring-check.component';

describe('AddRemoteMonitoringCheckComponent', () => {
  let component: AddRemoteMonitoringCheckComponent;
  let fixture: ComponentFixture<AddRemoteMonitoringCheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddRemoteMonitoringCheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRemoteMonitoringCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
