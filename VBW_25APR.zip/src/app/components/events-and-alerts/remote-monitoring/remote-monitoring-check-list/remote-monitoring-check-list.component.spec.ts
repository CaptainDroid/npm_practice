import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoteMonitoringCheckListComponent } from './remote-monitoring-check-list.component';

describe('RemoteMonitoringCheckListComponent', () => {
  let component: RemoteMonitoringCheckListComponent;
  let fixture: ComponentFixture<RemoteMonitoringCheckListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoteMonitoringCheckListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoteMonitoringCheckListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
