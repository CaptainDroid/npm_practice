import { Component, OnInit, ViewChild } from '@angular/core';
import { EventsService } from 'src/app/services/events.service';
import { WorksheetService } from '../../../../services/worksheet.service';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-remote-monitoring-check-list',
  templateUrl: './remote-monitoring-check-list.component.html',
  styleUrls: ['./remote-monitoring-check-list.component.css',
    '../../../../../assets/css/events.css']
})
export class RemoteMonitoringCheckListComponent implements OnInit {

  displayedColumns: string[] = ['plant', 'tagName', 'upperLimit', 'lowerLimit', 'action'];
  plants: any;
  plantsresponse: any;
  remoteMonitoringCheckListData: any;
  remoteMonitoringCheckList: any;
  remoteMonitoringList: any;
  selectedElement: any;
  selectedPlant = 0;
  errorMessage: any;
  dataSource: any;
  totalLength = 0;
  limit = 10;
  pageLimit: number[] = [10, 25, 100];
  searchFilter: any;
  plantFilter: any = 0;
  selectResult: any[] = [];
  searchResult: any[] = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private eventsService: EventsService,
    private worksheetService: WorksheetService,
    private errorservice: ErrorserviceService,
    private router: ActivatedRoute,

  ) {
    this.eventsService.getRemoteMonitoringList().subscribe(
      (res: any) => {
        if (res['status'] !== 'success') {
          this.errorservice.showerror({ status: res['status'], statusText: res['message'] });
        }
        if (res['status']) {
          this.remoteMonitoringList = res['data'];
          const plantList = [];
          const countries = this.remoteMonitoringList['countries'];
          countries.forEach(country => {
            const cities = country['cities'];
            cities.forEach(city => {
              const plants = city['plants'];
              plants.forEach(plant => {
                const monitoringChecks = plant['remotemonitoringchecks'];
                monitoringChecks.forEach(eachValue => {
                  const plantData = {
                    'id': eachValue.rmcid,
                    'lowerLimit': eachValue.lowerLimitVal != null ? eachValue.lowerLimitVal : '' ,
                    'plant': plant.acronym,
                    'tagName': eachValue.tagName,
                    'upperLimit': eachValue.upperLimitVal != null ? eachValue.upperLimitVal : '',
                    'countryId': city.countryId,
                    'cityId': plant.cityId,
                    'plantId': eachValue.plantId
                  };
                  plantList.push(plantData);
                });
              });
            });
          });
          this.remoteMonitoringCheckList = plantList;
        }
        if (this.router.params['value'].hasOwnProperty('plantid')) {
          const plantid = parseInt(this.router.params['value'].plantid, 10);
          this.plantFilter = plantid;
          this.applyFilter(this.plantFilter);
        } else {
          this.dataSource = new MatTableDataSource(this.remoteMonitoringCheckList);
          this.dataSource.paginator = this.paginator;
          this.totalLength = this.dataSource.data.length;
          if (this.plants && this.plants.length === 1) {
            this.applyFilter(this.plantFilter);
          }
        }
      }
    );
  }

  ngOnInit() {
    this.worksheetService.getplants().subscribe(data => {
      const plantsresponse = data['data'];
      if (data['status'] !== 'success') {
        this.errorservice.showerror({ status: data['status'], statusText: data['message'] });
      }
      const countries = plantsresponse['countries'];
      const plantCodeList = [];
      countries.forEach(country => {
        const cities = country['cities'];
        cities.forEach(city => {
          const plants = city['plants'];
          plants.forEach(plant => {
            const plantCode = {
              'id': plant.id,
              'value': plant.acronym
            };
            plantCodeList.push(plantCode);
          });
        });
      });
      this.plants = plantCodeList;
    });
  }

  applyFilter(filterValue: string) {
    if (this.plantFilter === 0) {
      this.dataSource = new MatTableDataSource(this.remoteMonitoringCheckList);
      if (filterValue === this.searchFilter) {
        this.filterSearch(this.remoteMonitoringCheckList, filterValue);
      }
    } else {
      if (this.searchFilter && this.plantFilter) {
        this.searchAndSelectFilter(filterValue);
      } else {
        if (this.searchFilter && !this.plantFilter) {
          filterValue = this.searchFilter;
          this.filterSearch(this.remoteMonitoringCheckList, filterValue);
        } else if (!this.searchFilter && this.plantFilter) {
          filterValue = this.plantFilter;
          this.filterSelect(this.remoteMonitoringCheckList, filterValue);
        }
      }
    }
    this.dataSource.paginator = this.paginator;
  }

  filterSearch(data, filterValue) {
    this.searchResult = data.filter(item => {
      return (item.plant.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
       (item.tagName.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
        (item.lowerLimit.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
         (item.upperLimit.toString().toLowerCase().includes(filterValue.toLowerCase()));
    });
    this.dataSource = new MatTableDataSource(this.searchResult);
  }

  filterSelect(data, filterValue) {
    this.selectResult = data.filter(item => item.plantId === filterValue);
    this.dataSource = new MatTableDataSource(this.selectResult);
  }

  searchAndSelectFilter(filterValue) {
    if (filterValue === this.searchFilter) {
      this.filterSelect(this.remoteMonitoringCheckList, this.plantFilter);
      this.filterSearch(this.selectResult, filterValue);
    } else {
      this.filterSearch(this.remoteMonitoringCheckList, this.searchFilter);
      this.filterSelect(this.searchResult, filterValue);
    }
  }


  changePage(event) {
    // sort and define paginator on page change event
    // only if the page size selected by the user is less than the total data length.
    if (this.dataSource.data.length > event['pageSize']) {
      this.dataSource.paginator = this.paginator;
    }
  }

  // get check list based on the plant
  getRemoteMonitoringCheckList(plantCode) {
    if (plantCode == null) {
      this.dataSource = new MatTableDataSource(this.remoteMonitoringCheckList);
      this.dataSource.paginator = this.paginator;
    } else {
      this.dataSource.filter = plantCode.trim().toLowerCase();
    }
  }

  getSelectedRemoteCheck(element) {
    sessionStorage.setItem('remoteData.rmcid', element.id);
    sessionStorage.setItem('remoteData.countryId', element.countryId);
    sessionStorage.setItem('remoteData.cityId', element.cityId);
    sessionStorage.setItem('remoteData.plantId', element.plantId);
  }

}
