import { Component, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    selector: 'cancel-confirmation-dialog',
    templateUrl: '../confirmation-dialog/cancel-confirmation-dialog.html',
    styleUrls: ['../../../../assets/css/events.css']
})
export class CancelConfirmationDialogComponent {
    isDelete = false;
    constructor(
        private router: Router,
        public dialogRef: MatDialogRef<CancelConfirmationDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data) {
        if (data.type === 'delete') {
            this.isDelete = true;
        }
    }

    onNoClick(): void {
        this.dialogRef.close();
    }
    onYesClick(): void {
        this.dialogRef.close();
        if (this.data.route) {
            this.router.navigate(['/' + this.data.route]);
        }
        this.dialogRef.close(true);
    }
}