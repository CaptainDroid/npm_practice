import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { EventsService } from 'src/app/services/events.service';

export interface EventList {
  type: string;
  description: string;
  action: string;
}

@Component({
  selector: 'app-event-type-list',
  templateUrl: './event-type-list.component.html',
  styleUrls: ['./event-type-list.component.css',
              '../../../../assets/css/events.css']
})

export class EventTypeListComponent implements OnInit {

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  displayedColumns: string[] = ['type', 'description', 'action'];
  allData: EventList[] = [];
  dataSource: any;
  errorMessage: any;

  constructor(
    private eventsService: EventsService
  ) {
    this.eventsService.getAllEvents().subscribe(
      (data: any) => {
        this.allData = data.data.eventtypes;
        this.dataSource = new MatTableDataSource(this.allData);
        if (this.dataSource) {
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  ngOnInit() {
    // this.dataSource.paginator = this.paginator;

    // this.eventsService.getAllEvents().subscribe(
    //   (data: any) => {
    //     this.allData = data.data.eventtypes;
    //     this.dataSource = new MatTableDataSource(this.allData);
    //     if (this.dataSource) {
    //       this.dataSource.paginator = this.paginator;
    //     }
    //   },
    //   (err: any) => {
    //     this.errorMessage = err;
    //   }
    // );
  }

  editAction() {

  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
}


// const ELEMENT_DATA: EventList[] = [
//   { type: 'Effluent COD audit', description: 'Effluent COD audit', action: 'Edit' },
//   { type: 'Helium', description: 'Effluent COD audit', action: 'Edit' },
//   { type: 'Lithium', description: 'Effluent COD audit', action: 'Edit' },
//   { type: 'Beryllium', description: 'Effluent COD audit', action: 'Edit' },
// ];

