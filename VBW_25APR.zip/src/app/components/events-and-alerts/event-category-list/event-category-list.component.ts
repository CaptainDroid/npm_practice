import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { EventsService } from 'src/app/services/events.service';
export interface IEventTypeList {
  eventType: any;
  eventCategoryName: string;
  eventCategoryId: any;
}

@Component({
  selector: 'app-event-category-list',
  templateUrl: './event-category-list.component.html',
  styleUrls: [
    './event-category-list.component.css',
    '../../../../assets/css/events.css'
  ]
})
export class EventCategoryListComponent implements OnInit {
  displayedColumns: string[] = ['eventCategory', 'eventType', 'action'];
  eventsListingData: any[];
  eventTypeArray: any[];
  dataSource: any;
  eventCategory: IEventTypeList;
  eventCategoryResponse: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private eventService: EventsService) {
    /**
     * Get Event Category List
     */
    this.eventService.getEventCategory().subscribe(
      (res: any) => {
        this.eventsListingData = [];
        this.eventTypeArray = [];
        this.eventCategory = {
          eventCategoryName: '',
          eventType: '',
          eventCategoryId: ''
        };
        this.eventCategoryResponse = res.data.eventCategories;
        this.eventCategoryResponse.forEach(eventCategory => {
          eventCategory.eventTypes.forEach(eventTypes => {
            this.eventTypeArray.push(eventTypes.eventType);
          });
          this.eventCategory = {
            eventCategoryName: eventCategory.eventCategoryName,
            eventType: this.eventTypeArray,
            eventCategoryId: eventCategory.eventCategoryId,
          };
          this.eventsListingData.push(this.eventCategory);
          this.eventTypeArray = [];
        });
        this.dataSource = new MatTableDataSource(this.eventsListingData);
        this.dataSource.filterPredicate = function (data: IEventTypeList, filter: string): boolean {
          return data.eventCategoryName.toLowerCase().includes(filter) || data.eventType.toString().toLowerCase().includes(filter);
        };
        this.dataSource.paginator = this.paginator;
      },
      (err: any) => {
        console.log('Events Listing Failed');
      });
  }

  /**
   * Event Search
   * @param filterValue
   */
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnInit() {
  }
}
