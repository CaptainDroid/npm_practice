import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { EventsService } from 'src/app/services/events.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CancelConfirmationDialogComponent } from '../confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
export interface IEventCategory {
  action: string;
  eventCategoryId: any;
  eventCategoryName: string;
  eventCategoryDescription: string;
  allowManualEventCreation: boolean;
  createdBy: any;
  createdAt: any;
  updatedBy: any;
  updatedAt: any;
  tenantId: number;
  eventTypeids: any[];
  actionRoleIds: any[];
  viewRoleIds: any[];
  emailCcRoleIds: any[];
}

@Component({
  selector: 'app-add-event-category',
  templateUrl: './add-event-category.component.html',
  styleUrls: [
    './add-event-category.component.css',
    '../../../../assets/css/events.css'
  ]
})
export class AddEventCategoryComponent implements OnInit {
  addNewEventForm: FormGroup;
  eventType = new FormControl();
  eventTypeList: string[] = [];
  users: any[];
  categoryId: any = '';
  isEditEvent = false;
  eventAction: string;
  eventCategories: any[] = [];
  formData: IEventCategory;
  isSubmitted = false;
  userId: number;

  validation_messages = {
    'eventCategory': [
      { type: 'required', message: 'data.L00297' },
      { type: 'pattern', message: 'data.L00297' },
      { type: 'alpha', message: 'data.L00520' }
    ],
    'description': [
      { type: 'required', message: 'data.L00298' },
      { type: 'pattern', message: 'data.L00520' },
      { type: 'minlength', message: 'data.L00466' }
    ],
    'eventType': [
      { type: 'required', message: 'data.L00299' },
    ],
    'manualEventCreation': [
      { type: 'required', message: 'data.L00300' }
    ],
    'actionByRoles': [
      { type: 'required', message: 'data.L00301' },
    ],
    'viewByRoles': [
      { type: 'required', message: 'data.L00302' },
    ],
    'emailCcRoles': [
      { type: 'required', message: 'data.L00793'}
    ]
  };

  constructor(
    private formBuilder: FormBuilder,
    private eventService: EventsService,
    private router: Router,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private errorservice: ErrorserviceService,
  ) {
    this.userId = parseInt(JSON.parse(localStorage.getItem('user')).amr, 10);

    /**
     * Get Category id from params
     */
    this.route.params.subscribe(params => {
      this.categoryId = params.eventCategoryId;
      if (this.categoryId) {
        this.isEditEvent = true;
      } else {
        this.categoryId = 0;
      }
    });
  }


  // Prevent blank space to enter intially
  handleInitialSpace(e) {
    if (e.target.value.length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  /**
   * Form Submit
   */
  onSubmit() {
    console.log(this.addNewEventForm);
    this.isSubmitted = true;
    if (this.addNewEventForm.valid) {
      const formValue = this.addNewEventForm.getRawValue();
      this.eventAction = 'Create';
      if (this.isEditEvent) {
        this.eventAction = 'Update';
      }
      this.eventService.eventData = formValue;
      this.formData = {
        action: this.eventAction,
        eventCategoryId: Number(this.categoryId),
        eventCategoryName: formValue.eventCategory,
        eventCategoryDescription: formValue.description,
        allowManualEventCreation: formValue.manualEventCreation,
        createdBy: this.userId,
        createdAt: '',
        updatedBy: this.userId,
        updatedAt: '',
        tenantId: 1,
        eventTypeids: formValue.eventType,
        actionRoleIds: formValue.actionByRoles,
        viewRoleIds: formValue.viewByRoles,
        emailCcRoleIds: formValue.emailCcRoles
      };
      /**
       * Add/Edit Form Data - POST
       */
      this.eventService.addEventCategory(this.formData).subscribe(
        (data: any) => {
          if (data.status === 'success') {
            if (this.isEditEvent) {
              this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00804' });
            } else {
              this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00805' });
            }

            this.router.navigate(['/event-category-list']);
          } else {
            this.errorservice.showerror({ status: data.status, statusText: data.message });
          }
        },
        (err: any) => {
          console.log('Failed');
        }
      );
    }
  }

  /**
   * {{"data.L00409" | translate}} Confirmation Dialog
   */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'event-category-list' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  alphabetsOnly(event) {
    const pattern = /^[a-zA-Z]$/;
    const inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode !== 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  alphanumericValidation(control: FormControl) {
    const format = /^[a-zA-Z][a-zA-Z0-9-_\s!@#$%^&*(),.?"';:{}|<>+=]*$/;
    if (control.value.trim().length > 0) {
      if (!format.test(control.value)) {
        return {
          alpha: true
        };
      }
    }
    return null;
  }

  ngOnInit() {

    /**
     * Event Type Multi Select Dropdown Listing
     */
    this.eventService.eventType().subscribe(
      (data: any) => {
        this.eventTypeList = data.data.eventtypes;
      },
      (err: any) => {
        console.log('Events Type Listing Failed');
      });

    /**
     * Get Roles
     */
    this.eventService.getRoles().subscribe(
      (data: any) => {
        this.users = data.data;
      },
      (err: any) => {
        console.log('Role Listing failed');
      });

    /**
     * Form Data
     */
    // this.addNewEventForm = this.formBuilder.group({
    //   eventCategory: [{ value: '', disabled: this.isEditEvent }, Validators.required],
    //   description: ['', Validators.required],
    //   eventType: ['', Validators.required],
    //   manualEventCreation: ['', Validators.required],
    //   actionByRoles: ['', Validators.required],
    //   viewByRoles: ['', Validators.required]
    // });

    this.addNewEventForm = this.formBuilder.group({
      eventCategory: new FormControl({value: '', disabled: this.isEditEvent},
      [Validators.required]),
      description: new FormControl('', Validators.compose([Validators.maxLength(255), Validators.minLength(3), Validators.required])),
      eventType: new FormControl('', [Validators.required]),
      manualEventCreation: new FormControl('', [Validators.required]),
      actionByRoles: new FormControl('', [Validators.required]),
      viewByRoles: new FormControl(''),
      emailCcRoles: new FormControl('')
    });

    /**
     * Check whether the page is Edit Event
     */
    if (this.isEditEvent) {
      this.eventService.getEventCategory(this.categoryId).subscribe(
        (data: any) => {
          const result = data.data.eventCategory[0];
          const eventTypeArray = [];
          result.eventTypes.forEach(eventType => eventTypeArray.push(eventType.eventTypeId));
          this.addNewEventForm.setValue({
            eventCategory: result.eventCategoryName,
            description: result.eventCategoryDescription,
            eventType: eventTypeArray,
            manualEventCreation: result.allowManualEventCreation,
            actionByRoles: result.actionByRoles,
            viewByRoles: result.viewByRoles,
            emailCcRoles: result.emailCcRoles
          });
        },
        (err: any) => {
          console.log('Failed to fetch Event Category Details');
        });
    }
  }
}
