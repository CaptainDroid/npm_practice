import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { WorksheetService } from 'src/app/services/worksheet.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { EventsService } from 'src/app/services/events.service';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { ActivatedRoute } from '@angular/router';

export interface PeriodicElement {
  id: number;
  plant: string;
  tag: string;
  negative: string;
  zero: string;
  outOfRange: string;
  drifting: string;
  suddenSpike: string;
  unchanging: string;
  flipFlop: string;
}

@Component({
  selector: 'app-sensor-failure-check-list',
  templateUrl: './sensor-failure-check-list.component.html',
  styleUrls: ['./sensor-failure-check-list.component.css', '../../../../assets/css/events.css']
})
export class SensorFailureCheckListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  errorMessage: any;
  dataSource: any;
  dataLength: number;
  addedSensorFailureData: any;
  sensorFailureData: any[];
  plantsresponse: any;
  plants = [];
  selectedPlant = 0;
  selectedPlantObj: any;
  searchFilter: any;
  plantFilter: any;
  selectResult: any[] = [];
  searchResult: any[] = [];
  sensorFailureResponse: any;

  displayedColumns: string[] = ['plant', 'tag', 'negative', 'zero', 'outofrange',
  'drifting', 'suddenspike', 'unchanging', 'flipflop', 'action'];


  constructor(
    private worksheetService: WorksheetService,
    private eventsService: EventsService,
    private errorservice: ErrorserviceService,
    private router: ActivatedRoute,
  ) {
  }

  ngOnInit() {
    if (this.router.params['value'].plantid !== undefined) {
      this.plantFilter = parseInt(this.router.params['value'].plantid, 10);
    } else {
      this.plantFilter = 0;
    }
    this.getAllPlantsList();
    if (this.dataSource) {
      this.dataSource.sort = this.sort;
    }
    this.eventsService.getplants().subscribe(
      data => {
        this.plantsresponse = data;
        this.plants = [];
        if (this.plantsresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsresponse.status, statusText: this.plantsresponse.message });
        } else {
          for (let i = 0; i < this.plantsresponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsresponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsresponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsresponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsresponse.data.countries[i].id;
                plantobj.citiId = this.plantsresponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
        }
      },
      (err: any) => {
        this.errorMessage = 'There are no plants pulled from the server!';
      }
    );

    if (this.dataSource) {
      this.dataSource.sort = this.sort;
    }
  }
  getAllPlantsList() {
    this.eventsService.sensorFailuresapi().subscribe(
      (data: any) => {
        this.sensorFailureData = [];
        this.sensorFailureResponse = data;
        if (this.sensorFailureResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.sensorFailureResponse.status, statusText: this.sensorFailureResponse.message });
        } else {
          const sensorFailureList = [];
          const countries = this.sensorFailureResponse.data['countries'];
          countries.forEach(country => {
            const cities = country['cities'];
            cities.forEach(city => {
              const plants = city['plants'];
              plants.forEach(plant => {
                const monitoringChecks = plant['sensorfailurechecks'];
                monitoringChecks.forEach(eachValue => {
                  const plantData = {
                    'sensorFailureCheckId': eachValue.sensorFailureCheckId,
                    'driftingVal': eachValue.driftingVal,
                    'flipFlopVal': eachValue.flipFlopVal,
                    'negativeCheckVal': eachValue.negativeCheckVal,
                    'outOfRangeVal': eachValue.outOfRangeVal,
                    'plantId': eachValue.plantId,
                    'plantAcronym': (eachValue.plantAcronym != null || eachValue.plantAcronym !== undefined) ? eachValue.plantAcronym : '',
                    'plantName': eachValue.plantName,
                    'suddenSpikeValMax': eachValue.suddenSpikeValMax,
                    'suddenSpikeValMin': eachValue.suddenSpikeValMin,
                    'tagName': (eachValue.tagName != null || eachValue.tagName !== undefined) ? eachValue.tagName : '',
                    'tenantId': eachValue.tenantId,
                    'unchangingVal': eachValue.unchangingVal,
                    'zeroCheckVal': eachValue.zeroCheckVal,
                    'cityId': city.id,
                    'countryId': country.id
                  };
                  sensorFailureList.push(plantData);
                });
              });
            });
          });
          this.sensorFailureData = sensorFailureList;

          if (this.router.params['value'].plantid !== undefined) {
            this.plantFilter = parseInt(this.router.params['value'].plantid, 10);
            this.applyFilter(this.plantFilter);
          } else {
            this.dataSource = new MatTableDataSource(this.sensorFailureData);
            this.dataLength = this.dataSource.filteredData.length;
            // if (this.plants && this.plants.length === 1) {
            //   this.plantFilter = this.plants[0].acronym;
            //   this.applyFilter(this.plantFilter);
            // }
            if (this.dataSource) {
              this.dataSource.paginator = this.paginator;
            }
          }
        }
      });
  }

  applyFilter(filterValue: string) {
    if (this.plantFilter === 0) {
      // this.dataSource = new MatTableDataSource(this.sensorFailureData);
      // if (filterValue === this.searchFilter) {
      //   this.filterSearch(this.sensorFailureData, filterValue);
      // }
      if (this.searchFilter) {
        this.filterSearch(this.sensorFailureData, this.searchFilter);
      } else {
        this.dataSource = new MatTableDataSource(this.sensorFailureData);
      }
      if (filterValue === this.searchFilter) {
        this.filterSearch(this.sensorFailureData, filterValue);
      }
    } else {
      if (this.searchFilter && this.plantFilter) {
        this.searchAndSelectFilter(filterValue);
      } else {
        if (this.searchFilter && !this.plantFilter) {
          filterValue = this.searchFilter;
          this.filterSearch(this.sensorFailureData, filterValue);
        } else if (!this.searchFilter && this.plantFilter) {
          filterValue = this.plantFilter;
          this.filterSelect(this.sensorFailureData, filterValue);
        }
      }
    }
    this.dataSource.paginator = this.paginator;
  }

  filterSearch(data, filterValue) {
    this.searchResult = data.filter(item => {
      return (item.plantAcronym.toString().toLowerCase().includes(filterValue.toLowerCase())) ||
      (item.tagName.toString().toLowerCase().includes(filterValue.toLowerCase()));
    });
    this.dataSource = new MatTableDataSource(this.searchResult);
  }

  filterSelect(data, filterValue) {
    this.selectResult = data.filter(item => item.plantId === filterValue);
    this.dataSource = new MatTableDataSource(this.selectResult);
  }

  searchAndSelectFilter(filterValue) {
    if (filterValue === this.searchFilter) {
      this.filterSelect(this.sensorFailureData, this.plantFilter);
      this.filterSearch(this.selectResult, filterValue);
    } else {
      this.filterSearch(this.sensorFailureData, this.searchFilter);
      this.filterSelect(this.searchResult, filterValue);
    }
  }

  getSelectedSensorCheck(element) {
    sessionStorage.setItem('sensorData.countryId', element.countryId);
    sessionStorage.setItem('sensorData.cityId', element.cityId);
    sessionStorage.setItem('sensorData.plantId', element.plantId);
    sessionStorage.setItem('sensorData.plantName', element.plantName);
  }

}
