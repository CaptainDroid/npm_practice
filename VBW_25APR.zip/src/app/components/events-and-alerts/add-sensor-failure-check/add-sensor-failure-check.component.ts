import { Component, OnInit, ViewChild, AfterViewInit, Inject } from '@angular/core';
import { FormControl, FormBuilder, FormGroupDirective, FormGroup, NgForm, Validators, AbstractControl } from '@angular/forms';
import { WorksheetService } from 'src/app/services/worksheet.service';
import { EventsService } from 'src/app/services/events.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ErrorStateMatcher } from '@angular/material/core';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

export interface Tags {
  tagname: string;
}

export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'app-add-sensor-failure-check',
  templateUrl: './add-sensor-failure-check.component.html',
  styleUrls: ['./add-sensor-failure-check.component.css', '../../../../assets/css/events.css']
})
export class AddSensorFailureCheckComponent implements OnInit {
  // @ViewChild('formData') formData: any;
  addSensorFailureForm: FormGroup;
  plants: any;
  errorMessage: any;
  submitted = false;
  editData: any = { plant: '', drifting: '', flipFlop: '' };
  animal: string;
  name: string;
  hideField = false;
  error = false;
  sensorFailureResponse: any;
  singleSensorFailureData: any;
  finalFormData: any;
  // allTags: any[];
  allTags: Observable<Tags[]>;
  selectedPlant: any;
  selectedData: any;
  userId: any;

  tagName = new FormControl();
  options: Tags[];
  sensorFailureList: any;
  noTags = false;
  paramPlantId = 0;

  plant: any;
  city: any;
  plantId: any;
  cityId: any;
  countryName: any;
  countryId: any;
  tag: any;
  editDataId: any;
  errorMsg: any;
  count = 0;
  yesValueRequired: boolean;
  invalidChars = [
    '-',
    '+',
    'e',
  ];
  isEdit: any;
  invalidTag = false;
  tagsList;
  negativeCheckValue: any;
  zeroCheckValue: any;
  rangeCheckValue: any;
  unChangingCheckValue: any;
  driftingCheckValue: any;
  suddenCheckValue: any;
  flipFlopCheckValue: any;
  suddenCheckMaxValue: any;
  sensorFailureCheck: any;
  // isNegativeDisable: boolean = false;
  // isZeroDisable: boolean = false;
  // isOutofRangeDisable: boolean = false;
  // isUnchangingDisable: boolean = false;
  // isDriftingDisable: boolean = false;
  // isSpikeDisable: boolean = false;
  // isFlipDisable: boolean = false;
  // sensorData: boolean = false

  constructor(
    private formBuilder: FormBuilder,
    private worksheetService: WorksheetService,
    private eventsService: EventsService,
    private router: ActivatedRoute,
    public dialog: MatDialog,
    private route: Router,
    private errorservice: ErrorserviceService
  ) {
    this.selectedData = {
      'countryId': sessionStorage.getItem('sensorData.countryId'),
      'cityId': sessionStorage.getItem('sensorData.cityId'),
      'plantId': sessionStorage.getItem('sensorData.plantId')
    };
  }

  ngOnInit() {

    this.addSensorFailureForm = this.formBuilder.group({
      sensorFailureCheckId: [''],
      plantId: [{ value: '', disabled: this.editDataId }, [Validators.required, Validators.min(1)]],
      updatedAt: [''],
      tenantId: [''],
      updatedBy: [''],
      createdAt: [''],
      createdBy: [''],
      plantName: [''],
      plantAcronym: [''],
      tagName: [{ value: '', disabled: this.editDataId }, Validators.required],
      NegativeCheck: [''],
      negativeCheckVal: [{ value: ''}, [this.NegativeValidate, this.patternCheck, Validators.min(1),
        Validators.maxLength(10)]],
      ZeroCheck: [''],
      zeroCheckVal: [{ value: '' }, [this.patternCheck, this.ZeroValidate, Validators.min(1)]],
      OutOfRangeCheck: [''],
      outOfRangeVal: [{ value: '' }, [this.patternCheck, this.OutOfRangeValidate, Validators.min(1)]],
      UnChangingCheck: [''],
      unchangingVal: [{ value: '' }, [this.patternCheck, this.UnchangeValidate, Validators.min(1)]],
      DriftingCheck: [''],
      driftingVal: [{ value: '' }, [this.AbspatternCheck, this.DriftValidate]],
      SuddenSpikeCheck: [''],
      suddenSpikeValMin: [{ value: '' }, [this.spikeMinValidate]],
      suddenSpikeValMax: [{ value: '' }, [this.spikeMaxValidate]],
      FlipFlopCheck: [''],
      flipFlopVal: [{ value: '' }, [this.patternCheck, this.FlipValidate, Validators.min(1)]]
    });

    this.worksheetService.getplants().subscribe(
      (val: any) => {
        const plantsresponse = val['data'];
        const countries = plantsresponse['countries'];
        const plantCodeList = [];
        countries.forEach(country => {
          const cities = country['cities'];
          cities.forEach(city => {
            this.cityId = city.id;
            const plants = city['plants'];
            plants.forEach(plant => {
              this.countryId = country.id;
              this.countryName = country.name;
              this.plantId = plant.id;
              const plantCode = {
                id: plant.id,
                value: plant.acronym,
                plantName: plant.name,
                countryId: country.id,
                countryName: country.name,
                cityId: city.id
              };
              plantCodeList.push(plantCode);
            });
          });
        });
        this.plants = plantCodeList;
        if (this.router.params['value'].plantid !== undefined && parseInt(this.router.params['value'].plantid, 10) !== 0) {
          const plantid = parseInt(this.router.params['value'].plantid, 10);
          this.addSensorFailureForm.controls['plantId'].setValue(plantid);
          const selected = this.plants.find((element) => {
            if (element.id === plantid) {
              return element;
            }
          });
          this.paramPlantId = selected.id;
          this.getTags(selected);
        }
      },
      (err: any) => {
        this.errorMessage = 'There are no plants pulled from the server!';
      });

    if (this.editData.plant) {
      this.hideField = true;
    }

    const loggedInUser = JSON.parse(localStorage.getItem('user'));
    this.userId = loggedInUser.amr;
    this.router.params.subscribe((params: Params) => {
      const id = params['id'];
      this.editDataId = id;
      if (this.editDataId) {
        this.isEdit = true;
      } else {
        this.isEdit = false;
      }
      this.eventsService.sensorFailuresapi().subscribe(
        data => {
          const sensorFailureList = [];
          this.sensorFailureResponse = data;
          const countries = this.sensorFailureResponse.data['countries'];
          countries.forEach(country => {
            const cities = country['cities'];
            cities.forEach(city => {
              const plants = city['plants'];
              plants.forEach(plant => {
                const monitoringChecks = plant['sensorfailurechecks'];
                monitoringChecks.forEach(eachValue => {
                  const plantData = {
                    'tagName': (eachValue.tagName != null || eachValue.tagName !== undefined) ? eachValue.tagName : '',
                    'plantId':  eachValue.plantId
                  };
                  sensorFailureList.push(plantData);
                });
              });
            });
          });
          this.sensorFailureList = sensorFailureList;
        });
    });

    if (this.editDataId) {
      const paramData = {
        country: this.selectedData.countryId,
        city: this.selectedData.cityId,
        plant: this.selectedData.plantId
      };

      // this.selectedPlantTags(paramData);

      // this.eventsService.getTagsForGivenPlant(paramData).subscribe(
      //   (val: any) => {
      //     const countries = val.data.countries;
      //     countries.forEach(city => {
      //       city.cities.forEach(cities => {
      //         const plantsArray = cities.plants;
      //         plantsArray.forEach(plants => {
      //           if (plants.id = paramData.plant) {
      //             this.allTags = plants.tags;
      //           }
      //         })
      //       });
      //     });
      //   },
      //   (err: any) => {
      //     this.errorMessage = 'There are no tags pulled from the server!';
      //   });
      this.eventsService.getSingleSensorFailure(this.selectedData.countryId, this.selectedData.cityId,
         this.selectedData.plantId, this.editDataId)
        .subscribe((val: any) => {
          // this.sensorData = true;
          const sensorFailureData = val;
          const country = sensorFailureData.data.country;
          const city = country.city;
          this.city = city;
          const plant = city.plant;
          this.plant = plant;
          this.sensorFailureCheck = plant.sensorfailurecheck;
          this.singleSensorFailureData = plant.sensorfailurecheck;

          this.sensorFailureCheck.NegativeCheck = this.sensorFailureCheck.negativeCheckVal > 0 ? 1 : 0;
          this.sensorFailureCheck.ZeroCheck = this.sensorFailureCheck.zeroCheckVal > 0 ? 1 : 0;
          this.sensorFailureCheck.OutOfRangeCheck = this.sensorFailureCheck.outOfRangeVal > 0 ? 1 : 0;
          this.sensorFailureCheck.UnChangingCheck = this.sensorFailureCheck.unchangingVal > 0 ? 1 : 0;
          this.sensorFailureCheck.DriftingCheck = this.sensorFailureCheck.driftingVal > 0 ? 1 : 0;
          this.sensorFailureCheck.SuddenSpikeCheck = this.sensorFailureCheck.suddenSpikeValMin > 0 ? 1 : 0;
          this.sensorFailureCheck.FlipFlopCheck = this.sensorFailureCheck.flipFlopVal > 0 ? 1 : 0;
          this.addSensorFailureForm.patchValue(this.sensorFailureCheck);
        });
    }
  }

  negativeCheck(event) {
    if (this.addSensorFailureForm.value.NegativeCheck === 0) {
      this.negativeCheckValue = '';
    } else if (this.addSensorFailureForm.value.NegativeCheck === 1) {
      this.negativeCheckValue = '';
    }
  }
  zeroCheck(event) {
    if (this.addSensorFailureForm.value.ZeroCheck === 0) {
      this.zeroCheckValue = '';
    } else if (this.addSensorFailureForm.value.ZeroCheck === 1) {
      this.zeroCheckValue = '';
    }
  }
  outOfRangeCheck(event) {
    if (this.addSensorFailureForm.value.OutOfRangeCheck === 0) {
      this.rangeCheckValue = '';
    } else if (this.addSensorFailureForm.value.OutOfRangeCheck === 1) {
      this.rangeCheckValue = '';
    }
  }
  unChangingCheck(event) {
    if (this.addSensorFailureForm.value.UnChangingCheck === 0) {
      this.unChangingCheckValue = '';
    } else if (this.addSensorFailureForm.value.UnChangingCheck === 1) {
      this.unChangingCheckValue = '';
    }
  }
  driftingCheck(event) {
    if (this.addSensorFailureForm.value.DriftingCheck === 0) {
      this.driftingCheckValue = '';
    } else if (this.addSensorFailureForm.value.DriftingCheck === 1) {
      this.driftingCheckValue = '';
    }
  }
  suddenCheck(event) {
    if (this.addSensorFailureForm.value.SuddenSpikeCheck === 0) {
      this.suddenCheckValue = '';
      this.suddenCheckMaxValue = '';
    } else if (this.addSensorFailureForm.value.SuddenSpikeCheck === 1) {
      this.suddenCheckValue = '';
      this.suddenCheckMaxValue = '';
    }
  }
  flipFlopCheck(event) {
    if (this.addSensorFailureForm.value.FlipFlopCheck === 0) {
      this.flipFlopCheckValue = '';
    } else if (this.addSensorFailureForm.value.FlipFlopCheck === 1) {
      this.flipFlopCheckValue = '';
    }
  }

  handleFloat(event) {
    if (this.countDecimals(event.target.value) > 3) {
      this.addSensorFailureForm.controls[event.target.attributes.formcontrolname.nodeValue].
      setValue(parseFloat(event.target.value).toFixed(3));
    }
  }

  countDecimals(value) {
    if ((value % 1) !== 0) {
        return value.toString().split('.')[1].length;
    }
    return 0;
  }

  removeNonDigits(event) {
    this.addSensorFailureForm.controls[event.target.attributes.formcontrolname.nodeValue].
    setValue(event.target.value.replace(/[^\d.\-]/g, ''));
    // if(event.target.value.replace(/[^-]/g, "").length > 1){
    //   this.addRemoteMonitorngCheckForm.controls[event.target.attributes.formcontrolname.nodeValue]
    // .setValue(event.target.value.replace(/[^\d.\-]/g, ''));
    // }
  }

  checkTags() {
    if(!this.isEdit) {
      if(this.tagName.value === null) return;
      const index = this.tagsList.findIndex(tag => {
        return tag.tagname.toLowerCase() == this.tagName.value.toString().toLowerCase();
      });
      if(index === -1) {
        this.invalidTag = true;
      } else {
        this.invalidTag = false;
      }
    }
  }

  onSubmit() {
    if (!this.editDataId) {
      this.addSensorFailureForm.value.tagName = this.tagName.value['tagname'];
      this.addSensorFailureForm.controls['tagName'].
        setValue(this.tagName.value['tagname']);
    }
    this.submitted = true;
    if (this.addSensorFailureForm.invalid) {
      return;
    }
    if(this.invalidTag) {
      return;
    }
    // console.log("tags", this.tagName, this.allTags);
    // if(this.allTags.findIndex)
    // return;
    this.yesValueRequired = false;
    if (this.addSensorFailureForm.value.NegativeCheck === 1 || this.addSensorFailureForm.value.ZeroCheck === 1 ||
      this.addSensorFailureForm.value.OutOfRangeCheck === 1 || this.addSensorFailureForm.value.UnChangingCheck === 1 ||
      this.addSensorFailureForm.value.DriftingCheck === 1 ||
      this.addSensorFailureForm.value.SuddenSpikeCheck === 1 ||
      this.addSensorFailureForm.value.FlipFlopCheck === 1) {
      this.count = 1;
    } else {
      this.count = 0;
      this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00288' });
    }
    if (this.count >= 1) {
      if (this.addSensorFailureForm.value.NegativeCheck === 1 && !this.addSensorFailureForm.value.negativeCheckVal) {
        this.yesValueRequired = false;
        this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00763' });
        return;
      } else if (this.addSensorFailureForm.value.ZeroCheck === 1 && !this.addSensorFailureForm.value.zeroCheckVal) {
        this.yesValueRequired = false;
        this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00763' });
        return;
      } else if (this.addSensorFailureForm.value.OutOfRangeCheck === 1 && !this.addSensorFailureForm.value.outOfRangeVal) {
        this.yesValueRequired = false;
        this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00763' });
        return;
      } else if (this.addSensorFailureForm.value.UnChangingCheck === 1 && !this.addSensorFailureForm.value.unchangingVal) {
        this.yesValueRequired = false;
        this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00763' });
        return;
      } else if (this.addSensorFailureForm.value.DriftingCheck === 1 && !this.addSensorFailureForm.value.driftingVal) {
        this.yesValueRequired = false;
        this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00763' });
        return;
      } else if (this.addSensorFailureForm.value.FlipFlopCheck === 1 && !this.addSensorFailureForm.value.flipFlopVal) {
        this.yesValueRequired = false;
        this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00763' });
        return;
      } else {
        this.yesValueRequired = true;
      }
    }
    if (this.addSensorFailureForm.value.SuddenSpikeCheck === 1 &&
       (!this.addSensorFailureForm.value.suddenSpikeValMin &&
        !this.addSensorFailureForm.value.suddenSpikeValMax)) {
      this.yesValueRequired = false;
      this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00849' });
      return;
    } else if (this.addSensorFailureForm.value.SuddenSpikeCheck === 1 && !this.addSensorFailureForm.value.suddenSpikeValMax) {
      this.yesValueRequired = false;
      this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00850' });
      return;
    } else if (this.addSensorFailureForm.value.SuddenSpikeCheck === 1 && !this.addSensorFailureForm.value.suddenSpikeValMin) {
      this.yesValueRequired = false;
      this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00851' });
      return;
    } else if (this.addSensorFailureForm.value.SuddenSpikeCheck === 1 &&
      (Number(this.addSensorFailureForm.value.suddenSpikeValMin) >= Number(this.addSensorFailureForm.value.suddenSpikeValMax))) {
        this.yesValueRequired = false;
        this.errorservice.showerror({ status: 'Failed', statusText: 'data.L00852' });
        return;
    }
    if (this.editDataId && this.addSensorFailureForm.valid && this.count && this.yesValueRequired) {
      this.addSensorFailureForm.value.action = 'Update';
      this.addSensorFailureForm.value.tenantId = 1;
      this.addSensorFailureForm.value.updatedBy = parseInt(this.userId, 10);
      this.addSensorFailureForm.value.createdBy = 0;
      this.addSensorFailureForm.value.plantId = parseInt(this.selectedData.plantId, 10);
      this.addSensorFailureForm.value.tagName = this.singleSensorFailureData.tagName;

      this.eventsService.postSensorFailure(this.selectedData.countryId, this.selectedData.cityId,
        this.selectedData.plantId, this.addSensorFailureForm.value)
        .subscribe((result: any) => {
          if (result.status === 'Failed') {
            this.errorservice.showerror({ status: result['status'], statusText: result['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00795' });
            this.route.navigate(['/sensor-failure', this.paramPlantId]);
          }
        }, err => {
        });
    } else if (!this.editDataId && this.addSensorFailureForm.valid && this.count && this.yesValueRequired) {
      this.addSensorFailureForm.value.action = 'Create';
      this.addSensorFailureForm.value.tenantId = 1;
      this.addSensorFailureForm.value.createdBy = parseInt(this.userId, 10);
      this.addSensorFailureForm.value.updatedBy = 0;
      this.addSensorFailureForm.value.sensorFailureCheckId = 0;
      const countryId = this.selectedPlant.countryId;
      const city = this.selectedPlant.cityId;
      const plant = this.selectedPlant.id;

      this.eventsService.postSensorFailure(countryId, city, plant, this.addSensorFailureForm.value)
        .subscribe((result: any) => {
          if (result.status !== 'success') {
            this.errorservice.showerror({ status: result['status'], statusText: result['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00488' });
            this.route.navigate(['/sensor-failure', this.paramPlantId]);
          }
        }, err => {
        });
    }

  }

  NegativeValidate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class');
      element.classList.remove('mat-form-field-invalid');
    }
  }
  ZeroValidate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class-zero');
      element.classList.remove('mat-form-field-invalid');
    }
  }
  OutOfRangeValidate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class-range');
      element.classList.remove('mat-form-field-invalid');
    }
  }
  UnchangeValidate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class-unchange');
      element.classList.remove('mat-form-field-invalid');
    }
  }
  DriftValidate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class-drift');
      element.classList.remove('mat-form-field-invalid');
    }
  }
  FlipValidate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class-flip');
      element.classList.remove('mat-form-field-invalid');
    }
  }
  spikeMinValidate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class-min');
      element.classList.remove('mat-form-field-invalid');
    }
  }
  spikeMaxValidate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class-max');
      element.classList.remove('mat-form-field-invalid');
    }
  }
  Validate(control: AbstractControl) {
    if (control.value) {
      const element = document.querySelector('.remove-class-max-min');
      element.classList.remove('mat-form-field-invalid');
    }
  }

  patternCheck(control: AbstractControl) {
    if (control.value) {
      const format = /^[0-9]*$/;
      if (!format.test(control.value)) {
        return {
          pattern: true
        };
      }
      return null;
    }
  }

  AbspatternCheck(control: AbstractControl) {
    if (control.value) {
      const format = /^[\.]?[\d]{1,9}(\.[\d]{1,})?$/;
      if (!format.test(control.value)) {
        return {
          pattern: true
        };
      }
      return null;
    }
  }

  getTags(plant: any) {
    this.selectedPlant = plant;
    const paramData = {
      // country: plant.countryId,
      // city: plant.cityId,
      plant: plant.id,
      SearchText: 'SEST'
      // acronym: plant.value
    };
    this.selectedPlantTags(paramData);
  }
  selectedPlantTags(paramData) {
    this.eventsService.getTagsForGivenPlant(paramData).subscribe(
      (val: any) => {
        this.noTags = false;
        if (val.status !== 'success') {
          this.errorservice.showerror({ status: val['status'], statusText: val['message'] });
          return;
        }
        this.tagsList = val.data.tags;
        this.allTags = val.data.tags;
        const arr = [], newTagList = [], newArray = [];
        val.data.tags.map((e) => {
            return arr.push({'tagname': e.tagname.trim()});
        });
        this.options = arr;
        this.sensorFailureList.filter((element) => {
          if (element.plantId === this.selectedPlant.id) {
            newArray.push(element.tagName.trim());
          }
        });
        for (let i = 0; i < this.options.length; i++) {
          if (newArray.indexOf(this.options[i].tagname) === -1) {
            newTagList.push(this.options[i]);
          }
        }
        this.options = newTagList;
        if (newTagList.length === 0) {
          this.noTags = true;
        } else {
          this.noTags = false;
        }
        this.allTags = this.tagName.valueChanges
        .pipe(
          startWith<string | Tags>(''),
          map(value => typeof value === 'string' ? value : value.tagname),
          map(name => name ? this._filter(name) : newTagList.slice())
        );
      },
      (err: any) => {
        this.errorMessage = 'There are no tags pulled from the server!';
      });
  }

  _filter(name: string): Tags[] {
    const filterValue = name.toLowerCase();

    // return this.options.filter(option => option.tagname.toLowerCase().indexOf(filterValue) === 0);
    return this.options.filter(option => option.tagname.toLowerCase().includes(filterValue));
  }

  displayFn(user?: Tags): string | undefined {
    return user ? user.tagname : undefined;
  }

  // openDialog(): void {
  //   const dialogRef = this.dialog.open(CancelDialogComponent, {
  //     width: '400px',
  //   });

  //   dialogRef.afterClosed().subscribe(result => {

  //   });
  // }

  openDialog() {
    const dialogRef = this.dialog.open(CancelDialogComponent, {
      width: '400px',
      data: { route: 'sensor-failure/' + this.paramPlantId }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  numberOnly(event): boolean {
    let limit = 0;
    if (event.target.value != null) {
      limit = event.target.value.toString().length;
    }
    if (limit >= 15) {
      return false;
    } else {
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode !== 45 && charCode !== 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    }
  }
  maxLengthCheck(object) {
    if (object.value.length > object.maxLength) {
      object.value = object.value.slice(0, object.maxLength);
    }
  }
  preventLetterE(e) {
    if (this.invalidChars.includes(e.key)) {
      e.preventDefault();
    }
  }

}

// Dialog box for add worksheet
@Component({
  selector: 'app-cancel-dialog-component',
  templateUrl: 'cancel-popup.dialog.html',
  styleUrls: ['./cancel-popup.dialog.css', '../../../../assets/css/events.css']
})
export class CancelDialogComponent {



  // constructor(
  //   public dialogRef: MatDialogRef<CancelDialogComponent>,
  //   private router: Router,
  //   @Inject(MAT_DIALOG_DATA) public data: DialogData) {
  //   }

  // onNoClick(): void {
  //   this.dialogRef.close();
  // }
  // onYesClick(): void {
  //   this.dialogRef.close();
  //   this.router.navigate(['/sensor-failure']);
  //   this.dialogRef.close(true);
  // }

  isDelete = false;
    constructor(
        private router: Router,
        public dialogRef: MatDialogRef<CancelDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data) {
        if (data.type === 'delete') {
            this.isDelete = true;
        }
    }

    onNoClick(): void {
        this.dialogRef.close();
    }
    onYesClick(): void {
        this.dialogRef.close();
        if (this.data.route) {
            this.router.navigate(['/' + this.data.route]);
        }
        this.dialogRef.close(true);
    }

}
