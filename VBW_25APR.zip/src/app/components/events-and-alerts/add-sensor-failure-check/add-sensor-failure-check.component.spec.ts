import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSensorFailureCheckComponent } from './add-sensor-failure-check.component';

describe('AddSensorFailureCheckComponent', () => {
  let component: AddSensorFailureCheckComponent;
  let fixture: ComponentFixture<AddSensorFailureCheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddSensorFailureCheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSensorFailureCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
