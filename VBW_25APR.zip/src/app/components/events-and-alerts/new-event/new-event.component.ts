import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Event } from './event';
import { Router, ActivatedRoute } from '@angular/router';
import { EventsService } from 'src/app/services/events.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CancelConfirmationDialogComponent } from '../confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';

// declare var window;

@Component({
  selector: 'app-new-event',
  templateUrl: './new-event.component.html',
  styleUrls: ['./new-event.component.css',
    '../../../../assets/css/events.css']
})

export class NewEventComponent implements OnInit {
  model = new Event('', '');

  submitted = false;
  userId: any;

  typeId: any;
  isEditEvent: boolean;
  allData: any;
  eventTypeResonse: any;
  eventdata: any;
  invalidInput = false;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private eventsService: EventsService,
    private dialog: MatDialog,
    private errorservice: ErrorserviceService
  ) {
    this.route.params.subscribe(params => {
      this.typeId = params.id;
      // if (this.typeId) {
      //   this.isEditEvent = true;
      // }
    });
  }

  ngOnInit() {
    const loggedInUser = JSON.parse(localStorage.getItem('user'));
    this.userId = loggedInUser.amr;
    if (this.typeId !== '' && this.typeId !== undefined) {
      this.eventsService.getEventDetails(this.typeId).subscribe(
        (data: any) => {
          this.allData = data.data.eventtype;
          this.model = new Event(this.allData.eventType, this.allData.eventDescription);
        },
        (err: any) => {
          console.log('Failed to fetch Event Category Details');
        });


      this.eventsService.getAllEvents().subscribe(
        data => {
          // this.allData = data[0].data.eventtypes;
          // this.dataSource = new MatTableDataSource(this.allData);
        },
        (err: any) => {
          console.log('Failed to fetch Event');
        }
      );

    }
  }

  /**
 * Cancel Confirmation Dialog
 */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'event-type' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  onlyEnglishAndHypen(event) {
    console.log(event);
    const charCode = (event.which) ? event.which : event.keyCode;
    console.log(charCode);
    // if (charCode != 46 && charCode != 45 && charCode > 31
    //   && (charCode < 48 || charCode > 57)) {
    //     return true;
    //   }
    if (charCode === 32) {
        return true;
      }
      if (charCode === 45) {
        return true;
      }

    if (48 <= charCode && charCode <= 57) {
        return true;
    }
    if (65 <= charCode && charCode <= 90) {
        return true;
    }
    if (97 <= charCode && charCode <= 122) {
        return true;
    }


    return false;
  }
  // numberOnly(event): boolean {
  //   console.log('number-only')
  //   const charCode = (event.which) ? event.which : event.keyCode;
  //   if (charCode > 31 && (charCode < 48 || charCode > 57)) {
  //     return false;
  //   }
  //   return false;

  // }

  onSubmit() {
    // const format = /^[a-zA-Z0-9\s]*$/;
    // if (this.model.eventType.length > 0 && !format.test(this.model.eventType)) {
    //   this.invalidInput = true;
    // } else {
    //   this.invalidInput = false;
    // }
    let action, msg;
    if (this.typeId !== '' && this.typeId !== undefined) {
      action = 'Update';
      msg = 'data.L00795';
    } else {
      action = 'Create';
      msg = 'data.L00488';
    }
    // var eventTypeWordLimit = this.model.eventType.match(/\S+/g).length;
    // var eventDescWordLimit = this.model.eventDesc.match(/\S+/g).length;
    // if(eventTypeWordLimit > 50) {
    //   this.errorservice.showerror({ type: 'Info', status: '', statusText: 'Event type should not exceed 50 words' });
    //   return
    // }
    // if(eventDescWordLimit > 100) {
    //   this.errorservice.showerror({ type: 'Info', status: '', statusText: 'Event description should not exceed 100 words' });
    //   return
    // }
    this.eventdata = {
      action: action,
      eventTypeId: this.typeId,
      eventType: this.model.eventType.trim(),
      tenantId: 1,
      eventDescription: this.model.eventDesc.trim(),
      createdAt: '',
      createdBy: parseInt(this.userId, 10),
      updatedAt: '',
      updatedBy: parseInt(this.userId, 10),
    };
    if (!this.eventdata.eventType.length && !this.eventdata.eventDescription.length) {
      this.errorservice.showerror({ type: 'Info', status: '', statusText: 'Please fill the form' });
      return;
    }
    if (this.eventdata.eventType.length && this.eventdata.eventDescription.length && !this.invalidInput) {
      this.eventsService.postEventType(this.eventdata).subscribe(
        eventResponse => {
          this.eventTypeResonse = eventResponse;
          if (this.eventTypeResonse.status === 'Failed') {
            this.errorservice.showerror({ status: this.eventTypeResonse['status'], statusText: this.eventTypeResonse['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: '', statusText: msg });
            this.router.navigate(['/event-type']);
          }
        },
        (err: any) => {
          console.log(err);
        });
    }
  }

  newEvent() {
    this.model = new Event(this.model.eventType, this.model.eventDesc);
  }

  clearEvent() {
    this.model = new Event('', '');
    this.router.navigate(['/event-type']);
  }

  restrictBlankSpace(e) {
    if (e.target.value.toString().trim().length === 0) {
      if (e.keyCode === 32  || e.code === 'Space' || e.key === ' ') {
        e.preventDefault();
      }
    }
    /**
     * The Angular '(paste)' event does not fire in IE, so manually handling it for IE and checking if text is pasted
     *
     * Also, this is a potential security vulnerability in IE that the broswer can access what's on somebody's
     * clipboard without them knowing; We're not doing anything, but it should not be allowed anyway.
     * But, to support IE.., oh well.
     */
    if (e.ctrlKey === true && (e.keyCode === 86 || e.code === 'keyV')) {
     if ((window as any).clipboardData && (window as any).clipboardData.getData) {
      e['copiedText'] = (window as any).clipboardData.getData('Text');
     }
    }
    this.englishOnly(e);
  }

  // Prevent blank space to enter intially
  onKeydown(e) {
    if (e.target.value.length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  /**
   * Function to retrict input language to English
   */
  englishOnly($event) {
    let message;
    if ($event.copiedText) { // pasted text using IE
      message = $event.copiedText;
    } else if ($event.clipboardData) { // pasted text using Chrome and other browsers
      message = $event.clipboardData.getData('Text');
    } else { // Single text input
      message = $event.key;
    }
    if (message !== undefined) {
      message = message.toString();
    } else {
      message = ' ';
    }
    const re = /^[\x00-\x7F]+$/;
    const isValid = re.test(message);
    if (!isValid) {
      $event.preventDefault();
    }
  }
  /**
   * If clipboard access is not allowed by the user in IE, the above function will not work
   * To handle this situation, this function manually removes all the Non-English-Non-Digit-Non-Special-Characters
   * from the input field.
   *
   * It is not that graceful, as you'll be able to see the Non-valid stuff being pasted in IE,
   * but it'll vanish on moving away; but handling 231 billion cases for IE is already such a pain!
   */
  removeNonEnglish(event, field) {
    this.model[field] = event.target.value.replace(/[^\x00-\x7F]/g, '');
    // if (field === 'eventType') {
    //   // const format = /^[a-zA-Z0-9\s]*$/;
    //   // const format = /^[\x00-\x7F]+$/;
    //   // if (this.model.eventType.length > 0 && !format.test(this.model.eventType)) {
    //   //   this.invalidInput = true;
    //   // } else {
    //   //   this.invalidInput = false;
    //   // }
    //   // this.model.eventType = this.model.eventType.trim();
    // }
  }


  /**
   * Function to disable the right click menu
   * Disabling to prevent pasting through the right click context menu
   */
  rightClick($event) {
    $event.preventDefault();
  }
}
