export class Event {

  constructor(
    public eventType: string,
    public eventDesc: string
  ) { }

}

