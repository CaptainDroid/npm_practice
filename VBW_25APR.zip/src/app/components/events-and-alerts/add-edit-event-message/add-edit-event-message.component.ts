import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, FormGroup, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { EventsService } from 'src/app/services/events.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CancelConfirmationDialogComponent } from '../confirmation-dialog/cancel-confirmation-dialog';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-add-edit-event-message',
  templateUrl: './add-edit-event-message.component.html',
  styleUrls: ['./add-edit-event-message.component.css', '../../../../assets/css/events.css']
})
export class AddEditEventMessageComponent implements OnInit {
  submitted = false;
  editData: any;
  editId: any;
  userId: any;

  addEventMessageForm = new FormGroup({
    eventMessageId: new FormControl(''),
    eventMessage: new FormControl('', [
      Validators.required
      // , Validators.pattern(/^[a-zA-Z\s0-9]*$/)
    ]),
    eventDescription: new FormControl(''),
  });

  constructor(
    private eventsService: EventsService,
    private router: ActivatedRoute,
    private dialog: MatDialog,
    private route: Router,
    private errorservice: ErrorserviceService
  ) { }
  /**
    * Cancel Confirmation Dialog
    */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'event-message' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }
  ngOnInit() {
    const loggedInUser = JSON.parse(localStorage.getItem('user'));
    this.userId = loggedInUser.amr;
    this.router.params.subscribe((params: Params) => {
      const id = params['id'];
      this.editId = id;
      if (id) {
        this.eventsService.singleEventMessage(id).subscribe(data => {
          const result: any = data;
          const message = result.data.eventMessage;
          this.editData = message;
          this.addEventMessageForm.setValue(this.editData);
        });
      }
    });
  }
  // convenience getter for easy access to form fields
  get f() { return this.addEventMessageForm.controls; }

  // Prevent blank space to enter intially
  onKeydown(e) {
    if (e.target.value.length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
    this.englishOnly(e);
  }

  /**
   * Function to retrict input language to English
   */
  englishOnly($event) {
    let message;
    if ($event.clipboardData) {
      message = $event.clipboardData.getData('Text');
    } else {
      message = $event.key;
    }
    const re = /^[\x00-\x7F]+$/;
    const isValid = re.test(message);
    if (!isValid) {
      $event.preventDefault();
    }
  }

  /**
   * If clipboard access is not allowed by the user in IE, the above function will not work
   * To handle this situation, this function manually removes all the Non-English-Non-Digit-Non-Special-Characters
   * from the input field.
   *
   * It is not that graceful, as you'll be able to see the Non-valid stuff being pasted in IE,
   * but it'll vanish on moving away; but handling 231 billion cases for IE is already such a pain!
   */
  removeNonEnglish(event) {
    // tslint:disable-next-line:max-line-length
    this.addEventMessageForm.controls[event.target.attributes.formcontrolname.nodeValue].setValue(event.target.value.replace(/[^\x00-\x7F]/g, '').trim());
  }

  onSubmit() {
    this.submitted = true;
    if (this.addEventMessageForm.invalid) {
      return;
    }
    if (this.addEventMessageForm.valid && this.editId) {
      const dataArray = { 'tenantId': 1,
       'action': 'Update',
       'eventMessageId': this.addEventMessageForm.value.eventMessageId,
       'updatedBy': parseInt(this.userId, 10),
       'eventMessage': this.addEventMessageForm.value.eventMessage.trim(),
       'eventDescription': this.addEventMessageForm.value.eventDescription.trim()};
      if (this.addEventMessageForm.value.eventMessage.length > 1) {
        this.eventsService.addEditEventMessage(dataArray)
        .subscribe((response: any) => {
          if (response.status === 'Failed') {
            this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: '', statusText: response['message'] });
            this.route.navigate(['/event-message']);
          }
        }, err => {
          console.log(err);
        });
      }
    } else {
      const dataArray = { 'tenantId': 1,
      'action': 'Create',
      'eventMessageId': 0,
      'createdBy': parseInt(this.userId, 10),
      'eventMessage': this.addEventMessageForm.value.eventMessage.trim(),
      'eventDescription': this.addEventMessageForm.value.eventDescription.trim()};
      if (this.addEventMessageForm.value.eventMessage.length > 1) {
        this.eventsService.addEditEventMessage(dataArray)
        .subscribe((response: any) => {
          if (response.status === 'Failed') {
            this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: '', statusText: response['message'] });
            this.route.navigate(['/event-message']);
          }
        }, err => {
          console.log(err);
        });
      }
    }

  }

}
