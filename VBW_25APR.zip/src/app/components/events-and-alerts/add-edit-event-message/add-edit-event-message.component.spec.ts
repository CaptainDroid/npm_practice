import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditEventMessageComponent } from './add-edit-event-message.component';

describe('AddEditEventMessageComponent', () => {
  let component: AddEditEventMessageComponent;
  let fixture: ComponentFixture<AddEditEventMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditEventMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditEventMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
