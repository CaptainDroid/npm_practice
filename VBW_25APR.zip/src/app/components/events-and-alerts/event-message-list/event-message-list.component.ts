import { Component, OnInit, ViewChild } from '@angular/core';
import { EventsService } from 'src/app/services/events.service';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';

@Component({
  selector: 'app-event-message-list',
  templateUrl: './event-message-list.component.html',
  styleUrls: ['./event-message-list.component.css', '../../../../assets/css/events.css']
})
export class EventMessageListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  eventMessages: any;
  dataSource: any;
  displayedColumns: string[] = ['eventmessage', 'description', 'action'];

  constructor(
    private evntService: EventsService,
    private errorService: ErrorserviceService
  ) { }

  ngOnInit() {
    this.evntService.eventMessage()
    .subscribe(message => {
      const msg: any = message;
      if (msg.status !== 'success') {
        this.errorService.showerror({
          status: msg.errorCode,
          statusText: msg.message
        });
      } else {
        const data = msg.data.eventMessages;
        this.eventMessages = data;
        this.dataSource = new MatTableDataSource(this.eventMessages);
        if (this.dataSource) {
          this.dataSource.paginator = this.paginator;
        }
      }
    },
    (err: any) => {
      this.errorService.showerror(null);
    });
  }

  applyFilter(filterValue: string) {
    if (this.dataSource) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
    }
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}
