import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventMessageListComponent } from './event-message-list.component';

describe('EventMessageListComponent', () => {
  let component: EventMessageListComponent;
  let fixture: ComponentFixture<EventMessageListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventMessageListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventMessageListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
