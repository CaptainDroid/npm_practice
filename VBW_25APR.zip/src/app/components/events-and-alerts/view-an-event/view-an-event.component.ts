import { Component, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { CommercialService } from '../../../services/commercial.service';
import { FormControl, FormGroup, FormBuilder, Validators, FormGroupDirective, NgForm, FormArray} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { EventsService } from 'src/app/services/events.service';
import { forEach } from '@angular/router/src/utils/collection';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '../../../../environments/environment';
export interface RecommendationElement {
  slno: number;
  no: number;
  id: number;
  tagName: string;
  description: string;
  cost: number;
  effluentValue: number;
  costUnit: string;
  effluentUnit: string;
  selectedOption: boolean;
}
export interface UserDefinesRecommendationElement {
  slno: number;
  no: number;
  id: number;
  tagName: string;
  beforeValue: number;
  afterValue: number;
  remarks: string;
  cost: number;
  effluentValue: number;
  costUnit: string;
  effluentUnit: string;
  selectedOption: boolean;
}
class CrossFieldErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    return control.dirty && form.invalid;
  }
}
@Component({
  selector: 'app-view-an-event',
  templateUrl: './view-an-event.component.html',
  styleUrls: ['./view-an-event.component.css',
    '../../../../assets/css/events.css']
})
export class ViewAnEventComponent implements OnInit {

  action = {
    "NEW": "data.L01243",
    "ASGN": "data.L00399",
    "CLSE": "data.L00401",
    "RORA": "data.L01244"
  }
  displayedColumns: string[] = ["eventId", "plantName", "eventDate", "valueDate", "eventCategory", "tagName", "reasons", "assignedTo", "lapsed", "eventType"];
  displayedColumns2: string[] = ["date", "action", "role", "message", "recommendation", "lastUpdatedBy"];
  displayedColumnsrca: string[] = ['Tagnames', 'description', 'median', 'UOM'];
  displayedColumnsrec: string[] = ['no', 'tagname', 'description', 'cost', 'effluentValue', 'selectOption'];
  displayedlistColumnsrec: string[] = ['no', 'tagname', 'beforeValue', 'afterValue', 'remarks', 'cost', 'effluentValue', 'selectOption', 'action'];
  task: string;
  eventDataSource: any;
  historyDataSource: any;
  rcaDataSource: any;
  recDataSorece: any;
  usrdefinedDataSorece: any;
  dataSourceuserdef: any;
  plantId: any;
  spansRec = [];
  spansUserdefined = [];
  spansAddUserdefined = [];
  spansArray = [];
  spansArrayUserdefined = [];
  spansArrayDialog = [];
  eventId: any;
  displaycostUnit: any;
  displayeffluentUnit: any;
  selectedEventIds: any = [];
  reasons: any;
  tagsresponse: any;
  recommondationCount: number;
  tagCount: number;
  tags = [];
  plants = [];
  selectedRec: any;
  selectedUserDef: any;
  selectedRecNumber: any = null;
  selectedUserDefNumber: any = null;
  plantDataresponce: any;
  errorMessage: any;
  event: { eventId: any; plant: any; eventDate: any; valueDate: any; eventCategory: any; reasons: any; assignedTo: any; lapsed: any; eventType: any; plantId: any };
  eventArray: any[];
  eventHistoryArray: any[];
  eventrcasArray: any[];
  typeOfEvent: any;
  selectedRole: any = 0;
  noRoleSelected: boolean = false;
  assignMessage: string = '';
  submit: boolean = false;
  closeMessage: string = '';
  reopenMessage: string = '';
  invalidSubmit: boolean = false;
  loggedInUserDetails: any;
  verifyRcaFlag: boolean = false;
  lapsedTime: any;
  eventsrecommendationDATA: Array<RecommendationElement>;
  eventsuserrecommendationDATA: Array<UserDefinesRecommendationElement>;
  addeventsuserrecommendationDATA: Array<UserDefinesRecommendationElement>;
  addUserDefinedRecommondationForm: FormGroup;

  roles: any[];
  systemrecommendations = [];
  userdefinedrecommendations = [];
  adduserdefinedrecommendations = [];
  dataAnalyticFlag: boolean = false;
  addRecord: UserDefinesRecommendationElement;
  disableEventsAnalytics = false;
  selectedlang = 'en';
  constructor(
    private route: ActivatedRoute,
    private commercialService: CommercialService,
    private router: Router,
    private errorservice: ErrorserviceService,
    private eventsService: EventsService,
    private commonService: CommonService,
    public translate: TranslateService,
    public dialog: MatDialog) {
    this.disableEventsAnalytics = this.commonService.isAccess(environment.role.alertevents.eventanalytics);
    if (this.route.params['value'].hasOwnProperty("eventId")) {
      this.eventId = this.route.params['value'].eventId;
      this.task = this.route.params['value'].action;
    }
    let selectedPlant = this.commonService.getPlantObj();
    let eventType = this.commonService.getEventType();
    if(eventType && eventType === 'Data Analytics'){
      this.dataAnalyticFlag = true;
    }else{
      let tagName = this.commonService.getselectedEventCategory();
      this.dataAnalyticFlag = tagName === 'Data Analytics' ? true : false;
    }
    if (selectedPlant && this.dataAnalyticFlag && this.task === 'Close' &&  this.disableEventsAnalytics === false){
      this.getAllTagsinPlant(selectedPlant);
    }
    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'en';
      } else {
        this.selectedlang = 'cn';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
      if (parseInt(language.lang, 10) === 1) {
        this.selectedlang = 'en';
      } else {
        this.selectedlang = 'cn';
      }
    });
  }

  ngOnInit() {
    this.loggedInUserDetails = JSON.parse(localStorage.getItem('user'));
    if (this.task == 'view' || this.eventsService.selectedEvents) {
      /**
    * Get Roles
    */
      this.eventsService.getRoles().subscribe(
        (data: any) => {
          this.roles = data.data;
        },
        (err: any) => {
          console.log('Role Listing failed');
        });

      this.initEventDetails();
    } else {
      this.router.navigate(["/view-all-events-categories"]);
    }
  }

  performEventAction(data) {
    // Assign,ReOpen,Close

    this.eventsService.performEventaction(data).subscribe(
      (data: any) => {
        if (data['status'] !== 'success') {
          this.errorservice.showerror({ status: data['status'], statusText: data['message'] });
          return;
        }
        this.router.navigate(["/view-all-events-categories"]);
      }
    );
  }

  initEventDetails() {
    // call api to get the event details.
    if (this.task == "view") {
      this.eventsService.getAnEventDetail(this.eventId).subscribe((data: any) => {
        if (data["status"] !== 'success') {
          this.errorservice.showerror({ status: data['status'], statusText: data['message'] });
        }
        if (data["status"]) {
          this.eventArray = [];
          this.typeOfEvent = data.data.event.eCurrWorkFlow;
          this.reasons = data.data.event.reasons;
          if (this.typeOfEvent != 'CLSE') {
            this.getLapsedTime(data.data.event.elapsedTime);
          } else {
            this.lapsedTime = '';
          }
          if (data['data'].event.eventId) {
            this.eventId = data['data'].event.eventId;
          }
          let eventData = {
            event: data.data.event,
            lapsed: this.lapsedTime,
            reasons: this.reasons
          }
          this.eventArray.push(eventData);
          let eventHistoryData = [];
          let histories = data['data'].event.eventHistory;
          histories.forEach(eventHistory => {
            if (eventHistory.updatedBy == null || eventHistory.updatedBy == undefined)
              eventHistory.updatedBy = eventHistory.createdBy;

            if (eventHistory.remarks == null || eventHistory.remarks == undefined)
              eventHistory.remarks = data['data'].event.reasons.en;

            eventHistoryData.push(eventHistory);
          })

          this.eventDataSource = new MatTableDataSource(this.eventArray);
          this.historyDataSource = new MatTableDataSource(eventHistoryData);
          this.plantId = data['data'].event.plantId;
          if (this.disableEventsAnalytics === false) {
            this.dataAnalyticsTables(data);
          }
        }

      });
    } else {
      this.selectedEventIds = this.eventsService.selectedEvents;
      if (this.selectedEventIds) {
        this.eventArray = [];
        this.eventHistoryArray = [];
        this.selectedEventIds.forEach((eventId: any) => {
          this.eventsService.getAnEventDetail(eventId).subscribe((data: any) => {
            if (data.status === 'success') {
              this.typeOfEvent = data.data.event.eCurrWorkFlow;
              if (this.typeOfEvent != 'CLSE') {
                this.getLapsedTime(data.data.event.elapsedTime);
              } else {
                this.lapsedTime = '';
              }
              this.reasons = data.data.event.reasons;
              let eventData = {
                event: data.data.event,
                lapsed: this.lapsedTime,
                reasons: this.reasons
              }
              this.eventArray.push(eventData);
              data.data.event.eventHistory.forEach(eventHistory => {
                if (eventHistory.updatedBy == null || eventHistory.updatedBy == undefined)
                  eventHistory.updatedBy = eventHistory.createdBy;

                if (eventHistory.remarks == null || eventHistory.remarks == undefined)
                  eventHistory.remarks = data['data'].event.reasons.en;

                this.eventHistoryArray.push(eventHistory)
              });

              this.eventDataSource = new MatTableDataSource(this.eventArray);
              this.historyDataSource = new MatTableDataSource(this.eventHistoryArray);
              if (this.disableEventsAnalytics === false) {
                this.dataAnalyticsTables(data);
              }

              this.eventDataSource.filterPredicate = (data: any, filter: string) => !filter || data.event.eventId == filter;
              this.historyDataSource.filterPredicate = (data: any, filter: string) => !filter || data.eventId == filter;
              this.applyFilter(this.eventId);
            } else {
              this.errorservice.showerror({ status: data.status, statusText: data.message });
            }
          });
        });
      }
    }
  }
  dataAnalyticsTables(data) {
    this.displaycostUnit = data.data.event.costUnit;
    this.displayeffluentUnit = data.data.event.effluentUnit;
    this.verifyRcaFlag = ((data.data.event.rcAs && data.data.event.rcAs.length > 0) ||
                          ( data.data.event.systemRecommendations.sysRecommendations && data.data.event.systemRecommendations.sysRecommendations.length > 0) ||
                          (data.data.event.userDefinedRecommendations && data.data.event.userDefinedRecommendations.length > 0))? false : true;
    //RCA details
    this.rcaDataSource = new MatTableDataSource(data.data.event.rcAs);
    // system recommendations
    this.systemrecommendations = [];
    this.systemrecommendations = data.data.event.systemRecommendations.sysRecommendations;
    if(this.systemrecommendations){
      this.eventsrecommendationDATA = this.reduceSystemRecommendationData();
      let selectedrecFlag = this.eventsrecommendationDATA.filter(
        obj => obj.selectedOption === true)[0];

      this.selectedRec = selectedrecFlag && (selectedrecFlag.slno);
      this.spansRec = this.cacheSpan(['no', 'cost', 'effluentValue', 'selectOption'], this.eventsrecommendationDATA, d => d);
    }else{
      this.eventsrecommendationDATA = [];
    }
    // this.recDataSorece = new MatTableDataSource(this.eventsrecommendationDATA);
    this.recDataSorece = this.eventsrecommendationDATA;
    // system recommendations ends here
    // user defined recommendations
    this.userdefinedrecommendations = [];
    this.userdefinedrecommendations = data.data.event.userDefinedRecommendations;
    const length = this.userdefinedrecommendations.length;
    this.recommondationCount = length > 0 ? (this.userdefinedrecommendations[length - 1].seqNo + 1) : 1;
    if(this.userdefinedrecommendations){
      this.eventsuserrecommendationDATA = this.reduceUserdefinedRecommendationData();
      let selectedudfFlag = this.eventsuserrecommendationDATA.filter(
        obj => obj.selectedOption === true)[0];

      this.selectedUserDef = selectedudfFlag && (selectedudfFlag.slno);
      this.spansUserdefined = this.cacheSpanUserDefined(['no', 'cost', 'effluentValue', 'selectOption'], this.eventsuserrecommendationDATA, d => d);
    }else{
      this.eventsuserrecommendationDATA = [];
    }
    // this.usrdefinedDataSorece = new MatTableDataSource(this.eventsuserrecommendationDATA);
    this.usrdefinedDataSorece = this.eventsuserrecommendationDATA;
    // user defined recommendations end
  }
  onChangeRecData(event, item){
    this.selectedRec = item.slno;
    this.selectedRecNumber = event.checked ? item.id : null;
  }
  onChangeUserDefData(event, item){
    this.selectedUserDef = item.slno;
    this.selectedUserDefNumber = event.checked ? item.id : null;
  }
  getRowSpan(col, index, spans) {
    if (spans[index] === undefined) {
      return 0;
    } else {
      return spans[index] && spans[index][col];
    }
  }
  reduceSystemRecommendationData() {
    let slno = 0;
    return this.systemrecommendations.reduce((current, next) => {
      next.tags.forEach(tagobj => {
        current.push({
          slno: slno++,
          no: next.seqNo,
          id: next.id,
          tagName: tagobj.tagName,
          description: tagobj.description,
          cost: next.cost,
          effluentValue: next.effluentValue,
          costUnit: next.costUnit,
          effluentUnit: next.effluentUnit,
          selectedOption: next.isSelected
        })
      });
      return current;
    }, []);
  }
  reduceUserdefinedRecommendationData() {
    let slno = 0;
    return this.userdefinedrecommendations.reduce((current, next) => {
      next.tags.forEach(tagobj => {
        current.push({
          slno: slno++,
          no: next.seqNo,
          id: next.id,
          tagName: tagobj.tagName,
          beforeValue: tagobj.beforeVal,
          afterValue: tagobj.afterVal,
          remarks: tagobj.remarks,
          cost: next.cost,
          effluentValue: next.effluentValue,
          costUnit: next.costUnit,
          effluentUnit: next.effluentUnit,
          selectedOption: next.isSelected
        })
      });
      return current;
    }, []);
  }
  cacheSpan(keys, data, accessor) {
    for (let k = 0; k < keys.length; k++) {
      for (let i = 0; i < data.length;) {
        let currentValue = accessor(data[i])[keys[k]];
        let count = 1;
        let currentNo = accessor(data[i]).no;

        // Iterate through the remaining rows to see how many match
        // the current value as retrieved through the accessor.
        for (let j = i + 1; j < data.length; j++) {
          if (currentValue == accessor(data[j])[keys[k]] && accessor(data[j])["no"] == currentNo) {
            count++;
          }
        }
        if (!this.spansArray[i]) {
          this.spansArray[i] = {};
        }
        // Store the number of similar values that were found (the span)
        // and skip i to the next unique row.
        this.spansArray[i][keys[k]] = count;
        i += count;
      }
    }
    return this.spansArray;
  }
  cacheSpanUserDefined(keys, data, accessor) {
    for (let k = 0; k < keys.length; k++) {
      for (let i = 0; i < data.length;) {
        let currentValue = accessor(data[i])[keys[k]];
        let count = 1;
        let currentNo = accessor(data[i]).no;

        // Iterate through the remaining rows to see how many match
        // the current value as retrieved through the accessor.
        for (let j = i + 1; j < data.length; j++) {
          if (currentValue == accessor(data[j])[keys[k]] && accessor(data[j])["no"] == currentNo) {
            count++;
          }
        }
        if (!this.spansArrayUserdefined[i]) {
          this.spansArrayUserdefined[i] = {};
        }
        // Store the number of similar values that were found (the span)
        // and skip i to the next unique row.
        this.spansArrayUserdefined[i][keys[k]] = count;
        i += count;
      }
    }
    return this.spansArrayUserdefined;
  }
  getAllTagsinPlant(plantobj: any) {
    this.commonService.getalltags(plantobj.id).subscribe(
      data => {
        this.tagsresponse = data;
        this.tags = [];
        if (this.tagsresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.tagsresponse.status, statusText: this.tagsresponse.message });
        } else {
          for (let m = 0; m < this.tagsresponse.data.tags.length; m++) {
            let tagobj: {
              tagName: any
            };
            tagobj = {
              tagName: this.tagsresponse.data.tags[m].tagname
            };
            this.tags.push(tagobj);
            this.tags.forEach(tag => {
              tag.isHide = false;
            });
          }
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no tags pulled from the server!';
      }
    );
  }
  /**
   * calculate lapsed time
   * @param createdDate
   */
  getLapsedTime(createdDate) {
    let now: any = new Date();
    let date_now: any = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
    let eventCreatedDate: any = new Date(createdDate);
    let seconds = Math.floor((date_now - (eventCreatedDate)) / 1000);
    let minutes: any = Math.floor(seconds / 60);
    let hours: any = Math.floor(minutes / 60);
    let days: any = Math.floor(hours / 24);
    hours = hours - (days * 24);
    minutes = minutes - (days * 24 * 60) - (hours * 60);
    seconds = seconds - (days * 24 * 60 * 60) - (hours * 60 * 60) - (minutes * 60);
    if (hours < 10)
      hours = '0' + hours;
    else
      hours = hours;

    if (minutes < 10)
      minutes = '0' + minutes;
    else
      minutes = minutes;

    if (days < 10 && days > 0)
      days = '0' + days;
    else
      days = days;

    this.lapsedTime = days + ':' + hours + ':' + minutes;
  }
  /**
   * Event Search
   * @param filterValue
   */
  applyFilter(filterValue: string) {
    this.eventDataSource.filter = filterValue;
    this.historyDataSource.filter = filterValue;
  }
  // assign events
  assignEvents() {
    this.submit = true;
    this.invalidSubmit = false;
    if (this.selectedRole == 0) {
      this.noRoleSelected = true;
    }
    if (!this.assignMessage || this.selectedRole == 0) {
      this.invalidSubmit = true;
    }
    if (!this.invalidSubmit) {
      let dataToAssign = [];
      this.eventArray.forEach(eventdata => {
        let eachEventData = {
          "eventAction": this.task,
          "eventId": eventdata.event.eventId,
          "plantId": eventdata.event.plantId,
          "eventCreatedDt": eventdata.event.eventCreatedDt,
          "eCurrWorkFlowId": eventdata.event.eCurrWorkFlowId,
          "createdAt": eventdata.event.createdAt,
          "createdBy": eventdata.event.createdBy,
          "updatedAt": eventdata.event.updatedAt,
          "updatedBy": eventdata.event.updatedBy,
          "tenantId": 1,
          "eventCategoryId": eventdata.event.eventCategoryId,
          "eventTypeId": eventdata.event.eventTypeId,
          "eventMessageId": eventdata.event.eventMessageId,
          "assignedToRoleId": this.selectedRole,
          "assignMessage": this.assignMessage,
          "closeMessage": null,
          "reOpenMessage": null
        }

        dataToAssign.push(eachEventData);
      });
      this.performEventAction(dataToAssign);
    }
  }

  closeEvents() {
    this.submit = true;
    this.invalidSubmit = false;
    if (!this.closeMessage) {
      this.invalidSubmit = true;
    }
    if (!this.invalidSubmit) {
      let dataToAssign = [];
      this.eventArray.forEach(eventdata => {
        let eachEventData = {
          "eventAction": this.task,
          "eventId": eventdata.event.eventId,
          "plantId": eventdata.event.plantId,
          "eventCreatedDt": eventdata.event.eventCreatedDt,
          "eCurrWorkFlowId": eventdata.event.eCurrWorkFlowId,
          "createdAt": eventdata.event.createdAt,
          "createdBy": eventdata.event.createdBy,
          "updatedAt": eventdata.event.updatedAt,
          "updatedBy": eventdata.event.updatedBy,
          "tenantId": 1,
          "eventCategoryId": eventdata.event.eventCategoryId,
          "eventTypeId": eventdata.event.eventTypeId,
          "eventMessageId": eventdata.event.eventMessageId,
          "assignedToRoleId": this.selectedRole,
          "assignMessage": null,
          "closeMessage": this.closeMessage,
          "reOpenMessage": null
        }
        if(this.dataAnalyticFlag){
          eachEventData['systemRecommendationId'] = this.selectedRecNumber;
          eachEventData['userDefinedRecommendationId'] = this.selectedUserDefNumber;
        }
        console.log('eachEventData', eachEventData)
        dataToAssign.push(eachEventData);
      });
      this.performEventAction(dataToAssign);
    }
  }

  getAssignedRole(roleobj: any) {
    // issue fix for reopen events reported by JEAN and fixed by DINESH
    this.selectedRole = roleobj.roleId;
  }

  getSelectedEventDetails(id: any) {
    this.eventId = id;
  }

  reOpenEvents() {
    this.submit = true;
    this.invalidSubmit = false;
    if (this.selectedRole == 0) {
      this.noRoleSelected = true;
    }
    if (!this.reopenMessage || !this.assignMessage || this.selectedRole == 0) {
      this.invalidSubmit = true;
    }
    if (!this.invalidSubmit) {
      let dataToAssign = [];
      this.eventArray.forEach(eventdata => {
        let eachEventData = {
          "eventAction": this.task,
          "eventId": eventdata.event.eventId,
          "plantId": eventdata.event.plantId,
          "eventCreatedDt": eventdata.event.eventCreatedDt,
          "eCurrWorkFlowId": eventdata.event.eCurrWorkFlowId,
          "createdAt": eventdata.event.createdAt,
          "createdBy": eventdata.event.createdBy,
          "updatedAt": eventdata.event.updatedAt,
          "updatedBy": eventdata.event.updatedBy,
          "tenantId": 1,
          "eventCategoryId": eventdata.event.eventCategoryId,
          "eventTypeId": eventdata.event.eventTypeId,
          "eventMessageId": eventdata.event.eventMessageId,
          "assignedToRoleId": this.selectedRole,
          "assignMessage": this.assignMessage,
          "closeMessage": null,
          "reOpenMessage": this.reopenMessage
        }

        dataToAssign.push(eachEventData);
      });
      this.performEventAction(dataToAssign);
    }
  }
  
  adduserrecommenddialog(): void {
    this.tags.forEach(tag => {
      tag.isHide = false;
    });
    let costValue = this.displaycostUnit ? this.displaycostUnit : '';
    let codValue = this.displayeffluentUnit ? this.displayeffluentUnit : '';
    const dialogRef = this.dialog.open(UserDefineDialogComponent, {
      width: '800px',
      disableClose: true,
      data: {
        tags: this.tags,
        event: this.eventId,
        count: this.recommondationCount,
        costUnitValue: costValue,
        codUnitValue: codValue
      }
    });
    const sub = dialogRef.componentInstance.saveUserDefined.subscribe(
      res => {
        this.userdefinedrecommendations = res;
        const length = this.userdefinedrecommendations.length;
        this.recommondationCount = length > 0 ? (this.userdefinedrecommendations[length - 1].seqNo + 1) : 1;
        this.eventsuserrecommendationDATA = this.reduceUserdefinedRecommendationData();
        this.spansUserdefined = this.cacheSpanUserDefined(['no', 'cost', 'effluentValue', 'selectOption'], this.eventsuserrecommendationDATA, d => d);
        this.usrdefinedDataSorece = this.eventsuserrecommendationDATA;
      }
    );
  }
  edituserrecommenddialog(element): void {
    let tempArray = JSON.parse(JSON.stringify(this.userdefinedrecommendations));
    let selectedObj = tempArray.filter(
      obj => obj.id === element.id)[0];
    const dialogRef = this.dialog.open(EditUserDefineDialogComponent, {
      width: '800px',
      disableClose: true,
      data: {
        editObject: selectedObj,
        tags: this.tags,
        eventId: this.eventId,
        completedata: tempArray
      }
    });
    const sub = dialogRef.componentInstance.updateUserDefined.subscribe(
      res => {
        this.userdefinedrecommendations = res;
        const length = this.userdefinedrecommendations.length;
        this.recommondationCount = length > 0 ? (this.userdefinedrecommendations[length - 1].seqNo + 1) : 1;
        this.eventsuserrecommendationDATA = this.reduceUserdefinedRecommendationData();
        this.spansUserdefined = this.cacheSpanUserDefined(['no', 'cost', 'effluentValue', 'selectOption'], this.eventsuserrecommendationDATA, d => d);
        this.usrdefinedDataSorece = this.eventsuserrecommendationDATA;
      }
    );
  }
}
@Component({
  // providers:[ViewAnEventComponent],
  selector: 'app-edituserdefine-dialog-component',
  templateUrl: './edit-user-define.dialog.html',
  styleUrls: ['./view-an-event.component.css',
    '../../../../assets/css/events.css']
})
export class EditUserDefineDialogComponent {
  editUserObject: any;
  errorMessage: any;
  formData: any;
  eventId: any;
  tags: any;
  tagDetailsArray:FormArray;
  editUserDefinedRecommondationForm = this.formBuilder.group({
    cost: ['', Validators.required ],
    effluentValue: '',
    tagDetailsArray: this.formBuilder.array([]) 
 }); //declarations
  @Output() updateUserDefined = new EventEmitter<any>(true);
  constructor(
    public dialogRefUserDefined: MatDialogRef<EditUserDefineDialogComponent>,
    public dialog: MatDialog,
    private formBuilder: FormBuilder,
    private errorservice: ErrorserviceService,
    private eventsService: EventsService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.editUserObject = data.editObject;
    this.tags = data.tags;
    this.eventId = data.eventId;
    const tagsArray = [];
    if (this.tags && data.completedata) {
      data.completedata.forEach(tag => {
        tag.tags.forEach(tag => {
          tagsArray.push(tag.tagName);
        });
      });
      this.tags.forEach(tag => {
        if (tagsArray.indexOf(tag.tagName) > -1) {
          tag.isHide = true;
        } else {
          tag.isHide = false;
        }
      });
    }
    
    this.tagDetailsArray = this.formBuilder.array([]);//declaration

    this.editUserObject.tags.forEach((tag: any) => {
      this.tagDetailsArray.push(this.initTagObject(tag));
    });
   this.editUserDefinedRecommondationForm = this.formBuilder.group({
      cost: [this.editUserObject.cost, Validators.required ],
      effluentValue: [this.editUserObject.effluentValue, Validators.compose([Validators.required, Validators.pattern(/^\d{1,3}([\.,](\d{1,2})?)?$/)])],
      tagDetailsArray: this.tagDetailsArray
   },{
      validator: this.edituserDefinedformValidator
   });
  }
  
  ngOnInit(){

  }
  private initTagObject = (obj: any): FormGroup => {
    return this.formBuilder.group({
      recommendationDetailId: [obj.recommendationDetailId],
      tagName: [obj.tagName, Validators.required],
      beforeVal: [obj.beforeVal, Validators.compose([Validators.required, Validators.pattern(/^\d{1,3}([\.,](\d{1,2})?)?$/)])],
      afterVal:[obj.afterVal, Validators.compose([Validators.required, Validators.pattern(/^\d{1,3}([\.,](\d{1,2})?)?$/)])],
      remarks:[obj.remarks, Validators.required]
      // 'email': [obj.email], //, any validation],
    });
  }

  edituserDefinedformValidator(form: FormGroup) {
    const regex=/^\d{1,5}([\.,](\d{1,2})?)?$/;
    const fieldvalue = form.get('cost').value;
      if(fieldvalue.toLowerCase() === "na" || fieldvalue.toLowerCase() === "n/a"){
        return null;
      }else{
        return (!regex.test(fieldvalue) && fieldvalue) ? { editcostfloatValidationFlag: true} : null;
      }
 }
  cancelDialog(): void {
    this.dialogRefUserDefined.close();
  }
  createmsgtemplate(): void {
    const formValue = this.editUserDefinedRecommondationForm.value;
    if (this.editUserDefinedRecommondationForm.valid) {
      this.formData = {
        action: 'update',
        id: this.editUserObject.id,
        cost: formValue.cost,
        effluent: formValue.effluentValue,
        costUnit: this.editUserObject.costUnit,
        tagDetails: formValue.tagDetailsArray
      };
      this.eventsService.saveUserDefinedRecommondation(this.eventId, this.formData).subscribe((data: any) => {
        if (data.status !== 'success') {
          this.errorservice.showerror({ status: this.data.status, statusText: this.data.message });
        } else {
          this.dialogRefUserDefined.close();
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            disableClose: true,
            data: { title: 'data.L00224', message: 'Record updated successfully' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
          });
          this.updateUserDefined.emit(data.data1);
        }
      },
        (err: any) => {
          console.log(err);
          this.errorMessage = 'There are no uoms pulled from the server!';
        });
    }
  }
}
// User Defined  Dialog component
@Component({
  selector: 'app-adduserdefine-dialog-component',
  templateUrl: './add-user-define.dialog.html',
  styleUrls: ['./view-an-event.component.css',
    '../../../../assets/css/events.css']
})

export class AddUserDefineDialogComponent {
  tags: any;
  eventId: any;
  firstObj: any;
  recommondationCount: number;
  tagCount: number;
  addRecord: {};
  addedtags = [];
  disabledfield: boolean = false;
  errorMatcher = new CrossFieldErrorMatcher();
  @Output() addUserRecommondation = new EventEmitter<any>(true);
  adduserdefinedrecommendations: any;
  constructor(
    private formBuilder: FormBuilder,
    public addRecorddialogRef: MatDialogRef<AddUserDefineDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.tags = data.tags;
    this.eventId = data.eventId;
    this.recommondationCount = data.recommondationCount;
    this.tagCount = data.tagCount;
    this.firstObj = data.firstObj[0];
    this.addedtags = data.firstObj;
    if(this.firstObj){
      this.disabledfield = true;
      this.addUserDefinedRecommondationForm.controls.cost.disable();
      this.addUserDefinedRecommondationForm.controls.effluentValue.disable();
      // this.addUserDefinedRecommondationForm.controls.costUnit.disable();
      this.addUserDefinedRecommondationForm.setValue({
        tag: '',
        beforeValue: '',
        afterValue: '',
        remarks:'',
        cost: this.firstObj.cost,
        effluentValue: this.firstObj.effluentValue,
        costUnit: this.firstObj.costUnit,
        effluentUnit: this.firstObj.effluentUnit
      });
    }else{
      this.addUserDefinedRecommondationForm.setValue({
        tag: '',
        beforeValue: '',
        afterValue: '',
        remarks:'',
        cost: '',
        effluentValue: '',
        costUnit: data.costUnit,
        effluentUnit: data.effluentUnit
      });
    }

  }
  addUserDefinedRecommondationForm = this.formBuilder.group({
    tag: [{ value: '' }, Validators.required],
    beforeValue: ['', Validators.compose([Validators.required, Validators.pattern(/^\d{1,3}([\.,](\d{1,2})?)?$/)])],
    afterValue: ['', Validators.compose([Validators.required, Validators.pattern(/^\d{1,3}([\.,](\d{1,2})?)?$/)])],
    remarks: ['', Validators.required],
    cost: ['', Validators.required],
    costUnit: ['', Validators.required],
    effluentUnit: ['', Validators.required],
    effluentValue: ['', Validators.compose([Validators.required, Validators.pattern(/^\d{1,3}([\.,](\d{1,2})?)?$/)])]
  },
  {
    validator: this.userDefinedformValidator
  });
  userDefinedformValidator(form: FormGroup) {
    const regex=/^\d{1,5}([\.,](\d{1,2})?)?$/;
    const fieldvalue = form.get('cost').value;
      if(fieldvalue.toLowerCase() === "na" || fieldvalue.toLowerCase() === "n/a"){
        return null;
      }else{
        return (!regex.test(fieldvalue) && fieldvalue) ? { costfloatValidationFlag: true} : null;
      }
 }
  closeAddRecorddialog(): void {
    this.addRecorddialogRef.close();
  }
  AddRecorddialog(): void {
    if (this.addUserDefinedRecommondationForm.valid) {
      const formValue = this.addUserDefinedRecommondationForm.value;
      this.addRecord = {
        slno: this.tagCount,
        no: this.recommondationCount,
        tagName: formValue.tag,
        beforeValue: formValue.beforeValue,
        afterValue: formValue.afterValue,
        remarks: formValue.remarks,
        cost: formValue.cost,
        effluentValue: formValue.effluentValue,
        costUnit: formValue.costUnit,
        effluentUnit: formValue.effluentUnit,
        selectedOption: false
      }
      // this.adduserdefinedrecommendations.push(this.addRecord);
      this.addUserRecommondation.emit(this.addRecord);
      this.addRecorddialogRef.close();
    }
  }
}
@Component({
  // providers:[ViewAnEventComponent],
  selector: 'app-userdefine-dialog-component',
  templateUrl: './user-define.dialog.html',
  styleUrls: ['./view-an-event.component.css',
    '../../../../assets/css/events.css']
})

export class UserDefineDialogComponent {
  tags: any;
  eventId: any;
  recommondationCount: number;
  costUnitVal: string;
  codUnitVal: string;
  tagCount: number;
  dataSourceuserdef : any;
  adduserdefinedrecommendations = [];
  spansAddUserdefined = [];
  errorMessage: any;
  formData: any;
  spansArrayDialog = [];
  displayedColumnsuserdef: string[] = ['no', 'tagname', 'beforeValue', 'afterValue', 'remarks', 'cost', 'effluentValue'];
  errorservice: any;
  saveFlag: boolean = true;
  @Output() saveUserDefined = new EventEmitter<any>(true);
  constructor(
    public dialogRefUserDefined: MatDialogRef<UserDefineDialogComponent>,
    // private viewComponent: ViewAnEventComponent,
    public dialog: MatDialog,
    private eventsService: EventsService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.tags = data.tags;
    this.eventId = data.event;
    this.recommondationCount = data.count;
    this.costUnitVal = data.costUnitValue;
    this.codUnitVal = data.codUnitValue
  }
  closeDialog(): void {
    this.dialogRefUserDefined.close();
  }
  addRecommondation(): void {
    const length = this.adduserdefinedrecommendations.length;
    this.tagCount = length > 0 ? (this.adduserdefinedrecommendations[length-1].slno + 1) : 1;
    const dialogRef = this.dialog.open(AddUserDefineDialogComponent, {
      width: '800px',
      disableClose: true,
      data: {
        tags: this.tags,
        eventId: this.eventId,
        recommondationCount: this.recommondationCount,
        tagCount: this.tagCount,
        costUnit: this.costUnitVal,
        effluentUnit: this.codUnitVal,
        firstObj: this.adduserdefinedrecommendations
      }

    });
    const sub = dialogRef.componentInstance.addUserRecommondation.subscribe(
      res => {
        console.log(res)
        this.adduserdefinedrecommendations.push(res);
        const conditionlist = [];
        if (this.tags && this.adduserdefinedrecommendations) {
          this.adduserdefinedrecommendations.forEach(tag => {
            conditionlist.push(tag.tagName);
          });
          this.tags.forEach(tag => {
            if (conditionlist.indexOf(tag.tagName) > -1) {
              tag.isHide = true;
            } else {
              tag.isHide = false;
            }
          });
        }
        this.spansAddUserdefined = this.cacheSpanDialog(['no', 'cost', 'effluentValue'], this.adduserdefinedrecommendations, d => d) ;
        this.dataSourceuserdef = new MatTableDataSource(this.adduserdefinedrecommendations);
        this.saveFlag = this.adduserdefinedrecommendations.length > 0 ? false : true;
      }
    );
  }
  saveRecommondation(): void {
    const tagsArray = [];
    this.adduserdefinedrecommendations.forEach(recommondation => {
      const singleObj = {
        tagName: recommondation.tagName,
        beforeVal: recommondation.beforeValue,
        afterVal: recommondation.afterValue,
        remarks: recommondation.remarks,
      };
      tagsArray.push(singleObj);
    });
    this.formData = {
      action: 'create',
      cost: this.adduserdefinedrecommendations[0].cost,
      effluent: this.adduserdefinedrecommendations[0].effluentValue,
      costUnit: this.adduserdefinedrecommendations[0].costUnit,
      tagDetails: tagsArray
    };
    this.eventsService.saveUserDefinedRecommondation(this.eventId, this.formData).subscribe((data: any) => {
      if (data.status !== 'success') {
        this.errorservice.showerror({ status: this.data.status, statusText: this.data.message });
      } else {
        this.dialogRefUserDefined.close();
        const dialogRef = this.dialog.open(DialogComponent, {
          width: '400px',
          disableClose: true,
          data: {title: 'data.L00224', message: 'Record saved successfully' }
        });
        const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
          dialogRef.componentInstance.closeDialog();
        });
        this.saveUserDefined.emit(data.data1);
        // const userdefineddata = data.data1;
        // const length = userdefineddata.length;
        // this.viewComponent.recommondationCount = length > 0 ? (userdefineddata[length - 1].seqNo + 1) : 1;
        // this.viewComponent.eventsuserrecommendationDATA = this.viewComponent.reduceUserdefinedRecommendationData();
        // this.viewComponent.spansUserdefined = this.cacheSpan(['no', 'cost', 'effluentValue', 'selectOption'], this.viewComponent.eventsuserrecommendationDATA, d => d);
        // this.viewComponent.usrdefinedDataSorece = new MatTableDataSource(this.viewComponent.eventsuserrecommendationDATA);
      }
    },
    (err: any) => {
      console.log(err);
      this.errorMessage = 'There are no uoms pulled from the server!';
    });
  }
  getRowSpanData(col, ind, spans) {
    let index = ind-1;
    if (spans[index] === undefined) {
      return 0;
    } else {
      return spans[index] && spans[index][col];
    }
  }
  cacheSpanDialog(keys, data, accessor) {
    for (let k = 0; k < keys.length; k++) {
      for (let i = 0; i < data.length;) {
        let currentValue = accessor(data[i])[keys[k]];
        let count = 1;
        let currentNo = accessor(data[i]).no;

        // Iterate through the remaining rows to see how many match
        // the current value as retrieved through the accessor.
        for (let j = i + 1; j < data.length; j++) {
          if (currentValue == accessor(data[j])[keys[k]] && accessor(data[j])["no"] == currentNo) {
            count++;
          }
        }
        if (!this.spansArrayDialog[i]) {
          this.spansArrayDialog[i] = {};
        }
        // Store the number of similar values that were found (the span)
        // and skip i to the next unique row.
        this.spansArrayDialog[i][keys[k]] = count;
        i += count;
      }
    }
    return this.spansArrayDialog;
  }
  // addeventsuserrecommendationDATA = this.reduceUserdefinedRecommendationData();


}
