import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAnEventComponent } from './view-an-event.component';

describe('ViewAnEventComponent', () => {
  let component: ViewAnEventComponent;
  let fixture: ComponentFixture<ViewAnEventComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAnEventComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAnEventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
