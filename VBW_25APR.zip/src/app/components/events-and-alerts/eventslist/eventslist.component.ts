import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog, PageEvent} from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { EventsService } from '../../../services/events.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from '../../commercial/customer-contract/date.adapter';
import { DatePipe } from '@angular/common';
import { environment } from '../../../../environments/environment';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'app-eventslist',
  templateUrl: './eventslist.component.html',
  styleUrls: ['./eventslist.component.css', '../../../../assets/css/events.css'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
  ]
})
export class EventslistComponent implements OnInit {
  displayedColumns: string[] = [
    'select', 'createdAt', 'eventId',
    'plantName', 'eventType', 'reason',
    'assignedTo', 'lapsedTime', 'action'];
  dataSource: any;
  eventsResponse: any;
  reqObj: any;
  newSearch = true;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  pageSize = 10;
  pageSizeOptions: number[] = [5, 10, 25, 100];
  pageEvent: PageEvent;

  plantsResponse: any;
  plants: any;
  selectedPlant = 0;

  eventscategories: any;
  selectedEventCategory = 0;

  fromDate: any;
  toDate: any;
  fromDateInput: any = '';
  toDateInput: any = '';

  allowManualEvtCreate = false;
  selectedEvents: any;

  userInfo: any;
  action: any;
  selectedlang = 'en';

  restrict_assign_close_evt_access = true;
  restrict_reopen_reassign_evt_access = true;
  create_event_access = environment.role.alertevents.create_event_access;
  assign_close_event_access = environment.role.alertevents.assign_close_events_access;
  reopen_reasssign_event_access = environment.role.alertevents.reopen_reassign_events_access;

  constructor(private eventService: EventsService,
    public translate: TranslateService,
    public errorservice: ErrorserviceService,
    private router: Router, private datePipe: DatePipe,
    public dialog: MatDialog,
    public commonservice: CommonService,
    private route: ActivatedRoute) {
      this.reqObj = this.prepareobj();
      this.getevents();
      this.selectedEvents = [];
      this.action = 'view';
      this.restrict_assign_close_evt_access = this.commonservice.isAccess(this.assign_close_event_access);
      this.restrict_reopen_reassign_evt_access = this.commonservice.isAccess(this.reopen_reasssign_event_access);
      this.userInfo = this.commonservice.getUser();
      console.log(this.userInfo);

      if (this.translate.currentLang) {
        const currentLang = parseInt(this.translate.currentLang, 10);
          if (currentLang === 1) {
            this.selectedlang = 'en';
          } else {
            this.selectedlang = 'cn';
          }
        }
        this.translate.onLangChange.subscribe((language) => {
           if (parseInt(language.lang, 10) === 1) {
             this.selectedlang = 'en';
           } else {
              this.selectedlang = 'cn';
           }
        });
    }

    ngOnInit() {
      this.getplants();
      this.geteventscategories();
    }

    getevents() {
      this.eventService.getmyevents(this.reqObj).subscribe((data: any) => {
        if (data.status !== 'success') {
          this.errorservice.showerror({
            status: data.errorCode,
            statusText: data.message
          });
        } else {
          if (data.data.events) {
            // tslint:disable-next-line:prefer-const
            let now: any = new Date();
            // tslint:disable-next-line:prefer-const
            let date_now: any = new Date(now.getUTCFullYear(),
            now.getUTCMonth(), now.getUTCDate(),  now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
            let lapsedTime: any;
            data.data.events.forEach(event => {
              event.enableselection = false;
              const assignto_list = event.assignedTo.split(',');
              if (this.userInfo.prn === 'Admin' && assignto_list.length === 0) {
                event.enableselection = true;
              } else {
                if (assignto_list.indexOf(this.userInfo.sub) > -1) {
                  event.enableselection = true;
                 } else {
                  event.enableselection = false;
                 }
              }

              // tslint:disable-next-line:prefer-const
              let eventCreatedDate: any = new Date(event.elapsedTime);
              let seconds = Math.floor((date_now - (eventCreatedDate)) / 1000);
              let minutes: any = Math.floor(seconds / 60);
              let hours: any = Math.floor(minutes / 60);
              // tslint:disable-next-line:prefer-const
              let days: any = Math.floor(hours / 24);
              hours = hours - (days * 24);
              minutes = minutes - (days * 24 * 60) - (hours * 60);
              seconds = seconds - (days * 24 * 60 * 60) - (hours * 60 * 60) - (minutes * 60);
              if (hours < 10) {
                hours = '0' + hours;
              } else {
                hours = hours;
              }
              if (minutes < 10) {
                minutes = '0' + minutes;
              } else {
                minutes = minutes;
              }
              if (days < 10 && days > 0)  {
                days = '0' + days;
              } else {
                days = days;
              }
              if (event.eCurrWorkFlow !== 'CLSE') {
                lapsedTime = days + ':' + hours + ':' + minutes;
              } else {
                lapsedTime = '';
              }
              event.lapsedTime = lapsedTime;
            });
          }
          this.dataSource = data.data.events;
          this.eventsResponse = data.data;
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          if (this.newSearch === true) {
            this.dataSource.paginator.firstPage();
          }
          this.newSearch = false;
          console.log(this.eventsResponse);
          this.defineviewaccess();
        }
      });
    }

    defineviewaccess() {
      const userRole = parseInt(this.userInfo.RoleId, 10);
      if (this.eventscategories && this.dataSource) {
        this.dataSource.forEach(event => {
          event.isView = false;
          const eventCategoryDetail = this.eventscategories.filter(eventcat => {
            return eventcat.eventCategoryId === event.eventCategoryId;
          });
          if (eventCategoryDetail) {
            eventCategoryDetail[0].viewByRoles.forEach(element => {
              element = parseInt(element, 10);
            });
            eventCategoryDetail[0].actionByRoles.forEach(element => {
              element = parseInt(element, 10);
            });
            const historyRoles = [];
            if (event.historyRoleId !== null) {
              event.historyRoleId.split(',').forEach(element => {
                historyRoles.push(parseInt(element, 10));
              });
            }
            if (eventCategoryDetail[0].viewByRoles.indexOf(userRole) > -1 ||
            eventCategoryDetail[0].actionByRoles.indexOf(userRole) > -1 ||
            historyRoles.indexOf(userRole) > -1) {
              event.isView = true;
            }
          }
        });
        console.log(this.dataSource);
      }
    }

    eventsbypages(paging: any) {
      this.pageEvent = paging;
      this.reqObj.currentPage = this.pageEvent.pageIndex + 1;
      this.reqObj.pageSize = this.pageEvent.pageSize;
      this.getevents();
    }

    filterevents(filtertype: any, filterValue: any) {
      if (filtertype === 'plants') {
          filterValue = parseInt(filterValue, 10);
          this.reqObj.plantId = (filterValue === 0) ? null : filterValue;
      } else if (filtertype === 'ecategory') {
          filterValue = parseInt(filterValue, 10);
          if (filterValue !== 0) {
            const selectedEvtCategory = this.eventscategories.filter( evtcategory => {
              return evtcategory.eventCategoryId === filterValue;
            });
            if (selectedEvtCategory) {
              if (selectedEvtCategory[0].allowManualEventCreation === true ) {
                this.allowManualEvtCreate = true;
              } else {
                this.allowManualEvtCreate = false;
              }
              sessionStorage.setItem('eventCategoryName', selectedEvtCategory[0].eventCategoryName);
              sessionStorage.setItem('eventCategoryId', selectedEvtCategory[0].eventCategoryId);
            }
          }
          this.reqObj.categoryId = (filterValue === 0) ? null : filterValue;
      } else if (filtertype === 'fdatefilter') {
          this.reqObj.from = (filterValue) ? filterValue : '';
      } else if (filtertype === 'tdatefilter') {
          this.reqObj.to = (filterValue) ? filterValue : '';
      }
      this.newSearch = true;
      this.getevents();
    }

    searchevents(searchText: any) {
      if (searchText) {
        if (searchText.length % 3 === 0) {
          this.reqObj.serchString = searchText;
          this.newSearch = true;
          this.getevents();
        }
      } else {
        this.reqObj.serchString = '';
        this.newSearch = true;
        this.getevents();
      }
    }

    clearDateRange() {
      this.reqObj.from = '';
      this.reqObj.to = '';
      this.fromDateInput = '';
      this.toDateInput = '';
      this.newSearch = true;
      this.getevents();
    }

    loadopenevents(isOpened: any) {
      this.selectedEvents = [];
      this.reqObj.isOpen = isOpened;
      this.newSearch = true;
      this.getevents();
    }

    navcreateevent() {
      this.router.navigate(['/create-new-event']);
    }

    selectevent(eventRow: any) {
      if (this.selectedEvents.indexOf(eventRow.eventId) > -1) {
          const eventIndex = this.selectedEvents.indexOf(eventRow.eventId);
          this.selectedEvents.splice(eventIndex,1);
      } else {
        this.selectedEvents.push(eventRow.eventId);
      }
      console.log(this.selectedEvents);
    }

    closereopenevents() {
      this.eventService.selectedEvents = this.selectedEvents;
      const eventId = this.selectedEvents[0];
      let action = 'Close';
      if (this.reqObj.isOpen === true) {
        action = 'Close';
      } else {
        action = 'ReOpen';
      }
      this.router.navigate(['/view-event/' + eventId + '/' + action]);
    }
    assignevents() {
      this.eventService.selectedEvents = this.selectedEvents;
      const eventId = this.selectedEvents[0];
      const action = 'Assign';
      this.router.navigate(['/view-event/' + eventId + '/' + action]);
    }

    getplants() {
      this.commonservice.getplants().subscribe(
        data => {
          this.plantsResponse = data;
          this.plants = [];
          if (this.plantsResponse.status !== 'success') {
            this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
          } else {
            for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
              for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
                for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                  const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                  plantobj.countryId = this.plantsResponse.data.countries[i].id;
                  plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                  this.plants.push(plantobj);
                }
              }
            }
          }
        },
        (err: any) => {
          console.log(err);
        }
      );
    }

    geteventscategories() {
      this.eventService.getEventCategory().subscribe(
        (data: any) => {
          if (data.status !== 'success') {
            this.errorservice.showerror({
                status: data.errorCode,
                statusText: data.message
              });
          } else {
            this.eventscategories = data.data.eventCategories;
            this.defineviewaccess();
          }
        },
        (err: any) => {
          console.log('Event Categories Fetching Failed!!!');
        });
    }

    prepareobj() {
      return {
        'plantId': null,
        'serchString': '',
        'from': '',
        'to': '',
        'categoryId': null,
        'isOpen': true,
        'currentPage': 1,
        'pageSize': 10,
        'enablePaging': true
      };
    }
}
