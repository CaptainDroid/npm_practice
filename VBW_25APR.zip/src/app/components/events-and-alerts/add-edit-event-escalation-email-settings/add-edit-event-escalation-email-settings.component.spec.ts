import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditEventEscalationEmailSettingsComponent } from './add-edit-event-escalation-email-settings.component';

describe('AddEditEventEscalationEmailSettingsComponent', () => {
  let component: AddEditEventEscalationEmailSettingsComponent;
  let fixture: ComponentFixture<AddEditEventEscalationEmailSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditEventEscalationEmailSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditEventEscalationEmailSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
