import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { EventsService } from 'src/app/services/events.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CancelConfirmationDialogComponent } from '../confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
export interface IEmailEscalationSettings {
  action: string;
  eventEmailSettingId: number;
  eventCategoryId: number;
  noOfDays: number;
  createdBy: any;
  createdAt: any;
  updatedBy: any;
  updatedAt: any;
  tenantId: number;
  eventEmailMessage: string;
  eventEmailgroup: any;
}
@Component({
  selector: 'app-add-edit-event-escalation-email-settings',
  templateUrl: './add-edit-event-escalation-email-settings.component.html',
  styleUrls: ['./add-edit-event-escalation-email-settings.component.css', '../../../../assets/css/events.css']
})
export class AddEditEventEscalationEmailSettingsComponent implements OnInit {
  isFormSubmitted = false;
  addNewEventEscalationEmailSetting: FormGroup;
  eventType = new FormControl();
  eventTypeList: string[] = [];
  users: any;
  eventEmailSettingId = 0;
  isEditEventEmailSettings = false;
  eventTypeArray = [];
  eventCategory: any;
  eventemailsettings: any[];
  emailGroups: any[];
  formData: IEmailEscalationSettings;
  eventEscalationAction: string;
  eventEmailgroupObjArray = [];
  isSubmitted = false;
  userId: number;
  constructor(
    private formBuilder: FormBuilder,
    private eventService: EventsService,
    private router: Router,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private errorservice: ErrorserviceService, ) {
    this.userId = parseInt(JSON.parse(localStorage.getItem('user')).amr, 10);
    /**
   * Get Category id from params
   */
    this.route.params.subscribe(params => {
      this.eventEmailSettingId = params.eventEmailSettingId;
      if (this.eventEmailSettingId) {
        this.isEditEventEmailSettings = true;
      }
    });
  }

  /**
     * Form Submit
     */
  onSubmit() {
    this.isSubmitted = true;
    this.eventEmailgroupObjArray = [];
    if (this.addNewEventEscalationEmailSetting.valid) {
      const formValue = this.addNewEventEscalationEmailSetting.value;
      this.eventEscalationAction = 'Create';
      if (this.isEditEventEmailSettings) {
        this.eventEscalationAction = 'Update';
      }
      this.eventService.eventData = formValue;

      for (let i = 0; i < formValue.emailGroup.length; i++) {
        const eventEmailgroupObj = {
          eventEmailGroupId: 0,
          emailgroupId: formValue.emailGroup[i],
          createdBy: this.userId,
          createdAt: '',
          updatedBy: this.userId,
          updatedAt: '',
          tenantId: 1
        };
        this.eventEmailgroupObjArray.push(eventEmailgroupObj);
      }

      this.formData = {
        action: this.eventEscalationAction,
        eventEmailSettingId: this.eventEmailSettingId,
        eventCategoryId: formValue.eventCategory,
        noOfDays: formValue.noOfDays,
        createdBy: this.userId,
        createdAt: '',
        updatedBy: this.userId,
        updatedAt: '',
        tenantId: 1,
        eventEmailMessage: formValue.eventEmailMessage,
        eventEmailgroup: this.eventEmailgroupObjArray
      };
      /**
       * Add/Edit Form Data - POST
       */
      this.eventService.addEventEscalationEmailSettings(this.formData).subscribe(
        (data: any) => {
          if (data.status === 'success') {
            if (this.isEditEventEmailSettings) {
              this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00795' });
            } else {
              this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00488' });
            }

            this.router.navigate(['/event-escalation-email-alert-settings-list']);
          } else {
            this.errorservice.showerror({ status: data.status, statusText: data.message });
          }
        },
        (err: any) => {
          console.log('Failed');
        }
      );
    }
  }

  /**
   * Cancel Confirmation Dialog
   */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'event-escalation-email-alert-settings-list' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  ngOnInit() {
    /**
     * Form Data
     */
    this.addNewEventEscalationEmailSetting = this.formBuilder.group({
      eventCategory: ['', Validators.required],
      emailGroup: ['', Validators.required],
      noOfDays: ['', Validators.compose([Validators.required, Validators.max(999), Validators.min(1),  Validators.pattern('^[0-9]*$')])],
      eventEmailMessage: ['', Validators.maxLength(200)]
    });

    /**
     * Get Event Categories
     */
    this.eventService.getEventCategory().subscribe(
      (data: any) => {
        this.eventCategory = data.data.eventCategories;
      },
      (err: any) => {
        console.log('Event Ecsalation Email Settings List Failed');
      });


    /**
 * Get Email Groups
 */
    this.eventService.getEmailGroups().subscribe(
      (data: any) => {
        this.emailGroups = data.data.emailgroups;
      },
      (err: any) => {
        console.log('Email Group Listing Failed');
      });

    /**
   * Check whether the page is Edit Event Escalation
   */
    if (this.isEditEventEmailSettings) {
      this.eventService.getEventEscalations(this.eventEmailSettingId).subscribe(
        (data: any) => {
          const result = data.data.eventescalationemailsetting;
          const eventEmailGroupArray = [];
          result.eventEmailgroup.forEach(emailGroup => eventEmailGroupArray.push(emailGroup.emailgroupId));
          eventEmailGroupArray.push();
          this.addNewEventEscalationEmailSetting.setValue({
            eventCategory: result.eventCategoryId,
            emailGroup: eventEmailGroupArray,
            noOfDays: result.noOfDays,
            eventEmailMessage: result.eventEmailMessage
          });
          console.log(this.addNewEventEscalationEmailSetting.value);
        },
        (err: any) => {
          console.log('Failed to fetch Event Category Details');
        });
    }
  }
}
