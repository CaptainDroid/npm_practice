import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllEventsCategoriesComponent } from './view-all-events-categories.component';

describe('ViewAllEventsCategoriesComponent', () => {
  let component: ViewAllEventsCategoriesComponent;
  let fixture: ComponentFixture<ViewAllEventsCategoriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAllEventsCategoriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllEventsCategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
