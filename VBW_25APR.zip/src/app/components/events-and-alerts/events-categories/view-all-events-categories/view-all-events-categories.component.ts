import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { EventsService } from '../../../../services/events.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import { SelectionModel } from '@angular/cdk/collections';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/components/commercial/customer-contract/date.adapter';
import { DatePipe } from '@angular/common';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { environment } from '../../../../../environments/environment';
import { CommonService } from '../../../../services/common.service';
import { TranslateService } from '@ngx-translate/core';

export interface IEvents {
  assignedTo: any;
  eCurrWorkFlow: any;
  eCurrWorkFlowId: any;
  ePrevWorkFlow: any;
  ePrevWorkFlowId: number;
  eventCategoryName: string;
  eventCreatedDt: any;
  elapsedTime: any;
  eventCreatedDtStr: any;
  eventId: any;
  historyRoleId: any;
  eventType: any;
  plantName: string;
  reason: any;
  reasonCN: any;
  lapsedTime: any;
  tagName: any;
}
@Component({
  selector: 'app-view-all-events-categories',
  templateUrl: './view-all-events-categories.component.html',
  styleUrls: ['./view-all-events-categories.component.css', '../../../../../assets/css/events.css'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
  ]
})
export class ViewAllEventsCategoriesComponent implements OnInit {
  // tslint:disable-next-line:max-line-length
  displayedColumns: string[] = ['select', 'eventCreatedDt', 'eventId', 'plantName', 'eventType', 'tagName', 'reason', 'assignedTo', 'lapsedTime', 'action'];
  dataSource: any;
  selection = new SelectionModel<IEvents>(true, []);
  eventCategories: any[] = [];
  events: IEvents;
  eventsArray: IEvents[] = [];
  eventsResponse: any;
  action: any;
  eventCategoryFilter: any = 'allEventCategories';
  eventType: any = '';
  searchFilter: any;
  plantFilter: any = 'allPlants';
  plants: any[] = [];
  plantsArray: any[] = [];
  selectedEvents: any;
  isOpenEvents: boolean = true;
  disableManualEvtcreate: boolean = false;
  selectedcheckRow: any;
  selectedcheckRowFlag: boolean = true;
  closeEventsArray: any[];
  openEventsArray: any[];
  roleId: any;
  roleBasedAccess: boolean = false;
  roleType: any;
  filteredeventCategoriesArray: any[];
  noaccessEventCategoriesArr: any[];
  filteredOpenEventsArray: any[];
  filteredCloseEventsArray: any[];
  rolefilteredOpenEveArray: any[];
  rolefilteredCloseEveArray: any[];
  applyfiltereventsArray: any[];
  applyfilterCloseeventsArray: any[];
  searchResult: any[];
  selectResult: any[];
  plantFilterResult: any[];
  eventCategoryResult: any[];
  eventCategoryDropdown;
  dateFilterResultOnLoad: any[];
  // dateFilterResult: any[];
  fromDateInput: any = '';
  toDateInput: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  eventDateInput = '';
  plantInput = '';
  reasonsInput = '';
  assignedToInput = '';
  lapsedTimeInput = '';
  eventIdInput = '';
  eventTypeInput = '';
  userEmailId: any;
  selectedlang = 'EN';
  tagNameInput = '';

  restrict_assign_close_evt_access = true;
  restrict_reopen_reassign_evt_access = true;

  create_event_access = environment.role.alertevents.create_event_access;
  assign_close_event_access = environment.role.alertevents.assign_close_events_access;
  reopen_reasssign_event_access = environment.role.alertevents.reopen_reassign_events_access;

  selectedCategory: any;


  constructor(private eventService: EventsService,
    public translate: TranslateService,
    public errorservice: ErrorserviceService,
    private router: Router, private datePipe: DatePipe,
    public dialog: MatDialog,
    public commonservice: CommonService,
    private route: ActivatedRoute) {
    this.action = 'view';
    this.roleId = Number(JSON.parse(localStorage.getItem('user')).RoleId);
    this.roleType = String(JSON.parse(localStorage.getItem('user')).prn);
    this.userEmailId = String(JSON.parse(localStorage.getItem('user')).sub);
    this.roleBasedAccess = [1, 2 , 6, 7, 20, 21].includes(this.roleId);
    if (this.route.params['value'].hasOwnProperty('eventType')) {
      this.eventType = this.route.params['value'].eventType;
      if (this.eventType === 'CLSE') {
        this.isOpenEvents = false;
      }
    }
    this.commonservice.setselectedEventCategory('');
    this.restrict_assign_close_evt_access = this.commonservice.isAccess(this.assign_close_event_access);
    this.restrict_reopen_reassign_evt_access = this.commonservice.isAccess(this.reopen_reasssign_event_access);

    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
        this.displayedColumns = [
          'select', 'eventCreatedDt', 'eventId', 'plantName', 'eventType',
          'tagName', 'reason', 'assignedTo', 'lapsedTime', 'action'];
      } else {
        this.selectedlang = 'CN';
        this.displayedColumns = [
          'select', 'eventCreatedDt', 'eventId', 'plantName', 'eventType', 'tagName',
          'reasonCN', 'assignedTo', 'lapsedTime', 'action'];
      }
    }
    this.translate.onLangChange.subscribe((language) => {
      if (parseInt(language.lang, 10) === 1) {
        this.selectedlang = 'EN';
        this.displayedColumns = [
          'select', 'eventCreatedDt', 'eventId', 'plantName', 'eventType', 'tagName',
          'reason', 'assignedTo', 'lapsedTime', 'action'];
      } else {
        this.selectedlang = 'CN';
        this.displayedColumns = [
          'select', 'eventCreatedDt', 'eventId', 'plantName', 'eventType',
          'tagName', 'reasonCN', 'assignedTo', 'lapsedTime', 'action'];

      }
    });

  }
  selectedPlant(plantObj) {
    const selectedPlantObj = this.plantsArray.filter(plant => {
      return plant.acronym === plantObj;
    });
    this.commonservice.setPlantObj(selectedPlantObj[0]);
  }
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  onchangeSelection(event, row) {
    this.selection.clear();
    if (this.selectedCategory === 'Data Analytics') {
      this.dataSource.data.forEach( data => {
        if (data.eventId !== row.eventId) {
          data.checked = false;
        }
      });
    }
    this.dataSource.data.forEach( data => {
      if (data.checked === true ) {
        this.selection.select(data);
      }
    });
    this.selectedcheckRow = row.eventId;
    this.selectedcheckRowFlag = this.selection.selected.length > 0 ? false : true;
  }
  /**
   * Table Header Filter
   */
  applyHeaderFilter(filterValue) {

    const self = this;
    this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
      if (data.eventCreatedDtStr === null) { data.eventCreatedDtStr = ''; }
      if (data.eventId === null) { data.eventId = ''; }
      if (data.plantName === null) { data.plantName = ''; }
      if (data.eventType === null) { data.eventType = ''; }
      if (data.reason === null) { data.reason = ''; }
      if (data.assignedTo === null) { data.assignedTo = ''; }
      if (data.lapsedTime === null) { data.lapsedTime = ''; }
      if (data.tagName === null) { data.tagName = ''; }

      return data.eventCreatedDtStr.toString().toLowerCase().includes(self.eventDateInput.toLowerCase())
        && data.eventId.toString().toLowerCase().includes(self.eventIdInput.toLowerCase())
        && data.plantName.toString().toLowerCase().includes(self.plantInput.toLowerCase())
        && data.eventType.toString().toLowerCase().includes(self.eventTypeInput.toLowerCase())
        && data.reason.toString().toLowerCase().includes(self.reasonsInput.toLowerCase())
        && data.assignedTo.toString().toLowerCase().includes(self.assignedToInput.toLowerCase())
        && data.lapsedTime.toString().toLowerCase().includes(self.lapsedTimeInput.toLowerCase())
        && data.tagName.toString().toLowerCase().includes(self.tagNameInput.toLowerCase())
    }
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource.paginator = this.paginator;
    this.dataSource.paginator.firstPage();
    this.dataSource.sort = this.sort;
  }

  clearHeaderFilter() {
    this.eventDateInput = '';
    this.eventIdInput = '';
    this.plantInput = '';
    this.eventTypeInput = '';
    this.reasonsInput = '';
    this.assignedToInput = '';
    this.lapsedTimeInput = '';
  }

  /**
   * Individual Filter
   */
  applyFilter(filterValue: string) {
    this.clearHeaderFilter();
    if (this.plantFilter !== 'allPlants') {
      this.applyfiltereventsArray = this.dateFilterResultOnLoad.filter(item => item.plantName === this.plantFilter);
      // this.applyfilterOpeneventsArray = this.plantFilterResult;
    } else {
      this.applyfiltereventsArray = this.dateFilterResultOnLoad;
    }

    if (this.isOpenEvents) { // Open Events
      if (filterValue === this.plantFilter) {
        this.eventCategoryFilter = 'allEventCategories'; // setting to default
        this.searchFilter = '';
        this.fromDateInput = '';
        this.toDateInput = '';

        let eveFromDate = new Date();
        let eveToDate = new Date();
        eveFromDate.setDate(eveFromDate.getDate() - 29);
        eveToDate.setDate(eveToDate.getDate());
        this.fromDateInput = eveFromDate; // Dinesh impl for default date selection
        this.toDateInput = eveToDate; // Dinesh impl for default date selection
        if (filterValue == 'allPlants') {
          this.Datefilteronload(eveFromDate, eveToDate, 'open');
        } else {
          this.filterPlant(this.dateFilterResultOnLoad, filterValue);
        }

      } else if (filterValue === this.eventCategoryFilter) {
        this.searchFilter = ''; // setting to default
        // this.fromDateInput =''; // Dinesh commented this
        // this.toDateInput = ''; // Dinesh commented this
        if (filterValue === 'allEventCategories') {
          this.dataSource = new MatTableDataSource(this.applyfiltereventsArray);
        } else {
          let manualEvtFlaf = this.eventCategories.filter(item => item.eventCategoryName === filterValue)[0].allowManualEventCreation;
          if (manualEvtFlaf === false) {
            this.disableManualEvtcreate = true;
          } else {
            this.disableManualEvtcreate = false;
          }
          this.filterEventCategory(this.applyfiltereventsArray, filterValue);
        }
      } else if (filterValue === this.searchFilter) {
        if (this.fromDateInput != '') {
          this.filterDateOnPlants(this.dateFilterResultOnLoad, this.plantFilter, this.fromDateInput, this.toDateInput);
          this.applyfiltereventsArray = this.plantFilterResult;
        }
        if (this.eventCategoryFilter !== 'allEventCategories') {
          this.applyfiltereventsArray = this.applyfiltereventsArray.filter(item => item.eventCategoryName === this.eventCategoryFilter);
        }
        if (this.searchFilter) {
          this.filterSearch(this.applyfiltereventsArray, filterValue);
        } else {
          this.dataSource = new MatTableDataSource(this.applyfiltereventsArray);
        }
      }
    } else { // Closed Events

      if (filterValue === this.plantFilter) {
        this.eventCategoryFilter = 'allEventCategories'; // setting to default
        this.searchFilter = '';
        this.fromDateInput = '';
        this.toDateInput = '';

        let eveFromDate = new Date();
        let eveToDate = new Date();
        eveFromDate.setDate(eveFromDate.getDate() - 29);
        eveToDate.setDate(eveToDate.getDate());
        this.fromDateInput = eveFromDate; // Dinesh impl for default date selection
        this.toDateInput = eveToDate; // Dinesh impl for default date selection
        if (filterValue == 'allPlants') {
          this.Datefilteronload(eveFromDate, eveToDate, 'close');
        } else {
          this.filterPlant(this.dateFilterResultOnLoad, filterValue);
        }
      }
      else if (filterValue === this.eventCategoryFilter) {
        this.searchFilter = ''; // setting to default
        if (this.fromDateInput != '') {
          this.filterDateOnPlants(this.dateFilterResultOnLoad, this.plantFilter, this.fromDateInput, this.toDateInput);
          this.applyfiltereventsArray = this.plantFilterResult;
        }
        if (filterValue === 'allEventCategories') {
          this.dataSource = new MatTableDataSource(this.applyfiltereventsArray);
        } else {
          this.filterEventCategory(this.applyfiltereventsArray, filterValue);
        }
      } else if (filterValue === this.searchFilter) {
        if (this.fromDateInput != '') {
          this.filterDateOnPlants(this.dateFilterResultOnLoad, this.plantFilter, this.fromDateInput, this.toDateInput);
          this.applyfiltereventsArray = this.plantFilterResult;
        }
        if (this.eventCategoryFilter !== 'allEventCategories') {
          this.applyfiltereventsArray = this.applyfiltereventsArray.filter(item => item.eventCategoryName === this.eventCategoryFilter);
        }

        if (this.searchFilter) {
          this.filterSearch(this.applyfiltereventsArray, filterValue);
        } else {
          this.dataSource = new MatTableDataSource(this.applyfiltereventsArray);
        }
      }
    }
    this.dataSource.paginator = this.paginator;
    this.dataSource.paginator.firstPage();
    this.dataSource.sort = this.sort;
  }

  filterSearch(data, filterValue) {
    this.searchResult = data.filter(item => {
      // tslint:disable-next-line:max-line-length
      return (item.eventCreatedDt !== null && item.eventCreatedDt.toString().toLowerCase().includes(filterValue.toLowerCase()))
        || (item.eventId !== null && item.eventId.toString().toLowerCase().includes(filterValue.toLowerCase()))
        || (item.plantName !== null && item.plantName.toString().toLowerCase().includes(filterValue.toLowerCase()))
        || (item.eventType !== null && item.eventType.toString().toLowerCase().includes(filterValue.toLowerCase()))
        || (item.reason !== null && item.reason.toString().toLowerCase().includes(filterValue.toLowerCase()))
        || (item.assignedTo !== null && item.assignedTo.toString().toLowerCase().includes(filterValue.toLowerCase()))
        || (item.tagName !== null && item.tagName.toString().toLowerCase().includes(filterValue.toLowerCase()))
        || (item.lapsedTime !== null && item.lapsedTime.toString().toLowerCase().includes(filterValue.toLowerCase()))
    });
    this.dataSource = new MatTableDataSource(this.searchResult);
  }

  filterPlant(data, filterValue) {
    if (data) {
      this.plantFilterResult = data.filter(item => item.plantName === filterValue);
      this.dataSource = new MatTableDataSource(this.plantFilterResult);
    }
  }

  filterEventCategory(data, filterValue) {
    if (data) {
      this.eventCategoryResult = data.filter(item => item.eventCategoryName === filterValue);
      this.dataSource = new MatTableDataSource(this.eventCategoryResult);
    }
  }

  filterDateOnPlants(data, plantName, fromDate, toDate) {
    const startDate = new Date(fromDate);
    const endDate = new Date(toDate);
    startDate.setHours(0, 0, 0, 0);
    endDate.setHours(0, 0, 0, 0);
    // endDate.setDate(endDate.getDate() + 1); //To select current date also

    if (plantName != 'allPlants') {
      this.plantFilterResult = data.filter(item => item.plantName === plantName);
    } else {
      this.plantFilterResult = data;
    }
    this.plantFilterResult = this.plantFilterResult.filter((item: any) => {
      const eventCreatedDt = new Date(item.eventCreatedDt);
      eventCreatedDt.setHours(0, 0, 0, 0);
      return eventCreatedDt >= startDate;
    });
    this.plantFilterResult = this.plantFilterResult.filter((item: any) => {
      const eventCreatedDt = new Date(item.eventCreatedDt);
      eventCreatedDt.setHours(0, 0, 0, 0);
      return eventCreatedDt <= endDate;
    });

    this.dataSource = new MatTableDataSource(this.plantFilterResult);
  }

  Datefilteronload(fromDate, toDate, eventType) {
    const startDate = new Date(fromDate);
    const endDate = new Date(toDate);
    startDate.setHours(0, 0, 0, 0);
    endDate.setHours(0, 0, 0, 0);

    if (eventType == 'open') {
      this.dateFilterResultOnLoad = this.filteredOpenEventsArray.filter((item: any) => {
        const eventCreatedDt = new Date(item.eventCreatedDt);
        eventCreatedDt.setHours(0, 0, 0, 0);
        return eventCreatedDt >= startDate;
      });
      this.dateFilterResultOnLoad = this.dateFilterResultOnLoad.filter((item: any) => {
        const eventCreatedDt = new Date(item.eventCreatedDt);
        eventCreatedDt.setHours(0, 0, 0, 0);
        return eventCreatedDt <= endDate;
      });
    } else {
      this.dateFilterResultOnLoad = this.filteredCloseEventsArray.filter((item: any) => {
        const eventCreatedDt = new Date(item.eventCreatedDt);
        eventCreatedDt.setHours(0, 0, 0, 0);
        return eventCreatedDt >= startDate;
      });
      this.dateFilterResultOnLoad = this.dateFilterResultOnLoad.filter((item: any) => {
        const eventCreatedDt = new Date(item.eventCreatedDt);
        eventCreatedDt.setHours(0, 0, 0, 0);
        return eventCreatedDt <= endDate;
      });
    }

    this.dateFilterResultOnLoad.sort(function (a: any, b: any) {
      let keyA = new Date(a.eventCreatedDt),
        keyB = new Date(b.eventCreatedDt);
      // Compare the 2 dates
      if (keyA < keyB) return 1;
      if (keyA > keyB) return -1;
      return 0;
    });
    this.dataSource = new MatTableDataSource(this.dateFilterResultOnLoad);

  }

  selectedEventCategory(selectedData) {
    this.selectedCategory = selectedData.eventCategoryName;
    this.commonservice.setselectedEventCategory(selectedData.eventCategoryName);
    sessionStorage.setItem('eventCategoryName', selectedData.eventCategoryName);
    sessionStorage.setItem('eventCategoryId', selectedData.eventCategoryId);
  }

  clearDateRange() {
    this.clearHeaderFilter();
    this.searchFilter = '';
    this.fromDateInput = '';
    this.toDateInput = '';
    let eveFromDate = new Date();
    let eveToDate = new Date();
    eveFromDate.setDate(eveFromDate.getDate() - 29);

    if (this.isOpenEvents) {
      // eveToDate.setDate(eveToDate.getDate() + 1);
      this.Datefilteronload(eveFromDate, eveToDate, 'open');
    } else {
      // eveToDate.setDate(eveToDate.getDate() + 1);
      this.Datefilteronload(eveFromDate, eveToDate, 'close');
    }
    eveToDate = new Date();
    if (this.plantFilter != 'allPlants') {
      this.filterDateOnPlants(this.dateFilterResultOnLoad, this.plantFilter, eveFromDate, eveToDate);
    }
    if (this.eventCategoryFilter != 'allEventCategories') {
      // tslint:disable-next-line: max-line-length
      this.filterEventCategory(this.plantFilter != 'allPlants' ? this.plantFilterResult : this.dateFilterResultOnLoad, this.eventCategoryFilter);
    }
    this.dataSource.paginator = this.paginator;
    this.dataSource.paginator.firstPage();
    this.dataSource.sort = this.sort;

  }
  onDateChange() {
    this.searchFilter = '';
    if (this.fromDateInput == '' || this.toDateInput == '') {
      const dialogRef = this.dialog.open(DialogComponent, {
        width: '400px',
        data: { title: 'data.L00224', message: 'data.L00836' }
      });
      const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
      });
      return;
    }

    if (this.fromDateInput > this.toDateInput) {
      const dialogRef = this.dialog.open(DialogComponent, {
        width: '400px',
        data: { title: 'data.L00224', message: 'data.L00837' }
      });
      const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
      });
      return;
    }
    let eveFromDate = this.fromDateInput;
    let eveToDate = this.toDateInput;

    if (this.isOpenEvents) {
      // eveToDate.setDate(eveToDate.getDate() + 1);
      this.Datefilteronload(eveFromDate, eveToDate, 'open');
      // eveToDate.setDate(eveToDate.getDate() - 1);
    } else {
      // eveToDate.setDate(eveToDate.getDate() + 1);
      this.Datefilteronload(eveFromDate, eveToDate, 'close');
      // eveToDate.setDate(eveToDate.getDate() - 1);
    }

    eveToDate = new Date();
    this.filterDateOnPlants(this.dateFilterResultOnLoad, this.plantFilter, eveFromDate, eveToDate);
    if (this.eventCategoryFilter != 'allEventCategories') {
      this.filterEventCategory(this.plantFilterResult, this.eventCategoryFilter);
    }

    this.dataSource.paginator = this.paginator;
    this.dataSource.paginator.firstPage();
    this.dataSource.sort = this.sort;

  }

  toggleOpenCloseEvents() {
    this.isOpenEvents = !this.isOpenEvents;
    // setting filter to default value
    this.eventCategoryFilter = 'allEventCategories';
    this.plantFilter = 'allPlants';
    this.fromDateInput = '';
    this.toDateInput = '';
    this.searchFilter = '';

    if (!this.isOpenEvents) {
      /*this.dataSource = new MatTableDataSource(this.filteredCloseEventsArray);
      this.dataSource.paginator = this.paginator;
      this.dataSource.paginator.firstPage();
      this.dataSource.sort = this.sort;*/
      this.router.navigate(['/view-all-events-categories/CLSE']);
    } else {
      /*this.dataSource = new MatTableDataSource(this.filteredOpenEventsArray);
      this.dataSource.paginator = this.paginator;
      this.dataSource.paginator.firstPage();
      this.dataSource.sort = this.sort;*/
      this.router.navigate(['/view-all-events-categories']);
    }
  }

  ngOnInit() {

    /**
     * Get Event Category List
     */
    this.eventService.getEventCategory().subscribe(
      (data: any) => {
        if (data.status !== 'success') {
          this.errorservice.showerror({
            status: data.errorCode,
            statusText: data.message
          });
        } else {
          this.eventCategories = data.data.eventCategories;
          // tslint:disable-next-line: max-line-length
          this.eventCategories.sort((a, b) => a.eventCategoryName.charAt(0).toString().toLowerCase() < b.eventCategoryName.charAt(0).toString().toLowerCase() ? -1 : (a.eventCategoryName.charAt(0).toString().toLowerCase() > b.eventCategoryName.charAt(0).toString().toLowerCase() ? 1 : 0));
          if (this.eventType !== '' && this.eventType === 'CLSE') {
            this.getEvents('close'); // on initial fetch open events
          } else {
            this.getEvents('open');
          }
        }
      },
      (err: any) => {
        console.log('Event Categories Fetching Failed!!!');
      });

    /**
   * Get Event Category List
   */
    this.eventService.getplants().subscribe(
      (data: any) => {
        this.plants = [];
        if (data.status !== 'success') {
          this.errorservice.showerror({
            status: data.errorCode,
            statusText: data.message
          });
        } else {
          data.data.countries.forEach(country => {
            country.cities.forEach(city => {
              city.plants.forEach(plant => {
                this.plants.push(plant.acronym);
              });
            });
          });
          // tslint:disable-next-line:max-line-length
          this.plants.sort((a, b) => a.toString().toLowerCase() < b.toString().toLowerCase() ? -1 : (a.toString().toLowerCase() > b.toString().toLowerCase() ? 1 : 0));
          if (this.plants && this.plants.length === 1) {
            this.plantFilter = this.plants[0];
            if (this.dataSource) {
              this.applyFilter(this.plantFilter);
            }
          }
          /**
           * Code to see if user is coming from the Events section on the plantView page
           */
          if (this.route.params['value'].hasOwnProperty('plantAcronym')) {
            this.plantFilter = this.route.params['value'].plantAcronym;
            if (this.dataSource) {
              this.applyFilter(this.plantFilter);
            }
          }
          /**
           * Checking plantView visitor code ends
           */
          // to form selected plant object which is used to get all tags in add userdefined recommondation acreen
          for (let i = 0; i < data.data.countries.length; i++) {
            for (let j = 0; j < data.data.countries[i].cities.length; j++) {
              for (let k = 0; k < data.data.countries[i].cities[j].plants.length; k++) {
                let plantobj: {
                  id: any, acronym: any, countryId: any, cityId: any
                };
                plantobj = {
                  id: data.data.countries[i].cities[j].plants[k].id,
                  acronym: data.data.countries[i].cities[j].plants[k].acronym,
                  countryId: data.data.countries[i].id,
                  cityId: data.data.countries[i].cities[j].id
                };
                this.plantsArray.push(plantobj);
              }
            }
          }
        }
      },
      (err: any) => {
        console.log('Plants Fetching Failed!!!');
      });


  }
  /**
    * Get Events
    */
  getEvents(eventType: any) {
    this.eventService.getEvents(eventType).subscribe(
      (data: any) => {
        if (data.status !== 'success') {
          this.errorservice.showerror({
            status: data.errorCode,
            statusText: data.message
          });
        } else {
          this.eventsResponse = data.data.events;
          // tslint:disable-next-line:prefer-const
          let now: any = new Date();
          // tslint:disable-next-line: max-line-length
          let date_now: any = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
          let lapsedTime: any;
          this.closeEventsArray = [];
          this.openEventsArray = [];
          let rolesCollection = [];
          this.eventsResponse.forEach(event => {
            // tslint:disable-next-line:prefer-const
            let eventCreatedDate: any = new Date(event.elapsedTime);
            let seconds = Math.floor((date_now - (eventCreatedDate)) / 1000);
            let minutes: any = Math.floor(seconds / 60);
            let hours: any = Math.floor(minutes / 60);
            // tslint:disable-next-line:prefer-const
            let days: any = Math.floor(hours / 24);
            hours = hours - (days * 24);

            minutes = minutes - (days * 24 * 60) - (hours * 60);
            seconds = seconds - (days * 24 * 60 * 60) - (hours * 60 * 60) - (minutes * 60);

            if (hours < 10) {
              hours = '0' + hours;
            } else {
              hours = hours;
            }

            if (minutes < 10) {
              minutes = '0' + minutes;
            } else {
              minutes = minutes;
            }

            if (days < 10 && days > 0) {
              days = '0' + days;
            } else {
              days = days;
            }

            if (event.eCurrWorkFlow !== 'CLSE') {
              lapsedTime = days + ':' + hours + ':' + minutes;
            } else {
              lapsedTime = '';
            }
            this.events = {
              assignedTo: (event.assignedTo !== null || event.assignedTo !== undefined) ? event.assignedTo : "",
              eCurrWorkFlow: (event.eCurrWorkFlow != null || event.eCurrWorkFlow != undefined) ? event.eCurrWorkFlow : "",
              eCurrWorkFlowId: (event.eCurrWorkFlowId != null || event.eCurrWorkFlowId !== undefined) ? event.eCurrWorkFlowId : "",
              ePrevWorkFlow: (event.ePrevWorkFlow != null || event.ePrevWorkFlow !== undefined) ? event.ePrevWorkFlow : "",
              ePrevWorkFlowId: (event.ePrevWorkFlowId != null || event.ePrevWorkFlowId !== undefined) ? event.ePrevWorkFlowId : "",
              eventCategoryName: (event.eventCategoryName != null || event.eventCategoryName !== undefined) ? event.eventCategoryName : "",
              eventCreatedDt: (event.createdAt != null || event.createdAt !== undefined) ? event.createdAt : "",
              elapsedTime: (event.elapsedTime != null || event.elapsedTime !== undefined) ? event.elapsedTime : "",
              eventCreatedDtStr: (event.createdAt != null || event.createdAt !== undefined) ? event.createdAt : "",
              eventId: (event.eventId != null || event.eventId !== undefined) ? event.eventId : "",
              historyRoleId: (event.historyRoleId != null || event.historyRoleId !== undefined) ? event.historyRoleId : "",
              eventType: (event.eventType != null || event.eventType !== undefined) ? event.eventType : "",
              plantName: (event.plantAcronym != null || event.plantAcronym !== undefined) ? event.plantAcronym : "",
              reason: (event.reason.en != null || event.reason.en !== undefined) ? event.reason.en : "",
              reasonCN: (event.reason.cn != null || event.reason.cn !== undefined) ? event.reason.cn : "",
              lapsedTime: lapsedTime,
              tagName: (event.tagName != null || event.tagName !== undefined) ? event.tagName : "",
            };
            this.events.eventCreatedDtStr = this.datePipe.transform(this.events.eventCreatedDt, 'dd/MMM/yy HH:mm:ss');
            this.events.eventCreatedDt = new Date(this.events.eventCreatedDt);
            this.eventsArray.push(this.events);
          });

          if (eventType === 'open') {
            this.openEventsArray = this.eventsArray.filter(event => event.eCurrWorkFlow !== 'CLSE');
          } else {
            this.closeEventsArray = this.eventsArray.filter(event => event.eCurrWorkFlow === 'CLSE');
          }
          /**
           * Filter Open Events
           */
          console.log('Role Id: ' + this.roleId);
          let historyRoleId: any = '';
          let eveFromDate = new Date();
          let eveToDate = new Date();
          eveFromDate.setDate(eveFromDate.getDate() - 29);
          // eveToDate.setDate(eveToDate.getDate() + 1);
          if (this.roleType != 'Admin') {
            if (eventType === 'open') {
              // open events
              this.filterOpenEventsArray();
              this.rolefilteredOpenEveArray.forEach(event => {
                if (event.historyRoleId !== undefined && event.historyRoleId !== null) {
                  rolesCollection = event.historyRoleId.split(',');
                  for (let i = 0; i < rolesCollection.length; i++) {
                    historyRoleId = rolesCollection[i];
                    if (historyRoleId == this.roleId) {
                      this.filteredOpenEventsArray.push(event);
                      break;
                    }
                  }
                }
              });
              this.Datefilteronload(eveFromDate, eveToDate, 'open');
            } else {
              // closed events
              this.filterCloseEventsArray();
              this.rolefilteredCloseEveArray.forEach(event => {
                if (event.historyRoleId !== undefined && event.historyRoleId !== null) {
                  rolesCollection = event.historyRoleId.split(',');
                  for (let i = 0; i < rolesCollection.length; i++) {
                    if (rolesCollection[i] == this.roleId) {
                      this.filteredCloseEventsArray.push(event);
                      break;
                    }
                  }
                }
              });
              this.Datefilteronload(eveFromDate, eveToDate, 'close');
            }
          } else {
            if (eventType === 'open') {
              this.filteredOpenEventsArray = this.openEventsArray;
              this.Datefilteronload(eveFromDate, eveToDate, 'open');
            } else {
              this.filteredCloseEventsArray = this.closeEventsArray;
              this.Datefilteronload(eveFromDate, eveToDate, 'close');
            }
          }

          // this.dataSource.filterPredicate = (data: IEvents, filter: string) => {
          //   !filter || data.eventCategoryName == filter || data.plantName == filter;
          // }
          this.dataSource.paginator = this.paginator;
          this.dataSource.paginator.firstPage();
          this.dataSource.sort = this.sort;
          // if(this.plants && this.plants.length){
          //   this.plantFilter = this.plants[0];
          // }
          /**
         * Code to filter by plant which the user is coming from, from the PlantView page
         */
          if (this.plantFilter) {
            this.applyFilter(this.plantFilter);
          }
          /**
           * Filter code Ends
           */
        }
      },
      (err: any) => {
        console.log('Events Listing Failed!!!');
      });
  }

  /**
   * filter Open Events Array
   */
  filterOpenEventsArray() {
    this.filteredeventCategoriesArray = [];
    this.noaccessEventCategoriesArr = [];
    this.filteredOpenEventsArray = [];
    this.eventCategories.forEach(eventCategory => {
      /**
       * Filter viewByRoles Array
       */
      const viewByRoles = eventCategory.viewByRoles.filter(viewByRole => viewByRole === this.roleId);

      /**
       * Filter actionByRoles Array
       */
      const actionByRoles = eventCategory.actionByRoles.filter(actionByRole => actionByRole === this.roleId);

      /**
       * Check either viewByRoles Array or actionByRoles Array contains RoleId
       */
      if ((viewByRoles.length > 0) || (actionByRoles.length > 0)) {
        this.filteredeventCategoriesArray.push(eventCategory);
      } else {
        this.noaccessEventCategoriesArr.push(eventCategory);
      }
    });

    /**
     * Compare Open Events array with Event Categories Array
     */
    this.filteredOpenEventsArray = this.openEventsArray.filter(openEvent => {
      return this.filteredeventCategoriesArray.some(filteredeventCategory => {
        return openEvent.eventCategoryName === filteredeventCategory.eventCategoryName;
      });
    });

    // List of removed event categaries
    this.rolefilteredOpenEveArray = this.openEventsArray.filter(openEvent => {
      return this.noaccessEventCategoriesArr.some(filteredeventCategory => {
        return openEvent.eventCategoryName === filteredeventCategory.eventCategoryName;
      });
    });

  }

  /**
   * filter Close Events Array
   */
  filterCloseEventsArray() {
    this.filteredCloseEventsArray = [];
    this.filteredeventCategoriesArray = [];
    this.noaccessEventCategoriesArr = [];

    this.eventCategories.forEach(eventCategory => {

      const viewByRoles = eventCategory.viewByRoles.filter(viewByRole => viewByRole === this.roleId);
      const actionByRoles = eventCategory.actionByRoles.filter(actionByRole => actionByRole === this.roleId);
      if ((viewByRoles.length > 0) || (actionByRoles.length > 0)) {
        this.filteredeventCategoriesArray.push(eventCategory);
      } else {
        this.noaccessEventCategoriesArr.push(eventCategory);
      }
    });
    /**
     * Compare Close Events array with Event Categories Array
     */
    this.filteredCloseEventsArray = this.closeEventsArray.filter(closeEvent => {
      return this.filteredeventCategoriesArray.some(filteredeventCategory => {
        return closeEvent.eventCategoryName === filteredeventCategory.eventCategoryName;
      });
    });

    // List of removed event categaries
    this.rolefilteredCloseEveArray = this.closeEventsArray.filter(closeEvent => {
      return this.noaccessEventCategoriesArr.some(filteredeventCategory => {
        return closeEvent.eventCategoryName === filteredeventCategory.eventCategoryName;
      });
    });


  }

  assignEvents() {
    // tslint:disable-next-line:prefer-const
    let checkedEventIds = [];
    this.selection.selected.forEach(event => {
      checkedEventIds.push(event.eventId);
    });
    this.eventService.selectedEvents = checkedEventIds;
    // tslint:disable-next-line:prefer-const
    let eventId = checkedEventIds[0];
    this.action = 'Assign';
    this.router.navigate(['/view-event/' + eventId + '/' + this.action]);
  }
  viewEvents(event, action) {
    this.commonservice.setEventType(event.eventCategoryName);
    this.router.navigate(['/view-event/' + event.eventId + '/' + action]);
  }
  closeOrReopenEvents() {
    // tslint:disable-next-line:prefer-const
    let checkedEventIds = [];
    this.selection.selected.forEach(event => {
      checkedEventIds.push(event.eventId);
    });
    this.eventService.selectedEvents = checkedEventIds;
    // tslint:disable-next-line:prefer-const
    let eventId = checkedEventIds[0];

    if (this.isOpenEvents) {
      this.action = 'Close';
    } else {
      this.action = 'ReOpen';
    }
    this.router.navigate(['/view-event/' + eventId + '/' + this.action]);
  }

  checkrole(emailcollection: any, email: any) {
    console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>', emailcollection, email)
    if (emailcollection !== null && emailcollection !== '') {
      return emailcollection.includes(email);
    } else {
      return true;
    }
  }

  clearFromDate() {
    this.fromDateInput = '';
  }
  clearToDate() {
    this.toDateInput = '';
  }

}
