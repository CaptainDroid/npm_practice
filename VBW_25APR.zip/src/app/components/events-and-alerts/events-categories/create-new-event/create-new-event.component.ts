import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormBuilder, FormGroupDirective, FormGroup, NgForm, Validators, AbstractControl } from '@angular/forms';
import { EventsService } from 'src/app/services/events.service';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { ErrorStateMatcher } from '@angular/material/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material';
import { CancelConfirmationDialogComponent } from '../../confirmation-dialog/cancel-confirmation-dialog';

export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: 'app-create-new-event',
  templateUrl: './create-new-event.component.html',
  styleUrls: ['./create-new-event.component.css', '../../../../../assets/css/events.css']
})
export class CreateNewEventComponent implements OnInit {
  @Input() disabled = true;
  createNewEventForm: FormGroup;
  plantsresponse: any;
  plants = [];
  errorMessage: any;
  eventCategories: any;
  eventTypes: any;
  eventMessages: any;
  loggedInUserDetails: any;
  eventCategoriesArray: any[];
  submitted = false;
  getEventCategoryName: string;
  getEventCategoryId: any;
  selectedPlant = '';

  constructor(
    private formBuilder: FormBuilder,
    private eventService: EventsService,
    private errorservice: ErrorserviceService,
    private route: Router,
    private actRoute: ActivatedRoute,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getEventCategoryName = sessionStorage.getItem('eventCategoryName');
    this.getEventCategoryId = sessionStorage.getItem('eventCategoryId');
    this.loggedInUserDetails = JSON.parse(localStorage.getItem('user'));
    /**
     * Form Data
     */
    this.createNewEventForm = this.formBuilder.group({
      createdBy: [{value: this.loggedInUserDetails.sub, disabled: true}, Validators.required],
      plant: ['', Validators.required],
      eventCategory: [{value: '', disabled: true}, Validators.required],
      eventType: ['', Validators.required],
      eventMessage: ['', Validators.required],
      eventCategoryName: [{value: '', disabled: true}]
    });
    this.createNewEventForm.patchValue({
      eventCategory: this.getEventCategoryId
    });

    /**
     * Get Plants
     */
    this.eventService.getplants().subscribe(
      data => {
        this.plantsresponse = data;
        this.plants = [];
        if (this.plantsresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsresponse.status, statusText: this.plantsresponse.message });
        } else {
          let plant;
          if (this.actRoute.params['value'].hasOwnProperty('plantAcronym')) {
            plant = this.actRoute.params['value'].plantAcronym;
          }

          for (let i = 0; i < this.plantsresponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsresponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsresponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsresponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsresponse.data.countries[i].id;
                plantobj.citiId = this.plantsresponse.data.countries[i].cities[j].id;
                /**
                 * Auto-select the plant in the dropdown if it was selected in the view-events screen
                 */
                if(plant && plantobj.acronym.toLowerCase() === plant.toLowerCase()) {
                  this.selectedPlant = plantobj.id;
                }
                this.plants.push(plantobj);
              }
            }
          }

        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no plants pulled from the server!';
      }
    );

    /**
     * Get Event Category
     */
    this.eventService.getEventCategory().subscribe(
      (data: any) => {
        this.eventCategories = data.data.eventCategories;
        this.eventCategoriesArray = [];
        this.eventCategories.filter(eventCategory => {
          // console.log('all-events', eventCategory)
          if (eventCategory.allowManualEventCreation === true) {
            if (eventCategory.eventCategoryId === +this.getEventCategoryId) {
              // console.log('filtered-event', eventCategory);
              this.eventTypes = eventCategory.eventTypes;
            }
            this.eventCategoriesArray.push(eventCategory);
          }
        });
      },
      (err: any) => {
        console.log('Failed fetching Event Category!!!');
      }
    );

    /**
     * Get Event Type
     */
    this.eventService.getAllEvents().subscribe(
      (data: any) => {
        // this.eventTypes = data.data.eventtypes;
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

    /**
     * Get Event Message
     */
    this.eventService.eventMessage()
      .subscribe((message: any) => {
        const msg: any = message;
        const data = msg.data.eventMessages;
        this.eventMessages = data;
      });
  }

  selectEventType(event) {
    this.eventTypes = event.eventTypes;
  }

  onSubmit() {
    this.submitted = true;
    if (this.createNewEventForm.valid) {
      const data = {
        'tenantId': 1,
        'createdBy': parseInt(this.loggedInUserDetails.amr, 10),
        'action': 'Create',
        'eventCategoryId': parseInt(this.getEventCategoryId, 10),
        'eventTypeId': this.createNewEventForm.value.eventType,
        'eventMessageId': this.createNewEventForm.value.eventMessage,
        'plantId': this.createNewEventForm.value.plant,
      };

      this.eventService.addEvent(data)
        .subscribe((result: any) => {
          if (result.status === 'Failed') {
            this.errorservice.showerror({ status: result['status'], statusText: result['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: '', statusText: 'Event saved successfully' });
            this.route.navigate(['/view-all-events-categories']);
          }
        }, (err: any) => {
          console.log('error', err);
        });
    }
  }
   /**
    * Cancel Confirmation Dialog
    */
   openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'view-all-events-categories' }
    });
  }


}
