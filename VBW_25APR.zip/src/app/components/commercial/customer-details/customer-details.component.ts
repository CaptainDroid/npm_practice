import { Component, OnInit } from '@angular/core';
import { CommercialService } from "../../../services/commercial.service";
import { Router } from '@angular/router';
import { DatePipe, Location } from '@angular/common';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {

  dateRange = 90;
  chartData;
  customerData;
  allCustomers;
  selectedCustomer;
  ready: boolean;
  numContracts = [];
  currentContract;
  numberOfContracts;
  customerContract;
  temp;
  plantAcronym;
  chartReady;
  contractReady;
  dataReady;
  show = [false, false, false];
  customer = [];
  pipe;
  message;
  plantId;
  public showParameters = false;
  public rawMaterials = {};
  public processes = {};
  public companyProducts = {};
  public industries = {};
  public products = {};
  public mainPollutants = {};
  public modelType = {};
  public companyType = {
    1767: "MNC",
    1766: "Local"
  };
  public productionType = {
    1759: "Batch",
    1764: "Continuous"
  };
  public billingFrequency = {
    1771: "One-off",
    1768: "Monthly",
    1773: "Quarterly",
    1758: "Annually",
    1760: "Biannually"
  };
  public treatabilityStudy = {
    1778: "Yes",
    1770: "No"
  };
  public wasteWaterDelivery = {
    1765: "Dedicated pipe",
    1762: "Common pipe",
    1777: "Trucked",
    1763: "Common pipe + Dedicated pipe"
  };

  constructor(public commService: CommercialService, private router: Router, private _location: Location) { }

  ngOnInit() {

    this.message = "data.L00741"
    this.pipe = new DatePipe('en-gb');
    this.chartData = this.commService.ChartData;
    this.selectedCustomer = this.commService.selectedCustomer;
    this.allCustomers = this.commService.allCustomers;

    if (this.selectedCustomer === undefined) {
      this.router.navigate(['/commercial']);
      return this;
    }

    this.plantAcronym = this.commService.plantAcronym;
    this.plantId = this.commService.plantId;
    /*
    ** Getting the data for the raw materials
    */
    this.commService.getParameters().subscribe(
      data => {
        if(data["status"] !== "success" || !data["data"]) {
          return;
        }

        // Storing the data for the raw materials
        if(data["data"]["rawMaterials"] && data["data"]["rawMaterials"].length) {
          for(let i=0; i < data["data"]["rawMaterials"].length; i++) {
            let id = data["data"]["rawMaterials"][i]["paramid"];
            this.rawMaterials[id] = data["data"]["rawMaterials"][i]["paramvalue"];
          }
        }
      
        // Storing the data for the raw materials
        if(data["data"]["mainPollutants"] && data["data"]["mainPollutants"].length) {
          for(let i=0; i < data["data"]["mainPollutants"].length; i++) {
            let id = data["data"]["mainPollutants"][i]["paramid"];
            this.mainPollutants[id] = data["data"]["mainPollutants"][i]["paramvalue"];
          }
        }
      
        // Storing the data for the raw materials
        if(data["data"]["companyProduct"] && data["data"]["companyProduct"].length) {
          for(let i=0; i < data["data"]["companyProduct"].length; i++) {
            let id = data["data"]["companyProduct"][i]["paramid"];
            this.companyProducts[id] = data["data"]["companyProduct"][i]["paramvalue"];
          }
        }
      
        // Storing the data for the raw materials
        if(data["data"]["customerProcess"] && data["data"]["customerProcess"].length) {
          for(let i=0; i < data["data"]["customerProcess"].length; i++) {
            let id = data["data"]["customerProcess"][i]["paramid"];
            this.processes[id] = data["data"]["customerProcess"][i]["paramvalue"];
          }
        }
      
        // Storing the data for the raw materials
        if(data["data"]["industry"] && data["data"]["industry"].length) {
          for(let i=0; i < data["data"]["industry"].length; i++) {
            let id = data["data"]["industry"][i]["paramid"];
            this.industries[id] = data["data"]["industry"][i]["paramvalue"];
          }
        }
      
        // Storing the data for the raw materials
        if(data["data"]["commercialModelType"] && data["data"]["commercialModelType"].length) {
          for(let i=0; i < data["data"]["commercialModelType"].length; i++) {
            let id = data["data"]["commercialModelType"][i]["paramId"];
            this.modelType[id] = data["data"]["commercialModelType"][i]["paramValue"];
          }
        }
      }
    );

    // console.log(this.customerData);
    // There's a typo in the API for key this.customers.customerName, as custEmerName, correct your code here when it is fixed 
    // this.selectedCustomer = this.customer.customerName; //This should be id (not name), but can be corrected once the structure of the APIs is known 

    //If the chartData for the customer is not available already, get it.
    if (this.chartData === undefined) {
      this.getSingleCustomerChartData(this.selectedCustomer.id);
      this.show[0] = true;
    } else {

      this.show[0] = true;
      this.chartReady = true;
    }

    //Get the customer information
    this.getSingleCustomerData(this.selectedCustomer.id);
    this.getSingleCustomerContract(this.selectedCustomer.id);


  }

  changeCustomer(selectedCustomer): void {
    this.chartReady = false;
    this.getSingleCustomerChartData(selectedCustomer.id);
    this.getSingleCustomerData(selectedCustomer.id);
    this.getSingleCustomerContract(selectedCustomer.id);
  }

  getSingleCustomerData(selectedCustomer): void {
    this.dataReady = false;
    this.commService.getSingleCustomerData(selectedCustomer).subscribe(
      data => {
        this.customerData = data;
        if (this.customerData.status !== "success") return;
        this.customerData = this.customerData.data;
        // console.log("Customer data received is ", data);

        this.dataReady = true;
      }
    );
  }

  getSingleCustomerContract(selectedCustomer) {
    this.contractReady = false;
    this.commService.getSingleCustomerContract(selectedCustomer).subscribe(
      data => {
        this.customerContract = data;
        // console.log("Customer contract received is ", data);
        this.numContracts = [];

        /*
         The this.customerContract.customerContract key should be an array but the API response contains 
         it as an object
         That's why the following line (used to get length of ARRAY) is disabled and command to get
         length of JSON object is used.

         Correct when API is fixed!
         */

        // this.numberOfContracts = this.customerContract.contract.length - 1;
        this.numberOfContracts = 1;


        /*
          JUST SOME CODE BECAUSE THE API RESPONSE DOES NOT CONTAIN THE CORRECT FORMAT OF DATA
          THE ONE FOLLOWED BY //EXTRA
          god!
        */

        this.customer = []; //EXTRA
        for (let i = 0; i < this.numberOfContracts; i++) {
          if(this.customerContract.data.country.city.plant.customer.customerContract)
            this.customer.push(this.customerContract.data.country.city.plant.customer.customerContract); //EXTRA

          this.numContracts.push({ id: i, hidden: true });
        }


        this.numContracts[0].hidden = false;
        this.currentContract = 0;
        this.contractReady = true;
      }
    )
  }

  getSingleCustomerChartData(selectedCustomer): void {
    this.message = "data.L00742";

    this.commService.getSingleCustomerChartData(selectedCustomer).subscribe(
      data => {
        this.chartData = data;
        // console.log("This is the chartdata received", data);
        let tempObj = {};
        let tempObj2 = [];
        tempObj2.length = 0;
        this.temp = data;
        if (this.temp.data == null) {
          this.message = "data.L00741";
          return;
        }
        for (let j = 0; j < this.temp.data.country.city.plant.customer.parameters.length; j++) {
          tempObj = {};
          let test =  this.temp.data.country.city.plant.customer.parameters[j].test;
          tempObj2[test] = ({ "customerId": this.temp.data.country.city.plant.customer.customerId, "type": "", "data": [[], []], "label": this.temp.data.country.city.plant.customer.parameters[j].test });

          tempObj2[test]["type"] = this.temp.data.country.city.plant.customer.parameters[j].test;
          let length = this.temp.data.country.city.plant.customer.parameters[j].plots.length;
          let startIndex = this.dateRange > length ? 0 : length - this.dateRange;
          for (let k = startIndex; k < this.temp.data.country.city.plant.customer.parameters[j].plots.length; k++) {
            tempObj2[test].data[0].push(this.temp.data.country.city.plant.customer.parameters[j].plots[k].value);
            tempObj2[test].data[1].push(this.pipe.transform(this.temp.data.country.city.plant.customer.parameters[j].plots[k].time, 'dd/MMM/yy'));
          }
        }

        this.chartData = tempObj2;
        this.chartData["size"] = Object.keys(this.chartData).length;
        this.chartReady = true;
        this.message = "data.L00741"
        // this.chartData = this.chartData.chartData;
      }
    );
  }

  Previous() {
    if(this.showParameters)
      this.showParameters = !this.showParameters;
    return;
    if (this.currentContract === 0) {
      // this.currentContract = this.customer.contract.length - 1;  
      return;
    } else {
      this.numContracts[this.currentContract].hidden = true;
      this.currentContract = (this.currentContract - 1) % this.customer.length; // For some reason the mod function was not returning the proper value for -ve values, so had to add the if-else condition
    }
    this.numContracts[this.currentContract].hidden = false;
  }

  Next() {
    if(!this.showParameters)
      this.showParameters = !this.showParameters;
    return;
    if (this.currentContract == this.numberOfContracts - 1) //Change this.customer to this.customerContract.customerContract when API is fixes
      return;
    this.numContracts[this.currentContract].hidden = true;
    this.currentContract = (this.currentContract + 1) % this.numberOfContracts; //Change this.customer to this.customerContract.customerContract when API is fixes
    this.numContracts[this.currentContract].hidden = false;
  }

  toggleChartReady() {
    this.chartReady = !this.chartReady;
  }

  toggleShow(tabIndex) {
    for (let i = 0; i < 3; i++) {
      if (i == tabIndex) this.show[i] = true;
      else this.show[i] = false;
    }
  }

  goBack() {
    this.router.navigate(['/commercial/' + this.plantId]);
    return;
  }

}
