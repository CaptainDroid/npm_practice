export class Customer {
    order: number;
    customerId: number;
    plantId: number;
    createdAt: string;
    tenantId: number;

    constructor(order: number, customerId: number, plantId: number, createdAt: string, tenantId: number) {
        this.order = order;
        this.customerId = customerId;
        this.plantId = plantId;
        this.createdAt = createdAt;
        this.tenantId = tenantId;
    }
}