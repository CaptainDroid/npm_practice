import { Component, OnInit, LOCALE_ID } from '@angular/core';
import { CommercialService } from '../../services/commercial.service';
import { LineChartConfig } from '../../models/lineChartConfig';
import { ViewChild } from '@angular/core';
import { LinechartComponent } from 'src/app/components/linechart/linechart.component';
import { Chart } from 'chart.js';
import { Router } from '@angular/router';
import { DashboardService } from 'src/app/services/dashboard.service';
import { CommonService } from '../../services/common.service';
import { Customer } from './Customer';
import { DatePipe } from '@angular/common';
import { ErrorserviceService } from '../../services/errorservice.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-commercial',
  templateUrl: './commercial.component.html',
  styleUrls: ['./commercial.component.css']
})


export class CommercialComponent implements OnInit {

  isDataAvailable: boolean = false;
  /*
  ** Data for the line chart
  */
  dropdownCustomer;
  title = '';
  data: any[];
  config: LineChartConfig;
  elementId: string;

  /*
  ** Chart Data end
  */

  dateRange = 90;
  plantId;
  cityId;
  countryId;
  user;
  plantAcronym;
  dashboardData;
  plants = [];
  accessiblePlants;
  plantData;
  custData;
  selectedPlant = 0;
  allCustomers;
  selectedCustomer = {};
  //  customerChartData= [];
  customerChartData = {};
  customerData: any;
  customerDropdown = [
    {
      'name': 'Top 5 Customers',
      'value': 5
    }
  ];
  plantSelected = false;
  custSelected = false;
  numCustomers = 0;
  topCustomers = [];
  isListOpen = false;
  temp: any;
  tempObj = {};
  tempObj2 = [];
  pipe;
  changed: boolean;
  top5CustAvailable: boolean = false;
  allCustAvailable: boolean = false;
  customerOrder = [];

  emptymessage = false;

  restrictCommercialContractView = false;
  myplantsResponse: any;
  // topdefaultcust: any;
  defaultCustomersArray: any;
  topfiveCust: any;



  constructor(
    private _commonService: CommonService,
    public commService: CommercialService,
    private errorservice: ErrorserviceService,
    private _dashboardService: DashboardService, private router: Router) {
      this.plantData = null;
      // this.topdefaultcust = this.defaultcustomers();
      // tslint:disable-next-line:max-line-length
      this.restrictCommercialContractView = this._commonService.isAccess(environment.role.commercial.commercialdashboard.commercialcontractview);
     }

  ngOnInit() {
    this.pipe = new DatePipe('en-gb');
    this.changed = false;
    this.allCustomers = [];
    this.accessiblePlants = [];

    this._commonService.getplants().subscribe(
      data => {
        this.myplantsResponse = data;
        this.plants = [];
        if (this.myplantsResponse.status !== 'success') {
          this.errorservice.showerror({  type: 'error', status: this.myplantsResponse.status, statusText: this.myplantsResponse.message });
        } else {

          this.myplantsResponse.data.countries.forEach(country => {
              country.cities.forEach(citi => {
                citi.plants.forEach (plant => {
                  const plantobj = plant;
                  plantobj.countryId = country.id;
                  plantobj.cityId = citi.id;
                  this.plants.push(plantobj);
                });
              });
          });
          if (this.plants.length > 0) {
            this.selectedPlant = this.plants[0].id;
            this.getAllCustomers(this.plants[0], this.plants[0].countryId, this.plants[0].cityId, this.selectedPlant);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  preSelectPlant() {
    if (this.plants && this.plants.length) {
      const url = this.router.url.split('/');
      const prevPlantId = +url[url.length - 1];

      const index = this.plants.findIndex(element => {
        return element.id == prevPlantId;
      });

      let plant;
      if (index !== -1) {
        plant = this.plants[index];
      } else {
        plant = this.plants[0];
      }
      this.selectedPlant = plant.id;
      this.getAllCustomers(plant, plant.countryId, plant.cityId, plant.id);
    }
  }
  // Fetches the customers' information
  getTopFiveCustomers(plant, countryId, cityId, plantId) {
    this.emptymessage = false;
    this.isDataAvailable = false;
    this.plantId = plantId;
    this.cityId = cityId;
    this.countryId = countryId;
    // Setting the ids in the service to access it for charts
    this.commService.countryId = this.countryId;
    this.commService.cityId = this.cityId;
    this.commService.plantId = this.plantId;

    /**
     * Code for the data for the past 90 days from the current data
     */

    this.commService.getTopFiveCustomers(countryId, cityId, plantId).subscribe(
      data => {
        this.customerData = data;
        if (this.customerData.data === undefined) {
          return;
        }
        if (this.customerData.status !== 'success') {
          this.errorservice.showerror({
              status: this.customerData.errorCode,
              statusText: this.customerData.message
            });
        } else {

          this.top5CustAvailable = true;
          this.defaultCustomersArray = this.defaultcustomers();
          this.topfiveCust = this.customerData.data.country.city.plant.customers;
          // for (let i = 0; i < this.customerData.data.country.city.plant.customers.length; i++) {
          //   this.customerData.data.country.city.plant.customers[i].id = '' + this.customerData.data.country.city.plant.customers[i].id;
          // }
          if(this.topfiveCust.length > 0){
            let customersArray = [];
            customersArray = this.defaultCustomersArray;
            for (let i = 0; i < this.customerData.data.country.city.plant.customers.length; i++) {
              let index = this.customerData.data.country.city.plant.customers[i].order;
              customersArray[index-1] = this.customerData.data.country.city.plant.customers[i];
            }

            this.customerData['customers'] = customersArray;
            
          // Storing the chartData
          for (let c = 0; c < this.customerData['customers'].length; c++) {
            this.tempObj = {};

            this.customerData['customers'][c].id = +this.customerData['customers'][c].id;

            this.customerChartData[this.customerData['customers'][c].id] = [];
            this.tempObj2.length = 0;
            if(this.customerData['customers'][c].parameters) {
            for (let j = 0; j < this.customerData['customers'][c].parameters.length; j++) {
              this.tempObj = {};
              // tslint:disable-next-line:prefer-const
              let test = this.customerData['customers'][c].parameters[j].test;
              // tslint:disable-next-line:max-line-length
              this.customerChartData[this.customerData['customers'][c].id][this.customerData['customers'][c].parameters[j].test] = ({ 'customerId': this.customerData['customers'][c].id, 'type': '', 'data': [[], []], 'label': this.customerData['customers'][c].parameters[j].test });

              // tslint:disable-next-line:prefer-const
              let length = this.customerData['customers'][c].parameters[j].plots.length;

              // tslint:disable-next-line:max-line-length
              this.customerChartData[this.customerData['customers'][c].id][test]['type'] = this.customerData['customers'][c].parameters[j].test;
              // tslint:disable-next-line:prefer-const
              let startIndex = this.dateRange > length ? 0 : length - this.dateRange;
              for (let k = startIndex ; k < this.customerData['customers'][c].parameters[j].plots.length; k++) {
                // tslint:disable-next-line:max-line-length
                this.customerChartData[this.customerData['customers'][c].id][test].data[0].push(this.customerData['customers'][c].parameters[j].plots[k].value);
                // tslint:disable-next-line:max-line-length
                this.customerChartData[this.customerData['customers'][c].id][test].data[1].push(this.pipe.transform(this.customerData['customers'][c].parameters[j].plots[k].time, 'dd/MMM/yy'));
              }
            }
          }
            // tslint:disable-next-line:max-line-length
            this.customerChartData[this.customerData['customers'][c].id]['size'] = this.size(this.customerChartData[this.customerData['customers'][c].id]);
          }
          }else {
            this.customerData.customers = this.defaultCustomersArray;
          }
          
          this.isDataAvailable = true;
          this.plantSelected = true;
          this.getStats(5, true);
          // this.getStats(this.numCustomers, this.custSelected);
        }
      }
    );

    return this;
  }

  // Get all the customers for that plant
  getAllCustomers(plant, countryId, cityId, plantId) {
    this.allCustAvailable = false;
    this.top5CustAvailable = false;
    this.plantAcronym = plant.acronym;
    this.allCustomers.length = 0;

    this.commService.getAllCustomers(countryId, cityId, plantId).subscribe(
      data => {
        this.custData = data;
        if (this.custData.status !== 'success') {
          this.errorservice.showerror({
            status: this.custData.errorCode,
            statusText: this.custData.message
          });
        } else {
          this.allCustAvailable = true;
          this.custData = this.custData.data;
          // Process the customers for this plant from the response
          for (let i = 0; i < this.custData.countries.length; i++) {
            if (this.custData.countries[i].id === countryId) {
              for (let j = 0; j < this.custData.countries[i].cities.length; j++) {
                if (this.custData.countries[i].cities[j].id === cityId) {
                  for (let k = 0; k < this.custData.countries[i].cities[j].plants.length; k++) {
                    if (this.custData.countries[i].cities[j].plants[k].id === plantId) {
                      this.allCustomers = this.custData.countries[i].cities[j].plants[k].customer;
                      break;
                    }
                  }
                }
              }
            }
          }
          // this.getTopFiveCustomers(plant, countryId, cityId, plantId);
          this.getStats(5, true);
        }
      }
    );
    this.getEvents(plant);
    this.getTopFiveCustomers(plant, countryId, cityId, plantId);
  }

  getEvents(plant: any) {

    this.commService.getPlantsAndEvents().subscribe(
      data => {
        this.temp = data;
        if (this.temp.status !== 'success') {
          this.errorservice.showerror({
            status: this.temp.errorCode,
            statusText: this.temp.message
          });
        } else {

          this.temp.data.output.result.forEach(element => {
            element['totalEventCount'] = 0;
            element.events.forEach(event => {
              element['totalEventCount'] += event.eventCount;
            });
          });

          const plantevent = this.temp.data.output.result.filter(evt => {
            return evt.plantId === plant.id;
         });
         if (plantevent.length > 0) {
          this.plantData = plantevent[0];
        } else {
          this.plantData = null;
        }

        }
      });
  }

  // Sorts the customers' data based on some parameter and displays the Top-N
  getStats(numCustomer: number, val: boolean) {
    this.custSelected = val;
    this.numCustomers = numCustomer;

    // If the plant has not been selected yet, or the data has not been fetched for some reason
    if (this.customerData === undefined || !this.allCustAvailable || !this.top5CustAvailable) {
      return;
    }
    this.customerData.customers.sort((a, b) => a.order < b.order ? -1 : (a.order > b.order ? 1 : 0));

    if (this.numCustomers) {
      this.topCustomers.length = 0;
      for (let i = 0; i < this.allCustomers.length; i++) {
        if (i < this.numCustomers && i < this.customerData.customers.length) {
            this.topCustomers.push(this.customerData.customers[i]);

            /**
             *  STOP!
             *  PLEASE TAKE A MOMENT TO READ THIS, AS THIS MIGHT HELP SOLVE YOUR ISSUE IF YOU'RE TRYING TO DEBUG IN THIS COMPLEX MAZE!
             *  The + operator here converts the id of the customer from String(converted it to string earlier for reasons! ) to an Integer
             *  Also, note that the functions parseInt(stringNumber) can also be used
             *  In case of null values :
             *  The method used below ( + ) will give +null = 0
             *  The parseInt method will give parseInt(null) = NaN
             *  So in case you want to use the parseInt, you can check for NaN with the isNaN() function.
             *  P.S If we don't convert it to a number, the ngModel listings for the top5Customers in the template won't work as expected.
             *  Thanks for reading!
             */
            this.selectedCustomer[i] = +this.customerData.customers[i].id;

          // Assigning the customer order for each of the top5
          this.customerOrder[this.customerData.customers[i].order - 1] = this.customerData.customers[i].id;
        }
        if (this.allCustomers[i].id === undefined && this.allCustomers[i].customerId !== undefined) {
          this.allCustomers[i]['id'] = this.allCustomers[i].customerId;
          // this.allCustomers[i]['order'] = this.allCustomers.length;
        }
        // this.customerData.customers.forEach(element => {
        //   if (element.id == this.allCustomers[i].customerId) {
        //     this.allCustomers[i]['order'] = element.order;
        //   }
        // });
        // this.selectedCustomer[this.allCustomers[i].id] = this.allCustomers[i].id;
      }
    } else if (this.custSelected) {
      /*
      ** ----BUG----
      ** Assigning the customers' array to the topCustomers variable for "All Customers" gives a reference to
      ** the original data and when switching to top 'n' customers, it clears this array.
      */
      // this.topCustomers = this.customerData.customers;


      /*
      ** The following piece of code can also be merged with the above loop, by setting numCustomers equal to
      ** customerData.customers.length
      */
      this.topCustomers.length = 0;
      for (let i = 0; i < this.customerData.customers.length; i++) {
        // Checking to see if the customer already exists in the topCustomers list
        const index = this.topCustomers.findIndex( customer => {
          return customer.id === this.customerData.customers[i].id;
        });
        // If the customer has not already been added to the list of top customers, add them
        if (index === -1) {
          this.topCustomers.push(this.customerData.customers[i]);
          this.selectedCustomer[this.customerData.customers[i].id] = this.customerData.customers[i];
        }
      }
    }

    // tslint:disable-next-line:max-line-length
    this.allCustomers.sort((a, b) => a.customerAcronym.toString().toLowerCase() < b.customerAcronym.toString().toLowerCase() ? -1 : (a.customerAcronym.toString().toLowerCase() > b.customerAcronym.toString().toLowerCase() ? 1 : 0));
    this.config = new LineChartConfig(this.title, 'function', { position: 'bottom' });
    this.elementId = 'customerLineChart';
    this.emptymessage = true;
    return this;
  }

  switchCustomer(customer, index) {
    this.changed = true;
    this.commService.changed = true;


    if (!this.customerChartData[+customer.id] || this.customerChartData[+customer.id].size == 0) {
      // console.log("Getting chartdata for ", customer.id)
      this.commService.getSingleCustomerChartData(customer.id).subscribe(
        data => {
          this.tempObj = {};
          this.tempObj2.length = 0;
          this.customerChartData[customer.id] = [];
          this.temp = data;
          if (this.temp.status !== 'success') {
            // this.errorservice.showerror({
            //   status: this.temp.errorCode,
            //   statusText: this.temp.message
            // });
          } else {
            if (this.temp.data != null && this.temp.data.country.city.plant.customer.parameters) {
              for (let j = 0; j < this.temp.data.country.city.plant.customer.parameters.length; j++) {
                this.tempObj = {};
                // tslint:disable-next-line:prefer-const
                let test = this.temp.data.country.city.plant.customer.parameters[j].test;
                // tslint:disable-next-line:max-line-length
                this.customerChartData[customer.id][test] = ({ 'customerId': this.temp.data.country.city.plant.customer.customerId, "type": "", "data": [[], []], "label":  this.temp.data.country.city.plant.customer.parameters[j].test });

                this.customerChartData[customer.id][test]['type'] = this.temp.data.country.city.plant.customer.parameters[j].test;
                // tslint:disable-next-line:prefer-const
                let length = this.temp.data.country.city.plant.customer.parameters[j].plots.length;
                // tslint:disable-next-line:prefer-const
                let startIndex = this.dateRange > length ? 0 : length - this.dateRange;
                for (let k = startIndex; k < this.temp.data.country.city.plant.customer.parameters[j].plots.length; k++) {
                  // tslint:disable-next-line:max-line-length
                  this.customerChartData[customer.id][test].data[0].push(this.temp.data.country.city.plant.customer.parameters[j].plots[k].value);
                  // tslint:disable-next-line:max-line-length
                  this.customerChartData[customer.id][test].data[1].push(this.pipe.transform(this.temp.data.country.city.plant.customer.parameters[j].plots[k].time, 'dd/MMM/yy'));
                }
              }
            }
            this.customerChartData[customer.id]['size'] = this.size(this.customerChartData[customer.id])
          }
        }
      );
    }

    // this.allCustomers.forEach(element => {
    //   if (element.id !== customer.id && element.order === index + 1) {
    //     // console.log("Order of element", element.id, "changed to ", customer.order);
    //     element.order = customer.order;
    //     return;
    //   }
    // });
    // // console.log("Updating order to", index + 1)
    // customer['order'] = index + 1;
    // // tslint:disable-next-line:prefer-const
    // let tmp = customer;
    this.customerOrder[index] = customer.id;
    return this;
  }

  size(obj: Object) {
    return Object.keys(obj).length;
  }

  viewCustomerDetails(clickedCustomerId, customerChartData, allCustomers): void {

    for (let i = 0; i < this.allCustomers.length; i++) {
      if (this.allCustomers[i].id === clickedCustomerId) {
        this.commService.selectedCustomer = this.allCustomers[i];
        break;
      }
    }

    this.commService.ChartData = customerChartData;
    this.commService.allCustomers = allCustomers;
    this.commService.countryId = this.countryId;
    this.commService.cityId = this.cityId;
    this.commService.plantId = this.plantId;
    this.commService.plantAcronym = this.plantAcronym;
    this.router.navigate(['/customerDetails']);
  }

  ngOnDestroy() {

    // Checking if any change has been made, else no need to save order of customers
    if (!this.changed) {
      // console.log("No changes in customer order made.")
      return;
    }

    this.saveCustomerOrder();
  }

  saveCustomerOrder() {

    /*
    ** Creating customerOrderData for save request
    */
    // tslint:disable-next-line:prefer-const
    let customerOrderData: Array<Customer> = [];
    if (this.allCustomers && this.allCustomers.length) {
      // this.allCustomers.sort((a, b) => a.order < b.order ? -1 : (a.order > b.order ? 1 : 0));
      for (let i = 0; i < this.customerOrder.length; i++) {
        // tslint:disable-next-line:prefer-const
        let pipe = new DatePipe('en-gb');
        // tslint:disable-next-line:prefer-const
        let now = Date.now();
        // tslint:disable-next-line:prefer-const
        let date = pipe.transform(now, 'yyyy-mm-ddThh:mm:ss.sssZ');
        // console.log("Date", date)
        // console.log(this.allCustomers[i].customerAcronym, this.allCustomers[i].order, i + 1)
        // tslint:disable-next-line:prefer-const
        // let cust = new Customer(i+1, this.allCustomers[i].id, this.plantId, "2018-12-12T05:29:28.193Z", 1);
        const cust = new Customer(i + 1, this.customerOrder[i], this.plantId, '2018-12-12T05:29:28.193Z', 1);
        customerOrderData.push(cust);
      }
      customerOrderData = customerOrderData.filter(item => item.customerId);
      // Make the request to save the order of the customers when user leaves the page
      // tslint:disable-next-line:prefer-const
      let data = { 'action': 'Create', 'customerList': customerOrderData };

      this.commService.saveTopFiveCustomers(data, this.countryId, this.cityId, this.plantId).subscribe(
        (response) => {
          this.changed = false;
          this.commService.changed = false;
          this.commService.triggeredSave = false;
        },
        (err) => {
          this.changed = false;
          this.commService.changed = false;
          this.commService.triggeredSave = false;
        }
      );
      // this.commService.changed = false;
    }
  }

  defaultcustomers() {
    const collection = [];
    
    for (let i = 1; i< 6; i++) {
      let colobj = {
        'id': '',
        'customerName': '',
        'order': i,
        'parameters': []
      };
      collection.push(colobj);
    }
    return collection;
  }
}
