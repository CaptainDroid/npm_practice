import { Component, OnInit, ElementRef } from '@angular/core';
import { FormControl, Validators, NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from "@angular/router";
import { Observable } from 'rxjs';
import { ContractService } from '../../../services/contract.service';
import { CommercialService } from '../../../services/commercial.service';
import { NativeDateAdapter, DateAdapter, MAT_DATE_FORMATS } from "@angular/material";
import { AppDateAdapter, APP_DATE_FORMATS } from './date.adapter';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-customer-contract',
  templateUrl: './customer-contract.component.html',
  styleUrls: ['./customer-contract.component.css',
    '../../../../assets/css/events.css'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
  ]
})

export class CustomerContractComponent implements OnInit {

  constructor(
    private router: Router,
    private ContractService: ContractService,
    private CommercialService: CommercialService,
    private route: ActivatedRoute,
    private datePipe: DatePipe,
    private el: ElementRef
    //public data: ContractData
  ) {
    this.route.params.subscribe(params => {
      this.customerId = params.id;
    });
    this.selectedCustomer = JSON.parse(sessionStorage.getItem('selectedCustomer'));
  }

  model: any = {}
  getcontractData: any = {
    companyName: '', contractNumber: '', contractVersion: '', contractStartDate: '', contractEndDate: '', commercialModelType: null, customerSince: '', billingFrequency: null, wasteWaterDelivery: null, unitPriceRmbTon: null, downPaymentRmb: null, contact_person: '', inCharge: '', contact_number: "", email: '', supplyDate: '', tariffAdjustmentDate: '', tariffAdjustmentFormula: '', offSpecTariffFormula: '', remarks: '', treatAbilityStudy: null, startDate: '', endDate: ''
  };
  customerDetail: any = { customerName: '', plant: '', contract: '', customerAcronym: '' };
  treatabilityStudy: string;
  contractPlant: string;
  errorMessage: any;
  customerId: any;
  customerName: any;
  customerAcronym: string;
  contractNo: any;
  plantId: number;
  contractVersion: number;
  countryId: number;
  cityId: number;
  cusId: number;
  selectedCustomer: any;
  //date = new FormControl(moment().format('DD/MMM/YY'));
  val: number = 1;
  minDate = new Date();
  minEndDate: any;
  modelTypes:any;

  billingFrequency: number;

  waterDelivery: string;
  invalidEndDate: boolean = false;
  isInvalid: boolean = false;
  invalidInput: boolean = false;
  field: any;
  regex: RegExp = new RegExp(/^[0-9 +-]{0,20}$/);
  specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-'];
  invalidDownPay: boolean = false;
  invalidPrice: boolean = false;

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }


  phoneNoOnly(event){
    if (event.target.value.length == 0) {
      if (event.keyCode == 32) {
        event.preventDefault();
      }
    }
    const charCode = (event.which) ? event.which : event.keyCode;
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }
    if((!event.key.match(this.regex)) && (charCode != 187) && (charCode != 107) && (charCode != 189) && (charCode != 109) && (charCode != 32)){
      return false;
    }
    else{
      return;
    }
    // if (charCode > 31 && (charCode < 48 || charCode > 57 || charCode < 96 || charCode > 105 || charCode == 32 || charCode == 107 || charCode ==109 )) {
    //   return false;
    // }
    // return true;
  }

  ngOnInit() {

    this.customerName = this.selectedCustomer.customerName;
    this.plantId = this.selectedCustomer.plantId;
    this.contractPlant = this.selectedCustomer.plant;
    this.countryId = this.selectedCustomer.country;
    this.cityId = this.selectedCustomer.city;
    this.cusId = this.selectedCustomer.customerId;
    this.customerAcronym = this.selectedCustomer.customerAcronym;
    if(this.ContractService.goBack === "true"){
      this.getcontractData = JSON.parse(sessionStorage.getItem('contractData'));
      this.getcontractData.contractStartDate =  this.getcontractData.contractStartDate ? new Date(this.getcontractData.contractStartDate) : null;
      this.getcontractData.contractEndDate =  this.getcontractData.contractEndDate ? new Date(this.getcontractData.contractEndDate) : null;
      this.getcontractData.supplyDate =  this.getcontractData.supplyDate ? new Date(this.getcontractData.supplyDate): null;
      this.getcontractData.tariffAdjustmentDate =  this.getcontractData.tariffAdjustmentDate ? new Date(this.getcontractData.tariffAdjustmentDate) : null;
      this.getcontractData.customerSince =  this.getcontractData.customerSince ? new Date(this.getcontractData.customerSince) : null;
      // this.contractData = JSON.parse(sessionStorage.getItem('contractData'));
      this.contractNo = sessionStorage.getItem('contract');
      // this.version = JSON.parse(sessionStorage.getItem('contractVersion'));
      
    }
    if (this.customerId !== '' && this.customerId !== undefined) {

      this.ContractService.getcontractdata(this.countryId, this.cityId, this.plantId, this.customerId).subscribe(
        (data: any) => {
          if(this.ContractService.goBack !== "true"){
            this.getcontractData = data.data.country.city.plant.customer.customerContract;            
          }
          this.minEndDate = data.data.country.city.plant.customer.customerContract.contractEndDate;
          if (data.data.country.city.plant.customer.customerContract) {
            this.contractVersion = data.data.country.city.plant.customer.customerContract.contractVersion + 1;
            this.billingFrequency = data.data.country.city.plant.customer.customerContract.billingFrequency;
          }
          
        },
        (err: any) => {
          this.errorMessage = err;
        }
      );
      this.contractNo = this.selectedCustomer.contract;

    } else {
      this.contractVersion = 1;
      this.minEndDate = this.getcontractData.contractStartDate;
      //this.getcontractData = '';
      //this.contractPlant = '';
    }
    
    /*** Get model type data */

    this.CommercialService.getModelType().subscribe(data => {
      const result: any = data;
      this.modelTypes = result.data.commercialModelType;
    });
  }

  // Prevent blank space to enter intially
  onKeydown(e){
    if (e.target.value.length == 0) {
      if (e.keyCode == 32) {
          e.preventDefault();
      }
    }
  } 

  validateFloat(event, field) {
    var str = event.target.value
    // var format = /^[\.]?[\d]{1,9}(\.[\d]{1,3})?$/;
    var format = /^[\.\d]{1,9}(\.[\d]{1,})?$/;
    if(str.length > 0){
      if(!format.test(str) || str === '.0')
      { this.isInvalid = true;
        if(field === "payment"){
          this.invalidDownPay = true
        } 
        if(field === "price") {
          this.invalidPrice = true;
        }
      } else{
        if(field === "payment"){
          this.invalidDownPay = false
        } 
        if(field === "price") {
          this.invalidPrice = false;
        }
        if(this.invalidDownPay == false && this.invalidPrice == false ){
          this.isInvalid = false;
        }
      }
    }
    if(str.length === 0){
      if(field === "payment"){
        this.invalidDownPay = false
      } 
      if(field === "price") {
        this.invalidPrice = false;
      }
      if(this.invalidDownPay == false && this.invalidPrice == false ){
      this.isInvalid = false;
      }
    }
  }

  validateContract(event) {
    var format = /^[a-zA-Z0-9-_\.]*$/;
    if (this.contractNo && (this.CommercialService.validateInput(this.contractNo) || !format.test(this.contractNo))) {
      this.invalidInput = true;
    } else {
      this.invalidInput = false;
    }
  }

  handleFloat(event){
    console.log(event, this.countDecimals(event.target.value))
    if(this.countDecimals(event.target.value) > 3)
      this.getcontractData[event.target.name] = parseFloat(event.target.value).toFixed(3)
  }

  countDecimals(value) { 
    if ((value % 1) != 0) 
        return value.toString().split(".")[1].length;  
    return 0;
  }

  clearDate(val) {
    this.getcontractData[val] = null;
  }

  validateEndDate(event){
    if(Date.parse(this.getcontractData.contractEndDate) < Date.parse(this.getcontractData.contractStartDate)){
      //start is less than End
      this.invalidEndDate = true;
   }else{
     this.invalidEndDate = false;
   }
  }



  validateStartDate(event){
    if(this.getcontractData.contractEndDate != null && this.getcontractData.contractEndDate != ''){
      if(Date.parse(this.getcontractData.contractEndDate) < Date.parse(this.getcontractData.contractStartDate)){
        //start is less than End
        this.invalidEndDate = true;
     }else{
       this.invalidEndDate = false;
     }
    }
  }

  setDisabled() {
    if (this.customerId) {
      return true;
    }
    else {
      return false;
    }
  }

  onSubmit() {
    this.isInvalid = false;
    // this.invalidInput = false;
    // if (this.CommercialService.validateInput(this.contractNo)) {
    //   this.invalidInput = true;
    // }
    this.validateContract(this.contractNo);
    if (!this.getcontractData.contractStartDate || !this.getcontractData.contractEndDate) {
      this.isInvalid = true;
    }
    if (this.getcontractData.email  && !this.CommercialService.validateEmail(this.getcontractData.email)) {
      this.isInvalid = true;
    }

    if(this.invalidDownPay || this.invalidPrice){
      this.isInvalid = true;
    }

    this.invalidEndDate = false;
    if (Date.parse(this.getcontractData.contractEndDate) < Date.parse(this.getcontractData.contractStartDate)) {
      //start is less than End
      this.invalidEndDate = true;
    }
    if (this.customerName && this.contractPlant && this.contractNo && this.getcontractData.contractStartDate && this.getcontractData.contractEndDate && !this.invalidEndDate && !this.isInvalid && !this.invalidInput) {

      this.ContractService.contactData = this.getcontractData;
      const customerData = {
        customerName: this.customerName,
        plant: this.contractPlant,
        contract: this.contractNo,
        country: this.countryId,
        city: this.cityId,
        plantId: this.plantId,
        customerId: this.cusId
      }
      // this.getcontractData.contractStartDate = this.datePipe.transform(this.getcontractData.contractStartDate, 'dd/MMM/yy');
      // this.getcontractData.contractEndDate = this.datePipe.transform(this.getcontractData.contractEndDate, 'dd/MMM/yy');
      // this.getcontractData.tariffAdjustmentDate = this.datePipe.transform(this.getcontractData.tariffAdjustmentDate, 'dd/MMM/yy');
      // this.getcontractData.supplyDate = this.datePipe.transform(this.getcontractData.supplyDate, 'dd/MMM/yy');
      // this.getcontractData.customerSince = this.datePipe.transform(this.getcontractData.customerSince, 'dd/MMM/yy');
      sessionStorage.setItem('contractData', JSON.stringify(this.getcontractData));
      sessionStorage.setItem('contractVersion', JSON.stringify(this.contractVersion));
      sessionStorage.setItem('contract', this.contractNo);
      if (this.customerId) {
        this.router.navigate(['/edit-contract-spec/' + this.customerId]);
      }
      else {
        this.router.navigate(['/contract-specification']);
      }

    }

  }

}


