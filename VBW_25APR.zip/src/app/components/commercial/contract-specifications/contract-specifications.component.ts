import { Component, OnInit, Inject } from '@angular/core';
import { ContractService } from '../../../services/contract.service';
import { WorksheetService } from '../../../services/worksheet.service';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { CancelConfirmationDialogComponent } from "src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog";
import { DOCUMENT } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { identity, BehaviorSubject } from 'rxjs';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-contract-specifications',
  templateUrl: './contract-specifications.component.html',
  styleUrls: ['./contract-specifications.component.css',
    '../../../../assets/css/events.css']
})
export class ContractSpecificationsComponent implements OnInit {
  bSubject = new BehaviorSubject(false);
  model: any = {};
  contractParams: any;
  errorMessage: any;
  alltestsResponse: any;
  contract: FormGroup;
  selling_points: FormArray;
  data: Array<Object>;
  customerId: number;
  contractResonse: any;
  commercialData: any;
  customerData: any;
  contractData: any;

  customerName: any;
  contractNo: any;
  plantId: number;
  contractVersion: number;
  countryId: number;
  cityId: number;
  cusId: number;
  contractPlant: any;
  selectedCustomer: any;
  contract_name: string;

  getSpecData: any = {};

  groupList: any = [];

  alltests: any = [];

  fieldArray: any = [];
  finalArray: any = [];
  newAttribute: any = { specs_parameter: '', tagname: '', UOM: '', UOMId: '', description: '', min_value: '', normal_value: '', max_value: '' };

  specArray: any = [];

  specParamArray: any = [];

  version: number;
  isAddable: boolean = true;
  isDuplicate:boolean = false;
  validMaxValue: boolean = true;
  validTagValue: boolean = true;
  tagsData: any = [];
  greaterZero: boolean = true;
  validInput: boolean = true;

  constructor(
    private router: Router,
    public route: ActivatedRoute,
    private ContractService: ContractService,
    private worksheetService: WorksheetService,
    private errorservice: ErrorserviceService,
    @Inject(DOCUMENT) document,
    private formBuilder: FormBuilder,
    private dialog: MatDialog,
    private datePipe: DatePipe,
  ) {
    this.route.params.subscribe(params => {
      this.customerId = params.id;
    });
    this.selectedCustomer = JSON.parse(sessionStorage.getItem('selectedCustomer'));
    this.contractData = JSON.parse(sessionStorage.getItem('contractData'));
    this.contract_name = sessionStorage.getItem('contract');
    this.version = JSON.parse(sessionStorage.getItem('contractVersion'));
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  getAllTests() {
    this.ContractService.alltests().subscribe(
      (data: any) => {
        this.alltestsResponse = data;
        for(let i = 0; i < this.alltestsResponse.data.length; i++){
          let testobj = this.alltestsResponse.data[i];
          testobj.testName = this.alltestsResponse.data[i].testName;
          this.alltests.push(testobj);
        }
        const flow = [
        // {
        //   testName: "Select a parameter"
        // },
        {
          id: 44,
          testName: "Flow",
          displayName: "Flow",
          minValue: null,
          maxValue: 0,
          labrecords: null
        }]
        // this.alltests = flow.concat(this.alltests);
        this.getContractData();
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  getContractData() {
    if (this.customerId) {
      this.ContractService.getcontractdata(this.countryId, this.cityId, this.plantId, this.customerId).subscribe(
        (data: any) => {
          this.getSpecData = data.data.country.city.plant.customer.customerContract;
          if(this.ContractService.goBack !== "true"){
            this.fieldArray = data.data.country.city.plant.customer.customerContract.contractSpecifications;
          }
          else{
            this.fieldArray = JSON.parse(sessionStorage.getItem('parameterData'));
          }
          
          this.fieldArray.filter(field => {
            return this.alltests.some(test => {
              // if (field.specs_parameter === "Flow") {
              //   return [field.UOM = "cu.m/day",  field.uomId = test.uom.id];
              // }
              // else 
              if(field.specs_parameter.toLowerCase() === test.testName.toLowerCase()) {
                if(test.uom){
                  return [field.UOM = test.uom.name,  field.uomId = test.uom.id]
                }
              }
            });
          });
        },
        (err: any) => {
          this.errorMessage = err;
        }
      );

      

    } else {
      if(this.ContractService.goBack === "true"){
        this.fieldArray = JSON.parse(sessionStorage.getItem('parameterData'));
      }
      this.getSpecData = '';
    }

  }

  ngOnInit() {
    
    this.customerName = this.selectedCustomer.customerName;
    this.plantId = this.selectedCustomer.plantId;
    this.contractPlant = this.selectedCustomer.plant;
    this.contractNo = this.selectedCustomer.contract;
    this.countryId = this.selectedCustomer.country;
    this.cityId = this.selectedCustomer.city;
    this.cusId = this.selectedCustomer.customerId;

    this.getAllTests();
    
    this.groupList = [{ specs_parameter: '', tagname: '', UOM: '', description: '', minValue: '', normal: '', max_value: '' }]

    /*** To get all tags */
    
    this.ContractService.getTagNames(this.plantId).subscribe(
      (data: any) => {
        for (let m = 0; m < data.data.tags.length; m++) {
          let tagobj = data.data.tags[m];
          if(data.data.tags[m].tagName){
            tagobj.tagname = data.data.tags[m].tagName;
            this.tagsData.push(tagobj);
          }
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

  }
 
  dataSource = [];

  validateOnAdd(event, field) {
    var max = event.max_value, min = event.min_value, normal = event.normal_value;  
    if (event.specs_parameter && event.max_value) {
        this.isAddable = true;
        if ((max && isNaN(max)) || (min && isNaN(min)) || (normal && isNaN(normal))) {
          this.validInput = false      
        }
        else{
          this.validInput = true
          if(event.max_value<=0){
            this.greaterZero = false;
          } 
          else{
            this.greaterZero = true;
          }
          if(event.min_value){
            if(parseFloat(event.max_value) > parseFloat(event.min_value)){
              this.validMaxValue = true;
            }
            else{
              this.validMaxValue = false;
            }
          }
          else{
            this.validMaxValue = true;    
          }
        }        
    }
    if(field === "max"){
      if(event.specs_parameter && !event.max_value){
        this.isAddable = false;
      }else{
        this.isAddable = true;
      }
    }
  }



  onAddData() {
    if (this.newAttribute.specs_parameter && this.newAttribute.max_value) {
      if(this.newAttribute.max_value == 0){
        this.greaterZero = false;
      }
      else{
        this.greaterZero = true;
      }
      if(this.newAttribute.min_value){
        if(parseFloat(this.newAttribute.max_value) > parseFloat(this.newAttribute.min_value)){
          this.validMaxValue = true;
        }
        else{
          this.validMaxValue = false;
        }        
      }

      this.fieldArray.push(this.newAttribute)
      this.newAttribute = {};
    } else {
      this.isAddable = false;
    }
  }

  isEmpty(obj) {
    for(var key in obj) {
        if(obj[key])
            return false;
    }
    return true;
  }

  deleteParam(event, type, i){
    if(type === "old"){
      this.fieldArray.forEach((key, index)=>{
        if(i === index){
          this.fieldArray.splice(index,1)
        }
      })
      this.tagValid(this.fieldArray)
      this.isDuplicateFn(this.finalArray);
      this.arrayValidation(this.fieldArray);
    }
    else{
      this.newAttribute = { specs_parameter: '', tagname: '', UOM: '', UOMId: 0, description: '', min_value: '', normal_value: '', max_value: '' }      
      this.isDuplicateFn(this.newAttribute);
      this.arrayValidation(this.newAttribute);
      this.tagValid(this.fieldArray)
    }
  }

  arrayValidation(array){
    this.greaterZero = true;
    this.validMaxValue = true;
    this.validInput = true; 
    this.isAddable = true;
    this.fieldArray.forEach((obj, index)=>{
      var max = obj.max_value, min = obj.min_value, normal = obj.normal_value;
      if (obj.max_value && obj.specs_parameter) {
        if(obj.max_value == 0){
          this.greaterZero = false;
        }
        if ((max && isNaN(max)) || (min && isNaN(min)) || (normal && isNaN(normal))) {
          this.validInput = false      
        }
       
        if(obj.min_value){
          if(parseFloat(obj.max_value) <= parseFloat(obj.min_value)){
            this.validMaxValue = false;
          }
        }
      }
      if(!obj.specs_parameter || !obj.max_value){
        if(obj.max_value === 0){
          this.greaterZero = false;
        }
      }
      if(!obj.max_value && obj.specs_parameter){
        this.isAddable = false;
      }
    });
  }

  validateIfDuplicate(uom, id){
    /** For populating uom - Starts */
    this.isAddable = true;
    var uomVal: string, uomId: number;
    // if (uom === "Flow") {
    //   uomVal = "cu.m/day";
    //   uomId = -1;

    //   // this.newAttribute.UOM = "cu.m/day";
    // }
    // else {
      this.validTagValue = true;
      for (let item of this.alltests) {
        if (item.testName === uom && item.uom) {
          uomVal = item.uom.name;
          uomId = item.uom.id;
          // this.newAttribute.UOM = item.uom.name; 
        }
      }
    // }
    if (id >= 0) {
      this.fieldArray.forEach((key, index) => {
        if (id == index) {
          key.uomId = uomId
          key.UOM = uomVal;
        }
      })
    } else {
      if (uom !== "Flow") {
        this.newAttribute.tagname = ""
      }
      this.newAttribute.UOM = uomVal;
      this.newAttribute.uomId = uomId;
    }
    /** For populating uom - ends */
    var temp_array = [];
    temp_array = this.fieldArray.concat(this.newAttribute);
    var valueArr = temp_array.map(function (item) { return item.specs_parameter });
    var duplicate = valueArr.some(function (item, idx) {
      return valueArr.indexOf(item) != idx
    });
    this.isDuplicate = duplicate;
  }

  isDuplicateFn = function(inputArray) {
    var temp_array = [];
    temp_array = this.fieldArray.concat(this.newAttribute);
    var valueArr = temp_array.map(function(item){ return item.specs_parameter });
    var duplicate = valueArr.some(function(item, idx){ 
        return valueArr.indexOf(item) != idx 
    });
    this.isDuplicate = duplicate;
    return duplicate;
  }

  goBack(){
    var temp_array = [];
    if(!this.isEmpty(this.newAttribute)){
      temp_array = this.fieldArray.concat(this.newAttribute);
    }
    else{
      temp_array = this.fieldArray;
    }
    this.ContractService.goBack = "true";
    sessionStorage.setItem('parameterData', JSON.stringify(temp_array));
    if(this.customerId){
      this.router.navigate(["/edit-contract/"+this.customerId]);
    } 
    else{
      this.router.navigate(["/customer-contract/"]);
    }    
  }


  onSubmit() {
    if(!this.isEmpty(this.newAttribute)){
      if(this.newAttribute.specs_parameter){
        if(this.newAttribute.max_value){
          if(this.newAttribute.max_value == 0){
            this.greaterZero = false;
          }
          else{
            this.greaterZero = true;
          }
          if(this.newAttribute.min_value){
            if(parseFloat(this.newAttribute.max_value) > parseFloat(this.newAttribute.min_value)){
              this.validMaxValue = true;  
            }
            else{
              this.validMaxValue = false;
            } 
          }
          this.finalArray = this.fieldArray.concat(this.newAttribute);
        } else{
          this.isAddable = false; 
        }
      } 
      else if((!this.newAttribute.specs_parameter) && (this.newAttribute.max_value)){
        this.isAddable = false; 
      }
      else if((!this.newAttribute.specs_parameter) && (!this.newAttribute.max_value)){
        this.isAddable = true; 
        this.finalArray = this.fieldArray;
      }    
    }      
    else{
      this.finalArray = this.fieldArray;
      this.isAddable = true;         
    }
    this.isDuplicateFn(this.finalArray)
    if (this.finalArray.length > 0){   
      var action, custId: number, contract_name: string, contractNo: number;
      if (this.customerId) {
        action = "Update";
        custId = this.customerId;
        contract_name = this.contract_name;
        contractNo = this.contractData.customerContractId;

      } else {
        action = "Create";
        custId = this.cusId
        contract_name = this.contract_name
        contractNo = 0;
      }

      var spec = [{ contractSpecificationEntryId: '', customerContractId: '', UOM: '', description: '', minValue: '', normal: '', maxValue: '' }], param;


      if (this.finalArray.length < 1) {        
        if(this.newAttribute.max_value && this.newAttribute.specs_parameter) {
            var rObj = {};
            rObj['contractSpecificationEntryId'] = 0;
            rObj['customerContractId'] = contractNo;
            rObj['paramCode'] = this.newAttribute.specs_parameter;
            rObj['tagName'] = this.newAttribute.tagname;
            rObj['uomid'] = this.newAttribute.uomId ? this.newAttribute.uomId : null;
            rObj['description'] = this.newAttribute.description;
            rObj['minValue'] = this.newAttribute.min_value;
            rObj['maxValue'] = this.newAttribute.max_value;
            rObj['normal'] = this.newAttribute.normal_value;
            rObj['createdBy'] = 2;
            rObj['createdDate'] = '';
            rObj['updatedBy'] = 2;
            rObj['updateddate'] = '';

            reformattedArray = rObj
        }
      } else {
        
        var reformattedArray = this.finalArray.map(obj =>{  
          if(obj.max_value && obj.specs_parameter){
            if(parseFloat(obj.max_value) === 0){
              this.greaterZero = false; 
            }
            if(obj.min_value){
              if(parseFloat(obj.max_value) <= parseFloat(obj.min_value)){
                this.validMaxValue = false;
              }
                           
              // else{
              //   this.validMaxValue = false;
              // }
            }
            if(obj.specs_parameter === "Flow"){
              this.tagValid(obj)
            } 
            // this.isAddable = true;
          }
          if(!obj.specs_parameter || !obj.max_value){
            if(parseFloat(obj.max_value) == 0){
              this.greaterZero = false;
            }
            else{
              this.isAddable = false;
            }
          }
          var rObj = {};
          rObj['contractSpecificationEntryId'] = obj.contractSpecificationEntryID ? obj.contractSpecificationEntryID : 0;
          rObj['customerContractId'] = contractNo;
          rObj['paramCode'] = obj.specs_parameter;
          rObj['tagName'] = obj.tagname;
          rObj['uomid'] = obj.uomId ? obj.uomId : '';
          rObj['description'] = obj.description;
          rObj['minValue'] = obj.min_value;
          rObj['maxValue'] = obj.max_value;
          rObj['normal'] = obj.normal_value;
          rObj['createdBy'] = 2;
          rObj['createdDate'] = '';
          rObj['updatedBy'] = 2;
          rObj['updateddate'] = '';
          return rObj;
       });
      }
      // return true;
      this.specArray = reformattedArray;

      this.commercialData = {
        action: action,
        customerContractId: contractNo,
        customerId: custId,
        plantId: this.selectedCustomer.plantId,
        inCharge: this.contractData.inCharge ? this.contractData.inCharge.trim() : null,
        contactPerson: this.contractData.contact_person ? this.contractData.contact_person.trim() : null,
        contractName: contract_name,
        contractVersion: this.version,
        contactNo: this.contractData.contact_number ? this.contractData.contact_number.trim() : null,
        contractStartDate: this.datePipe.transform(this.contractData.contractStartDate, 'dd/MMM/yy'),
        email: this.contractData.email ? this.contractData.email.trim() : null,
        contractEndDate: this.datePipe.transform(this.contractData.contractEndDate, 'dd/MMM/yy'),
        supplyDate: this.datePipe.transform(this.contractData.supplyDate, 'dd/MMM/yy'),
        commercialModelType: this.contractData.commercialModelType,
        tariffAdjustmentDate: this.datePipe.transform(this.contractData.tariffAdjustmentDate, 'dd/MMM/yy'),
        customerSince: this.datePipe.transform(this.contractData.customerSince, 'dd/MMM/yy'),
        tariffAdjustmentFormula: this.contractData.tariffAdjustmentFormula ? this.contractData.tariffAdjustmentFormula.trim() : null,
        billingFrequency: this.contractData.billingFrequency,
        offSpecTariffFormula: this.contractData.offSpecTariffFormula ? this.contractData.offSpecTariffFormula.trim() : "",
        wasteWaterDelivery: this.contractData.wasteWaterDelivery,
        remarks: this.contractData.remarks ? this.contractData.remarks.trim() : null,
        treatAbilityStudy: this.contractData.treatAbilityStudy,
        unitPriceRmbTon: this.contractData.unitPriceRmbTon,
        downPaymentRmb: this.contractData.downPaymentRmb,
        tariffAmount: 0,
        createdBy: 2,
        createdAt: "",
        updatedBy: 2,
        updatedAt: "",
        tenantId: 1,
        contractSpec: this.specArray
      }
      if((this.isAddable) && (!this.isDuplicate) && (this.validMaxValue) && (this.validTagValue) && (this.greaterZero) && (this.validInput)){
        this.ContractService.postContract(this.commercialData, this.selectedCustomer.country, this.selectedCustomer.city, this.selectedCustomer.plantId, custId).subscribe(
          resonse => {
            this.contractResonse = resonse;
            if (this.contractResonse.status == 'success') {
              this.errorservice.showerror({ type: 'Info', status: resonse['status'], statusText: 'data.L00488' });
              this.router.navigate(["/customerList"]);
            } else {
              this.errorservice.showerror(
                {
                  status: this.contractResonse.errorCode,
                  statusText: this.contractResonse.message
                });
            }
          },
          (err: any) => {
            console.log(err);
          }
        );
      }
    }
    else{
      this.isAddable = false;
    }
    // if(this.newAttribute.specs_parameter &&
    //   !this.newAttribute.max_value) {
    //   this.isAddable = false;
    //   console.log(this.isAddable);
    // }
  }
  onCancel() {
    // this.router.navigate(['/customerList']);

    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'customerList' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  tagValid(event){
    if(!event){
      this.validTagValue = true;
      return true;
    } 
    if(event && !event.tagname){
      this.validTagValue = true;
      return true;
    }
    var valid = this.tagsData.some(item => {
      if(event.tagname === item.tagname){
        this.validTagValue = true;
        return true;
      }
      else{
        this.validTagValue = false;
        return false;
      } 
      // return this.validTagValue
    })
  }

  onChange(uom, id) {
    // this.isDuplicateFn(this.fieldArray)
    this.isAddable = true;
    var uomVal: string, uomId: number, tagname: any;
    // if (uom === "Flow") {
    //   uomVal = "cu.m/day";
    //   uomId = -1;
    //   // this.newAttribute.UOM = "cu.m/day";
    // }
    // else {
      this.validTagValue = true;
      for (let item of this.alltests) {
        if (item.testName === uom && item.uom) {
          uomVal = item.uom.name;
          uomId = item.uom.id;
          tagname = ""
          // this.newAttribute.UOM = item.uom.name; 
        }
      }
    // }
    if (id >= 0) {
      this.fieldArray.forEach((key, index) => {
        if((key.specs_parameter === "Flow")){
          uomId = -1;
          if((key.tagname !== "")){
            this.tagValid(key)
          }          
        }
        if (id == index) {
          key.uomId = uomId
          key.UOM = uomVal;
          key.tagname = ""
        }
      })
    } else {
      if (uom !== "Flow") {
        this.newAttribute.tagname = ""
      }
      this.newAttribute.UOM = uomVal;
      this.newAttribute.UOMId = uomId;
    }
  }
}
