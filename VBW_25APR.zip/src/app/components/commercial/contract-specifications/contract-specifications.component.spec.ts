import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractSpecificationsComponent } from './contract-specifications.component';

describe('ContractSpecificationsComponent', () => {
  let component: ContractSpecificationsComponent;
  let fixture: ComponentFixture<ContractSpecificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContractSpecificationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractSpecificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
