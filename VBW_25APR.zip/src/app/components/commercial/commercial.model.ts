export class Contract {
    public CustomerContractId: number;
    public CustomerId: number;
    public plantId: number;
    public ContractName: string;
    public ContractVersion: number;
    public ContractStartDate: string;
    public ContractEndDate: string;
    public CommercialModelType: string;
    public CustomerSince: string;
    public BillingFrequency: string;
    public WasteWaterDelivery: string;
    public UnitPrice: string;
    public DownPayment: string;
    public PersonInCharge: string;
    public ContactPerson: string;
    public ContactNo: string;
    public Email: string;
    public SupplyDate: string;
    public TariffAmount: string;
    public TariffAdjustmentDate: string;
    public TariffAdjustmentFormula: string;
    public OffSpecTariffFormula: string;
    public Remarks: string;
    public TreatAbilityStudy: boolean;
    public CreatedBy: string;
    public CreatedAt: string;
    public UpdateBy: string;
    public UpdatedAt: string;
    public TenantId: number;

    constructor(
      CustomerContractId: number,
      CustomerId: number,
      plantId: number,
      ContractName: string,
      ContractVersion: number,
      ContractStartDate: string,
      ContractEndDate: string,
      CommercialModelType: string,
      CustomerSince: string,
      BillingFrequency: string,
      WasteWaterDelivery: string,
      UnitPrice: string,
      DownPayment: string,
      PersonInCharge: string,
      ContactPerson: string,
      ContactNo: string,
      Email: string,
      SupplyDate: string,
      TariffAmount: string,
      TariffAdjustmentDate: string,
      TariffAdjustmentFormula: string,
      OffSpecTariffFormula: string,
      Remarks: string,
      TreatAbilityStudy: boolean,
      CreatedBy: string,
      CreatedAt: string,
      UpdateBy: string,
      UpdatedAt: string,
      TenantId: number ) {

      this.CustomerContractId= CustomerContractId;
      this.CustomerId= CustomerId;
      this.plantId= plantId;
      this.ContractName= ContractName;
      this.ContractVersion= ContractVersion;
      this.ContractStartDate= ContractStartDate;
      this.ContractEndDate= ContractEndDate;
      this.CommercialModelType= CommercialModelType;
      this.CustomerSince= CustomerSince;
      this.BillingFrequency= BillingFrequency;
      this.WasteWaterDelivery= WasteWaterDelivery;
      this.UnitPrice= UnitPrice;
      this.DownPayment= DownPayment;
      this.PersonInCharge= PersonInCharge;
      this.ContactPerson= ContactPerson;
      this.ContactNo= ContactNo;
      this.Email= Email;
      this.SupplyDate= SupplyDate;
      this.TariffAmount= TariffAmount;
      this.TariffAdjustmentDate= TariffAdjustmentDate;
      this.TariffAdjustmentFormula= TariffAdjustmentFormula;
      this.OffSpecTariffFormula= OffSpecTariffFormula;
      this.Remarks= Remarks;
      this.TreatAbilityStudy= TreatAbilityStudy;
      this.CreatedBy= CreatedBy;
      this.CreatedAt= CreatedAt;
      this.UpdateBy= UpdateBy;
      this.UpdatedAt= UpdatedAt;
      this.TenantId= TenantId
        }

}
