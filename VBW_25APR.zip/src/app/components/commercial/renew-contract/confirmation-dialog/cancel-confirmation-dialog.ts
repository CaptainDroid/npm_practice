import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ContractService } from '../../../../services/contract.service';
import { CommercialService } from '../../../../services/commercial.service';
 import { ErrorserviceService } from 'src/app/services/errorservice.service';
 import { FormControl, FormGroup } from '@angular/forms';

@Component({
    selector: 'cancel-confirmation-dialog',
    templateUrl: '../confirmation-dialog/cancel-confirmation-dialog.html',
    styleUrls: ['../../../../../assets/css/events.css']
})
export class CloseContractDialogComponent implements OnInit {
    contractResonse: any;
    popupForm: FormGroup;


    constructor(
        private router: Router,
        public dialogRef: MatDialogRef<CloseContractDialogComponent>,
        private contractService: ContractService,
        private commercialService: CommercialService,
        private errorservice: ErrorserviceService,
        @Inject(MAT_DIALOG_DATA) public data) {
    }


    onNoClick(): void {
        this.dialogRef.close();
    }
    onYesClick(): void {
        this.dialogRef.close();
        this.contractService.postContract(this.data.contractData, this.data.countryId,
            this.data.cityId, this.data.plantId, this.data.customerId).subscribe(
            resonse => {
                this.contractResonse = resonse;
                if (this.contractResonse.status !== 'Success') {
                    this.errorservice.showerror(
                      { status: this.contractResonse.errorCode,
                        statusText: this.contractResonse.message
                      });
                } else {
                    this.errorservice.showerror(
                        { status: this.contractResonse.errorCode,
                          statusText: this.contractResonse.message
                        });
                    this.router.navigate(['/customerList']);
                }
            },
            (err: any) => {
                console.log(err);
            }
          );
    }

    ngOnInit() {
    this.popupForm = new FormGroup({
        reason: new FormControl()
     });
    }
}
