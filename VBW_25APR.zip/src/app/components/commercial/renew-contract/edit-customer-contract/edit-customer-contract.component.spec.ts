import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCustomerContractComponent } from './edit-customer-contract.component';

describe('EditCustomerContractComponent', () => {
  let component: EditCustomerContractComponent;
  let fixture: ComponentFixture<EditCustomerContractComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCustomerContractComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCustomerContractComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
