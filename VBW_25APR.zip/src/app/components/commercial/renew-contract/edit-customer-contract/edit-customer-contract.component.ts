import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CancelConfirmationDialogComponent } from 'src/app/components/events-and-alerts/confirmation-dialog/cancel-confirmation-dialog';
import { Observable } from 'rxjs';
import { ContractService } from '../../../../services/contract.service';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { CommercialService } from '../../../../services/commercial.service';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { ExcelService } from 'src/app/services/excel.service';

import { AppDateAdapter, APP_DATE_FORMATS } from 'src/app/components/commercial/customer-contract/date.adapter';
import { CloseContractDialogComponent } from '../confirmation-dialog/cancel-confirmation-dialog';
import { DatePipe } from '@angular/common';
import { isNull } from 'util';
import { Variable } from '@angular/compiler/src/render3/r3_ast';

@Component({
  selector: 'app-customer-contract',
  templateUrl: './edit-customer-contract.component.html',
  styleUrls: ['./edit-customer-contract.component.css',
    '../../../../../assets/css/events.css'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }
  ]
})

export class EditCustomerContractComponent implements OnInit {

  editCustomerForm: FormGroup;
  editContarctSpecForm: FormGroup;
  selectedCustomer: any;
  companyName = new FormControl();
  customerDetailsForm: FormGroup;

  fieldArray: any = [];
  newAttribute: any = { specs_parameter: '',
  tagname: '', UOM: '', UOMId: 0, description: '', min_value: '', normal_value: '', max_value: '' };
  finalArray: any = [];
  contract_name: any;
  specArray: any = [];
  contractResonse: any;

  data: any;
  isvalidPhoneNumber = true;
  isvalidEmail = true;
  popupStatus: boolean;
  isAddable = true;
  validMaxValue = true;
  minDate = new Date();
  invalidEndDate = false;
  isInvalid = false;
  isDuplicate = false;
  startDate: any;
  endDate: any;
  tariffAdjustmentDate: any;
  supplyDate: any;
  customerSinceDate: any;
  modelTypes: any;
  validTagValue = true;
  tagsData: any = [];

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private contractService: ContractService,
    private commercialService: CommercialService,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private errorservice: ErrorserviceService,
    private excelService: ExcelService,
    private datePipe: DatePipe
  ) {
    this.route.params.subscribe(params => {
      this.customerId = params.id;
    });
    this.selectedCustomer = JSON.parse(sessionStorage.getItem('selectedCustomer'));
    this.contract_name = sessionStorage.getItem('contract');

  }

  model: any = {};
  getcontractData: any = { companyName: '', contractNumber: '', contractVersion: '', contractStartDate: '',
  contractEndDate: '', commercialModelType: '', customerSince: '', billingFrequency: '',
  wasteWaterDelivery: '', unitPrice: '', downPayment: '', inCharge: '', contactPerson: '',
  contactNumber: '', email: '', supplyDate: '', tariffAdjustmentDate: '', tariffAdjustmentFormula: '',
  offSpecTariffFormula: '', remarks: '', treatabilityStudy: '' };
  customerDetail: any = { customerName: '', plant: '', contract: '' };
  // treatabilityStudy: string;
  contractPlant: string;
  errorMessage: any;
  customerId: any;
  customerName: any;
  contractNo: any;
  contractVersion: number;
  plantId: number;
  countryId: number;
  cityId: number;
  cusId: number;
  customerAcronym: string;
  new_specs_parameter: any;
  new_tag: string;
  new_UOM: string;
  new_description: string;
  new_min_value: number;
  new_normal_value: number;
  new_max_value: number;
  alltests: any = [];
  alltestsResponse: any;
  countries = [];
  tasks = [];
  wasteWaterDelivery: any;
  contractId: any;
  plantDataresponce: any;
  plants: any;
  processId: any;
  commercialData: any;
  customerStatus: boolean;
  contractStatus: boolean;
  production: any;
  countryName: any;
  plant: any;
  description: any;
  waterVolume: number;
  industry: any;
  field: any;
  isExpired: boolean;
  validInput = true;
  submitted = false;
  invalidInput = false;
  // customerProduction: any;
  // billFreq: any;
  // treatabilityStudy: any;
  // wasteWaterDeliveryValues: any;

  companyProduct = [];

  mainPollutants = [];
  materials = [];
  customerProcess = [];
  industries = [];


  customerProduction = {
    1759: 'Batch',
    1764: 'Continuous'
  };

  billFreq = {
    1771: 'One-off',
    1768: 'Monthly',
    1773: 'Quarterly',
    1758: 'Annually',
    1760: 'Biannually'
  };
  treatabilityStudy = {
    1778: 'Yes',
    1770: 'No'
  };
  wasteWaterDeliveryValues = {
    1765: 'Dedicated pipe',
    1762: 'Common pipe',
    1777: 'Trucked',
    878: 'Common pipe + Dedicated pipe'
  };


  billingFrequency: string;
  frequency: string[] = ['One Off', 'Monthly', 'Quarterly', 'Annually'];

  waterDelivery: string;
  water: string[] = ['Dedicated Pipe', 'Common Pipe', 'Trucked'];
  regex: RegExp = new RegExp(/^[0-9 +-]{0,20}$/);
  specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-'];
  invalidPhone = false;
  greaterZero = true;

  invalidDownPay = false;
  invalidPrice = false;



  validation_messages = {
    'customerName': [
      { type: 'required', message: 'data.L00502' },
      { type: 'minLength', message: 'data.L00711' },
      { type: 'maxlength', message: 'data.L00712' },
      { type: 'pattern', message: 'data.L00502' },
      { type: 'alpha', message: 'data.L00520' },
    ],
    // 'countryId': [
    //   { type: 'required', message: 'data.L00479' },
    // ],
    'countryName': [
      { type: 'required', message: 'data.L00479' },
    ],
    'plantId': [
      { type: 'required', message: 'data.L00286' },
    ],
    'plant': [
      { type: 'required', message: 'data.L00286' },
    ],
    'companyProduct': [
      { type: 'required', message: 'data.L00502' }
    ],
    'mncOrLocal': [
      { type: 'required', message: 'data.L00502' }
    ],
    'industry': [
      { type: 'required', message: 'data.L00502' }
    ],
    'description': [
      { type: 'required', message: 'data.L00502' },
      { type: 'minlength', message: 'data.L00452' },
      { type: 'maxlength', message: 'data.L00714' },
      { type: 'pattern', message: 'data.L00502' },
      { type: 'alpha', message: 'data.L00520' },

    ],
    'descriptionCn': [
      { type: 'required', message: 'data.L00502' },
      { type: 'minlength', message: 'data.L00452' },
      { type: 'maxlength', message: 'data.L00714' },
      { type: 'pattern', message: 'data.L00502' },

    ],
    'mainPollutant': [
      { type: 'required', message: 'data.L00502' }
    ],
    'productionCapacity': [
      { type: 'required', message: 'data.L00502' },
      { type: 'maxlength', message: 'data.L00716' },
      { type: 'float', message: 'data.L00520' },
      // { type: 'pattern', message: 'Please enter a positive value' }
    ],
    'processId': [
      { type: 'required', message: 'data.L00502' }
    ],
    'preTreatment': [
      { type: 'required', message: 'data.L00502' },
      { type: 'minlength', message: 'data.L00466' },
      { type: 'maxlength', message: 'data.L00716' },
      { type: 'pattern', message: 'data.L00502' },

    ],
    'rawMaterials': [
      { type: 'required', message: 'data.L00502' }
    ],
    'remarks': [
      { type: 'required', message: 'data.L00502' },
      { type: 'minlength', message: 'data.L00466' },
      { type: 'maxlength', message: 'data.L00588' },
      { type: 'pattern', message: 'data.L00502' },
    ],
    'production': [
      { type: 'required', message: 'data.L00502' }
    ],
    'waterVolumeM3Day': [
      { type: 'maxlength', message: 'data.L00721' }
    ],
    'waterVolume': [
      { type: 'required', message: 'data.L00502' },
      // { type: 'pattern', message: 'Please enter a positive value' },
      { type: 'maxlength', message: 'data.L00721' },
      { type: 'float', message: 'data.L00520' },
    ],
    'concentrationOfMainComponents': [
      { type: 'required', message: 'data.L00502' },
      // { type: 'pattern', message: 'Please enter a positive value' },
      { type: 'maxlength', message: 'data.L00721' },
      { type: 'float', message: 'data.L00520' },
    ],
  };

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  decemalNumber(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode !== 46) {
      return false;
    }
    return true;
  }

  phoneNoOnly(event) {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }
    if ((!event.key.match(this.regex)) && (charCode !== 187) && (charCode !== 107) &&
    (charCode !== 189) && (charCode !== 109) && (charCode !== 32)) {
      return false;

    } else {
      return;
    }
  }

  tagValid(event) {
    if (!event) {
      this.validTagValue = true;
      return true;
    }
    if (event && !event.tagname) {
      this.validTagValue = true;
      return true;
    }
    this.tagsData.some(item => {
      if (event.tagname === item.tagname) {
        this.validTagValue = true;
        return true;
      } else {
        this.validTagValue = false;
        return false;
      }
      // return this.validTagValue
    });
  }

  validateIfDuplicate(uom, id) {
    /** For populating uom - Starts */
    this.isAddable = true;
    let uomVal: string, uomId: number, tagname: any;
      this.validTagValue = true;
      for (const item of this.alltests) {
        if (item.testName === uom && item.uom) {
          uomVal = item.uom.name;
          uomId = item.uom.id;
          tagname = '';
          // this.newAttribute.UOM = item.uom.name;
        }
      }
    // }
    if (id >= 0) {
      this.fieldArray.forEach((key, index) => {
        if ((key.specs_parameter === 'Flow')) {
          uomId = -1;
          if ((key.tagname !== '')) {
            this.tagValid(key);
          }
        }
        if (id === index) {
          key.uomId = uomId;
          key.UOM = uomVal;
          key.tagname = '';
        }
      });
    } else {
      if (uom !== 'Flow') {
        this.newAttribute.tagname = '';
      }
      this.newAttribute.UOM = uomVal;
      this.newAttribute.uomId = uomId;
    }
    /** For populating uom - ends */
    let temp_array = [];
    temp_array = this.fieldArray.concat(this.newAttribute);
    const valueArr = temp_array.map(function (item) { return item.specs_parameter; });
    const duplicate = valueArr.some(function (item, idx) {
      return valueArr.indexOf(item) !== idx;
    });
    this.isDuplicate = duplicate;
  }

  getAllTests() {
    this.contractService.alltests().subscribe(
      (data: any) => {
        this.alltestsResponse = data;
        for (let i = 0; i < this.alltestsResponse.data.length; i++) {
          const testobj = this.alltestsResponse.data[i];
          testobj.testName = this.alltestsResponse.data[i].testName;
          this.alltests.push(testobj);
        }
        const flow = [{
          id: 1,
          testName: 'Flow',
          displayName: 'Flow',
          minValue: null,
          maxValue: 0,
          labrecords: null
        }];
        // this.alltests = flow.concat(this.alltests);
        this.getContractDetails();
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  getContractDetails() {
    if (this.contractId) {

      this.contractService.getcontractdata(this.countryId, this.cityId, this.plantId, this.customerId).subscribe(
        (data: any) => {
          this.getcontractData = data.data.country.city.plant.customer.customerContract;
          if (data.data.country.city.plant.customer.customerContract) {
            this.contractVersion = data.data.country.city.plant.customer.customerContract.contractVersion;
            this.billingFrequency = data.data.country.city.plant.customer.customerContract.billingFrequency;

            let endDate = data.data.country.city.plant.customer.customerContract.contractEndDate;
            const CurrentDate = new Date();
            endDate = new Date(endDate);

            if (endDate > CurrentDate) {
                this.isExpired = false;
            } else {
              this.isExpired = true;
            }
          }

          this.fieldArray = data.data.country.city.plant.customer.customerContract.contractSpecifications;

          this.fieldArray.filter(specs => {
            return this.alltests.some(test => {
              if (specs.specs_parameter === test.testName) {
                if (test.uom) {
                  return [specs.UOM = test.uom.name, specs.uomId = test.uom.id];
                }
              }
            });
          });
        },
        (err: any) => {
          this.errorMessage = err;
        }
      );
      this.contractNo = this.selectedCustomer.contract;

    } else {
      this.contractVersion = 1;
      // this.getcontractData = '';
      // this.contractPlant = '';
    }
  }

  ngOnInit() {

    this.customerName = this.selectedCustomer.customerName;
    this.plantId = this.selectedCustomer.plantId;
    this.contractPlant = this.selectedCustomer.plant;
    this.countryId = this.selectedCustomer.country;
    this.cityId = this.selectedCustomer.city;
    this.cusId = this.selectedCustomer.customerId;
    this.customerAcronym = this.selectedCustomer.customerAcronym;
    this.contractId = this.selectedCustomer.contractId;
    this.popupStatus = true;

    this.getAllTests();

    /* Plant drop down service*/
    this.commercialService.getPlants().subscribe(data => {
      this.plantDataresponce = data;
      this.plants = [];
      if (this.plantDataresponce.status !== 'success') {
        this.errorservice.showerror({ status: this.plantDataresponce.status, statusText: this.plantDataresponce.message });
      } else {
        for (let i = 0; i < this.plantDataresponce.data.countries.length; i++) {
          // if(this.plantDataresponce.data.countries[i].id == country){
          for (let j = 0; j < this.plantDataresponce.data.countries[i].cities.length; j++) {
            for (let k = 0; k < this.plantDataresponce.data.countries[i].cities[j].plants.length; k++) {
              const plantobjList = this.plantDataresponce.data.countries[i].cities[j].plants[k];
              plantobjList.cityId = this.plantDataresponce.data.countries[i].cities[j].id;
              plantobjList.id = this.plantDataresponce.data.countries[i].cities[j].plants[k].id;
              plantobjList.acronymName = this.plantDataresponce.data.countries[i].cities[j].plants[k].acronym;
              this.plants.push(plantobjList);
            }
          }
          // }
        }
      }
    });

    /*** Get Customer contract Data */

    this.commercialService.getcustomerData(this.countryId, this.cityId, this.plantId, this.cusId).subscribe(data => {
      const result: any = data;
      let isMnc, cusProduction;
      if (Array.isArray(result.data.country.city.plant.result.isMnc)) {
        isMnc = result.data.country.city.plant.result.isMnc[0];
      }
      if (Array.isArray(result.data.country.city.plant.result.custProdInBatch)) {
        cusProduction = result.data.country.city.plant.result.custProdInBatch[0];
      }
      this.customerDetailsForm.controls['plant'].setValue(result.data.country.city.plant.result.plantId);
      this.customerDetailsForm.controls['companyProduct'].setValue(result.data.country.city.plant.result.companyproducts);
      this.customerDetailsForm.controls['mncOrLocal'].setValue(isMnc);
      this.customerDetailsForm.controls['description'].setValue(result.data.country.city.plant.result.description.en);
      this.customerDetailsForm.controls['descriptionCn'].setValue(result.data.country.city.plant.result.description.cn);
      this.customerDetailsForm.controls['productionCapacity'].setValue(result.data.country.city.plant.result.customerProductionCapacity);
      this.customerDetailsForm.controls['processId'].setValue(result.data.country.city.plant.result.customerProcess);
      this.customerDetailsForm.controls['preTreatment'].setValue(result.data.country.city.plant.result.preTreatment);
      this.customerDetailsForm.controls['rawMaterials'].setValue(result.data.country.city.plant.result.rawmaterials);
      this.customerDetailsForm.controls['waterVolume'].setValue(result.data.country.city.plant.result.waterVolume);
      this.customerDetailsForm.controls['concentrationOfMainComponents'].
      setValue(result.data.country.city.plant.result.concentrationOfMainComponent);
      this.customerDetailsForm.controls['acronym'].setValue(this.customerAcronym);
      this.customerDetailsForm.controls['companyProduct'].setValue(result.data.country.city.plant.result.companyProducts);
      this.customerDetailsForm.controls['industry'].setValue(result.data.country.city.plant.result.industry);
      this.customerDetailsForm.controls['mainPollutant'].setValue(result.data.country.city.plant.result.mainPollutants);
      this.customerDetailsForm.controls['remarks'].setValue(result.data.country.city.plant.result.remarks);
      this.customerDetailsForm.controls['production'].setValue(cusProduction);
      this.customerDetailsForm.controls['countryName'].setValue(result.data.country.city.plant.result.countryId);

    });

    /* Get parameter service*/
    this.commercialService.getParameters().subscribe((data: any) => {
      this.mainPollutants = data.data.mainPollutants;
      this.companyProduct = data.data.companyProduct;
      this.customerProcess = data.data.customerProcess;
      this.materials = data.data.rawMaterials;
      this.industries = data.data.industry;
    });


    /*** Get model type data */

    this.commercialService.getModelType().subscribe(data => {
      const result: any = data;
      this.modelTypes = result.data.commercialModelType;
    });


    /*** Get countries list */
    this.commercialService.getCountries().subscribe(data => {
      const result: any = data;
      this.countries = result.data.countries;
    });

    /*** To get all tags */

    this.contractService.getTagNames(this.plantId).subscribe(
      (data: any) => {
        for (let m = 0; m < data.data.tags.length; m++) {
          const tagobj = data.data.tags[m];
          if (data.data.tags[m].tagName) {
            tagobj.tagname = data.data.tags[m].tagName;
            this.tagsData.push(tagobj);
          }
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

    /**
     * Form Data
     */
    this.editCustomerForm = this.formBuilder.group({
      companyName: [{ value: '' }, Validators.required],
      customerAcronym: ['', Validators.required],
      contractPlant: ['', Validators.required],
      contractNo: ['', Validators.required],
      contractStartDate: ['', Validators.required],
      contractVersion: ['', Validators.required],
      contractEndDate: ['', Validators.required],
      commercialModelType: '',
      customerSince: ['', Validators.required],
      billingFrequency: 0,
      wasteWaterDelivery: 0,
      unitPrice: 0,
      downPayment: 0,
      inCharge: '',
      contactPerson: '',
      contactNumber: 0,
      email: '',
      supplyDate: '',
      tariffAdjustmentDate: '',
      tariffAdjustmentFormula: '',
      offSpecTariffFormula: '',
      remarks: '',
      treatabilityStudy: 0
    });

    this.editContarctSpecForm = this.formBuilder.group({
      specs_parameter: '',
      tagname: '',
      UOM: '',
      description: '',
      min_value: '',
      normal_value: 0,
      max_value: '',
      new_specs_parameter: '',
      new_tag: '',
      new_UOM: '',
      new_description: '',
      new_min_value: 0,
      new_normal_value: 0,
      new_max_value: 0
    });

    this.customerDetailsForm = this.formBuilder.group({
      id: '',
      custProdInBatch: '',
      industry: '',
      otherComponents: '',
      contractId: '',
      contract: '',
      contractEndDate: '',
      customerName: new FormControl('', [this.alphanumericValidation, Validators.pattern(/^(?!\s*$).+/), Validators.required]),
      acronym: new FormControl({ value: '', disabled: true }),
      companyProduct: new FormControl('', [Validators.required]),
      countryName: new FormControl('', [Validators.required]),
      plant: new FormControl('', [Validators.required]),
      description: new FormControl('', Validators.compose([this.alphanumericValidation, Validators.pattern(/^(?!\s*$).+/),
        Validators.maxLength(255), Validators.minLength(3), Validators.required])),
      descriptionCn: new FormControl('', Validators.compose([Validators.pattern(/^(?!\s*$).+/),
        Validators.maxLength(255), Validators.minLength(3), Validators.required])),
      mainPollutant: new FormControl('', [Validators.required]),
      productionCapacity: new FormControl('', Validators.compose([this.floatNumber, Validators.required])),
      processId: new FormControl('', [Validators.required]),
      preTreatment: new FormControl('', Validators.compose([Validators.pattern(/^(?!\s*$).+/),
        Validators.maxLength(200), Validators.minLength(3), Validators.required])),
      rawMaterials: new FormControl('', [Validators.required]),
      mncOrLocal: new FormControl('', [Validators.required]),
      production: new FormControl('', [Validators.required]),
      remarks: new FormControl('', Validators.compose([Validators.pattern(/^(?!\s*$).+/),
        Validators.maxLength(255), Validators.minLength(3), Validators.required])),
      waterVolume: new FormControl('', Validators.compose([this.floatNumber, Validators.required])),
      concentrationOfMainComponents: new FormControl('', Validators.compose([this.floatNumber,
        Validators.maxLength(20), Validators.required])),
    });

    this.customerDetailsForm.controls['customerName'].setValue(this.customerName);


  }

  getDisabledVer() {
    if (this.customerId !== '' && this.customerId !== undefined) {
      return false;
    } else {
      return true;
    }
  }

  onAddData() {
    this.isAddable = true;
    if (this.newAttribute.specs_parameter && this.newAttribute.max_value) {
      if (this.newAttribute.max_value === '0') {
        this.greaterZero = false;
      } else {
        this.greaterZero = true;
      }
      if (this.newAttribute.min_value) {
        if (this.newAttribute.min_value) {
          if (parseFloat(this.newAttribute.max_value) > parseFloat(this.newAttribute.min_value)) {
            this.validMaxValue = true;
          } else {
            this.validMaxValue = false;
          }
        }
      }
      this.fieldArray.push(this.newAttribute);
      this.newAttribute = {};
    } else {
      this.isAddable = false;
    }
  }

  clearDate(val) {
    this.getcontractData[val] = null;
  }

  onChange(uom, id) {
    this.isAddable = true;
    let uomVal: string, uomId: number, tagname: any;
      this.validTagValue = true;
      for (const item of this.alltests) {
        if (item.testName === uom && item.uom) {
          uomVal = item.uom.name;
          uomId = item.uom.id;
          tagname = '';
          // this.newAttribute.UOM = item.uom.name;
        }
      }
    // }
    if (id >= 0) {
      this.fieldArray.forEach((key, index) => {
        if ((key.specs_parameter === 'Flow') && (key.tagname !== '')) {
          this.tagValid(key);
        }
        if (id == index) {
          key.uomId = uomId;
          key.UOM = uomVal;
          key.tagname = '';
        }
      });
    } else {
      if (uom !== 'Flow') {
        this.newAttribute.tagname = '';
      }
      this.newAttribute.UOM = uomVal;
      this.newAttribute.uomId = uomId;
    }
  }

  isEmpty(obj) {
    for (const key in obj) {
      if (obj[key]) {
        return false;
      }
    }
    return true;
  }

  isDuplicateFn = function (inputArray) {
    let temp_array = [];
    temp_array = this.fieldArray.concat(this.newAttribute);
    const valueArr = temp_array.map(function (item) { return item.specs_parameter; });
    const duplicate = valueArr.some(function (item, idx) {
      return valueArr.indexOf(item) != idx;
    });
    this.isDuplicate = duplicate;
    return duplicate;
  };

  validateEndDate(event) {
    if (Date.parse(this.getcontractData.contractEndDate) < Date.parse(this.getcontractData.contractStartDate)) {
      // start is less than End
      this.invalidEndDate = true;
    } else {
      this.invalidEndDate = false;
    }
  }

  validateStartDate(event) {
    if (this.getcontractData.contractEndDate != null) {
      if (Date.parse(this.getcontractData.contractEndDate) < Date.parse(this.getcontractData.contractStartDate)) {
        // start is less than End
        this.invalidEndDate = true;
      } else {
        this.invalidEndDate = false;
      }
    }
  }

  validateIfAddable(event, field) {
    const max = event.max_value, min = event.min_value, normal = event.normal_value;
    if (event.specs_parameter && event.max_value) {
      this.isAddable = true;
      if ((max && isNaN(max)) || (min && isNaN(min)) || (normal && isNaN(normal))) {
        this.validInput = false;
      } else {
        this.validInput = true;
        if (event.max_value <= 0) {
          this.greaterZero = false;
        } else {
          this.greaterZero = true;
        }
        if (event.min_value) {
          if (parseFloat(event.max_value) > parseFloat(event.min_value)) {
            this.validMaxValue = true;
          } else {
            this.validMaxValue = false;
          }
        } else {
          this.validMaxValue = true;
        }
      }
    }
    if (field === 'max') {
      if (event.specs_parameter && !event.max_value) {
        this.isAddable = false;
      } else {
        this.isAddable = true;
      }
    }
  }

  deleteParam(event, type, i) {
    if (type === 'old') {
      this.fieldArray.forEach((key, index) => {
        if (i === index) {
          this.fieldArray.splice(index, 1);
        }
      });
      this.tagValid(this.fieldArray);
      this.isDuplicateFn(this.fieldArray);
      this.arrayValidation(this.fieldArray);
    } else {
      this.newAttribute = { specs_parameter: '', tagname: '', UOM: '', UOMId: 0, description: '',
       min_value: '', normal_value: '', max_value: '' };
      this.validTagValue = true;
      this.isDuplicateFn(this.newAttribute);
      this.arrayValidation(this.newAttribute);
    }
  }

  arrayValidation(array) {
    this.isAddable = true;
    this.greaterZero = true;
    this.validMaxValue = true;
    this.validInput = true;
    this.fieldArray.forEach((obj, index) => {
      const max = obj.max_value, min = obj.min_value, normal = obj.normal_value;
      if (obj.max_value && obj.specs_parameter) {
        if (obj.max_value == 0) {
          this.greaterZero = false;
        }
        if ((max && isNaN(max)) || (min && isNaN(min)) || (normal && isNaN(normal))) {
          this.validInput = false;
        }

        if (obj.min_value) {
          if (parseFloat(obj.max_value) <= parseFloat(obj.min_value)) {
            this.validMaxValue = false;
          }
        }
      }
      if (!obj.specs_parameter || !obj.max_value) {
        if (obj.max_value === 0) {
          this.greaterZero = false;
        }
      }
      if (!obj.max_value && obj.specs_parameter) {
        this.isAddable = false;
      }
    });
  }

  validateFloat(event, field) {
    const str = event.target.value;
    const format = /^[\.]?[\d]{1,9}(\.[\d]{1,})?$/;
    if (str.length > 0) {
      if (!format.test(str) || str === '.0') {
        this.isInvalid = true;
        if (field === 'payment') {
          this.invalidDownPay = true;
        }
        if (field === 'price') {
          this.invalidPrice = true;
        }
      } else {
        if (field === 'payment') {
          this.invalidDownPay = false;
        }
        if (field === 'price') {
          this.invalidPrice = false;
        }
        if (this.invalidDownPay === false && this.invalidPrice === false ) {
          this.isInvalid = false;
        }
      }
    }
    if (str.length === 0) {
      if (field === 'payment') {
        this.invalidDownPay = false;
      }
      if (field === 'price') {
        this.invalidPrice = false;
      }
      if (this.invalidDownPay === false && this.invalidPrice === false ) {
      this.isInvalid = false;
      }
    }
  }

  floatNumber(control: FormControl) {
    // var format = /^[\.]?[\d]{1,9}(\.[\d]{1,3})?$/;
    const format = /^[\.\d]{1,9}(\.[\d]{1,})?$/;
    if (control.value.length > 0) {
      if (control.value === '.' || control.value === '.0' || !format.test(control.value)) {
        return {
          float: true
        };
      }
    }
    return null;
  }

  alphanumericValidation(control: FormControl) {
    const format = /^[a-zA-Z][a-zA-Z0-9-_\s!@#$%^&*(),.?"';:{}|<>+=]*$/;
    if (control.value.trim().length > 0) {
      if (!format.test(control.value)) {
        return {
          alpha: true
        };
      }
    }
    return null;
  }

  // Prevent blank space to enter intially
  onKeydown(e) {
    if (e.target.value.length === 0) {
      if (e.keyCode === 32) {
          e.preventDefault();
      }
    }
  }

  handleFloat(event, form) {
    if (this.countDecimals(event.target.value) > 3) {
      if (form === 'customer') {
        this.customerDetailsForm.controls[event.target.attributes.formcontrolname.nodeValue].
        setValue(parseFloat(event.target.value).toFixed(3));
      } else {
        this.getcontractData[event.target.name] = parseFloat(event.target.value).toFixed(3);
      }
    }
  }

  countDecimals(value) {
    if ((value % 1) !== 0) {
        return value.toString().split('.')[1].length;
    }
    return 0;
  }

  restrictChinese(e) {
    const value = e.target.value;
    this.onKeydown(e);
    // let res = value.toString().match(/^[\x00-\x7F\(\)]+$/);
    // if(res)
    //   console.log("match")
    // else console.log("Miss")
  }

  onSubmit(action) {
    this.submitted = true;
    const formValue = this.customerDetailsForm.value;
    this.isInvalid = false;
    if (this.contractId) {
      if ((this.getcontractData.contractStartDate == null) || (this.getcontractData.contractEndDate == null) || (this.contractNo == null)) {
        this.isInvalid = true;
      }
      if (this.getcontractData.email && !this.commercialService.validateEmail(this.getcontractData.email)) {
        this.isInvalid = true;
      }
    }

    if (this.customerDetailsForm.invalid) {
      this.isInvalid = true;
    }

    this.invalidEndDate = false;
    if (Date.parse(this.getcontractData.contractEndDate) < Date.parse(this.getcontractData.contractStartDate)) {
      // start is less than End
      this.invalidEndDate = true;
    }


    const today = new Date();

    if (!this.isEmpty(this.newAttribute)) {
      if (this.newAttribute.specs_parameter) {
        if (this.newAttribute.max_value) {
          if (this.newAttribute.max_value == 0) {
            this.greaterZero = false;
          } else {
            this.greaterZero = true;
          }
          if (this.newAttribute.min_value) {
            if (parseFloat(this.newAttribute.max_value) > parseFloat(this.newAttribute.min_value)) {
              this.validMaxValue = true;
            } else {
              this.validMaxValue = false;
            }
          }
          this.finalArray = this.fieldArray.concat(this.newAttribute);
        } else {
          this.isAddable = false;
        }
      } else if ((!this.newAttribute.specs_parameter) && (this.newAttribute.max_value)) {
        this.isAddable = false;
      } else if ((!this.newAttribute.specs_parameter) && (!this.newAttribute.max_value)) {
        this.isAddable = true;
        this.finalArray = this.fieldArray;
      }
    } else {
      this.finalArray = this.fieldArray;
      this.isAddable = true;
    }
    this.isDuplicateFn(this.finalArray);

    let endDate;

    let reformattedArray;
    const apiData = {
      action: 'Update',
      customerId: this.customerId,
      plantId: this.plantId,
      acronym: this.customerAcronym,
      customerName: formValue.customerName ? formValue.customerName.trim() : null,
      countryId: formValue.countryName,
      industry: formValue.industry,
      mncLocal: formValue.mncOrLocal,
      productionCapacity: formValue.productionCapacity,
      preTreatment: formValue.preTreatment ? formValue.preTreatment.trim() : null,
      remark: formValue.remarks ? formValue.remarks.trim() : null,
      production: formValue.production,
      otherComponents: null,
      waterVolumeM3Day: parseFloat(formValue.waterVolume),
      concentrationOfMainComponent: parseFloat(formValue.concentrationOfMainComponents),
      createdBy: 2,
      createdAt: '',
      updatedAt: '',
      tenantId: 1,
      updatedBy: 2,
      descriptionEn: formValue.description ? formValue.description.trim() : null,
      descriptionCn: formValue.descriptionCn ? formValue.descriptionCn.trim() : null,
      companyProducts: formValue.companyProduct,
      customerProcesses: formValue.processId,
      rawMaterials: formValue.rawMaterials,
      mainpollutants: formValue.mainPollutant
    };
    if (this.finalArray.length < 1) {

      // var reformattedArray = this.finalArray.map(obj =>{
      const rObj = {};
      rObj['contractSpecificationEntryId'] = 0;
      rObj['customerContractId'] = this.getcontractData.customerContractId;
      rObj['paramCode'] = this.newAttribute.specs_parameter;
      rObj['tagName'] = this.newAttribute.tagname;
      rObj['uomid'] = this.newAttribute.uomId ? this.newAttribute.uomId : null;
      rObj['description'] = this.newAttribute.description;
      rObj['minValue'] = this.newAttribute.min_value;
      rObj['maxValue'] = this.newAttribute.max_value;
      rObj['normal'] = this.newAttribute.normal_value;
      rObj['createdBy'] = 2;
      rObj['createdDate'] = '';
      rObj['updatedBy'] = 2;
      rObj['updateddate'] = '';

      reformattedArray = rObj;
      // return rObj;
      //  });
    } else {

      reformattedArray = this.finalArray.map(obj => {
        if (obj.max_value && obj.specs_parameter) {
          if (obj.max_value == 0) {
            this.greaterZero = false;
          }

          if (obj.min_value) {
            if (parseFloat(obj.max_value) <= parseFloat(obj.min_value)) {
              this.validMaxValue = false;
            }
            // else{
            //   this.validMaxValue = true;
            // }
          }
          if (obj.specs_parameter === 'Flow') {
            this.tagValid(obj);
          }
          // this.isAddable = true;
        }
        if (!obj.specs_parameter || !obj.max_value) {
          if (obj.max_value == 0) {
            this.greaterZero = false;
          } else {
            this.isAddable = false;
          }
        }
        const rObj = {};
        rObj['contractSpecificationEntryId'] = obj.contractSpecificationEntryID ? obj.contractSpecificationEntryID : 0;
        rObj['customerContractId'] = this.getcontractData.customerContractId;
        rObj['paramCode'] = obj.specs_parameter;
        rObj['tagName'] = obj.tagname;
        rObj['uomid'] = obj.uomId ? obj.uomId : null;
        rObj['description'] = obj.description;
        rObj['minValue'] = obj.min_value;
        rObj['maxValue'] = obj.max_value;
        rObj['normal'] = obj.normal_value;
        rObj['createdBy'] = 2;
        rObj['createdDate'] = '';
        rObj['updatedBy'] = 2;
        rObj['updateddate'] = '';
        return rObj;
      });
    }
    let actionMsg;
    this.specArray = reformattedArray;
    if (action === 'close') {
      endDate = today;
      actionMsg = 'Close';
    } else {
      endDate = this.getcontractData.contractEndDate;
      actionMsg = 'Update';
    }
    this.startDate = this.datePipe.transform(this.getcontractData.contractStartDate, 'dd/MMM/yy');
    this.endDate = this.datePipe.transform(endDate, 'dd/MMM/yy');
    this.tariffAdjustmentDate = this.datePipe.transform(this.getcontractData.tariffAdjustmentDate, 'dd/MMM/yy');
    this.supplyDate = this.datePipe.transform(this.getcontractData.supplyDate, 'dd/MMM/yy');
    this.customerSinceDate = this.datePipe.transform(this.getcontractData.customerSince, 'dd/MMM/yy');
    this.commercialData = {
      action: actionMsg,
      customerContractId: this.getcontractData.customerContractId,
      customerId: this.customerId,
      plantId: this.selectedCustomer.plantId,
      inCharge: this.getcontractData.inCharge ? this.getcontractData.inCharge.trim() : null,
      contactPerson: this.getcontractData.contact_person ? this.getcontractData.contact_person.trim() : null,
      contractName: this.contractNo,
      contractVersion: this.contractVersion,
      contactNo: this.getcontractData.contact_number ? this.getcontractData.contact_number.trim() : null,
      contractStartDate: this.startDate,
      email: this.getcontractData.email ? this.getcontractData.email.trim() : null,
      contractEndDate: this.endDate,
      supplyDate: this.supplyDate,
      commercialModelType: this.getcontractData.commercialModelType,
      tariffAdjustmentDate: this.tariffAdjustmentDate,
      customerSince: this.customerSinceDate,
      tariffAdjustmentFormula: this.getcontractData.tariffAdjustmentFormula ? this.getcontractData.tariffAdjustmentFormula.trim() : null,
      billingFrequency: this.getcontractData.billingFrequency,
      offSpecTariffFormula: this.getcontractData.offSpecTariffFormula ? this.getcontractData.offSpecTariffFormula.trim() : '',
      wasteWaterDelivery: this.getcontractData.wasteWaterDelivery,
      remarks: this.getcontractData.remarks ? this.getcontractData.remarks.trim() : null,
      treatAbilityStudy: this.getcontractData.treatAbilityStudy,
      unitPriceRmbTon: this.getcontractData.unitPriceRmbTon,
      downPaymentRmb: this.getcontractData.downPaymentRmb,
      tariffAmount: 0,
      createdBy: 2,
      createdAt: '',
      updatedBy: 2,
      updatedAt: '',
      tenantId: 1,
      contractSpec: this.specArray
    };

    var customerStatus: boolean, contractStatus: boolean;

    if ((action === 'close') && (!this.invalidEndDate) && (!this.isInvalid) && (!this.isDuplicate)
    && (this.isAddable) && (this.validMaxValue) && (this.validTagValue) && (this.greaterZero) && (this.validInput)) {
      const dialogRef = this.dialog.open(CloseContractDialogComponent, {
        width: '400px',
        data: { customerData: apiData, customerId: this.customerId, contractData: this.commercialData,
          countryId: this.countryId, cityId: this.cityId, plantId: this.plantId }
      });
      dialogRef.afterClosed().subscribe(result => {
      });
    }
    if (action === 'download') {
      const downloadData = {
        'customerContractId': this.getcontractData.customerContractId,
        'customerId': this.customerId,
        'plantId': this.selectedCustomer.plantId,
        'contractName': this.contractNo
      };
      this.contractService.downloadContract(downloadData).subscribe(
        resonse => {
          this.contractResonse = resonse;
          if (this.contractResonse.status === 'success') {
            if (this.popupStatus) {
              const array = [];
              for (let i = 0; i < this.finalArray.length; i++) {
                const finalArray = {
                  // Contract_Specification_Entry_ID: this.finalArray[i].contractSpecificationEntryID,
                  'Specs Parameter': this.finalArray[i].specs_parameter,
                  'Tag Name': this.finalArray[i].tagname,
                  'UOM': this.finalArray[i].uom,
                  'Description': this.finalArray[i].description,
                  'Max Value': this.finalArray[i].max_value,
                  'Min Value': this.finalArray[i].min_value,
                  'Normal Value': this.finalArray[i].normal_value,
                  // UOM_ID: this.finalArray[i].uomId
                };
                // array.push(finalArray, this.getcontractData, formValue);
                array.push(finalArray);

                var newData = array;
              }

              const contractData = this.getcontractData;
              const formValues = formValue;

              /**
              *  CODE FOR THE EXPORT DATA TO EXCEL FEATURE DATA FORMATTING
              */

              const cDetails = {};
              cDetails['Customer Name'] = formValues.customerName;
              cDetails['Customer Acronym'] = this.customerAcronym;
              cDetails['Customer Origin'] = formValues.countryName;

              cDetails['Company Product'] = '';
              cDetails['Plant'] = this.contractPlant;
              cDetails['MNC or Local'] = formValues.mncOrLocal;
              cDetails['Industry'] = formValues.industry;
              cDetails['Description in English'] = formValues.description;
              cDetails['Description In Chinese'] = formValues.descriptionCn;
              cDetails['Main Pollutants'] = '';
              cDetails['Customer Production Capacity'] = formValues.productionCapacity;
              cDetails['Customer Processes'] = '';
              cDetails['Pretreatment'] = formValues.preTreatment;
              cDetails['Customer Remark'] = formValues.remarks;
              cDetails['Customer Production'] = this.customerProduction[formValues.production];
              cDetails['Water Volume'] = formValues.waterVolume;
              cDetails['Concentration Of Main Component'] = formValues.concentrationOfMainComponents;


              const contractDetails = {};
              contractDetails['Contract'] = this.contractNo;
              contractDetails['Contract Version'] = contractData.contractVersion;
              contractDetails['Start Date'] = this.datePipe.transform(contractData.contractStartDate, 'dd/MMM/yy');
              contractDetails['End Date'] = this.datePipe.transform(contractData.contractEndDate, 'dd/MMM/yy');
              contractDetails['Commercial Model Type'] = contractData.commercialModelType;
              contractDetails['Customer Since'] = this.datePipe.transform(contractData.customerSince, 'dd/MMM/yy');
              contractDetails['Billing Frequency'] = this.billFreq[contractData.billingFrequency];
              contractDetails['Waste Water Delivery'] = this.wasteWaterDeliveryValues[contractData.wasteWaterDelivery];
              contractDetails['Unit Price'] = contractData.unitPriceRmbTon;
              contractDetails['Down Payment'] = contractData.downPaymentRmb;
              contractDetails['In Charge'] = contractData.inCharge;
              contractDetails['Contact Person'] = contractData.contact_person;
              contractDetails['Contact Number'] = contractData.contact_number;
              contractDetails['Email'] = contractData.email;
              contractDetails['Supply Date'] = this.datePipe.transform(contractData.supplyDate, 'dd/MMM/yy');
              contractDetails['Tariff Adjustment Date'] = this.datePipe.transform(contractData.tariffAdjustmentDate, 'dd/MMM/yy');
              contractDetails['Tariff Adjustment Formula'] = contractData.tariffAdjustmentFormula;
              contractDetails['Off-Spec Tariff Formula'] = contractData.offSpecTariffFormula;
              contractDetails['Contract Remarks'] = contractData.remarks;
              contractDetails['Treatability Study'] = this.treatabilityStudy[contractData.treatAbilityStudy];



              // Mapping the ids of the raw materials from the selected values to their names
              const mat = [];
              formValue.rawMaterials.forEach(element => {
                this.materials.forEach(material => {
                  if (element == material.paramid) {
                    mat.push(material.paramvalue);
                  }
                });
              });
              cDetails['Raw Materials'] = '';
              let l = mat !== undefined ? mat.length : 0;
              for (let i = 0; i < l; i++) {
              cDetails['Raw Materials'] += i < (l - 1) ? mat[i].toString() + ', ' : mat[i].toString();
              }

              // Mapping the ids of the processId from the selected values to their names
              const proc = [];
              formValue.processId.forEach(element => {
                this.customerProcess.forEach(item => {
                  if (element == item.paramid) {
                    proc.push(item.paramvalue);
                  }
                });
              });
              cDetails['Customer Processes'] = '';
              l = proc !== undefined ? proc.length : 0;
              for (let i = 0; i < l; i++) {
              cDetails['Customer Processes'] += i < (l - 1) ? proc[i].toString() + ', ' : proc[i].toString();
              }


              // Mapping the ids of the main Pollutants from the selected values to their names
              const mainPolltnt = [];
              formValue.mainPollutant.forEach(element => {
                this.mainPollutants.forEach(item => {
                  if (element == item.paramid) {
                    mainPolltnt.push(item.paramvalue);
                  }
                });
              });
              cDetails['Main Pollutants'] = '';
              l = mainPolltnt !== undefined ? mainPolltnt.length : 0;
              for (let i = 0; i < l; i++) {
              cDetails['Main Pollutants'] += i < (l - 1) ? mainPolltnt[i].toString() + ', ' : mainPolltnt[i].toString();
              }

              // Mapping the ids of the company products from the selected values to their names
              const companyProd = [];
              formValue.companyProduct.forEach(element => {
                this.companyProduct.forEach(item => {
                  if (element == item.paramid) {
                    companyProd.push(item.paramvalue);
                  }
                });
              });
              cDetails['Company Product'] = companyProd;
              cDetails['Company Product'] = '';
              l = companyProd !== undefined ? companyProd.length : 0;
              for (let i = 0; i < l; i++) {
              cDetails['Company Product'] += i < (l - 1) ? companyProd[i].toString() + ', ' : companyProd[i].toString();
              }

              // Mapping the ids for it being an Mnc or Local
              const mncOrLocal = {
                1767: 'MNC',
                1766: 'Local'
              };
              cDetails['MNC or Local'] = mncOrLocal[formValue.mncOrLocal];

              // Mapping the industry from the id to the name from the industries list
              var ind = formValue.industry;
              this.industries.forEach(industry => {
                if (industry.paramid == formValue.industry) {
                  ind = industry.paramvalue;
                  return;
                }
              });
              if (ind == 0) { ind = ''; }
              cDetails['Industry'] = ind;


              // Mapping the country from the id to the name from the countries list
              var cntry = formValue.countryName;
              this.countries.forEach(country => {
                if (country.id == formValue.countryName) {
                  cntry = country.name;
                  return;
                }
              });
              cDetails['Customer Origin'] = cntry;

              // Mapping the plant from the plant id to the name
              var plnt = formValue.plant;
              this.plants.forEach(plant => {
                if (plant.id == formValue.plant) {
                  plnt = plant.acronym;
                  return;
                }
              });
              cDetails['Plant'] = plnt;

              // Mapping the commercialModelType from the id to the name
              var mdlType = contractData.commercialModelType;
              this.modelTypes.forEach(model => {
                if (model.paramId == contractData.commercialModelType) {
                  mdlType = model.paramValue;
                  return;
                }
              });
              contractDetails['Commercial Model Type'] = mdlType;




              this.data = [];
              if (newData && newData.length) {
                this.data = [{...cDetails, ...contractDetails, ...newData.splice(0, 1)[0]}];
              } else { this.data = [{...cDetails, ...contractDetails}]; }
              this.data.push(...newData);

              this.exportAsXLSX();
            }
          } else {
            // this.contractStatus = true;
            this.errorservice.showerror(
              {
                status: this.contractResonse.errorCode,
                statusText: this.contractResonse.message
              });
          }
        },
        (err: any) => {
          console.log(err);
        }
      );
    } else {
      if (this.contractId) {
        if (this.finalArray.length < 1) {
          this.isAddable = false;
        } else {
          this.isAddable = true;
        }
      }
      endDate = this.getcontractData.contractEndDate;
      if ((action === 'update') && (!this.invalidEndDate) && (!this.isInvalid) && (!this.isDuplicate)
      && (this.isAddable) && (this.validMaxValue) && (this.validTagValue) && (this.greaterZero) && (this.validInput)) {
        this.commercialService.editCustomer(this.countryId, this.cityId, this.plantId, apiData).subscribe(
          (data: any) => {

            if (!this.contractId) {
              if (data['status'] === 'success') {
                this.errorservice.showerror({ type: 'Info', status: data['status'], statusText: 'data.L00795' });
                this.popupStatus = false;
              } else {
                this.errorservice.showerror({ type: 'Error', status: data['status'], statusText: data['message'] });

              }
            }

            this.router.navigate(['/customerList']);
            this.customerStatus = true;
          },
          (err: any) => {
            console.log('Failed');
          }
        );

        if (this.contractId && (!this.isDuplicate) && (this.isAddable)) {
          this.contractService.postContract(this.commercialData, this.selectedCustomer.country,
            this.selectedCustomer.city, this.selectedCustomer.plantId, this.customerId).subscribe(
            resonse => {
              this.contractResonse = resonse;
              if (this.contractResonse.status === 'success') {
                if (this.popupStatus) {
                  this.errorservice.showerror({ type: 'Info', status: resonse['status'], statusText: 'data.L00795' });
                }
                this.router.navigate(['/customerList']);
              } else {
                // this.contractStatus = true;
                this.errorservice.showerror(
                  {
                    status: this.contractResonse.errorCode,
                    statusText: this.contractResonse.message
                  });
              }
            },
            (err: any) => {
              console.log(err);
            }
          );
        }
      }
      if (contractStatus && customerStatus) {
        this.router.navigate(['/customerList']);
      }
    }

  }

  exportAsXLSX(): void {
    this.excelService.exportAsExcelFile(this.data, this.customerName + '_' + this.contractNo + '_' + this.contractVersion);
  }
  /**
  * Cancel Confirmation Dialog
  */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(CancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'customerList' }
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

}


