﻿import { Injectable, NgZone } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AdalService } from 'adal-angular4';
import { AuthenticationService } from '../../services/authentication.service';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(
      private authenticationService: AuthenticationService,
      private _zone: NgZone,
      private adal: AdalService, private router: Router, private translate: TranslateService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot, ) {
      if (sessionStorage.getItem('token')) {
        return true;
      }
     // this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
     this.router.navigate(['/login']);
     return false;
    }
}
