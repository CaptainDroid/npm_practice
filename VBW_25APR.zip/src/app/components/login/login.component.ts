﻿import { Component, OnInit, Renderer2, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';

import { AlertService } from '../../services/alert.service';
import { AuthenticationService } from '../../services/authentication.service';
import { ErrorserviceService } from '../../services/errorservice.service';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '../../../environments/environment';
import { CommonService } from '../../services/common.service';

@Component(
  {
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
  })
export class LoginComponent implements OnInit, AfterViewInit {
  loginForm: any;
  loading = false;
  submitted = false;
  returnUrl: string;
  loginResponse: any;
  isAdal = environment.enableAdalLogin;
  loginConfig = environment.loginConfig;

  isResponseErr = false;
  emptyvalid = false;
  errMsg: any;
  forgotpasswordResponse: any;

  showLoginForm = false;

  // Forgot password defines
  showforgotpwd = false;
  frpwdInvalid: any;
  fpMsg: any;
  frpwdSuccess: any;
  fpobj = {
    username: ''
  };

  step: any;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    public commonservice: CommonService,
    private authenticationService: AuthenticationService,
    private alertService: AlertService,
    private errorservice: ErrorserviceService,
    public renderer: Renderer2,
    private translate: TranslateService) {
    this.frpwdInvalid = false;
    this.frpwdSuccess = false;
    this.fpMsg = '';
    this.step = 1;
    this.loginForm = {
      un: '',
      pd: '',
    };
  }

  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }
  ngAfterViewInit() {
    const usernameField = this.renderer.selectRootElement('#username');
    setTimeout(() => usernameField.focus(), 10);
  }
  onSubmit() {
    const username = this.loginForm.un;
    let password = this.loginForm.pd;
    this.emptyvalid = false;
    this.submitted = true;
    this.isResponseErr = false;

    if (this.step === 1) {
      if (username === '') {
        this.emptyvalid = true;
        this.errMsg = 'Please enter your username';
        return;
      }
      password = '';
    } else if (this.step === 2) {
      if (password === '') {
        this.emptyvalid = true;
        this.errMsg = 'Please enter your password';
        return;
      }
    }
    this.loading = true;
    this.authenticationService.login(username, password)
      .subscribe(
        data => {
          this.loginResponse = data;
          this.loading = false;
          this.submitted = false;
          if (this.loginResponse.status) {
            if (this.loginResponse.status.toLowerCase() === 'failure') {
              this.isResponseErr = true;
              this.errMsg = this.loginResponse.message;
            } else {
              if (this.step === 1) {
                if (this.loginResponse.data === 'REGR') {
                  this.step = 2;
                  setTimeout(() => {
                    const passwordField = this.renderer.selectRootElement('#password');
                    passwordField.focus();
                  }, 10);
                } else if (this.loginResponse.data === 'CORP') {
                  this.adallogin();
                } else {
                  this.isResponseErr = true;
                  // this.errMsg = this.loginResponse.data;
                  this.errMsg = 'Invalid login credentials';
                }
              } else if (this.step === 2) {
                let jwtToken = null;
                jwtToken = this.loginResponse.data;
                const userInfo = this.commonservice.decodeJWT(jwtToken);
                this.commonservice.setUser(userInfo);
                sessionStorage.setItem('token', jwtToken);
                const defaultlang = (userInfo.typ) ? userInfo.typ : '1';
                this.translate.setDefaultLang(defaultlang);
                this.translate.use(defaultlang);
                this.router.navigate([this.returnUrl]);
              }
            }
          }
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }
  adallogin() {
    this.authenticationService.adallogin();
  }

  back() {
    this.step = 1;
    const usernameField = this.renderer.selectRootElement('#username');
    setTimeout(() => usernameField.focus(), 20);
  }

  showlogin() {
    this.showLoginForm = (this.showLoginForm === true) ? false : true;
  }
  // Forgot password methods

  toggleforgotpassword(flag: any) {
    this.loading = false;
    this.frpwdInvalid = false;
    this.frpwdSuccess = false;
    this.fpMsg = '';
    this.fpobj.username = '';
    this.showforgotpwd = flag;
  }

  forgotpwdsubmit() {
    this.loading = true;
    this.frpwdInvalid = false;
    this.frpwdSuccess = false;
    this.fpMsg = '';
    const reqObj = {
      'action': 'Update',
      'userName': this.fpobj.username
    };
    this.authenticationService.forgotpwd(reqObj)
      .pipe(first())
      .subscribe(
        data => {
          this.forgotpasswordResponse = data;
          this.loading = false;
          if (this.forgotpasswordResponse.status) {
            if (this.forgotpasswordResponse.status.toLowerCase() !== 'success') {
              this.frpwdInvalid = true;
              this.fpMsg = this.forgotpasswordResponse.message;
            } else {
              this.frpwdSuccess = true;
              this.fpMsg = 'Temporary password sent your admin';
            }
          }
        },
        error => {
          this.alertService.error(error);
          this.loading = false;
        });
  }
}
