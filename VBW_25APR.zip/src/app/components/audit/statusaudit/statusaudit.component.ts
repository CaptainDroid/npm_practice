import { Component, Inject, OnInit, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MatPaginator, MatTableDataSource } from "@angular/material";
import { AuditService } from '../../../services/audit.service';
import { CommonService } from 'src/app/services/common.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { DOCUMENT } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-statusaudit',
  templateUrl: './statusaudit.component.html',
  styleUrls: ['./statusaudit.component.css']
})

export class StatusauditComponent implements OnInit {
 
  @ViewChild(MatPaginator) paginator: MatPaginator;
  
  displayedColumns = ['pointList', 'plantName', 'createdBy', 'testDate', 'executionDate', 'nextrunDate', 'status'];
  dataSource: any; 

  temp: any;
  plants: any;
  selectedPlant: any;

  auditData: any;
  statusList: any;
  sortedData: any;

  plantsResponse: any;
  selectedPlantObj: any;
  statusListResponse: any;

  result: any;
  pageParams: any;
  plantId: any;

  constructor(private auditService: AuditService, 
              private commonservice: CommonService,
              private route: ActivatedRoute,
              private errorservice: ErrorserviceService,

              public dialog: MatDialog, @Inject(DOCUMENT) document) {
                this.route.params.subscribe(params => {                
                  this.pageParams = params;
                  if (this.pageParams.plantid) {
                    this.plantId = parseInt(this.pageParams.plantid, 10);        
                  } else {
                    this.plantId = 0;        
                  }      
                 /* if(this.pageParams.auditid){
                    this.mode = 'edit';
                    this.getauditpointdata(this.auditData.plantId, this.pageParams.auditid);
                  }   */                    
                });
               }

  ngOnInit() {
    this.plants = [];
    this.auditData = [];
    this.statusList = [];
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.getplants(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.getplants(this.selectedPlant);
      }
    });
  }

  getplants(plantId: any) {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if(plantId === 0) {
            this.statusList = [];
            this.selectedPlant = 0;
            if(this.plants.length > 0){
              this.selectedPlantObj =  this.plants[0];
              this.selectedPlant =  this.plants[0].id;
              this.getauditstatustemplate(this.plants[0]);
            }
          } else {
              const plantobj = this.plants.filter(plnt => {
              return plnt.id === plantId;
            });
            this.selectedPlant = plantId;
            if(plantobj[0]) {
              this.getauditstatustemplate(plantobj[0]);
            }
          }         
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getauditstatustemplate(plantObj: any){
   // this.auditService.setplantInfo(plantObj);
    this.statusList = [];
    this.auditService.getauditstatuslist(plantObj.id).subscribe(
      data => {
        this.statusListResponse = data;
        if (this.statusListResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.statusListResponse.status, statusText: this.statusListResponse.message });
        } else {
          this.statusList = this.statusListResponse.data;
          this.statusList.filter(audit => {
            audit.acronym = plantObj.acronym;
          });
          this.dataSource = new MatTableDataSource(this.statusList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
           // if (data.auditPointTestStatus !== null) {
              return data.auditPointName.toLowerCase().includes(filter) ||
              data.createdByStringName.toString().toLowerCase().includes(filter) ||
              (data.auditPointTestStatus !== null ? data.auditPointTestStatus.toString().toLowerCase().includes(filter) : null);
           // }
          };
          this.dataSource.paginator = this.paginator;
        }
        console.log(this.statusList);
      },
      (err: any) => {
        console.log(err);
      }
    );

  }

  selectplant(plantObj: any) {
    this.selectedPlantObj = plantObj;
    this.getauditstatustemplate(plantObj);
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  } 

  showStatusReport(element: any) {
   /* if(element.auditPointTestStatus === "Successful") {
      this.result = "data.L00755";
    } else {
      this.result = "data.L00754";
    }*/
   // this.result = element.statusMessage;
    this.result = element.failureMessage + ' on ' + element.auditPointExecutionDateString;
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {type: '', title: 'Status Report', message: this.result}
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
    });
  }

  changePlant(selectedPlant) {
    console.log(selectedPlant);

  }


}

