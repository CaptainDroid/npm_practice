import { Component, Inject, OnInit, ViewChild, ViewEncapsulation, EventEmitter, Output } from '@angular/core';
import { MatPaginator, MatTableDataSource } from "@angular/material";
import { AuditService } from '../../services/audit.service';
import { CommonService } from 'src/app/services/common.service';
import { ErrorserviceService } from '../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { DialogComponent } from '../common/dialog/dialog.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-audit',
  templateUrl: './audit.component.html',
  styleUrls: ['./audit.component.css']
})

export class AuditComponent implements OnInit {
  
  @ViewChild(MatPaginator) paginator: MatPaginator;

  auditData;
  displayedColumns = ['plantName', 'pointList', 'createdBy', 'executionDate', 'action'];
  dataSource: any;
  
  temp: any;
  plants: any;
  selectedPlant: any;
  sortedData: any;

  plantsResponse: any;
  selectedPlantObj: any;

  auditList: any;
  auditListResponse: any;
  user: any;
  searchValue: any;

  constructor(
              private route: ActivatedRoute,
              public router: Router,
              private auditService: AuditService, 
              private commonservice: CommonService,
              private errorservice: ErrorserviceService,
              public dialog: MatDialog, @Inject(DOCUMENT) document) { }

  ngOnInit() {
    this.plants = [];
    this.auditData = [];
    this.auditList = [];
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.getplants(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.getplants(this.selectedPlant);
      }
    });
   // this.getplants();  
    this.user = this.commonservice.getUser();
  }

  getplants(plantId: any) {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if(plantId === 0) {
            this.auditList = [];
            this.selectedPlant = 0;
            if(this.plants.length > 0){
              this.selectedPlantObj =  this.plants[0];
              this.selectedPlant =  this.plants[0].id;
              this.getaudittemplates(this.plants[0]);
            }
          } else {
              const plantobj = this.plants.filter(plnt => {
              return plnt.id === plantId;
            });
            this.selectedPlantObj = plantobj[0];
            this.selectedPlant = plantId;
            if(plantobj[0]) {
              this.getaudittemplates(plantobj[0]);
            }
          }         
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getaudittemplates(plantObj: any) {
   // this.auditService.setplantInfo(plantObj);
   this.searchValue = '';
    this.auditList = [];
    this.auditService.getauditlist(plantObj.id).subscribe (
      data => {
        this.auditListResponse = data;
        if (this.auditListResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.auditListResponse.status, statusText: this.auditListResponse.message });
        } else {
          this.auditList = this.auditListResponse.data;
          this.auditList.filter(audit => {
            audit.acronym = plantObj.acronym;
          });
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.auditList);
          this.dataSource.filterPredicate = function (data: any, filter: string): boolean {
            return data.auditPointName.toLowerCase().includes(filter) || data.createdByStringName.toString().toLowerCase().includes(filter)
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  selectplant(plantObj: any) {
    this.selectedPlantObj = plantObj;
    this.getaudittemplates(plantObj);
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  
  editauditpoint(actionType, auditpoint): void {
    if (actionType === 'edit') {
        this.router.navigate(['editauditpoint/' + this.selectedPlant + '/' + auditpoint.auditPointId]);
    }
  }

  viewauditpoint(actionType, auditpoint): void {
    if (actionType === 'view') {
      this.router.navigate(['viewauditpoint/' + this.selectedPlant + '/' + auditpoint.auditPointId + '/' + actionType]);
    }
  }
 
  cloneauditpoint(auditpoint): void {
    const dialogRef = this.dialog.open(CloneAuditDialogComponent, {
      width: '500px',
      data: {
        'selectedPlantObj':this.selectedPlantObj,
        'plants':this.plants,
        'selectedPlant':this.selectedPlant,
        'user': this.user,
        'auditpoint':auditpoint
      }
    });
    const sub = dialogRef.componentInstance.cloneauditcallback.subscribe(result => {
      this.getaudittemplates(this.selectedPlantObj);
    });
  }

  runauditpoint(auditpoint): void {
    let runMessage;
    runMessage = (this.user.prn === 'Admin' && auditpoint.isEditable === true) ? 'data.L00833' : 'data.L00654';
    const dialogRef1 = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: {type: 'yesno', title: 'data.L00224', message: runMessage }
    });
    const sub = dialogRef1.componentInstance.okCallback.subscribe(result => {
      dialogRef1.componentInstance.closeDialog();
      const dialogRef = this.dialog.open(RunAuditDialogComponent, {
      width: '500px',
      data: {'auditpoint':auditpoint, 'selectedPlant':this.selectedPlant}
    });
  });
  }

  deleteauditpoint(auditpoint): void {
    const dialogReg = this.dialog.open(DeleteAuditDialogComponent, {
      width: '500px',
      data: {
        'selectedPlantObj':this.selectedPlantObj,
        'selectedPlant':this.selectedPlant,
        'auditpoint':auditpoint
      }
    });
    const sub = dialogReg.componentInstance.deleteauditpointcallback.subscribe(result => {    
      this.getaudittemplates(this.selectedPlantObj);
    });
  }
  
  scheduleaudit(auditpointId, plantId, auditName) {
    localStorage.setItem('auditName', auditName);   
    this.router.navigate(['scheduleaudit/' + plantId + '/' + auditpointId]);
  }
}

@Component({
selector: 'app-cloneauditpoint-dialog-component',
templateUrl: 'cloneauditpoint.dialog.html',
styleUrls: ['./audit.component.css'],
encapsulation: ViewEncapsulation.None
})

export class CloneAuditDialogComponent {
  @Output() cloneauditcallback = new EventEmitter<any>(true);
  cloneauditObj: any;
  plants: any;
  selectedPlant: any;
  user: any;
  userNameList: any;
  userListResponse: any;
  selectedUser: any;
  userList: any;
  selectedPlantObj: any;
  selectedUserObj: any;
  auditPointId: any;
  newAuditPointName: any;
  cloneAuditResponse: any;
  selectedUserId: any;
  
  constructor(
    public dialogRef: MatDialogRef<CloneAuditDialogComponent>,
    private auditService: AuditService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      this.plants = data.plants;
      this.selectedPlant = data.selectedPlant;
      this.selectedUser = 0;
      this.user = data.user;
      this.getuserid(this.selectedPlant);
      this.auditPointId = data.auditpoint.auditPointId;
      this.selectedPlantObj = data.selectedPlantObj;
    }

    getuserid(plantid: any) {
      this.userNameList = [];
      this.auditService.getuserdetailsbyplant(plantid, this.user.amr, this.user.sub).subscribe(
        data => {
          this.userListResponse = data;
          if (this.userListResponse.status !== 'success') {
            this.errorservice.showerror({status: this.userListResponse.status, statusText: this.userListResponse.message});
          } else {
            for (let i = 0; i < this.userListResponse.data.userPlants.length; i++) {
              this.userList = this.userListResponse.data.userPlants[i];
              this.userNameList.push(this.userList);
            }
          }
          this.selectedUserId = this.userNameList.filter(user => user.userId == this.user.amr);
          this.selectedUser = this.selectedUserId[0].userId;
        });
    }

    closeDialog(): void {
      this.dialogRef.close();
    }

    selectplant(plantObj: any) {
      this.selectedPlant = plantObj.id;
    }

    cloneConfirm() {
      const requestObj = this.preparecloneobj();
      this.auditService.cloneauditpoint(requestObj.plantId, requestObj).subscribe(
        data => {
          this.cloneAuditResponse = data;
          if (this.cloneAuditResponse.status !== 'success') {
            this.errorservice.showerror({
              status: this.cloneAuditResponse.errorCode, statusText: this.cloneAuditResponse.message
            });
          } else {
            this.dialogRef.close();

              const dialogRef = this.dialog.open(DialogComponent, {
                width: '400px',
                data: {title: 'data.L00224', message: 'data.L00649' }
              });
              const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
                dialogRef.componentInstance.closeDialog();
                this.cloneauditcallback.emit(this.selectedPlantObj);
              });
          }
      });
    }

    preparecloneobj() {
      const reqObj = {      
        'plantId': this.selectedPlant,
        'newAuditPointName': this.newAuditPointName,
        'sourceAuditPointId': this.auditPointId,
        'userId':this.selectedUser
      };    
      return reqObj;
    }
  
  }

  @Component({
    selector: 'runauditpointdialogcomponent',
    templateUrl: 'runauditpoint.dialog.html',
    styleUrls: ['./audit.component.css'],
    encapsulation: ViewEncapsulation.None
  })
  
  export class RunAuditDialogComponent {
    @Output() runauditpointcallback = new EventEmitter<any>(true);
    runauditObj: any; 
    auditPointId: any;
    auditPointName: any;
    testdatetime: any;
    emailid: any;
    selectedPlant: any;
    runresponse: any;
    validateDateTime: any;
    validateEmail: any;
    emailError: any;
    dateTimeError: any;

    constructor(
        public dialogRef: MatDialogRef<RunAuditDialogComponent>,
        public dialog: MatDialog,
        private auditService: AuditService,
        private errorservice: ErrorserviceService,
        @Inject(MAT_DIALOG_DATA) public data: any) {
          this.auditPointId = data.auditpoint.auditPointId;
          this.auditPointName = data.auditpoint.auditPointName;
          this.selectedPlant = data.selectedPlant;
          this.emailError = false;
          this.dateTimeError = false;
        }
  
    closeDialog(): void {
        this.dialogRef.close();
    }  

    parseDateTime(model: any) {      
      const isValidTime = model.match(/^([1-9]|([012][0-9])|(3[01]))\/([0]{0,1}[1-9]|1[012])\/\d\d\d\d (20|21|22|23|[0-1]?\d):[0-5]?\d:[0-5]?\d$/);
      this.dateTimeError = (isValidTime) ? true : false;
      return this.dateTimeError;
    }

    checkEmailFormat(model: any) {
      const isValidEmail  = model.match(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/);
      this.emailError = (isValidEmail)? true : false ;
      return this.emailError;
    }
  
    runaudit() {
      const requestrunobj = this.preparerunobj();      
      this.validateDateTime = this.parseDateTime(this.testdatetime);
      this.validateEmail = this.checkEmailFormat(this.emailid);

      if(!this.validateDateTime) {
         this.dateTimeError = true;      
      } else if(!this.validateEmail){
        this.emailError = true; 
      } else {
          this.auditService.initiaterun(requestrunobj).subscribe(data => {
          this.runresponse = data;
          if (this.runresponse.status !== 'success') {
            this.errorservice.showerror({ 
              status: this.runresponse.errorCode, statusText: this.runresponse.message
            });
          } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            data: {title: 'data.L00224', message: 'data.L00865' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();          
          });
        }

      });
     
    }
       
    }

    preparerunobj(){
      const reqObj = {      
        'plantId': this.selectedPlant,
        'auditPointId': this.auditPointId,
        'APTestDate':this.testdatetime,
        'notificationEmail':this.emailid
      };    
      return reqObj;
    }
  }

  @Component({
    selector: 'deleteauditpointdialogcomponent',
    templateUrl: 'deleteauditpoint.dialog.html',
    styleUrls: ['./audit.component.css'],
    encapsulation: ViewEncapsulation.None
  })

  export class DeleteAuditDialogComponent {  
    @Output() deleteauditpointcallback = new EventEmitter<any>(true);
    selectedPlantObj: any;
    selectedPlant: any;
    deleteauditresponse: any;
    auditPointId: any;
    auditList: any;

    constructor(
      public dialogRef: MatDialogRef<DeleteAuditDialogComponent>,
      private auditService: AuditService,
      private errorservice: ErrorserviceService,
      public dialog: MatDialog,
      @Inject(MAT_DIALOG_DATA) public data: any) {
        this.selectedPlantObj = data.selectedPlantObj;
        this.selectedPlant = data.selectedPlant;
        this.auditPointId = data.auditpoint.auditPointId;       
      }

      closeDialog(): void {
        this.dialogRef.close();
      }

      deleteAudit() {
        const requestObj = this.preparereq(); 
        requestObj.action = "delete";
        requestObj.plantId = this.selectedPlant; 
        requestObj.auditPointId = this.auditPointId;    
        this.auditService.saveauditpoint(this.selectedPlant, requestObj).subscribe (
          data => { 
            this.deleteauditresponse = data;
            if (this.deleteauditresponse.status !== 'success') {
              this.errorservice.showerror({ 
                status: this.deleteauditresponse.errorCode, statusText: this.deleteauditresponse.message
              });
            } else {
              this.dialogRef.close();
              const dialogRef = this.dialog.open(DialogComponent, {
                width: '400px',
                data: {title: 'data.L00224', message: 'data.L00650' }
              });
              const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
                dialogRef.componentInstance.closeDialog();
                this.deleteauditpointcallback.emit(this.selectedPlantObj);
               // this.router.navigate(['audit']);
              });
            }
          },
          (err: any) => {
            console.log(err);
          }
        );       
      }

      preparereq() {
        const reqObj = {
          "action": "",
          "plantId": "",
          "auditPointName": "",
          "calculatePvalue": false,
          "eventTypeId": 0,
          "auditPointTestDate": "",
          "auditPointId": 0,      
          "tenantId":1,
          "parameters": [
            {       
                "name": "P1",
                "formula": "",
                "noOfDays": ""        
            }
          ],
          "pearsonFunction": [
            {
              "name": "F1",
              "formula": ""
           }
          ], 
          "calculations": [
            {
              "name":"C1",
              "formula":"",
              "noOfDays":""
            }
          ],
          "decisionTrees": [
            {
              "name":"D1",
              "formula":"",
              "message":""
            }
          ]
         // "testDate": "",
         // "Roles": ""      
        };    
        return reqObj;
     }
  }