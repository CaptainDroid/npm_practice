import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { AuditService } from '../../../services/audit.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { MatDialog } from '@angular/material';
import { JitCompiler, jitExpression, NullTemplateVisitor } from '@angular/compiler';

@Component({
  selector: 'app-scheduleaudit',
  templateUrl: './scheduleaudit.component.html',
  styleUrls: ['./scheduleaudit.component.css']
})
export class ScheduleauditComponent implements OnInit {
  plantsResponse: any;
  plants: any;
  selectedPlant = 0;
  pageParams: any;
  auditName: any;
  scheduleAuditData: any;
  userRoles: any;
  monthdays: any;
  weekdays: any;
  selectedfname: any;
  scheduledataResponse: any;
  getscheduleResponse: any;
  getweekdaysResponse: any;
  getscheduletypeResponse: any;
  scheduleTypes: any;
  errorMessage: any;
  isActive = false;
  timeError: any;
  checkSchedule = true;

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    public auditService: AuditService,
    public commonservice: CommonService,
    public errorservice: ErrorserviceService,
    public dialog: MatDialog) {
    this.route.params.subscribe(params => {
      this.pageParams = params;
      if (this.pageParams.plantid) {
        this.selectedPlant = parseInt(this.pageParams.plantid, 10);
        this.getschedule(this.pageParams.plantid);
      } else {
        this.selectedPlant = 0;
      }
    });
  }

  ngOnInit() {
    this.selectedfname = [];
    this.monthdays = [];
    this.auditName = localStorage.getItem('auditName');
    this.scheduleAuditData = this.prepareobj();
    this.getPlants();
    for (let i = 1; i <= 31; i++) {
      const monthobj = { 'id': i, 'value': i };
      this.monthdays.push(monthobj);
    }
    this.getWeekdays(this.selectedPlant);
    this.getScheduleType(this.selectedPlant);
  }

  getWeekdays(plantid) {
    this.auditService.getweekdays(plantid).subscribe(
      data => {
        this.getweekdaysResponse = data;
        if (this.getweekdaysResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.getweekdaysResponse.errorCode, statusText: this.getweekdaysResponse.message });
        } else {
          this.weekdays = this.getweekdaysResponse.data;
        }
      }
    );
  }

  getScheduleType(plantid) {
    this.auditService.getscheduletype(plantid).subscribe(
      data => {
        this.getscheduletypeResponse = data;
        if (this.getscheduletypeResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.getscheduletypeResponse.errorCode, statusText: this.getscheduletypeResponse.message });
        } else {
          this.scheduleTypes = this.getscheduletypeResponse.data;
          this.findschtype();
        }
      }
    );
  }

  changeFrequency(type: any, scheduleobj: any) {
    if (scheduleobj.dateOfMonth === null) {
      scheduleobj.dateOfMonth = 0;
    }

    if (scheduleobj.dayOfWeek === null) {
      scheduleobj.dayOfWeek = 0;
    }

    if (type.paramVal === 'W') {
      scheduleobj.isWeek = true;
      scheduleobj.isMonth = false;
      scheduleobj.lastdayOfMonth = false;
      scheduleobj.dateOfMonth = null;
    } else if (type.paramVal === 'M') {
      scheduleobj.isMonth = true;
      scheduleobj.isWeek = false;
      if (scheduleobj.lastdayOfMonth === true) {
        scheduleobj.dateOfMonth = 0;
      }
    } else {
      scheduleobj.isMonth = false;
      scheduleobj.isWeek = false;
      scheduleobj.lastdayOfMonth = false;
      scheduleobj.dateOfMonth = 0;
    }
  }

  findschtype() {
    if (this.scheduleTypes && this.scheduleAuditData.auditpointSchedule) {

      this.scheduleAuditData.auditpointSchedule.forEach(auditdata => {

        const typeid = auditdata.scheduleType;
        const typeobj = this.scheduleTypes.filter(filterdata => {
          return filterdata.paramId === typeid;
        });
        if (typeobj.length > 0) {
          this.changeFrequency(typeobj[0], auditdata);
        }
      });
    }
  }

  getPlants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  getschedule(plantid) {
    this.auditService.getscheduledata(plantid, this.pageParams.auditid).subscribe(
      data => {
        this.getscheduleResponse = data;
        if (this.getscheduleResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.getscheduleResponse.errorCode, statusText: this.getscheduleResponse.message });
        } else {
          this.scheduleAuditData = this.getscheduleResponse.data;
          this.scheduleAuditData.auditpointSchedule.forEach(auditdata => {
            auditdata.lastdayOfMonth = false;
            if (auditdata.dateOfMonth === 0) {
              auditdata.lastdayOfMonth = true;
            } else if (auditdata.dateOfMonth === null || auditdata.dateOfMonth === '') {
              auditdata.dateOfMonth = 0;
            }
            if (auditdata.dayOfWeek === null || auditdata.dayOfWeek === '') {
              auditdata.dayOfWeek = 0;
            }
            if (auditdata.scheduleType === null || auditdata.scheduleType === '' || auditdata.scheduleType === -1) {
              auditdata.scheduleType = 0;
            }

          });
          this.findschtype();
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  selectmonthday(schmodel: any) {
    if (schmodel.dateOfMonth === 0) {
      schmodel.lastdayOfMonth = true;
    } else {
      schmodel.lastdayOfMonth = false;
    }
  }

  checklastdayofmonth(schmodel: any) {
    if (schmodel.lastdayOfMonth === true) {
      schmodel.dateOfMonth = 0;
    }
  }

  checkTimeFormat(model: any) {
    if (model === null) {
      return this.timeError = null;
    } else {
      const isValidTime = model.match(/^(?:(?:([01]?\d|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$/);
      this.timeError = (isValidTime) ? true : false;
    }
    return this.timeError;
  }

  saveschedule(plantid) {
    this.checkSchedule = false;
    this.scheduleAuditData.plantId = plantid;
    this.scheduleAuditData.auditPointId = parseInt(this.pageParams.auditid, 10);
    this.scheduleAuditData.tenantId = 1;
    this.scheduleAuditData.action = (this.scheduleAuditData.scheduleId === 0) ? 'create' : 'update';

    let isValidamonthselection = true;
    this.scheduleAuditData.auditpointSchedule.forEach(schdata => {
      if (schdata.isMonth === true) {
        schdata.dayOfWeek = null;
        if (schdata.dateOfMonth === 0 && schdata.lastdayOfMonth === false) {
          isValidamonthselection = false;
        }

        if (schdata.lastdayOfMonth === true) {
          schdata.dateOfMonth = 0;
        } else {
          schdata.dateOfMonth = (schdata.dateOfMonth === 0) ? null : schdata.dateOfMonth;
        }
      } else if (schdata.isWeek === true) {
        schdata.dateOfMonth = null;
        if (schdata.dayOfWeek === 0) {
          isValidamonthselection = false;
          schdata.dayOfWeek = null;

        }
      } else {
        schdata.lastdayOfMonth = false;
        schdata.dateOfMonth = null;
        schdata.dayOfWeek = null;
      }
    });

    const validateSchedule1Time = this.checkTimeFormat(this.scheduleAuditData.auditpointSchedule[0].scheduleTime);
    const validateSchedule2Time = this.checkTimeFormat(this.scheduleAuditData.auditpointSchedule[1].scheduleTime);

    if (validateSchedule1Time === null && validateSchedule2Time === null) {
      this.errorservice.showerror({ status: '', statusText: 'data.L00767' });
      setTimeout(() => { this.checkSchedule = true; }, 1000);
    } else if (!validateSchedule1Time || !validateSchedule2Time &&
      validateSchedule2Time !== null && this.scheduleAuditData.auditpointSchedule[1].scheduleTime !== '') {
      this.errorservice.showerror({ status: '', statusText: 'data.L00778' });
      setTimeout(() => { this.checkSchedule = true; }, 1000);
    } else if (this.scheduleAuditData.auditpointSchedule[0].scheduleTime === ''
      || this.scheduleAuditData.auditpointSchedule[0].scheduleType === 0
      || isValidamonthselection !== true) {
      this.errorservice.showerror({ status: '', statusText: 'data.L00767' });
      setTimeout(() => { this.checkSchedule = true; }, 1000);
    } else if (this.scheduleAuditData.auditpointSchedule.length > 1) {
      if (((this.scheduleAuditData.auditpointSchedule[1].scheduleTime !== null &&
        this.scheduleAuditData.auditpointSchedule[1].scheduleTime !== '') &&
        this.scheduleAuditData.auditpointSchedule[1].scheduleType === 0) ||
        (this.scheduleAuditData.auditpointSchedule[1].scheduleTime === null ||
          this.scheduleAuditData.auditpointSchedule[1].scheduleTime === '') &&
        this.scheduleAuditData.auditpointSchedule[1].scheduleType !== 0 || isValidamonthselection !== true) {
        this.errorservice.showerror({ status: '', statusText: 'data.L00768' });
        setTimeout(() => { this.checkSchedule = true; }, 1000);
      } else {
        this.scheduleSaveData(plantid);
      }
    } else {
      this.scheduleSaveData(plantid);
    }
  }

  scheduleSaveData(plantid) {
    this.auditService.savescheduledata(plantid, this.scheduleAuditData).subscribe(
      data => {
        this.scheduledataResponse = data;
        this.checkSchedule = true;
        if (this.scheduledataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.scheduledataResponse.status, statusText: this.scheduledataResponse.message });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            data: { title: 'data.L00224', message: 'data.L00653' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
            this.router.navigate(['audit/' + plantid]);
          });
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  prepareobj() {
    const scheduleaudit = {
      'action': '',
      'plantId': '',
      'scheduleId': 0,
      'tenantId': 1,
      'auditPointId': '',
      'auditpointSchedule': [{
        'auditPointScheduleId': 0,
        'scheduleId': 0,
        'scheduleTime': '',
        'scheduleType': 0,
        'dateOfMonth': null,
        'dayOfWeek': null,
        'status': false,
        'lastdayOfMonth': false
      }, {
        'auditPointScheduleId': 0,
        'scheduleId': 0,
        'scheduleTime': '',
        'scheduleType': 0,
        'dateOfMonth': null,
        'dayOfWeek': null,
        'status': false,
        'lastdayOfMonth': false
      }]

    };

    return scheduleaudit;
  }

}
