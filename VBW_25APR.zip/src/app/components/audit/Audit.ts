export interface Audit {
    pointList: string;
    plantName: string;
    createdBy: string;
    executionDate: string;
    testDate: string;
    status: string;
}