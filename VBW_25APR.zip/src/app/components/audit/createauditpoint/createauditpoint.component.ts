import { Component, Inject, OnInit, Output, ViewEncapsulation, EventEmitter } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { AuditService } from '../../../services/audit.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-createauditpoint',
  templateUrl: './createauditpoint.component.html',
  styleUrls: ['./createauditpoint.component.css']
})
export class CreateauditpointComponent implements OnInit {

  plants: any;
  auditData: any;
  pageParams: any;

  plantsResponse: any;
  selectedPlantObj: any;

  pearsonData: any;
  pearsonDataResponse: any;
  selectedPearsonObj: any;

  selectedRoleObj: any;
  userroleData: any;
  userroleDataResponse: any;

  selectedEventObj: any;
  eventtypeData: any;
  eventtypeDataResponse: any;

  saveauditresponse: any;
  validateauditresponse: any;
  testrunresponse: any;
  user: any;
  isEnabled: any;
  adminEmailNotification: any;
  mode: any;

  auditpointresponse: any;
  selectedPlant: any;
  dtRecords: any;

  validateparametersresponse: any;
  validatecalculationsresponse: any;
  validatedecisiontreesresponse: any;

  isSimple: any;

  constructor(
    private auditService: AuditService,
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    private route: ActivatedRoute,
    public router: Router,
    public dialog: MatDialog
  ) {
    {
      this.route.params.subscribe(params => {
        this.mode = 'new';
        this.auditData = this.preparereq();
        this.pageParams = params;
        if (this.pageParams.plantid) {
          this.auditData.plantId = parseInt(this.pageParams.plantid, 10);
        } else {
          this.auditData.plantId = 0;
        }
        if (this.pageParams.actionType) {
          this.mode = 'view';
          this.getauditpointdata(this.auditData.plantId, this.pageParams.auditid);
        } else if (this.pageParams.auditid) {
          this.mode = 'edit';
          this.getauditpointdata(this.auditData.plantId, this.pageParams.auditid);
        }
      });
    }
  }

  ngOnInit() {
    this.getPlants();
    this.auditData.eventTypeId = 0;
    this.auditData.pearsonFunction.formula = 0;
    this.user = this.commonservice.getUser();
    this.isEnabled = false;
    this.auditData.adminEmailNotification = false;
    this.pearsonData = [];
    this.auditData.isSimple = false;
  }

  getauditpointdata(plantId: any, auditId: any) {
    this.auditService.getauditpoint(plantId, auditId).subscribe(
      data => {
        this.auditpointresponse = data;
        if (this.auditpointresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.auditpointresponse.status, statusText: this.auditpointresponse.message });
        } else {
          this.auditData = this.auditpointresponse.data;
          this.isEnabled = (this.auditData.calculatePvalue) ? this.auditData.calculatePvalue : false;
          // this.ischeckEnabled = (this.auditData.roles.length > 1) ? true : false;
          console.log(this.auditData);
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getPlants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (this.plants.length > 0) {
            // this.selectedPlantObj =  this.plants[0];
            this.selectedPlantObj = this.plants.filter(plant => plant.id === this.auditData.plantId);
            this.getpearsondatalist(this.auditData.plantId);
            this.getusernames(this.auditData.plantId);
            this.geteventtype(this.auditData.plantId);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  selectplant(plantObj: any) {
    this.selectedPlantObj = plantObj;
    this.getpearsondatalist(this.selectedPlantObj.id);
  }

  selectevent(eventObj: any) {
    this.selectedEventObj = eventObj;
  }

  getpearsondatalist(plantid: any) {
    this.pearsonData = [];
    this.auditService.getpearsondata(plantid).subscribe(
      data => {
        this.pearsonDataResponse = data;
        if (this.pearsonDataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.pearsonDataResponse.status, statusText: this.pearsonDataResponse.message });
        } else {
          for (let i = 0; i < this.pearsonDataResponse.data.length; i++) {
            this.pearsonData.push(this.pearsonDataResponse.data[i]);
          }
          if (this.pearsonData.length > 1) {
            this.selectedPearsonObj = this.pearsonData[0];
            // this.auditData.pearsonFunction.pearsonName = this.pearsonData[0].pearsonName;
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getusernames(plantid: any) {
    this.userroleData = [];
    this.auditService.getCorpUserbyPlant(plantid).subscribe(
      data => {
        this.userroleDataResponse = data;
        if (this.userroleDataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.userroleDataResponse.status, statusText: this.userroleDataResponse.message });
        } else {
          for (let i = 0; i < this.userroleDataResponse.data.length; i++) {
            this.userroleData.push(this.userroleDataResponse.data[i]);
          }
          /* if (this.userroleData.length > 1) {
             this.selectedRoleObj = this.userroleData;
           }*/
        }
        // this.auditData.Roles = [0];
      }
    );

  }

  geteventtype(plantObj: any) {
    this.eventtypeData = [];
    this.auditService.geteventtype(plantObj).subscribe(
      data => {
        this.eventtypeDataResponse = data;
        if (this.eventtypeDataResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.eventtypeDataResponse.status, statusText: this.eventtypeDataResponse.message });
        } else {
          for (let i = 0; i < this.eventtypeDataResponse.data.length; i++) {
            this.eventtypeData.push(this.eventtypeDataResponse.data[i]);
          }
          if (this.eventtypeData.length > 1) {
            this.selectedEventObj = this.eventtypeData.filter(eventType => eventType.eventTypeId === this.auditData.eventTypeId);
          }
        }
      }
    );
  }

  validateParameters() {
    this.auditService.validateparameters(this.auditData.plantId, this.auditData).subscribe(
      data => {
        this.validateparametersresponse = data;
        if (this.validateparametersresponse.status !== 'success') {
          this.errorservice.showerror({
            status: this.validateparametersresponse.errorCode, statusText: this.validateparametersresponse.message
          });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            data: { title: 'data.L00224', message: 'data.L00678' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  validateCalculation() {
    this.auditService.validatecalculations(this.auditData.plantId, this.auditData).subscribe(
      data => {
        this.validatecalculationsresponse = data;
        if (this.validatecalculationsresponse.status !== 'success') {
          this.errorservice.showerror({
            status: this.validatecalculationsresponse.errorCode, statusText: this.validatecalculationsresponse.message
          });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            data: { title: 'data.L00224', message: 'data.L00658' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  validateDecisionTree() {
    this.auditService.validatedecisions(this.auditData.plantId, this.auditData).subscribe(
      data => {
        this.validatedecisiontreesresponse = data;
        if (this.validatedecisiontreesresponse.status !== 'success') {
          this.errorservice.showerror({
            status: this.validatedecisiontreesresponse.errorCode, statusText: this.validatedecisiontreesresponse.message
          });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            data: { title: 'data.L00224', message: 'data.L00661' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  saveaudittemplate(plantid) {
    this.auditData.action = (this.mode === 'edit') ? 'update' : 'create';
    this.auditData.plantId = plantid;
    this.auditData.calculatePvalue = this.isEnabled;
    this.auditData.eventTypeId = (this.user.prn !== 'Admin') ? 0 : this.auditData.eventTypeId;
    this.auditData.roles = (this.auditData.roles.length === 'undefined') ? [this.auditData.roles] : this.auditData.roles;

    if (this.auditData.calculatePvalue === true &&
      (this.auditData.pearsonFunction[0].formula === '' || this.auditData.pearsonFunction[0].formula === null)) {
      this.errorservice.showerror({ status: '', statusText: 'data.L00667' });
    } else if (this.auditData.adminEmailNotification === true && this.auditData.roles.length < 1 && this.user.prn === 'Admin') {
      this.errorservice.showerror({ status: '', statusText: 'Please select a user for sending notification' });
    } else {
      this.auditService.saveauditpoint(plantid, this.auditData).subscribe(
        data => {
          this.saveauditresponse = data;
          if (this.saveauditresponse.status !== 'success') {
            this.errorservice.showerror({
              status: this.saveauditresponse.errorCode, statusText: this.saveauditresponse.message
            });
          } else {
            const dialogRef = this.dialog.open(DialogComponent, {
              width: '400px',
              data: { title: 'data.L00224', message: 'data.L00655' }
            });
            const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
              this.router.navigate(['audit/' + plantid]);
            });
          }
        },
        (err: any) => {
          console.log(err);
        }
      );
    }

  }

  cancelaudit() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: { type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.router.navigate(['audit/' + this.auditData.plantId]);
    });
  }

  parseDate(str) {
    let m: any;
    m = str.match(/^([1-9]|([012][0-9])|(3[01]))\/([0]{0,1}[1-9]|1[012])\/\d\d\d\d (20|21|22|23|[0-1]?\d):[0-5]?\d:[0-5]?\d$/);
    return (m) ? true : false;
  }

  testrun() {
    const testrunObj = this.preparetestrunObj(this.auditData);
    testrunObj.plantName = this.selectedPlantObj[0].acronym;
    if (this.user.prn === 'Admin') {
      if (this.selectedEventObj[0] === undefined) {
        testrunObj.eventTypeName = this.selectedEventObj.eventType;
      } else {
        testrunObj.eventTypeName = this.selectedEventObj[0].eventType;
      }
    } else {
      testrunObj.eventTypeName = 'Others';
    }
    this.dtRecords = [];
    for (let i = 0; i < this.auditData.decisionTrees.length; i++) {
      if (this.auditData.decisionTrees[i].formula !== '') {
        this.dtRecords.push(this.auditData.decisionTrees[i]);
      }
    }
    this.testRunResultData(testrunObj);
  }

  testRunResultData(testrunObj) {
    if (this.dtRecords.length < 1) {
      this.errorservice.showerror({ status: '', statusText: 'data.L00809' });
    } else {
      const dialogRef = this.dialog.open(DialogComponent, {
        width: '400px',
        disableClose: true,
        data: { type: 'yesno', title: 'data.L00224', message: 'data.L00927' }
      });
      const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
        this.auditService.initiatetestrun(testrunObj).subscribe(data => {
          this.testrunresponse = data;
          if (this.testrunresponse.status !== 'success') {
            this.errorservice.showerror({
              status: this.testrunresponse.errorCode, statusText: this.testrunresponse.message
            });
          } else {
            const dialogRun = this.dialog.open(TestRunDialogComponent, {
              width: '900px',
              data: {
                'testResult': this.testrunresponse
              }
            });
            const sub = dialogRun.componentInstance.testRuncallback.subscribe(result => {
              dialogRun.componentInstance.closeDialog();
            });
          }
        });
      });
    }
  }

  preparetestrunObj(data) {
    const reqObj = {
      'auditPointId': data.auditPointId,
      'auditPointName': data.auditPointName,
      'plantId': data.plantId,
      'plantName': '',
      'eventTypeId': data.eventTypeId,
      'eventTypeName': '',
      'calculatePvalue': this.isEnabled,
      'parameters': data.parameters,
      'pearsonFunction': data.pearsonFunction,
      'calculations': data.calculations,
      'decisionTrees': data.decisionTrees
    };
    return reqObj;
  }

  addparam() {
    const rowno = this.auditData.parameters.length + 1;
    const param = {
      'name': 'P' + rowno,
      'formula': '',
      'noOfDays': ''
    };

    this.auditData.parameters.push(param);
  }

  addpearsonparam() {
    const prowno = this.auditData.pearsonFunction.length + 1;
    const pearsonparam = {
      'name': 'F' + prowno,
      'formula': ''
    };
    this.auditData.pearsonFunction.push(pearsonparam);
  }

  addcalcparam() {
    const crowno = this.auditData.calculations.length + 1;
    const calcparam = {
      'name': 'C' + crowno,
      'formula': '',
      'noOfDays': ''
    };

    this.auditData.calculations.push(calcparam);
  }

  addDTparam() {
    const drowno = this.auditData.decisionTrees.length + 1;
    const dtparam = {
      'name': 'D' + drowno,
      'formula': '',
      'message': ''
    };

    this.auditData.decisionTrees.push(dtparam);
  }

  preparereq() {
    const reqObj = {
      'action': '',
      'plantId': '',
      'auditPointName': '',
      'calculatePvalue': false,
      'eventTypeId': '',
      'isSimple': false,
      'adminEmailNotification': false,
      'auditPointTestDate': '',
      'auditPointId': 0,
      'tenantId': 1,
      'parameters': [
        {
          'name': 'P1',
          'formula': '',
          'noOfDays': ''
        }
      ],
      'pearsonFunction': [
        {
          'name': 'F1',
          'formula': ''
        }
      ],
      'calculations': [
        {
          'name': 'C1',
          'formula': '',
          'noOfDays': ''
        }
      ],
      'decisionTrees': [
        {
          'name': 'D1',
          'formula': '',
          'message': ''
        }
      ],
      'roles': []
    };

    return reqObj;
  }

  checkNumberFieldLength(num) {
    num = num.toString();
    if (num.length > 2) {
      num = num.slice(0, 3);
      event.preventDefault();
    }
  }

  // Angular material drag and drop

  dropParameterData(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.auditData.parameters, event.previousIndex, event.currentIndex);
  }

  dropPearsonData(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.auditData.pearsonFunction, event.previousIndex, event.currentIndex);
  }

  dropCalculationData(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.auditData.calculations, event.previousIndex, event.currentIndex);
  }

  dropDTData(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.auditData.decisionTrees, event.previousIndex, event.currentIndex);
  }

}

@Component({
  selector: 'testrunauditpointdialogcomponent',
  templateUrl: 'testrunresult.dialog.html',
  styleUrls: ['./createauditpoint.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class TestRunDialogComponent implements OnInit {
  @Output() testRuncallback = new EventEmitter<any>(true);

  testResult: any;

  constructor(
    public dialogRef: MatDialogRef<TestRunDialogComponent>,
    public dialog: MatDialog,
    private auditService: AuditService,
    private errorservice: ErrorserviceService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.testResult = data.testResult.data;
  }

  ngOnInit() {
    window.scrollTo(0, 0);
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
  testOk() {
    this.closeDialog();
  }
}
