import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateauditpointComponent } from './createauditpoint.component';

describe('CreateauditpointComponent', () => {
  let component: CreateauditpointComponent;
  let fixture: ComponentFixture<CreateauditpointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateauditpointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateauditpointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
