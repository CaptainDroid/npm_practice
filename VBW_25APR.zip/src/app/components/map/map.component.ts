import { Component, OnInit } from '@angular/core';
import { icon, marker, geoJSON, Map, point, polyline, latLng, tileLayer } from 'leaflet';
import { DashboardService } from 'src/app/services/dashboard.service';
import { CommonService } from '../../services/common.service';
import { environment } from '../../../environments/environment';

// tslint:disable-next-line:prefer-const
let markers: any[];
declare var require: any;
// tslint:disable-next-line:prefer-const
let countriesgeo = require('../../../assets/geoJson/countriesgeo.json');

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {
  private plantData;
  public ready = false;
  markers = [];
  pageaccess = environment.pageaccess.home;

  outline = geoJSON(countriesgeo, { // initialize layer with data
    style: function (feature) { // Style option
      if (feature.id === 'TWN') {
        return {
            'weight': 1,
            'color': 'white',
            'fillColor': 'rgb(255, 255, 255)',
            'fillOpacity': 0,
            'strokeWidth': '0px'
        };
      } else {
        return {
        'weight': 1,
        'color': '#fbfbfb',
        'fillColor': 'rgb(255, 255, 255)',
        'fillOpacity': 0.5
       };
      }
    }
  });

  // streetMaps = tileLayer('http://{s}.tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png', { });
  streetMaps = tileLayer('https://tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png', {});
  markerIcon = icon({
    iconUrl: 'assets/images/marker.png',
    iconSize: [30, 36],
    iconAnchor: [25, 25],
    popupAnchor: [-6, -25]
});

  options = {
    layers: [
      this.streetMaps, this.outline
    ],
    zoom: 3.5,
    attributionControl: false,
    center: latLng([35, 105])
  };

  onMapReady(map: Map) { }

  constructor(private _dashboardService: DashboardService, private _commonService: CommonService) { }

  ngOnInit() {
    if (this.pageaccess.mapapiaccess === true) {
      this.getuserplants();
    } else {
      this.plantData = this.staticmapdata();
      this.addMarkers();
    }
   }

   getuserplants() {
    if (this._dashboardService.allPlants === undefined) {
      this._commonService.getplants().subscribe(
        data => {
          this.plantData = data;
          if (this.plantData.status !== 'success') {
            return;
          }
          this._dashboardService.allPlants = this.plantData;
          this.addMarkers();
        }
      );
    } else {
      this.plantData = this._dashboardService.allPlants;
      this.addMarkers();
    }
   }

   addMarkers() {
    for (let i = 0; i < this.plantData.data.countries.length; i++) {
      for (let j = 0; j < this.plantData.data.countries[i].cities.length; j++) {
        for (let k = 0; k < this.plantData.data.countries[i].cities[j].plants.length; k++) {
          // tslint:disable-next-line:prefer-const
          let latitude = this.plantData.data.countries[i].cities[j].plants[k].latitude;
          // tslint:disable-next-line:prefer-const
          let longitude = this.plantData.data.countries[i].cities[j].plants[k].longitude;
          // tslint:disable-next-line: prefer-const
          let coordinate = [ latitude, longitude];
          // tslint:disable-next-line: prefer-const
          let newMarker = marker( [latitude, longitude], { icon: this.markerIcon })
            // tslint:disable-next-line:max-line-length
            .bindTooltip(this.plantData.data.countries[i].cities[j].plants[k].acronym + " : " + this.plantData.data.countries[i].cities[j].plants[k].name);
          this.markers.push(newMarker);
        }
      }
    }
    this.ready = true;
  }

  staticmapdata() {
    return {
      'status': 'success',
      'message': 'Successful',
      'errorCode': 200,
      'data': {
          'countries': [{
              'id': 26,
              'name': 'China',
              'cities': [{
                  'id': 7,
                  'name': 'CHANGZHI',
                  'plants': [{
                      'id': 9,
                      'name': 'Sembcorp Changzhi Water Co., Ltd',
                      'acronym': 'CZ',
                      'latitude': 36.48409438,
                      'longitude': 113.09703162,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 24000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 5,
                  'name': 'LIANYUNGANG',
                  'plants': [{
                      'id': 7,
                      'name': 'Sembcorp Lianyungang Water Co., Ltd.',
                      'acronym': 'LYG',
                      'latitude': 34.46057087,
                      'longitude': 119.7617121766,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 20000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 2,
                  'name': 'NANJING',
                  'plants': [{
                      'id': 10,
                      'name': 'Sembcorp NCIP  Water Co., Ltd.',
                      'acronym': 'NCIP',
                      'latitude': 32.253564255,
                      'longitude': 118.8266231753,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 240000.0,
                      'process': 'Water treatment'
                  }, {
                      'id': 3,
                      'name': 'Sembcorp Nanjing  SUIWU Co., Ltd.',
                      'acronym': 'NSS1',
                      'latitude': 32.254371,
                      'longitude': 118.826407,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 28000.0,
                      'process': 'Water treatment'
                  }, {
                      'id': 4,
                      'name': 'Sembcorp Nanjing  SUIWU Co., Ltd.',
                      'acronym': 'NSS2',
                      'latitude': 32.252629,
                      'longitude': 118.826536,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 19200.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 6,
                  'name': 'QIDONG',
                  'plants': [{
                      'id': 8,
                      'name': 'Sembcorp Qidong Water Co., Ltd.',
                      'acronym': 'QD',
                      'latitude': 32.02749419,
                      'longitude': 121.7338192,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 10000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 8,
                  'name': 'QINZHOU',
                  'plants': [{
                      'id': 12,
                      'name': 'Sembcorp Qinzhou Water Co., Ltd.',
                      'acronym': 'QSW',
                      'latitude': 21.70791335,
                      'longitude': 108.6169349,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 15000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 11,
                  'name': 'QITAIHE',
                  'plants': [{
                      'id': 15,
                      'name': 'Sembcorp Qitaihe Water Co., Ltd.',
                      'acronym': 'QTH',
                      'latitude': 45.78258076,
                      'longitude': 131.0216093,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 100000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 9,
                  'name': 'SHENYANG',
                  'plants': [{
                      'id': 13,
                      'name': 'Sembcorp ShenYang Water Co.,Ltd',
                      'acronym': 'SY',
                      'latitude': 41.7683039508,
                      'longitude': 123.254697906,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 160000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 1,
                  'name': 'TIANJIN',
                  'plants': [{
                      'id': 2,
                      'name': 'Sembcorp Tianjin Lingang Water CO., Ltd.',
                      'acronym': 'TLIA',
                      'latitude': 38.93362558,
                      'longitude': 117.72709137,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 10000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 12,
                  'name': 'YANJIAO',
                  'plants': [{
                      'id': 16,
                      'name': 'Sanhe Yanjiao sembcorp  Co., Ltd.',
                      'acronym': 'YJ',
                      'latitude': 39.9710447,
                      'longitude': 116.79924131,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 80000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }, {
                  'id': 3,
                  'name': 'ZHANGJIAGANG',
                  'plants': [{
                      'id': 5,
                      'name': 'Zhangjiagang Free Trade Zone Sembcorp Water Co.,Ltd.',
                      'acronym': 'ZJG',
                      'latitude': 31.99245343,
                      'longitude': 120.46323979,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 45000.0,
                      'process': 'Water treatment'
                  }, {
                      'id': 6,
                      'name': 'Zhangjiagang Free Trade Zone Sembcorp Reclaimed Water  Co., Ltd.',
                      'acronym': 'ZJGWR',
                      'latitude': 31.989842,
                      'longitude': 120.462681,
                      'timeZone': 'China Standard Time',
                      'installedCapacity': 24000.0,
                      'process': 'Water treatment'
                  }],
                  'plant': null
              }],
              'city': null
          }],
          'country': null
      }
  };
}
}
