import { Component, OnInit, ViewChild, ElementRef, Inject } from '@angular/core';
import { MatTable, MatTableDataSource, MatPaginator, MatPaginatorIntl, MatSort } from '@angular/material';
import  { ChartData } from './chartData';
import { DataAnalysisService } from 'src/app/services/data-analysis.service';
import { MatIconModule, MatButtonModule } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { MultiAxesChartComponent } from 'src/app/components/multi-axes-chart/multi-axes-chart.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { DatePipe } from '@angular/common'
import * as moment from 'moment';

@Component({
  selector: 'app-test-chart',
  templateUrl: './data-analysis.component.html',
  styleUrls: ['./data-analysis.component.css']
})


export class DataAnalysisComponent implements OnInit {

  private tagData;
  private tags : ChartData[];
  private tagsOriginalOrder : ChartData[];
  public dataY1;
  public dataY2;
  public dataY1in = [];
  public dataY2in = [];
  public trend;
  public trendY1;
  public trendY2;
  public labels;
  private elementId;
  public range;
  public datesMethod;
  public dateRange;
  public ranges = [1, 7, 30, 180];
  public plants;
  public currentPlant;
  public selectedPlant;
  public temp;
  public ready = false;
  public startDate;
  public endDate;
  public startDateObject;
  public endDateObject;
  public maxDate: Date;
  public minDate: Date;
  public fileName: string;
  public fromDate;
  public toDate;

  /**
   * Declarations for the Material table
   */
  dataSource: MatTableDataSource<ChartData>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('TABLE') table: ElementRef;
  @ViewChild(MultiAxesChartComponent) chart: MultiAxesChartComponent;
  displayedColumns: string[] = ['id', 'label', 'desc', 'desc_ch'];
  pageIndex = 0;
  pageSize = 10;
  maxSize;
  selectedPlantId = 0;
  constructor(private _dataAnalysisService: DataAnalysisService,
              private _commonService: CommonService,
              public dialog: MatDialog,
              private pipe: DatePipe,
              private errorService: ErrorserviceService) { }

  ngOnInit() {

    this.trendY1 = [];
    this.trendY2 = [];
    this.dateRange = 7; // Showing the plot for 7 days by default
    this.range = 7;
    this.datesMethod = "dropdown"; // The method for choosing how the plot values are displayed, by selecting number of days (dropdown), or by selecting start and end dates (range)
    this.labels = [];

    this.dataY1 = [];
    this.dataY2 = [];
    this.trend = [];

    this.plants = [];

    /**
     * NOTE:
     * Here we are enabling the user to select the dates from the 1st if January 2018 till today,
     * But are restricting them to be able to see only 1 year worth of data at maximum at once
     * Kind of like a Sliding Window (If you got the reference, enjoy the warm, fuzzy feeling of pride and satisfaction ;) )
     */

    this.maxDate = new Date();
    this.minDate = new Date(2018, 0, 1);
    
    this.toDate = new Date();
    this.fromDate = new Date(this.toDate.getFullYear() - 1, this.toDate.getMonth(), this.toDate.getDate() + 1);

    this.chart.startDate = this.pipe.transform(this.fromDate, 'dd/MMM/yy').toString();
    this.chart.endDate = this.pipe.transform(this.toDate, 'dd/MMM/yy').toString();



    /*
    ** This function gets all the plants available for data analysis
    */

    this._commonService.getplants().subscribe(
      data => {
        this.temp = data;
        if(this.temp.status !== "success"){
          this.errorService.showerror({
            status: this.temp.errorCode,
            statusText: this.temp.message
          });
          return;
        }
        this.temp = this.temp.data;

        // Process all the plants into the plants variable
        for(let i=0; i < this.temp.countries.length; i++) {
          for(let j=0; j < this.temp.countries[i].cities.length; j++) {
            for(let k=0; k < this.temp.countries[i].cities[j].plants.length; k++) {
              this.temp.countries[i].cities[j].plants[k]["countryId"] = this.temp.countries[i].id;
              this.temp.countries[i].cities[j].plants[k]["cityId"] = this.temp.countries[i].cities[j].id;
              this.plants.push(this.temp.countries[i].cities[j].plants[k]);
            }
          }
        }
        this.plants.sort((a, b) => a.acronym.toLowerCase() < b.acronym.toLowerCase() ? -1 : (a.acronym.toLowerCase() > b.acronym.toLowerCase() ? 1 : 0));
      }
    );
    this.updateInputs();
  }

  /*
  ** Function to filter table values
  */
  applyFilter(filterValue: string) {
    if(this.dataSource === undefined) return;
    this.dataSource.filter = filterValue.toLowerCase();

    this.dataSource.filterPredicate = (data, filter) => {
      try {
        return ( data.label.toLowerCase().indexOf(filter) !== -1 || data.desc.toLowerCase().indexOf(filter) !== -1 || data.desc_ch.toLowerCase().indexOf(filter) !== -1);
      } catch(e) {
        return;
      }
    }
    this.maxSize = this.dataSource.filteredData.length;

    if (this.dataSource.paginator) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.paginator.firstPage();
    }
  }

  /*
  ** Function to sort table values
  */
  sortTable(event) {

    let column = event.active;
    let direction = event.direction;
    switch(direction) {
      case "asc":
        this.dataSource.filteredData.sort((a, b) => a[column] < b[column] ? -1 : (a[column] > b[column] ? 1 : 0));
        break;
      case "desc":
        this.dataSource.filteredData.sort((a, b) => a[column] > b[column] ? -1 : (a[column] < b[column] ? 1 : 0));
        break;
      case "":
        let value = (<HTMLInputElement>document.getElementById("filter")).value;
        this.dataSource.data = [];
        this.dataSource.data.length = 0;
        for(let i = 0; i < this.tagsOriginalOrder.length; i++) {
          let index = this.dataY1.findIndex(item => {
            return item.id === this.tagsOriginalOrder[i].id;
          });
          if(index !== -1) continue;
          index = this.dataY2.findIndex(item => {
            return item.id === this.tagsOriginalOrder[i].id;
          });
          if(index !== -1) continue;
          this.dataSource.data.push(this.tagsOriginalOrder[i]);
        }
        this.applyFilter(value);
    }
    
  }

  /*
  ** Choose a plant
  */
  changePlant(selectedPlant) {
    this.ready = false;
    this.resetChart();
    this.currentPlant = selectedPlant.acronym;
    this.selectedPlantId = selectedPlant.id;
    this._dataAnalysisService.getAllTags(selectedPlant.countryId, selectedPlant.cityId, selectedPlant.id).subscribe(
      data => {
          this.tagData = data;
          if(this.tagData.status != "success") {
            this.errorService.showerror({
              status: this.tagData.errorCode,
              statusText: this.tagData.message
            });
            return;
          }
          if(this.tagData.data) {
            this.tags = [];
            this.tagsOriginalOrder = [];
            for(let i=0; i < this.tagData.data.countries.length; i++) {
              if(this.tagData.data.countries[i].id == 26) {
              for(let j=0; j < this.tagData.data.countries[i].cities.length; j++) {
                for(let k = 0; k < this.tagData.data.countries[i].cities[j].plants.length; k++) {
                  for(let l = 0; l < this.tagData.data.countries[i].cities[j].plants[k].tags.length; l++) {
                    if(this.tagData.data.countries[i].cities[j].plants[k].tags[l]["tagtypeCode"] !== "EQUP") {
                      this.tags.push(
                        {
                          id: this.tagData.data.countries[i].cities[j].plants[k].tags[l].tagId,
                          label: this.tagData.data.countries[i].cities[j].plants[k].tags[l].tagname,
                          desc: this.tagData.data.countries[i].cities[j].plants[k].tags[l].tagDesc.en,
                          desc_ch: this.tagData.data.countries[i].cities[j].plants[k].tags[l].tagDesc.cn,
                          plantId: this.tagData.data.countries[i].cities[j].plants[k].tags[l].plantId,
                          countryId: this.tagData.data.countries[i].id,
                          cityId: this.tagData.data.countries[i].cities[j].id,
                          data: [[], []],
                          originalData: [[], []],
                          rawData: [[], []]
                        }
                      )
                      this.tagsOriginalOrder.push(
                        {
                          id: this.tagData.data.countries[i].cities[j].plants[k].tags[l].tagId,
                          label: this.tagData.data.countries[i].cities[j].plants[k].tags[l].tagname,
                          desc: this.tagData.data.countries[i].cities[j].plants[k].tags[l].tagDesc.en,
                          desc_ch: this.tagData.data.countries[i].cities[j].plants[k].tags[l].tagDesc.cn,
                          plantId: this.tagData.data.countries[i].cities[j].plants[k].tags[l].plantId,
                          countryId: this.tagData.data.countries[i].id,
                          cityId: this.tagData.data.countries[i].cities[j].id,
                          data: [[], []],
                          originalData: [[], []],
                          rawData: [[], []]
                        }
                      )
                    }
                  }
                }
              }
            }
            }

            /**
             * Sort the tags into ascending order by name
             */
            this.tags.sort((a, b) => a.label.toLowerCase() < b.label.toLowerCase() ? -1 : (a.label.toLowerCase() > b.label.toLowerCase() ? 1 : 0));
            this.tagsOriginalOrder.sort((a, b) => a.label.toLowerCase() < b.label.toLowerCase() ? -1 : (a.label.toLowerCase() > b.label.toLowerCase() ? 1 : 0));

            this.dataSource = new MatTableDataSource(this.tags);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
            this.dataSource.connect().subscribe(
              data => { }
            );
            this.ready = true;
            this.pageIndex = 0;
            this.maxSize = this.dataSource.filteredData.length;
            
          }
        }
    )
    // this.updateInputs();
  }

  /*
  ** Change the range of values displayed in the graph
  */
  changeRange(type, range) {

    
    let startingDateIndex;
    let endingDateIndex;

    /**
     * CODE FOR THE DETAILED VALUES WHEN DATE RANGE IS 1 DAY
     */
    // console.log("Dates comparison", this.pipe.transform(this.startDate, 'dd/MMM/yy') , this.chart.today, this.pipe.transform(this.chart.startDate, 'dd/MMM/yy') === this.chart.today);
    // if( (type === 'dropdown' && range === 1) || (type === 'range' && (this.chart.startDate && ( this.pipe.transform(this.chart.startDate, 'dd/MMM/yy') === this.chart.today)) ) ) {// Please ignore if the IDE gives any error saying it will always return false. It wont. Sometimes, IDEs can be stupid. Uncomment above console.log line and try for yourself.
    //   console.log("Show 1 day data pls")
    // }

    if(type === "dropdown") {
      startingDateIndex =  this.chart.allLabels.length - range;
      endingDateIndex = this.chart.allLabels.length;
    } 
    else if(type === "range") {

      // Checking if the chosen start date is after the end date
      if(this.chart.startDate && this.chart.endDate) {
        console.log("Difference", moment(this.chart.startDate, "DD/MMM/YY").diff(moment(this.chart.endDate, "DD/MMM/YY"), 'days'))
        if(moment(this.chart.endDate, "DD/MMM/YY").diff(moment(this.chart.startDate, "DD/MMM/YY"), 'days') > 364 ) {
          this.errorService.showerror({
            status: "Invalid.",
            statusText: "Please select dates within 1 year."
          });
          this.changeRange('dropdown', 0);
          return;
        }

        if(moment(this.chart.startDate, "DD/MMM/YY") > moment(this.chart.endDate, "DD/MMM/YY")) {
          this.errorService.showerror({
            status: "Invalid.",
            statusText: "Invalid Dates Chosen."
          });
          this.changeRange('dropdown', 0);
          return;
        }
      }
      if(this.chart.startDate !== undefined) {
        startingDateIndex = this.chart.allLabels.findIndex( t => {
          return t === this.chart.startDate;
        });
      }
      else startingDateIndex = 0; // If the dates have not been chosen even once yet, show everything from the start

      if(this.chart.endDate !== undefined) {
        endingDateIndex = this.chart.allLabels.findIndex( t => {
          return t === this.chart.endDate;
        });
      }
      else endingDateIndex = this.chart.allLabels.length;
      
    }
    
    // Checking if there is enough data to show for requested number of days
    if(startingDateIndex < 0) {
      if(type === "dropdown") startingDateIndex = 0;
      else startingDateIndex = this.chart.allLabels.length; // Trying to delete? HOLD UP! This is not a mistake!
        // This is so that no data is shown if an invalid date is chosen
    }
    if(endingDateIndex < 0) {
      endingDateIndex = this.chart.allLabels.length;
    } else endingDateIndex += 1; // end Date has to be inclusive

    /*
    ** Changing the range for the elements in Y1 Axis box
    */
    this.dataY1.forEach(element => {
      if(!element.originalData) return;
      element.data[0] = [];
      // element.data[0].length = 0;
      if( (type === 'dropdown' && range === 1) || (type === 'range' && (this.chart.startDate && ( this.chart.startDate === this.chart.today.toString())) ) ) {// Please ignore if the IDE gives any error saying it will always return false. It wont. Sometimes, IDEs can be stupid. Uncomment above console.log line and try for yourself.
        element.data[0] = element.rawData[0];
      } else {
        for(let k = startingDateIndex; k < element.originalData[0].length && k < endingDateIndex; k++) {
          element.data[0].push(element.originalData[0][k]);
        }
      }
      
    });

    /*
    ** Changing the range for the elements in Y2 Axis box
    */
    this.dataY2.forEach(element => {
      if(!element.originalData) return;
      element.data[0] = [];
      element.data[0].length = 0;
      if( (type === 'dropdown' && range === 1) || (type === 'range' && (this.chart.startDate && ( this.chart.startDate === this.chart.today.toString())) ) ) {// Please ignore if the IDE gives any error saying it will always return false. It wont. Sometimes, IDEs can be stupid. Uncomment above console.log line and try for yourself.
        element.data[0] = element.rawData[0];
      } else {
        for(let k = startingDateIndex; k < element.originalData[0].length && k < endingDateIndex; k++) {
          element.data[0].push(element.originalData[0][k]);
        }
      }
    });

    this.dateRange = range;

    /*
    ** Changing the range for the elements in Trend box
    */
   
    if( (type === 'dropdown' && range === 1) || (type === 'range' && (this.chart.startDate && ( this.chart.startDate === this.chart.today.toString())) ) ) {// Please ignore if the IDE gives any error saying it will always return false. It wont. Sometimes, IDEs can be stupid. Uncomment above console.log line and try for yourself.
      this.trendY1.forEach(element => {
        element.data = this.calculateTrendLine(element.rawData, element.rawData[1].length, 0, element.rawData[1].length, type)
      });
      this.trendY2.forEach(element => {
        element.data = this.calculateTrendLine(element.rawData, element.rawData[1].length, 0, element.rawData[1].length, type)
      });
    } else {
      this.trendY1.forEach(element => {
        element.data = this.calculateTrendLine(element.originalData, range, startingDateIndex, endingDateIndex, type)
      });
      this.trendY2.forEach(element => {
        element.data = this.calculateTrendLine(element.originalData, range, startingDateIndex, endingDateIndex, type)
      });
    }

    /*
    ** Changing the range for the labels
    */
    this.chart.labels = [];
    this.labels = [];
    this.chart.labels.length = 0;
    this.labels.length = 0;
    if( (type === 'dropdown' && range === 1) || (type === 'range' && (this.chart.startDate && ( this.chart.startDate === this.chart.today.toString())) ) ) {// Please ignore if the IDE gives any error saying it will always return false. It wont. Sometimes, IDEs can be stupid. Uncomment above console.log line and try for yourself.
      for(let i = 0; i < this.chart.rawDataLabels.length; i++) {
        this.chart.labels.push(this.chart.rawDataLabels[i]);
        this.labels.push(this.chart.rawDataLabels[i]);
      }  
    } else {
      for(let i = startingDateIndex; i < this.chart.allLabels.length && i < endingDateIndex; i++) {
        this.chart.labels.push(this.chart.allLabels[i]);
        this.labels.push(this.chart.allLabels[i]);
      }
    }
  }

  /*
  ** Function to show the trendline for a particular tag
  */
  showTrendLine($event) {
    
    if($event.dragData[1] === "Y1") {
      /*
      ** Checking if tag already exists in Trend Box
      */
      let index = this.trendY1.findIndex(t=> {
        return $event.dragData[0].id+'trend' === t.id;
      })
      if(index !== -1) return;

      $event.dragData[0]["axis"] = "Y1";
      this.trend.push($event.dragData[0]);

      this.trendY1.push({
        id: $event.dragData[0].id+'trend',
        label: $event.dragData[0].label+'trend',
        color: $event.dragData[0].color,
        desc: $event.dragData[0].desc,
        dotted: true,
        data: [],
        originalData: [[],[]],
        rawData: [[], []]
      })
      if($event.dragData[0].originalData) {
        $event.dragData[0].originalData[0].forEach(element => {
          this.trendY1[this.trendY1.length - 1].originalData[0].push(element)
        });
        $event.dragData[0].originalData[1].forEach(element => {
          this.trendY1[this.trendY1.length - 1].originalData[1].push(element)
        });
      }
      if($event.dragData[0].rawData) {
        $event.dragData[0].rawData[0].forEach(element => {
          this.trendY1[this.trendY1.length - 1].rawData[0].push(element)
        });
        $event.dragData[0].rawData[1].forEach(element => {
          this.trendY1[this.trendY1.length - 1].rawData[1].push(element)
        });
      }

      /*
      ** Finding the startingIndex to calculate the trendline
      */
      let startingIndex = this.trendY1[this.trendY1.length - 1].originalData[1].findIndex(date => {
        return this.pipe.transform(date, 'dd/MMM/yy') === this.chart.startDate;
      })
      startingIndex = startingIndex < 0 ? 0 : startingIndex;

      /*
      ** Finding the endingIndex to calculate the trendline
      */
      let endingIndex= this.trendY1[this.trendY1.length - 1].originalData[1].findIndex(date => {
        return this.pipe.transform(date, 'dd/MMM/yy') === this.chart.endDate;
      })
      endingIndex = endingIndex < 0 ? this.trendY1[this.trendY1.length - 1].originalData[1].length : endingIndex + 1;

      if( (this.chart.datesMethod === 'dropdown' && this.chart.range === 1) || (this.chart.datesMethod === 'range' && (this.chart.startDate && (this.chart.startDate === this.chart.today.toString())) ) ) {// Please ignore if the IDE gives any error saying it will always return false. It wont. Sometimes, IDEs can be stupid. Uncomment above console.log line and try for yourself.
        this.trendY1[this.trendY1.length - 1].data = this.calculateTrendLine(this.trendY1[this.trendY1.length - 1].rawData, this.trendY1[this.trendY1.length - 1].rawData[1].length, 0, this.trendY1[this.trendY1.length - 1].rawData[1].length, this.datesMethod)
      } else {
        this.trendY1[this.trendY1.length - 1].data = this.calculateTrendLine(this.trendY1[this.trendY1.length - 1].originalData, this.range, startingIndex, endingIndex, this.datesMethod)
      }
      this.dataY1in = this.dataY1.concat(this.trendY1);
    } else {
      /*
      ** Checking if tag already exists in Trend Box
      */
      let index = this.trendY2.findIndex(t=> {
        return $event.dragData[0].id+'trend' === t.id;
      })
      if(index !== -1) return;

      $event.dragData[0]["axis"] = "Y2";
      this.trend.push($event.dragData[0]);
      this.trendY2.push({
        id: $event.dragData[0].id+'trend',
        label: $event.dragData[0].label+'trend',
        color: $event.dragData[0].color,
        desc: $event.dragData[0].desc,
        dotted: true,
        data: [],
        originalData: [[], []],
        rawData: [[], []]
      });

      if($event.dragData[0].originalData) {
        $event.dragData[0].originalData[0].forEach(element => {
          this.trendY2[this.trendY2.length - 1].originalData[0].push(element)
        });
        $event.dragData[0].originalData[1].forEach(element => {
          this.trendY2[this.trendY2.length - 1].originalData[1].push(element)
        });
      }
      if($event.dragData[0].rawData) {
        $event.dragData[0].rawData[0].forEach(element => {
          this.trendY2[this.trendY2.length - 1].rawData[0].push(element)
        });
        $event.dragData[0].rawData[1].forEach(element => {
          this.trendY2[this.trendY2.length - 1].rawData[1].push(element)
        });
      }
      
      /*
      ** Finding the startingIndex to calculate the trendline
      */
      let startingIndex = this.trendY2[this.trendY2.length - 1].originalData[1].findIndex(date => {
        return this.pipe.transform(date, 'dd/MMM/yy') === this.chart.startDate;
      })
      startingIndex = startingIndex < 0 ? 0 : startingIndex;

      /*
      ** Finding the endingIndex to calculate the trendline
      */
      let endingIndex= this.trendY2[this.trendY2.length - 1].originalData[1].findIndex(date => {
        return this.pipe.transform(date, 'dd/MMM/yy') === this.chart.endDate;
      })
      endingIndex = endingIndex < 0 ? this.trendY2[this.trendY2.length - 1].originalData[1].length : endingIndex + 1;
      if( (this.chart.datesMethod === 'dropdown' && this.chart.range === 1) || (this.chart.datesMethod === 'range' && (this.chart.startDate && (this.chart.startDate === this.chart.today.toString())) ) ) {// Please ignore if the IDE gives any error saying it will always return false. It wont. Sometimes, IDEs can be stupid. Uncomment above console.log line and try for yourself.
        this.trendY2[this.trendY2.length - 1].data = this.calculateTrendLine(this.trendY2[this.trendY2.length - 1].rawData, this.trendY2[this.trendY2.length - 1].rawData[1].length, 0, this.trendY2[this.trendY2.length - 1].rawData[1].length, this.datesMethod)
      } else {
        this.trendY2[this.trendY2.length - 1].data = this.calculateTrendLine(this.trendY2[this.trendY2.length - 1].originalData, this.range, startingIndex, endingIndex, this.datesMethod)
      }
      this.dataY2in = this.dataY2.concat(this.trendY2);
    }
    // this.changeRange(this.datesMethod, this.range);
  }

  /*
  ** Function to calculate the trendline for a tag
  */
  calculateTrendLine(d, dateRange, startDateIndex, endDateIndex, type) {

    /*
    ** MANUAL FUNCTION TO CALCULATE THE TRENDLINE FOR A GIVEN SET OF PLOT POINTS
    */

    let startingDateIndex;
    let endingDateIndex;
    if(type === 'dropdown'){
      startingDateIndex = d[1].length - dateRange;;
      endingDateIndex = d[1].length;
    } else if(type === 'range') {
      startingDateIndex =  startDateIndex
      endingDateIndex = endDateIndex;
      dateRange = endingDateIndex - startingDateIndex;
    }
    if(startingDateIndex < 0) {
      
      startingDateIndex = 0;
      // return;
    }
    let data = [[], []];
    // for(let i = startingDateIndex; i < d[0].length && i < d[1].length; i++) {
    //   data[0].push(d[0][i]);
    //   data[1].push(d[1][i]);
    // }
    data[0] = d[0].slice(startingDateIndex, endingDateIndex);
    data[1] = d[1].slice(startingDateIndex, endingDateIndex);
    if(!data || !data[0] || !data[1]) {
      this.errorService.showerror({
        status: "Invalid.",
        statusText: "No data present to show trend line."
      });
      return;
    }


    let nullCount = 0;
    let sigmaX = 0, sigmaY = 0, sigmaXY = 0; // Summation of X values, Summation of Y values
    let sigmaXSqrd = 0; // Summation of values of X squared
    let alpha, beta, x, y, xy; // alpha is the slope, beta is the offset 
    let n = Math.min(data[1].length, data[0].length); // Total number of values
    let trendData = [[], []];
    for(let i = 0; i < dateRange && i < data[1].length &&  i < data[0].length; i++) {
      x = i + 1;
      y = data[0][i];
      if(y === null) {
        nullCount += 1;
        continue;
      }
      xy = x * y;
      sigmaX += x;
      sigmaY += y;
      sigmaXY += xy;
      sigmaXSqrd += (x * x);
    }
    alpha = (((n - nullCount) * sigmaXY) - (sigmaX * sigmaY)) / (((n - nullCount) * sigmaXSqrd) - (sigmaX * sigmaX));
    if(dateRange == 1) {
      alpha = 1; // In case of only 1 day range, the denominator in the above formula will become 0, and will give NaN
    }
    beta = (sigmaY - (alpha * sigmaX)) / (n - nullCount);
    // console.log("N = ", n)
    // console.log("Net N = ", n - nullCount)
    // console.log("Sigma xy = ", sigmaXY)
    // console.log("Sigma x = ", sigmaX)
    // console.log("Sigma y = ", sigmaY)
    // console.log("Sigma x sqrd = ", sigmaXSqrd)
    // console.log("(Sigma x)sq = ", sigmaXY * sigmaX)
    // console.log("Alpha = ", alpha)
    // console.log("Beta = ", beta)
    //Calculating the y values for the trendline now
    
    for(let i = 0; i < dateRange && i < data[1].length &&  i < data[0].length; i++) {
      x = i+1;
      y = (alpha * x) + beta;
      trendData[0].push(y); // Putting the calculated plot values for the trend line
      trendData[1].push(data[1][i]) // Putting the label on that index into the trend array
    }
    return trendData;
  }

  updateChart($event) {

    

    if($event[1] === "Table") {
      let id = $event[0].id;
      //Checking if data entered in Y1
      let index = this.dataY1.findIndex(item => {
        return item.id === id;
      });
      // If data not present in Y1
      if(index === -1) {
        // Checking if data entered in Y2
        index = this.dataY2.findIndex(item => {
          return item.id === id;
        });
      }
      // If data present in either Y1 or Y2
      if(index !== -1) {
        index = this.dataSource.data.findIndex(item => {
          return item.id === id;
        });

        if(index !== -1) { // If data also present in dataSource, delete data
          this.dataSource.data.splice(index, 1);
        }
      }
    }

    let filter = (<HTMLInputElement>document.getElementById("filter")).value;
    if(filter !== "") {
      if($event[1] === "Y1" || $event[1] === "Y2") {
        let index;
        let target = $event[1] === "Y1" ? "Y2" : "Y1";
        
        index = this.dataY1.findIndex(item => {
          return item.id === $event[0].id;
        })
        if(index === -1) {
            index = this.dataY2.findIndex(item => {
              return item.id === $event[0].id;
            });
        }
        if(index === -1) {
          this.dataSource.data.unshift($event[0]);
        }
      }
    }
    this.dataSource.data = this.dataSource.data; //Updating the datasource
    this.maxSize = this.dataSource.filteredData.length;
    this.updateInputs();
    
  }

  resetChart() {
    this.dataY1 = [];
    this.dataY1.length = 0;
    this.dataY2 = [];
    this.dataY2.length = 0;
    this.trendY1 = [];
    this.trendY1.length = 0;
    this.trendY2 = [];
    this.trendY2.length = 0;
    this.trend = [];
    this.trend.length = 0;
    this.chart.labels = [];
    this.chart.labels.length = 0;
    this.chart.allLabels = [];
    this.chart.allLabels.length = 0;
    this.dataY1in = [];
    this.dataY1in.length = 0;
    this.dataY2in = [];
    this.dataY2in.length = 0;
    this.clearDate('both');
    (<HTMLInputElement>document.getElementById("filter")).value = "";
  }

  updateInputs() {
    this.dataY1in = this.dataY1.concat(this.trendY1);
    this.dataY2in = this.dataY2.concat(this.trendY2);
  }

  /*
  ** Function to remove the trendline from the plotted graph
  */
  removeTrendLine(item) {
    //Remove from trend array
    let index = this.trend.findIndex(t => {
      return t.id === item.id
    });

    if(index !== -1) {
      this.trend.splice(index, 1);
    }
    if(item.axis === "Y1") {
      index = this.trendY1.findIndex(t => {
        return t.id === item.id+'trend'
        });
      if(index !== -1) {
        this.trendY1.splice(index, 1);
      }
      this.dataY1in = this.dataY1.concat(this.trendY1);
    } else if(item.axis === "Y2") {
        index = this.trendY2.findIndex(t => {
          return t.id === item.id+'trend'
        });
        if(index !== -1) {
          this.trendY2.splice(index, 1);
        }
        this.dataY2in = this.dataY2.concat(this.trendY2);
    }
  }

  exportData() {
    this.openDialog('data');
    return;
  }

  exportGraph() {
    this.openDialog('chart');
  }

  onPaginateChange($event) {
    this.pageIndex = $event.pageIndex;
    this.pageSize = $event.pageSize;
  }

  draggedToY1($event) {
    
    let element = $event["dragData"][0];
    this.dataY1.push(element);
    if($event["dragData"][1] === "Y2") {
      let index = this.dataY2.findIndex(t => {
        return t.id === element.id;
      })
      if(index !== -1) {
        this.dataY2.splice(index, 1);
      }
      this.removeTrendLine(element);
    } else if($event["dragData"][1] === "Table") {
      let index = this.dataSource.data.findIndex(t => {
        return t.id === element.id;
      })
      if(index !== -1) {
        this.dataSource.data.splice(index, 1);
        this.dataSource.data = this.dataSource.data;
      } 
    }
    this.changeRange(this.datesMethod, this.range);
    this.updateInputs();
    
  }
  draggedToY2($event) {
    
    let element = $event["dragData"][0];
    this.dataY2.push(element);
    if($event["dragData"][1] === "Y1") {
      let index = this.dataY1.findIndex(t => {
        return t.id === element.id;
      })
      if(index !== -1) {
        this.dataY1.splice(index, 1);
      }
      this.removeTrendLine(element);
    } else if($event["dragData"][1] === "Table") {
      let index = this.dataSource.data.findIndex(t => {
        return t.id === element.id;
      })
      if(index !== -1) {
        this.dataSource.data.splice(index, 1);
        this.dataSource.data = this.dataSource.data;
      } 
    }
    this.changeRange(this.datesMethod, this.range);
    this.updateInputs();
    
  }
  draggedToTable($event) {
    
    let element = $event["dragData"][0];
    this.dataSource.data.unshift(element);
    if($event["dragData"][1] === "Y1") {
      let index = this.dataY1.findIndex(t => {
        return t.id === element.id;
      })
      if(index !== -1) {
        this.dataY1.splice(index, 1);
      }
      this.removeTrendLine(element);
    } else if($event["dragData"][1] === "Y2") {
      let index = this.dataY2.findIndex(t => {
        return t.id === element.id;
      })
      if(index !== -1) {
        this.dataY2.splice(index, 1);
      }
      this.removeTrendLine(element);
    }
    this.dataSource.data = this.dataSource.data;
    // if(this.dataY1.length === 0 && this.dataY2.length === 0) {
    //   this.chart.labels = [];
    //   this.chart.labels.length = 0;
    // }
    this.updateInputs();
    
  }

  /*
  ** Set the start and end dates for the range
  */
  addDate(type: string, $event) {
    
    let date = $event.value.toString().split(' ');
    date = date[2] + "/" + date[1] + "/" + date[3].slice(2);
    if(type === 'start') {
      this.startDateObject = $event;
      this.chart.startDate = date;
      // this.endMinDate = new Date(this.chart.startDate);
    }
    if(type === 'end') {
      this.endDateObject = $event;
      this.chart.endDate = date;
      // this.maxDate = new Date(this.chart.endDate)
    }
    this.changeRange('range', this.range);
  }

  /**
   * Clear the dates for the range
   */
  clearDate(which: string) {
    if(which === 'start') {
      this.fromDate = new Date(this.maxDate.getFullYear() - 1, this.maxDate.getMonth(), this.maxDate.getDate() + 1);
      // this.fromDate = this.minDate;
      this.chart.startDate = this.pipe.transform(this.fromDate, 'dd/MMM/yy').toString();
    }
    else if(which === 'end') {
      this.toDate = new Date(this.maxDate.getFullYear(), this.maxDate.getMonth(), this.maxDate.getDate());
      this.chart.endDate = this.pipe.transform(this.toDate, 'dd/MMM/yy').toString();
    }
    else if(which === 'both') {
      this.fromDate = new Date(this.maxDate.getFullYear() - 1, this.maxDate.getMonth(), this.maxDate.getDate() + 1);
      this.toDate = new Date(this.maxDate.getFullYear(), this.maxDate.getMonth(), this.maxDate.getDate());
      this.chart.startDate = this.pipe.transform(this.fromDate, 'dd/MMM/yy').toString();
      this.chart.endDate = this.pipe.transform(this.toDate, 'dd/MMM/yy').toString();
    }
    this.changeRange('range', this.range);
  }

  /**
   *  Function for opening the dialog and accepting the name
   */
  openDialog(action: string) {

    if(moment(this.chart.endDate, "DD/MMM/YY").diff(moment(this.chart.startDate, "DD/MMM/YY"), 'days') > 364 ) {
      this.errorService.showerror({
        status: "Invalid.",
        statusText: "Please select dates within 1 year."
      });
      return;
    }

    const dialogRef = this.dialog.open(NameDialog, {
      width: '250px',
      data: {fileName : this.fileName}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.fileName = result;
      if(!result || result.toString().trim().length === 0) return;

      if(action === 'chart') {
        this.chart.downloadChart(this.fileName);
      } else if(action === 'data') {
        this.chart.exportToExcel(this.fileName);
      }
      this.fileName = '';
    });
  }
}


@Component({
  selector: 'name-dialog',
  templateUrl: 'name-dialog.html',
  styleUrls: ['./data-analysis.component.css']
})
export class NameDialog {
  constructor(public dialogRef: MatDialogRef<NameDialog>, @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onCancel() {
    this.dialogRef.close();
  }
}

export interface DialogData {
  fileName: string;
}