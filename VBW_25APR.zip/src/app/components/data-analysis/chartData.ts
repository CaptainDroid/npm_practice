export interface ChartData {
    id: string;
    label?: string;
    color?: string;
    data: any[];
    desc: string;
    desc_ch?: string;
    name?: string;
    plantId?: number; // REMEMBER TO REMOVE THE OPTIONAL PARAMETER FOR THESE WHEN DONE
    countryId?: number; // "
    cityId?: number; // "
    originalData: any[];
    rawData: any[];
  }