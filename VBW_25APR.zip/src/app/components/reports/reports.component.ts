import { Component, Inject, OnInit, ViewEncapsulation, EventEmitter, Output, ViewChild} from '@angular/core';
import { CommonService } from '../../services/common.service';
import { ErrorserviceService } from '../../services/errorservice.service';
import { ReportsService } from '../../services/reports.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { DialogComponent } from '../common/dialog/dialog.component';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { environment } from '../../../environments/environment';

// Report list component
@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {

  plants: any;
  plantsResponse: any;
  reporttemplatesResponse: any;
  reportTemplates: any;
  selectedPlant = 0;
  selectedTemplate = 0;
  selectedPlantObj: any;

  selectedReport: any = 'allreports';
  reportTypes: any;

  displayedColumns = ['acronym', 'templateName', 'createdAt', 'updatedAt', 'createdBy', 'action'];
  dataSource: any;
  users: any;
  clonereponse: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    private commonservice: CommonService,
    public router: Router,
    private route: ActivatedRoute,
    private errorservice: ErrorserviceService,
    private reportservice: ReportsService,
    public dialog: MatDialog, @Inject(DOCUMENT) document) {

      this.route.params.subscribe(params => {
        if (params.plantid) {
          this.selectedPlant = parseInt(params.plantid, 10);
        }
      });
    }

  ngOnInit() {
    this.plants = [];
    this.reportTemplates = [];
    this.reporttypes();
    this.getplants();
    this.getuserslist();
  }

  getplants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({  type: 'error', status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (this.plants.length > 0 && this.selectedPlant === 0) {
              this.reportservice.setplantInfo(this.plants[0]);
              this.getreporttemplates(this.plants[0]);
            } else if (this.plants.length > 0 && this.selectedPlant !== 0) {
              const plantobj = this.plants.filter(plant => {
                return plant.id === this.selectedPlant;
              });
            this.reportservice.setplantInfo(plantobj[0]);
            this.getreporttemplates(plantobj[0]);
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }
  getreporttemplates(plantObj: any) {
    this.selectedPlant = plantObj.id;
    this.selectedPlantObj = plantObj;
    this.reportTemplates = [];
    this.reportservice.setplantInfo(plantObj);
    this.selectedReport = 'allreports';
    this.reportservice.getreportTemplates(plantObj.id).subscribe(
      data => {
        this.reporttemplatesResponse = data;
        if (this.reporttemplatesResponse.status !== 'success') {
          this.errorservice.showerror({
            type: 'error',
            status: this.reporttemplatesResponse.status,
            statusText: this.reporttemplatesResponse.message });
        } else {
          this.reportTemplates = this.reporttemplatesResponse.data.country.city.plant.reportTemplate;
          /* this.reportTemplates.filter(report => {
            report.acronym = plantObj.acronym;
          }); */
          this.paginator.pageIndex = 0;
          this.dataSource = new MatTableDataSource(this.reportTemplates);
          this.dataSource.filterPredicate = function (filterdata: any, filter: string): boolean {
            // tslint:disable-next-line:max-line-length
            return filterdata.templateTypeName.toLowerCase().includes(filter) || filterdata.templateName.toLowerCase().includes(filter) || filterdata.createdBy.toString().toLowerCase().includes(filter)
          };
          this.dataSource.paginator = this.paginator;
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  selectplant(plantObj: any) {
    let plantinfo = {};
    const currentPlantObj = this.plants.filter( plant => {
      return plant.id === plantObj;
    });
    if (currentPlantObj[0]) {
      this.selectedPlantObj = currentPlantObj[0];
      plantinfo = currentPlantObj[0];
    } else {
      plantinfo = { id: plantObj};
    }
    this.getreporttemplates(plantinfo);
  }

  applyFilter(filterValue: string) {
    if (filterValue) {
      this.dataSource.filter = filterValue.trim().toLowerCase();
    } else  {
      this.dataSource.filter = filterValue;
    }

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  filtertemplate(selectedTemplate: any) {
    if (selectedTemplate !== 'allreports') {
      const filteredReport =  this.reportTemplates.filter(report => {
        return report.templateTypeName === selectedTemplate;
      });
      this.dataSource = new MatTableDataSource(filteredReport);
      this.dataSource.paginator = this.paginator;
    } else {
      this.dataSource = new MatTableDataSource(this.reportTemplates);
      this.dataSource.paginator = this.paginator;
    }
  }

  reporttypes() {
    this.reportservice.getreporttypes().subscribe(
      data => {
        this.reportTypes = data;
        if (this.reportTypes.status !== 'success') {
          this.errorservice.showerror({  type: 'error', status: this.reportTypes.status, statusText: this.reportTypes.message });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  createtemplatedialog(): void {
    const reportTypes = this.reportTypes.data;
// tslint:disable-next-line: no-use-before-declare
    const dialogRef = this.dialog.open(AddreportDialogComponent, {
      width: '500px',
      disableClose: true,
      data: reportTypes
    });
    const sub = dialogRef.componentInstance.addreportcallback.subscribe(result => {
      const plant = this.reportservice.getplantInfo();
      // if (plant.id) {
        if (result.templateType === 'FF') {
          localStorage.setItem('FF_rows', result.rows);
          localStorage.setItem('FF_cols', result.cols);
          this.router.navigate(['createadhoctemplate/' + plant.id]);
        } else {
          this.router.navigate(['createstdreport/' + plant.id]);
        }
      // }
    });
  }

  getuserslist() {
    this.commonservice.getusers().subscribe(data => {
      this.users = data;
      if (this.users.status !== 'success') {
        this.users = [];
        this.errorservice.showerror({  type: 'error', status: this.users.status, statusText: this.users.message });
      }
    });
  }

  reportaction(actionType, templateId, templateType, tempobj) {
    localStorage.setItem('templateName', tempobj.templateName);
    if (actionType === 'edit') {
      if (templateType === 'SF') {
        this.router.navigate(['editstdreport/' + tempobj.plantId + '/' + templateId]);
      } else if (templateType === 'FF') {
        this.router.navigate(['editffreport/' + tempobj.plantId + '/' + templateId]);
      }
    } else if (actionType === 'schedule') {
      this.router.navigate(['schedulereport/' + tempobj.plantId + '/' + templateId]);
    } else if (actionType === 'clone') {
    this.clonereportdialog(templateId);
    }
  }

  clonereportdialog(templateId: any) {
    const userslist = (this.users.data.users) ? this.users.data.users : [];
    const userInfo = this.commonservice.getUser();
// tslint:disable-next-line: no-use-before-declare
    const dialogRef = this.dialog.open(ClonereportDialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
          'templateId': templateId,
           'plants': this.plants,
           'users': userslist,
           'selectedplant': this.selectedPlant,
           'userinfo': userInfo}
      });
    const sub = dialogRef.componentInstance.clonereportcallback.subscribe(result => {
    this.clonereporttemplate(result);
    });
  }

  clonereporttemplate(reqObj: any) {
    reqObj.templateName = reqObj.templateName.trim();
    this.reportservice.clonereport(reqObj).subscribe(
    data => {
        this.clonereponse = data;
        if (this.clonereponse.status !== 'success') {
            this.errorservice.showerror(
              { status: this.clonereponse.errorCode,
                statusText: this.clonereponse.message,
                type: 'error'
              });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            disableClose: true,
            data: {title: 'data.L00224', message: 'data.L00780' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
            const plantobj = this.plants.filter(plant => {
              return plant.id === reqObj.plant;
            });
            this.getreporttemplates(plantobj[0]);
          });
        }
    },
    (err: any) => {
       console.log(err);
    }
);
  }
}

// Add report component

@Component({
  selector: 'app-addreport-dialog-component',
  templateUrl: 'addreport.dialog.html',
  styleUrls: ['./reports.component.css']
})

export class AddreportDialogComponent {
  @Output() addreportcallback = new EventEmitter<any>(true);
  addreportObj = {
    cols: '',
    rows: '',
    templateType: 'SF'
  };

  constructor(
      public dialogRef: MatDialogRef<AddreportDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any) { }

  closeDialog(): void {
      this.dialogRef.close();
  }

  createreporttemplate() {
      this.addreportcallback.emit(this.addreportObj);
  }
}

// Clone report component

@Component({
  selector: 'app-clonereport-dialog-component',
  templateUrl: 'clonereport.dialog.html',
  styleUrls: ['./reports.component.css']
})

export class ClonereportDialogComponent implements OnInit  {

  @Output() clonereportcallback = new EventEmitter<any>(true);

  clonereportObj = {
    plant: 0,
    templateId: 0,
    templateName: '',
    userId: 0
  };
  users: any;

  plantDisabled: any;

  reportModuleAccess = environment.role.reports.view;

  constructor(
      public dialogRef: MatDialogRef<AddreportDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any) {
        this.clonereportObj.plant = data.selectedplant;
        this.clonereportObj.templateId = data.templateId;
        this.users = [];
        this.plantDisabled =  false ;
        const plantChangeRoles = ['Admin'];
        if (plantChangeRoles.indexOf(this.data.userinfo.prn) < 0) {
          this.plantDisabled =  true ;
        }
       }
  ngOnInit() {
    this.populateusers(this.clonereportObj.plant);
  }
  closeDialog(): void {
      this.dialogRef.close();
  }

  clonereport() {
     this.clonereportcallback.emit(this.clonereportObj);
  }

  validatetemplatename() {
    return /^[a-z\d\-_\s]+$/i.test(this.clonereportObj.templateName);
  }

  populateusers(plantid: any) {
    const plantID = parseInt(plantid, 10);
    this.users = [];
    let plantacro = '';
    this.data.plants.forEach(plantobj => {
      if (plantobj.id === plantID) {
        plantacro = plantobj.acronym;
      }
    });
    this.data.users.forEach(userobj => {
      if (userobj.userPlant) {
        const userPlants = userobj.userPlant;
        const userIndex = userPlants.indexOf(plantacro);
        let userRole = userobj.roleName;
        if (userRole) {
          userRole = userRole.toLowerCase();
          userRole = userRole.replace(/\s/g, '');
        }
        const reportsModRole = [];
        this.reportModuleAccess.split(',').forEach(element => {
          if (element) {
            element = element.toLowerCase();
            element = element.replace(/\s/g, '');
            if (reportsModRole.indexOf(element) < 0) {
              reportsModRole.push(element);
            }
          }
        });
        const reportAccess = reportsModRole.indexOf(userRole);
        if (userIndex > -1 && reportAccess > -1) {
          this.users.push(userobj);
        }
      }
    });
    if (this.users.length === 0) {
      this.clonereportObj.userId = 0;
    }
  }
}

// Free format report component

@Component({
  selector: 'app-adhoc-template-component',
  templateUrl: 'adhoc.template.html',
  styleUrls: ['./reports.component.css']
})

export class AdhocTemplateComponent implements OnInit {
  rows: any;
  cols: any;
  plants: any;
  selectedPlant = 0;
  plantsResponse: any;
  frequencylist: any;
  formData: any;
  valdatetagresponse: any;
  savetemplateresponse: any;
  dateFormatlist: any;
  mode: any;
  edittemplateresponse: any;
  pageParams: any;
  selectedPlantObj: any;

  constructor(
    public commonservice: CommonService,
    public errorservice: ErrorserviceService,
    public reportservice: ReportsService,
    public dialog: MatDialog ,
    public router: Router,
    private route: ActivatedRoute,
  ) {
      this.route.params.subscribe(params => {
        this.mode = 'new';
        this.formData = this.preparereq();
        this.pageParams = params;
        if (this.pageParams.templateid) {
           this.mode = 'edit';
        }
        if (this.pageParams.plantid) {
          if (this.mode === 'edit') {
            this.selectedPlant = parseInt(this.pageParams.plantid, 10);
          } else {
            // this.selectedPlant = 0;
            this.selectedPlant = parseInt(this.pageParams.plantid, 10);
          }
        } else {
          this.selectedPlant = 0;
        }
        if (this.mode === 'edit' &&  this.pageParams.templateid) {
          this.gettemplatedata(this.pageParams.templateid);
        }
      });

      if (this.mode === 'new') {
         this.rows = localStorage.getItem('FF_rows');
         this.cols = localStorage.getItem('FF_cols');
         for (let i = 1; i <= this.rows; i++) {
          const colsobj = [];
          for (let j = 1; j <= this.cols; j++) {
            const colobj = {
              'id': 0 ,
              'fieldType': 29,
              'expression': '',
              'rowNo': i,
              'colNo': j
            };
            colsobj.push(colobj);
          }
          const rowobj = { 'row': colsobj };
          this.formData.parameetrs.push(rowobj);
        }
      }

   }
  ngOnInit() {
    this.getplants();
    this.frequencies();
    this.dateformats();
  }

  gettemplatedata(templateId: any) {
      this.reportservice.gettemplate(this.selectedPlant, templateId).subscribe(
        data => {
            this.edittemplateresponse = data;
            if (this.edittemplateresponse.status !== 'success') {
                this.errorservice.showerror(
                  { status: this.edittemplateresponse.errorCode,
                    statusText: this.edittemplateresponse.message,
                    type: 'error'
                  });
            } else {
              this.formData = this.edittemplateresponse.data;
              if (this.mode === 'edit') {
                if (this.formData.parameetrs) {
                  this.rows = this.formData.parameetrs.length;
                  this.cols =  this.formData.parameetrs[0].row.length;
                }
              }
            }
        },
        (err: any) => {
           console.log(err);
        }
    );
  }

  getplants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ type: 'error', status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          this.plants.forEach(plant => {
            if (plant.id === this.selectedPlant) {
              this.selectedPlantObj = plant;
            }
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  changeplant(plantid: any) {
    if (plantid !== 0) {
      this.plants.forEach(plant => {
        if (plant.id === this.selectedPlant) {
          this.selectedPlantObj = plant;
        }
      });
    }
  }


  frequencies() {
    this.reportservice.getfrequency().subscribe(
      data => {
        this.frequencylist = data;
        if (this.frequencylist.status !== 'success') {
          this.errorservice.showerror({ type: 'error', status: this.frequencylist.status, statusText: this.frequencylist.message });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  dateformats() {
    this.reportservice.getdateformats().subscribe(
      data => {
        this.dateFormatlist = data;
        if (this.dateFormatlist.status !== 'success') {
          this.errorservice.showerror({  type: 'error', status: this.dateFormatlist.status, statusText: this.dateFormatlist.message });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  preparereq() {
    const reqObj = {
      'isStandard': false,
      'isFreeFormat': true,
      'isFixed': false,
      'isShedule': false,
      'templateId': 0,
      'templateName': '',
      'templateType': 0,
      'frequency': 0,
      'dateFormat': 0,
      'footer': '',
      'header': '',
      'parameetrs': [],
      'shedule': null
    };
    return reqObj;
 }

 validatetemplatename() {
  return /^[a-z\d\-_\s]+$/i.test(this.formData.templateName);
 }

 savetemplate() {
  this.formData.isFreeFormat = true;
  this.formData.templateName =  this.formData.templateName.trim();

  /* if (/^[a-z\d\-_\s]+$/i.test(this.formData.templateName) === false ) {
    this.errorservice.showerror({type: 'error', status: '', statusText: 'data.L00229'});
    return false;
  } */
  this.reportservice.savetemplate(this.selectedPlant, this.formData).subscribe(
    data => {
        this.savetemplateresponse = data;
        if (this.savetemplateresponse.status !== 'success') {
            this.errorservice.showerror(
              { type: 'error',
                status: this.savetemplateresponse.errorCode,
                statusText: this.savetemplateresponse.message
              });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            disableClose: true,
            data: {title: 'data.L00224', message: 'Template save successfully' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
            this.router.navigate(['reports/' + this.selectedPlant]);
          });
        }
    },
    (err: any) => {
       console.log(err);
    }
);
 }

 validate() {
  this.reportservice.validatetag(this.selectedPlant, this.formData).subscribe(
    data => {
        this.valdatetagresponse = data;
        if (this.valdatetagresponse.status !== 'success') {
            this.errorservice.showerror(
              {
                type: 'error',
                status: this.valdatetagresponse.errorCode,
                statusText: this.valdatetagresponse.message
              });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            disableClose: true,
            data: {title: 'data.L00224', message: 'data.L00777' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
          });
        }
    },
    (err: any) => {
       console.log(err);
    }
  );
}

 cancel() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: {type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.router.navigate(['reports/' + this.selectedPlant]);
    });
  }
  breadcrumbnav() {
    this.router.navigate(['reports/' + this.selectedPlant]);
  }
}

