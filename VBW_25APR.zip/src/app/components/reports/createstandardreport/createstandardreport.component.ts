import { Component, Inject, OnInit, Output } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { ReportsService } from '../../../services/reports.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { MatDialog } from '@angular/material';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-createstandardreport',
  templateUrl: './createstandardreport.component.html',
  styleUrls: ['./createstandardreport.component.css']
})
export class CreatestandardreportComponent implements OnInit {

  plants: any;
  plantsResponse: any;
  selectedPlant = 0;
  selectedReport = 0;
  formData: any;
  pageParams: any;
  savetemplateresponse: any;
  edittemplateresponse: any;
  mode: any;
  valdatetagresponse: any;

  frequencylist: any;

  dateFormatlist: any;
  fieldtypelist: any;
  fieldtypes: any;

  selectedPlantObj: any;

  constructor(
    private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    private reportservice: ReportsService,
    private route: ActivatedRoute,
    public router: Router,
    public dialog: MatDialog
  ) {
    this.fieldtypes = {
      label: 0,
      value: 0
    };
    this.getfieldtypes();
    this.route.params.subscribe(params => {
      this.mode = 'new';
      this.formData = this.preparereq();
      this.pageParams = params;
     if (this.pageParams.templateid) {
        this.mode = 'edit';
     }
     if (this.pageParams.plantid) {
       if (this.mode === 'edit') {
         this.selectedPlant = parseInt(this.pageParams.plantid, 10);
       } else {
         // this.selectedPlant = 0;
         this.selectedPlant = parseInt(this.pageParams.plantid, 10);
       }
     } else {
       this.selectedPlant = 0;
     }
     if (this.mode === 'edit' &&  this.pageParams.templateid) {
       this.gettemplatedata(this.pageParams.templateid);
     }
    });
    this.dateformats();
    this.frequencies();
   }

  ngOnInit() {
    this.getPlants();
    this.selectedReport = 0;
  }

  gettemplatedata(templateId: any) {
    this.reportservice.gettemplate(this.selectedPlant, templateId).subscribe(
      data => {
          this.edittemplateresponse = data;
          console.log(this.edittemplateresponse);
          if (this.edittemplateresponse.status !== 'success') {
              this.errorservice.showerror(
                {
                  type: 'error',
                  status: this.edittemplateresponse.errorCode,
                  statusText: this.edittemplateresponse.message
                });
          } else {
            this.formData = this.edittemplateresponse.data;
            if (this.formData.parameetrs) {
              this.formData.parameetrs.forEach((item, index) => {
                let paramRow = index + 1;
                if (item.row) {
                  if (item.row[0]) {
                    paramRow = item.row[0].rowNo;
                  }
                }
                item.paramname = 'P' + paramRow;
              });
            }
          }
      },
      (err: any) => {
         console.log(err);
      }
  );
  }

  getPlants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({  type: 'error', status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                if (this.selectedPlant === plantobj.id) {
                  this.reportservice.setplantInfo(plantobj);
                }
                this.plants.push(plantobj);
              }
            }
          }
          this.plants.forEach(plant => {
            if (plant.id === this.selectedPlant) {
              this.selectedPlantObj = plant;
            }
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }
  changeplant(plantid: any) {
    if (plantid !== 0) {
      this.plants.forEach(plant => {
        if (plant.id === this.selectedPlant) {
          this.selectedPlantObj = plant;
        }
      });
    }
  }

  getfieldtypes() {
    this.reportservice.fieldtypes().subscribe(
      data => {
      this.fieldtypelist = data;
        if (this.fieldtypelist.status !== 'success') {
          this.errorservice.showerror({  type: 'error', status: this.fieldtypelist.status, statusText: this.fieldtypelist.message });
        } else {
            if (this.fieldtypelist.data) {
                this.fieldtypelist.data.filter(field => {
                  if(field.name === 'L') {
                      this.fieldtypes.label = field.id;
                    } else if (field.name === 'V') {
                      this.fieldtypes.value = field.id;
                    }
                })
            }
            if (this.formData.parameetrs.length > 0 && this.mode === 'new') {
                this.formData.parameetrs[0].row[0].fieldType = this.fieldtypes.label;
                this.formData.parameetrs[0].row[1].fieldType = this.fieldtypes.value;
             }
        }

      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  addparam() {
    const rowno = this.formData.parameetrs.length;
    const paramnameIndex = rowno + 1;
    const pname = 'P' + paramnameIndex;
    const param = [
      {
        'id': 0 ,
        'fieldType': this.fieldtypes.label,
        'expression': '',
        'rowNo': rowno + 1,
        'colNo': 1
     },
     {
        'id': 0 ,
        'fieldType': this.fieldtypes.value,
        'expression': '',
        'rowNo': rowno + 1,
        'colNo': 2
     }
    ];

    this.formData.parameetrs.push({ 'row': param, paramname: pname});
  }

  validatetemplatename() {
    return /^[a-z\d\-_\s]+$/i.test(this.formData.templateName);
  }

  savetemplate() {
    this.formData.isStandard = true;
    this.formData.templateName =  this.formData.templateName.trim();
    this.formData.header =  this.formData.header.trim();
    this.formData.footer =  this.formData.footer.trim();

    /* if (/^[a-z\d\-_\s]+$/i.test(this.formData.templateName) === false ) {
      this.errorservice.showerror({type: 'error', status: '', statusText: 'data.L00229'});
      return false;
    } */

    this.reportservice.savetemplate(this.selectedPlant, this.formData).subscribe(
      data => {
          this.savetemplateresponse = data;
          if (this.savetemplateresponse.status !== 'success') {
              this.errorservice.showerror(
                {
                  type: 'error',
                  status: this.savetemplateresponse.errorCode,
                  statusText: this.savetemplateresponse.message
                });
          } else {
            const dialogRef = this.dialog.open(DialogComponent, {
              width: '400px',
              disableClose: true,
              data: {title: 'data.L00224', message: 'data.L00488' }
            });
            const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
              this.router.navigate(['reports/' + this.selectedPlant]);
            });
          }
      },
      (err: any) => {
         console.log(err);
      }
  );
  }
  validate() {
    this.reportservice.validatetag(this.selectedPlant, this.formData).subscribe(
      data => {
          this.valdatetagresponse = data;
          if (this.valdatetagresponse.status !== 'success') {
              this.errorservice.showerror(
                {
                  type: 'error',
                  status: this.valdatetagresponse.errorCode,
                  statusText: this.valdatetagresponse.message
                });
          } else {
            const dialogRef = this.dialog.open(DialogComponent, {
              width: '400px',
              disableClose: true,
              data: {title: 'data.L00224', message: 'data.L00777' }
            });
            const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
            });
          }
      },
      (err: any) => {
         console.log(err);
      }
    );
  }
  dateformats() {
    this.reportservice.getdateformats().subscribe(
      data => {
        this.dateFormatlist = data;
        if (this.dateFormatlist.status !== 'success') {
          this.errorservice.showerror({  type: 'error', status: this.dateFormatlist.status, statusText: this.dateFormatlist.message });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  frequencies() {
    this.reportservice.getfrequency().subscribe(
      data => {
        this.frequencylist = data;
        if (this.frequencylist.status !== 'success') {
          this.errorservice.showerror({  type: 'error', status: this.frequencylist.status, statusText: this.frequencylist.message });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  preparereq() {

    const reqObj = {
      'isStandard': true,
      'isFreeFormat': false,
      'isFixed': false,
      'isShedule': false,
      'templateId': 0,
      'templateName': '',
      'templateType': 0,
      'frequency': 0,
      'dateFormat': 0,
      'footer': '',
      'header': '',
      'parameetrs': [
        {
          'row': [
             {
                'id': 0 ,
                'fieldType': this.fieldtypes.label,
                'expression': '',
                'rowNo': 1,
                'colNo': 1
             },
             {
                'id': 0 ,
                 'fieldType': this.fieldtypes.label,
                'expression': '',
                'rowNo': 1,
                'colNo': 2
             }
          ],
          'paramname': 'P1'
        }
      ],
      'shedule': null
    };
    return reqObj;
 }

 cancel() {
  const dialogRef = this.dialog.open(DialogComponent, {
    width: '400px',
    disableClose: true,
    data: {type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
  });
  const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
    dialogRef.componentInstance.closeDialog();
    this.router.navigate(['reports/' + this.selectedPlant]);
  });
 }

 breadcrumbnav() {
  this.router.navigate(['reports/' + this.selectedPlant]);
 }

 dropparameters(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.formData.parameetrs, event.previousIndex, event.currentIndex);
 }

}
