import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatestandardreportComponent } from './createstandardreport.component';

describe('CreatestandardreportComponent', () => {
  let component: CreatestandardreportComponent;
  let fixture: ComponentFixture<CreatestandardreportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatestandardreportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatestandardreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
