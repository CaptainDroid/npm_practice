import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { ReportsService } from '../../../services/reports.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-schedulereport',
  templateUrl: './schedulereport.component.html',
  styleUrls: ['./schedulereport.component.css']
})
export class SchedulereportComponent implements OnInit {

  plantsResponse: any;
  plants: any;
  selectedPlant = 0;

  templateName: any;
  pageParams: any;

  schduletemplateResponse: any;

  frequencylist: any;
  selectedfname = '';

  status = 0;
  userRoles: any;
  weekdays: any;
  monthdays: any;

  schduleReportData: any;
  saveScheduleResponse: any;

  ccusers = [];
  tousers = [];

  selectedPlantObj: any;

  constructor( private commonservice: CommonService,
    private errorservice: ErrorserviceService,
    private reportservice: ReportsService,
    private route: ActivatedRoute,
    public router: Router,
    public dialog: MatDialog) {
      this.route.params.subscribe(params => {
        this.pageParams = params;
        if (this.pageParams.plantid) {
          this.selectedPlant = parseInt(this.pageParams.plantid, 10);
          this.userroles();
        } else {
          this.selectedPlant = 0;
        }
      });
    }

  ngOnInit() {
    this.monthdays = [];
    this.templateName = localStorage.getItem('templateName');
    this.schduleReportData = this.prepareobj();
    this.getPlants();
    this.frequencies();
    this.getweekdays();
    if (this.pageParams.templateid) {
      this.getschduletemplatedata(this.pageParams.templateid);
    }
    for (let i = 1; i <= 31;i++ ){
      const monthobj = { 'id': i, 'value': i };
      this.monthdays.push(monthobj);
    }
  }
  getPlants() {
    this.commonservice.getplants().subscribe(
      data => {
        this.plantsResponse = data;
        this.plants = [];
        if (this.plantsResponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsResponse.status, statusText: this.plantsResponse.message });
        } else {
          for (let i = 0; i < this.plantsResponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsResponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsResponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsResponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsResponse.data.countries[i].id;
                plantobj.citiId = this.plantsResponse.data.countries[i].cities[j].id;
                if (this.selectedPlant === plantobj.id) {
                  this.reportservice.setplantInfo(plantobj);
                }
                this.plants.push(plantobj);
              }
            }
          }
          this.plants.forEach(plant => {
            if (plant.id === this.selectedPlant) {
              this.selectedPlantObj = plant;
            }
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  userroles() {
    this.commonservice.getuserroles().subscribe(
      data => {
        this.userRoles = data;
        if (this.userRoles.status !== 'success') {
          this.errorservice.showerror({ status: this.userRoles.status, statusText: this.userRoles.message });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
 }

 getweekdays() {
  this.reportservice.getweekdays().subscribe(
    data => {
      this.weekdays = data;
      if (this.weekdays.status !== 'success') {
        this.errorservice.showerror({ status: this.weekdays.status, statusText: this.weekdays.message });
      }
    },
    (err: any) => {
      console.log(err);
    }
  );
}

  getschduletemplatedata(templateId: any) {
    this.reportservice.getschduletemplate(this.selectedPlant, templateId).subscribe(
      data => {
          this.schduletemplateResponse = data;
          console.log(this.schduletemplateResponse);
          if (this.schduletemplateResponse.status !== 'success') {
              this.errorservice.showerror(
                { status: this.schduletemplateResponse.errorCode,
                  statusText: this.schduletemplateResponse.message
                });
          } else {
              if (this.schduletemplateResponse.data) {
                this.schduleReportData.sheduleId =
                (this.schduletemplateResponse.data.sheduleId) ? this.schduletemplateResponse.data.sheduleId : 0;
                this.schduleReportData.scheduleTime =
                (this.schduletemplateResponse.data.scheduleTime) ? this.schduletemplateResponse.data.scheduleTime : 0;
                this.schduleReportData.frequency =
                (this.schduletemplateResponse.data.frequency) ? this.schduletemplateResponse.data.frequency : 0;
                this.schduleReportData.dateOfMonth =
                (this.schduletemplateResponse.data.dateOfMonth) ? this.schduletemplateResponse.data.dateOfMonth : 0;
                this.schduleReportData.dayOfWeek =
                (this.schduletemplateResponse.data.dayOfWeek) ? this.schduletemplateResponse.data.dayOfWeek : 0;
                this.schduleReportData.to = (this.schduletemplateResponse.data.to) ? this.schduletemplateResponse.data.to : [];
                this.schduleReportData.cc = (this.schduletemplateResponse.data.cc) ? this.schduletemplateResponse.data.cc : [];
                this.schduleReportData.isActive =
                (this.schduletemplateResponse.data.isActive) ? this.schduletemplateResponse.data.isActive : false;

                /* if (this.schduleReportData.dateOfMonth !== 0) {
                  this.selectedfname = 'M';
                }
                if (this.schduleReportData.dayOfWeek !== 0) {
                    this.selectedfname = 'W';
                } */

                if(this.frequencylist) {
                    const getfrequency = this.frequencylist.data.filter( freq => {
                       return freq.id === this.schduleReportData.frequency;
                    });
                    if(getfrequency) {
                      this.selectedfname = getfrequency[0].name;
                      if(this.selectedfname === 'M' && this.schduleReportData.dateOfMonth === 0 ) {
                        this.schduleReportData.lastdayOfMonth = true
                      }
                    }
                }

                this.ccusers = [];
                this.schduleReportData.cc.filter( ccuser => {
                    this.ccusers.push(ccuser.roleId);
                 });
                this.tousers = [];
                this.schduleReportData.to.filter( touser => {
                  this.tousers.push(touser.roleId);
                });
                this.schduleReportData.to = this.tousers;
              }
          }
      },
      (err: any) => {
         console.log(err);
      }
    );
  }

  frequencies() {
    this.reportservice.getfrequency().subscribe(
      data => {
        this.frequencylist = data;
        if (this.frequencylist.status !== 'success') {
          this.errorservice.showerror({ status: this.frequencylist.status, statusText: this.frequencylist.message });
        } else {
          if(this.schduleReportData.frequency) {
            const getfrequency = this.frequencylist.data.filter( freq => {
               return freq.id === this.schduleReportData.frequency;
            });
            if(getfrequency) {
              this.selectedfname = getfrequency[0].name;
              if(this.selectedfname === 'M' && this.schduleReportData.dateOfMonth === 0 ) {
                this.schduleReportData.lastdayOfMonth = true;
              }
            }
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  changefrequency(freq: any) {
    this.selectedfname = freq.name;
    if (this.selectedfname !== 'M') {
      this.schduleReportData.lastdayOfMonth = false;
    }
  }

  changeplant(plantid: any) {
    if (plantid !== 0) {
      this.plants.forEach(plant => {
        if (plant.id === this.selectedPlant) {
          this.selectedPlantObj = plant;
        }
      });
    }
  }

  save() {

    if (this.schduleReportData.scheduleTime
      && /^(2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/.test(this.schduleReportData.scheduleTime) === false) {
        this.errorservice.showerror({status: '', statusText: 'data.L00778'});
        return false;
    }
    this.schduleReportData.cc  = [];
    this.ccusers.filter(ccuser => {
      this.schduleReportData.cc.push({
        'roleId': ccuser
      });
    });

    this.schduleReportData.to = [];
    this.tousers.filter(touser => {
        this.schduleReportData.to.push({
        'roleId': touser
      });
    });

    if (this.selectedfname === 'W') {
        this.schduleReportData.dateOfMonth = 0;
    } else if(this.selectedfname === 'M'){
        this.schduleReportData.dayOfWeek = 0;
    } else {
        this.schduleReportData.dateOfMonth = 0;
        this.schduleReportData.dayOfWeek = 0;
    }

    this.schduleReportData.dateOfMonth = (this.schduleReportData.dateOfMonth === 0 && this.schduleReportData.lastdayOfMonth === false ) ? null : this.schduleReportData.dateOfMonth;
    this.schduleReportData.dayOfWeek = (this.schduleReportData.dayOfWeek === 0) ? null : this.schduleReportData.dayOfWeek;

    this.reportservice.saveschedule(this.selectedPlant, this.schduleReportData).subscribe(
      data => {
        this.saveScheduleResponse = data;
      if (this.saveScheduleResponse.status !== 'success') {
          this.errorservice.showerror(
            {
              status: this.saveScheduleResponse.errorCode,
              statusText: this.saveScheduleResponse.message
            });
        } else {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            disableClose: true,
            data: { title: 'data.L00224', message: 'data.L00779' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
            this.router.navigate(['reports/' + this.selectedPlant]);
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );

  }

  cancelsc() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: {type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.router.navigate(['reports/' + this.selectedPlant]);
    });
  }

  breadcrumbnav() {
    this.router.navigate(['reports/' + this.selectedPlant]);
  }

  prepareobj() {
    const schedulerequest = {
      'sheduleId': 0,
      'tempateId': this.pageParams.templateid,
      'scheduleTime': '',
      'frequency': 0,
      'dateOfMonth': 0,
      'lastdayOfMonth': false,
      'dayOfWeek': 0,
      'isActive': false,
      'to': [],
      'cc': []
    };

    return schedulerequest;
        }
}
