import {Component, HostBinding, Input, OnInit} from '@angular/core';
import {NavItem} from '../main-nav/nav-item';
import {Router} from '@angular/router';
import {NavService} from '../main-nav/nav.service';
import {animate, state, style, transition, trigger} from '@angular/animations';
import { TranslateService } from '@ngx-translate/core';
import { AuthenticationService } from '../../services/authentication.service';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-menu-list-item',
  templateUrl: './menu-list-item.component.html',
  styleUrls: ['./menu-list-item.component.scss'],
  animations: [
    trigger('indicatorRotate', [
      state('collapsed', style({transform: 'rotate(0deg)'})),
      state('expanded', style({transform: 'rotate(180deg)'})),
      transition('expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4,0.0,0.2,1)')
      ),
    ])
  ]
})
export class MenuListItemComponent {
  expanded: boolean;
  translate: any;
  selectedlang = '1';
  userInfo: any;
  @HostBinding('attr.aria-expanded') ariaExpanded = this.expanded;
  @Input() item: NavItem;
  @Input() depth: number;

  constructor(
    private authservice: AuthenticationService,
    private commonservice: CommonService,
    translate: TranslateService, public navService: NavService, public router: Router) {
    if (this.depth === undefined) {
      this.depth = 0;
    }
    this.translate = translate;
    this.userInfo = this.commonservice.getUser();

    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
        if (currentLang === 1) {
          this.selectedlang = '1';
        } else {
          this.selectedlang = '2';
        }
      }
  }

  onItemSelected(item: NavItem) {
    if (item.control) {
        if (item.control === 'LOGOUT') {
          this.authservice.logout();
        }
    } else {
      if (!item.children || !item.children.length) {
        if (item.route) {
          this.router.navigate([item.route]);
        }
        // this.navService.closeNav();
      }
    }
    if (item.children && item.children.length) {
      this.expanded = !this.expanded;
    }
  }

  switchlang(lang: any) {
    this.translate.use(lang);
  }
  // Check menu role permission
  hasRole(roles: any) {
    let isHide = false;
    let rolesCollection = [];
    const trimedRoles = [];
    let currentuserrole = '';
    const currentuser = this.commonservice.getUser();
    if(currentuser.prn) {
      currentuserrole =currentuser.prn;
      currentuserrole = currentuserrole.toLowerCase();
      currentuserrole = currentuserrole.replace(/\s/g, '');
    }

   if(roles) {
    rolesCollection = roles.split(',');
     for (let i = 0; i < rolesCollection.length; i++) {
       let role = rolesCollection[i].toLowerCase();
       role = role.replace(/\s/g, '');
       trimedRoles.push(role);
     }
   }
   if (trimedRoles.length < 1) {
      isHide = false;
   } else {
     if (trimedRoles.indexOf(currentuserrole) > -1) {
      isHide = false;
     } else {
      isHide = true;
     }
   }
   return isHide;
}

}
