import { Component, OnInit, Input } from '@angular/core';
import { DashboardService } from '../../services/dashboard.service';
import { CityviewComponent } from '../cityview/cityview.component';
import { PfdComponent } from '../pfd/pfd.component';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { environment } from '../../../environments/environment';
import { DialogComponent } from '../common/dialog/dialog.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-plantview',
  templateUrl: './plantview.component.html',
  styleUrls: ['./plantview.component.css']
})
export class PlantviewComponent implements OnInit {

  private dashboardData;
  private city : string;
  public country: string;
  public cityName : string;
  public plantData : any;
  private url: any[];

  pfdroleaccess: any;
  isEventsRestricted: any;
  enablepfdfeature = environment.pageaccess.home.pfd;


  constructor(private router: Router,
    private _dashboardService: DashboardService,
    public dialog: MatDialog,
    public commonservice: CommonService,
    private location: Location, private pfdcomp: PfdComponent) {
      this.pfdroleaccess = this.commonservice.isAccess(environment.role.dashboard.pfd.view);
      this.isEventsRestricted = this.commonservice.isAccess(environment.role.alertevents.events);
     }

  ngOnInit() {

    // Getting the selected city
    this.city = this.router.url;
    this.url = this.city.split('/');
    this.city = this.url[this.url.length - 2];
    this.country = this.url[this.url.length - 3];

    // Getting the data for the dashboard
    this.dashboardData = this._dashboardService.dashboardData;
    if(this.dashboardData === undefined) { // To minimise server requests
      this._dashboardService.getDashboardData().subscribe(
        data => {
          this.dashboardData = data;
          this.setCountryData(this.country, this.city);
        }
      );
    } else {
      this.setCountryData(this.country, this.city);
    }
  }

  setCountryData(countryId, cityId): void {
    for(let i = 0; i < this.dashboardData.global.countries.length; i++) {
      if(this.dashboardData.global.countries[i].countryId == countryId) {
        for(let j = 0; j < this.dashboardData.global.countries[i].cities.length; j++) {
          if( this.dashboardData.global.countries[i].cities[j].cityId == cityId) {
            this.cityName = this.dashboardData.global.countries[i].cities[j].cityName;
            this.plantData = this.dashboardData.global.countries[i].cities[j].plants;
          }
        }
      }
    }
  }

  openPFD(pid: Number) {
    // if (this.pfdcomp.pfdopened){
    //   return;
    // }
    // this.pfdcomp.pfdopened = true;
    this.pfdcomp.openDialog(this.country, this.city, pid)
    return this;
  }


  goBack(country: string) {
    /* The location module can be used to go back to the previous page,
    ** but it ACTUALLY takes us back to the PREVIOUS PAGE, regardless of what page we're coming from
    ** so it can lead to some unintended results, so it's better to use router.navigate .
    */
    // this.location.back();

    country = '/cityView/' + country + '/city';
    this.router.navigate([country]);
  }

  viewEvents(plantAcronym) {
    if (this.isEventsRestricted === false) {
      this.router.navigate(['/view-all-events-categories/plant/' + plantAcronym]);
      return;
    } else {
      const dialogRef = this.dialog.open(DialogComponent, {
        width: '400px',
        disableClose: true,
        data: {title: 'data.L00224', message: 'data.L00835' }
      });
      const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
      });
    }
  }

}
