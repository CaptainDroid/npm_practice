import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlantviewComponent } from './plantview.component';

describe('PlantviewComponent', () => {
  let component: PlantviewComponent;
  let fixture: ComponentFixture<PlantviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlantviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlantviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
