import { Component, Inject, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ViewChild, ElementRef, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { NavItem } from './nav-item';
import { environment } from '../../../environments/environment';
import { CommonService } from '../../services/common.service';
import { Keepalive } from '@ng-idle/keepalive';
import { EventTargetInterruptSource, Idle } from '@ng-idle/core';
import { SessiontimeComponent } from '../common/sessiontimeout/sessiontimeout.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AuthenticationService } from '../../services/authentication.service';
import { ChangePasswordDialogComponent } from 'src/app/components/changepassword/changepassword.component';
import { AdalService } from 'adal-angular4';
@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.css']
})

export class MainNavComponent {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
  navItems: NavItem[] = [{
    displayName: 'data.L00062',
    isHide: false,
    route: 'dashboard',
    roles: environment.role.dashboard.view
  },
  {
    displayName: 'data.L00516',
    isHide: false,
    roles: environment.role.admin.view,
    children: [
      {
        displayName: 'data.L00161',
        isHide: false,
        route: 'email-groups',
        roles: environment.role.admin.emailmgmt.view
      },
      {
        displayName: 'data.L00160',
        isHide: false,
        route: 'roles',
        roles: environment.role.admin.rolemgmt.view
      },
      {
        displayName: 'data.L00152',
        isHide: false,
        route: 'user-list',
        roles: environment.role.admin.usermgmt.view
      },
      {
        displayName: 'data.L00252',
        isHide: false,
        route: 'cities',
        roles: environment.role.admin.citymgmt.view
      },
      {
        displayName: 'data.L00237',
        isHide: false,
        route: 'plants',
        roles: environment.role.admin.plantmgmt.view
      },
      {
        displayName: 'data.L00267',
        isHide: false,
        route: 'tags',
        roles: environment.role.admin.tagmgmt.view
      },
      {
        displayName: 'data.L00001',
        isHide: false,
        roles: environment.role.admin.labadminmgmt.view,
        children: [
          {
            displayName: 'data.L00924',
            isHide: false,
            route: 'lab-sample-list',
            roles: ''
          },
          {
            displayName: 'data.L00960',
            isHide: false,
            route: 'lab-test-list',
            roles: ''
          },
          {
            displayName: 'data.L00990',
            isHide: false,
            route: 'sample-test',
            roles:  ''
          },
          {
            displayName: 'data.L01167',
            isHide: false,
            route: 'worksheet-templates-list',
            roles: ''
          }
        ]
      },
      {
        displayName: 'data.L00065',
        isHide: false,
        roles: environment.role.admin.opsadminmgmt.view,
        children: [
          {
            displayName: 'data.L01164',
            isHide: false,
            route: 'ops-location',
            roles: environment.role.admin.opsadminmgmt.locationlist
          },
          {
            displayName: 'data.L01225',
            isHide: false,
            route: 'ops-measurement',
            roles: environment.role.admin.opsadminmgmt.measurementlist
          },
          {
            displayName: 'data.L01166',
            isHide: false,
            route: 'ops-assign',
            roles: environment.role.admin.opsadminmgmt.locationmeasurement
          },
          {
            displayName: 'data.L01167',
            isHide: false,
            route: 'ops-setup',
            roles: environment.role.admin.opsadminmgmt.setupws
          }
        ]
      },
      {
        displayName: 'data.L00104',
        isHide: false,
        roles:  environment.role.admin.maintadminmgmt.view,
        children: [
          {
            displayName: 'Equipment List',
            isHide: false,
            route: 'equipmentlist',
            roles: environment.role.admin.maintadminmgmt.equipmentlist
          },
          {
            displayName: 'Activity List',
            isHide: false,
            route: 'activitylist',
            roles: environment.role.admin.maintadminmgmt.activitylist
          }
        ]
      },
      {
        displayName: 'data.L01127',
        isHide: false,
        route: 'unlock-worksheets',
        roles: environment.role.admin.unlockreqmgmt.view
      }
    ]
  }, {
    displayName: 'data.L00064',
    isHide: false,
    roles: environment.role.alertevents.view,
    children: [
      {
        displayName: 'data.L00375',
        isHide: false,
        route: 'sensor-failure',
        roles: environment.role.alertevents.sensorfailure
      },
      {
        displayName: 'data.L00290',
        isHide: false,
        route: 'event-category-list',
        roles: environment.role.alertevents.eventcategories
      },
      {
        displayName: 'data.L00383',
        isHide: false,
        route: 'event-escalation-email-alert-settings-list',
        roles:  environment.role.alertevents.eventesclations
      },
      {
        displayName: 'data.L00387',
        isHide: false,
        route: 'remote-monitoring-check-list',
        roles: environment.role.alertevents.remotemonitoring
      },
      {
        displayName: 'data.L00327',
        isHide: false,
        route: 'event-message',
        roles: environment.role.alertevents.eventmessages
      },
      {
        displayName: 'data.L00291',
        isHide: false,
        route: 'event-type',
        roles: environment.role.alertevents.eventtypes
      },
      {
        displayName: 'data.L00064',
        isHide: false,
        route: 'view-all-events-categories',
        roles: environment.role.alertevents.events
      }
    ]
  }, {
    displayName: 'data.L00001',
    isHide: false,
    roles: environment.role.lab.view,
    children: [
      {
        displayName: 'data.L00002',
        isHide: false,
        route: 'worksheets',
        roles: ''
      }, {
        displayName: 'data.L00056',
        isHide: false,
        route: 'records',
        roles: ''
      }
    ]
  },
  {
    displayName: 'data.L00065',
    isHide: false,
    roles: environment.role.ops.view,
    children: [
      {
        displayName: 'data.L00002',
        isHide: false,
        route: 'opsworksheets',
        roles: ''
      },
      {
        displayName: 'data.L00056',
        isHide: false,
        route: 'opsrecords',
        roles: ''
      }
    ]
  },
  {
    displayName: 'data.L00104',
    isHide: false,
    roles: environment.role.maintenance.view,
    children: [
      {
        displayName: 'data.L00002',
        isHide: false,
        route: 'opsmaintenance',
        roles: ''
      },
      {
        displayName: 'data.L00056',
        isHide: false,
        route: 'opsmainrecords',
        roles: ''
      }
    ]
  },
  {
    displayName: 'data.L00066',
    isHide: false,
    roles: environment.role.commercial.view,
    children: [
      {
        displayName: 'data.L00416',
        isHide: false,
        route: '/commercial',
        roles: environment.role.commercial.commercialdashboard.view
      },
      {
        displayName: 'data.L00415',
        isHide: false,
        route: 'customerList',
        roles: environment.role.commercial.customercontract.view
      }
    ]
  }, {
    displayName: 'data.L00067',
    isHide: false,
    roles: environment.role.datas.view,
    children: [
      {
        displayName: 'data.L00070',
        isHide: false,
        route: '/audit',
        roles: environment.role.datas.audit.view
      }, {
        displayName: 'data.L00071',
        isHide: false,
        route: '/dataAnalysis',
        roles: environment.role.datas.analysis.view
      }, {
        displayName: 'data.L00551',
        isHide: false,
        route: 'analytics-tags-list/prediction/0',
        roles: environment.role.datas.analyticstags.view
      }, {
        displayName: 'data.L00072',
        isHide: false,
        route: 'prognosis',
        roles: environment.role.datas.progonosis.view
      }, {
        displayName: 'data.L00105',
        isHide: false,
        route: 'troubleshooting',
        roles: environment.role.datas.troubleshooting.view
      }
    ]
  },
  {
    displayName: 'data.L00216',
    isHide: false,
    route: 'reports',
    roles: environment.role.reports.view
  },
  {
    displayName: 'data.L00068',
    isHide: false,
    roles: environment.role.settings.view,
    control: 'settings',
    children: [
      {
        displayName: 'data.L00074',
        isHide: false,
        roles: environment.role.settings.lang,
        dropdown: [
          {
            value: '1', viewValue: 'English 英文'
          }, {
            value: '2', viewValue: 'Chinese 中文'
          }
        ]
      }, {
        displayName: 'data.L01035',
        isHide: false,
        route: 'changepassword',
        roles: environment.role.settings.enablecp
      },
      {
        displayName: 'data.L00075',
        isHide: true,
        route: '/',
        roles: ''
      }
    ]
  },
  {
    displayName: 'data.L00628',
    isHide: false,
    control: 'loggedinfo',
    roles: ''
  },
  {
    displayName: 'data.L00076',
    isHide: false,
    route: '/login',
    control: 'LOGOUT',
    roles: ''
  }
  ];

  idleState = 'NOT_STARTED';
  timedOut = false;
  lastPing?: Date = null;
  sessiontimeoutpopup: any;
  dialogRef: any;
  isOpenedDialog = false;

  constructor(
    private breakpointObserver: BreakpointObserver,
    private element: ElementRef,
    public adal: AdalService,
    private idle: Idle, private keepalive: Keepalive,
    public dialog: MatDialog, @Inject(DOCUMENT) document,
    public authservice: AuthenticationService,
    private commonservice: CommonService) {

    // Session Timeout implementation
    idle.setIdle(2400); // Session timeout warning dialog (2400 Secs)
    idle.setTimeout(300); // Session timeout time (300 Secs)
    // sets the interrupts like Keydown, scroll, mouse wheel, mouse down, and etc
    idle.setInterrupts([
      new EventTargetInterruptSource(
        this.element.nativeElement, 'keydown DOMMouseScroll mousewheel mousedown touchstart touchmove scroll')]);

    idle.onIdleEnd.subscribe(() => {
      this.idleState = 'NO_LONGER_IDLE';
    });

    idle.onTimeout.subscribe(() => {
      console.log('timeout');
      this.idleState = 'TIMED_OUT';
      this.timedOut = true;
      this.closeProgressForm();
    });

    idle.onIdleStart.subscribe(() => {
      if (!this.sessiontimeoutpopup && this.isOpenedDialog === false) {
       this.idleState = 'IDLE_START', this.opensessionTimeout();
      }
    });

    idle.onTimeoutWarning.subscribe((countdown: any) => {
      this.idleState = 'IDLE_TIME_IN_PROGRESS';
      if (this.sessiontimeoutpopup.componentInstance) {
        this.sessiontimeoutpopup.componentInstance.count = (Math.floor((countdown - 1) / 60) + 1);
        this.sessiontimeoutpopup.componentInstance.progressCount = this.reverseNumber(countdown);
        this.sessiontimeoutpopup.componentInstance.countMinutes = (Math.floor(countdown / 60));
        this.sessiontimeoutpopup.componentInstance.countSeconds = countdown % 60;
      }
    });

    // sets the ping interval to 15 seconds
    keepalive.interval(15);
    this.reset();

    // Force change password initialization
    const currentuser = this.commonservice.getUser();
    if (currentuser !== null && currentuser !== '') {
      if (this.adal.userInfo.authenticated === false &&
        environment.loginConfig.forceChangePassword === true
        && (currentuser.UserStatus === 'New' || (currentuser.azp <= 14 && this.commonservice.cancelChangepwd === false))) {
        this.openChangePasswordDialog(true);
      }
    }

  }
  // Session timeout implementation
  closeProgressForm() {
    if (this.sessiontimeoutpopup.componentInstance) {
      this.sessiontimeoutpopup.componentInstance.closeDialog();
    }
    this.logout();
  }

  reverseNumber(countdown: number) {
    return (300 - (countdown - 1));
  }

  /*ngOnDestroy() {
    this.resetTimeOut();
  }*/

  opensessionTimeout() {
    if (!this.sessiontimeoutpopup && this.isOpenedDialog === false) {
      this.isOpenedDialog = true;
      this.sessiontimeoutpopup = this.dialog.open(SessiontimeComponent, {
        width: '500px',
        data: {},
        disableClose: true
      });
      this.sessiontimeoutpopup.componentInstance.continuecallback.subscribe(result => {
        this.isOpenedDialog = false;
        this.sessiontimeoutpopup.componentInstance.closeDialog();
        this.reset();
      });
      this.sessiontimeoutpopup.componentInstance.logoutcallback.subscribe(result => {
        this.isOpenedDialog = false;
        this.sessiontimeoutpopup.componentInstance.closeDialog();
        this.logout();
      });
    }
  }

  logout() {
    this.sessiontimeoutpopup = '';
    this.resetTimeOut();
    this.authservice.logout();
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
    this.sessiontimeoutpopup = '';
  }

  resetTimeOut() {
    this.idle.stop();
    /*this.idle.onIdleStart.unsubscribe();
    this.idle.onTimeoutWarning.unsubscribe();
    this.idle.onIdleEnd.unsubscribe();*/
  }

  // Check menu role permission
  hasRole(roles: any) {

    let isHide = false;
    let rolesCollection = [];
    const trimedRoles = [];
    let currentuserrole = '';
    const currentuser = this.commonservice.getUser();
    if (currentuser.prn) {
      currentuserrole = currentuser.prn;
      currentuserrole = currentuserrole.toLowerCase();
      currentuserrole = currentuserrole.replace(/\s/g, '');
    }


    if (roles) {
      rolesCollection = roles.split(',');
      for (let i = 0; i < rolesCollection.length; i++) {
        let role = rolesCollection[i].toLowerCase();
        role = role.replace(/\s/g, '');
        trimedRoles.push(role);
      }
    }
    if (trimedRoles.length < 1) {
      isHide = false;
    } else {
      if (trimedRoles.indexOf(currentuserrole) > -1) {
        isHide = false;
      } else {
        isHide = true;
      }
    }
    return isHide;
  }


  // Force change password implementation
  openChangePasswordDialog(newUser: boolean) {
    const currentuser = this.commonservice.getUser();

    const disableClose  = (currentuser.azp <= 14 && currentuser.UserStatus !== 'New') ? true : true;
    this.dialogRef = this.dialog.open(ChangePasswordDialogComponent, {
      width: '600px',
      disableClose: disableClose,
      data: {
        newUser: newUser
      }
    });
  }

  closeChangePasswordDialog() {
    this.dialogRef.close();
  }

}

