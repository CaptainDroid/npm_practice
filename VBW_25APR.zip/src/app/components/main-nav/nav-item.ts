export interface NavItem {
    displayName: string;
    disabled?: boolean;
    iconName?: string;
    route?: string;
    children?: NavItem[];
    dropdown?: Language[];
    notif?: String;
    control?: any;
    isHide?: any;
    roles?:any;
  }
 export interface Language {
    value: String;
    viewValue: String;
 }
