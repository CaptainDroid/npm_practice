export interface ChartData {
  id: string;
  label?: string;
  color?: string;
  data: any[];
  desc: string;
  name?: string;
  plantId: number;
  countryId: number;
  cityId: number;
  originalData: any[];
}