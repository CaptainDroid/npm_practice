import { Component, OnInit, Inject, Input, AfterViewInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { PlantdataService } from '../../services/plantdata.service';
import { Router } from '@angular/router';
import { Observable, timer } from 'rxjs';
import { DatePipe } from '@angular/common';
import * as moment from "moment";

import * as SvgPanZoom from 'svg-pan-zoom';
import * as d3 from 'd3';
import { DataAnalysisService } from 'src/app/services/data-analysis.service';
import { ChartData } from './chartData';
import { LinechartComponent } from 'src/app/components/linechart/linechart.component';
import { QTHhash, SYhash, YJhash, TLIAHash, CZHash, ZJGHash, ZJGPathHash, ZJGWRHash, LYGHash, QDHash, QSWHash, NCIPHash, NSSHash } from './mappingList';

@Component({
  selector: 'app-pfd',
  templateUrl: './pfd.component.html',
  styleUrls: ['./pfd.component.css']
})

export class PfdComponent {

  pfdDetails: any;
  private plant_id: any;
  private country: string;
  private city: string;
  private timerSubscription: any;
  public pfdopened: boolean;
  private dialogRef: MatDialogRef<PfdDialog>
  public zoomRate: any;
  public panRate: any;
  constructor(private router: Router, public dialog: MatDialog, private pfdDataService: PlantdataService) { }

  ngOnInit() {
  }

  openDialog(country: string, city: string, plantid: Number): void {
    this.plant_id = plantid;
    this.country = country;
    this.city = city;
    this.pfdopened = true;

    this.pfdDataService.getPFDDetails(country, city, plantid).toPromise().then(data => {
      this.pfdDetails = data["data"].country.city.plant;
      this.pfdDetails["countryId"] = data["data"].country.id;
      this.dialogRef = this.dialog.open(PfdDialog, {
        data: {
          pfdDetails: this.pfdDetails
        },
        width: '100%',
        panelClass: 'dialog-pane'
      });
      this.subscribeToData();
    })
  }

  private refreshData(): void {
    this.pfdDataService.getPFDDetails(this.country, this.city, this.plant_id).toPromise().then(data => {
      this.pfdDetails = data["data"].country.city.plant;
      if (this.dialogRef && this.dialogRef.componentInstance) {
        this.dialogRef.updateSize('100%', '100%')
        this.dialogRef.componentInstance.data = {
          pfdDetails: this.pfdDetails,
        }

        switch (this.pfdDetails.acronym) {
          case "QTH":
            d3.select("#svg-pfd").attr("data", "assets/svg/QTH.svg")
            break;
          case "SY":
            d3.select("#svg-pfd").attr("data", "assets/svg/Shenyang.svg")
            break;
          case "CZ":
            d3.select("#svg-pfd").attr("data", "assets/svg/CZ.svg")
            break;
          case "YJ":
            d3.select("#svg-pfd").attr("data", "assets/svg/Yanjiao.svg")
            break;
          case "ZJGWR":
            d3.select("#svg-pfd").attr("data", "assets/svg/ZJGWR.svg")
            break;
          case "TLIA":
            d3.select("#svg-pfd").attr("data", "assets/svg/TLIA.svg")
            break;
          case "LYG":
            d3.select("#svg-pfd").attr("data", "assets/svg/LYG.svg")
            break;
          case "QD":
            d3.select("#svg-pfd").attr("data", "assets/svg/QiDong.svg")
            break;
          case "QSW":
            d3.select("#svg-pfd").attr("data", "assets/svg/Qinzhou.svg")
          break;
          case "NCIP":
            d3.select("#svg-pfd").attr("data", "assets/svg/NCIP.svg")
            break;
          case "NSS1":
            d3.select("#svg-pfd").attr("data", "assets/svg/NSS.svg")
            break;
          case "NSS2":
            d3.select("#svg-pfd").attr("data", "assets/svg/NSS2.svg")
            break;
          case "ZJG":
            d3.select("#svg-pfd").attr("data", "assets/svg/ZJGSimplify.svg")
            d3.select("#svg-pfd").attr("style", "visibility:visible;width: 100% !important; height: 100% !important");
            d3.select("#svgnew-pfd").attr("data", "assets/svg/ZJGPath.svg")
            d3.select("#svgnew-pfd").attr("style", "visibility:hidden;width: 0% !important; height: 0% !important");
            break;
        }
        this.subscribeToData();
      } else {
        this.dialogRef.close();
        this.timerSubscription.unsubscribe();
      }
    });
  }

  private subscribeToData(): void {
    const source = timer(300000)
    this.timerSubscription = source.subscribe(() => this.refreshData());
  }

  public ngOnDestroy(): void {
    if (this.timerSubscription) {
      this.timerSubscription.unsubscribe();
      this.plant_id = null;
    }
    this.pfdopened = null;
  }

}

export interface Ihash {
  [location: string]: string;
}

@Component({
  selector: 'pfd-dialog',
  templateUrl: './pfd-dialog.component.html',
  styleUrls: ['./pfd.component.css'],
  encapsulation: ViewEncapsulation.None
})



export class PfdDialog {
  private locations: any;
  public plantName: string;
  public translatepfdTitle: string;
  public translatepfdgraphTitle: string;
  public countryId;
  public cityId;
  public plantId;
  public tagData;
  public tags: {};
  public allTagValues = {};
  public dataY1 = [];
  public dataY2 = [];
  public labels;
  public label;
  public ranges = [7, 30, 60, 90];
  public currentRange = [7, 7, 7, 7];
  public empty = [];
  public ready = false;
  public pipe;
  public predStartIndex;
  public numPredictions;
  public today;
  public predtmrw;
  
  @ViewChild(LinechartComponent) linechart: LinechartComponent;
  constructor(public dialogRef: MatDialogRef<PfdDialog>, 
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dataAnalysisService: DataAnalysisService, 
    private pfdDataService: PlantdataService) { }

  ngOnInit() {
    this.ready = false;
    this.pipe = new DatePipe('en-gb');
    this.today = this.pipe.transform(Date.now(), 'dd/MMM/yy');
    this.predtmrw = this.pipe.transform(Date.now() + 1*24*60*60*1000, '(dd -MMM)');
    this.countryId = this.data.pfdDetails.countryId;
    this.cityId = this.data.pfdDetails.cityId;
    this.plantId = this.data.pfdDetails.id;
    this.plantName = this.data.pfdDetails.acronym
    PfdComponent.prototype.zoomRate = 1;
    PfdComponent.prototype.panRate = {x:1,y:1};

    switch (this.data.pfdDetails.acronym) {
      case "QTH":
        d3.select("#svg-pfd").attr("data", "assets/svg/QTH.svg")
        this.translatepfdTitle = "data.L00901";    
        this.translatepfdgraphTitle = "data.L00912";    
        break;
      case "SY":
        d3.select("#svg-pfd").attr("data", "assets/svg/Shenyang.svg")
        this.translatepfdTitle = "data.L00900";    
        this.translatepfdgraphTitle = "data.L00911";    
        break;
      case "CZ":
        d3.select("#svg-pfd").attr("data", "assets/svg/CZ.svg")
        this.translatepfdTitle = "data.L00898";    
        this.translatepfdgraphTitle = "data.L00909";    
        break;
      case "YJ":
        d3.select("#svg-pfd").attr("data", "assets/svg/Yanjiao.svg")
        this.translatepfdTitle = "data.L00902";    
        this.translatepfdgraphTitle = "data.L00913";    
        break;
      case "ZJGWR":
        d3.select("#svg-pfd").attr("data", "assets/svg/ZJGWR.svg")
        this.translatepfdTitle = "data.L00903";    
        this.translatepfdgraphTitle = "data.L00914";    
        break;
      case "TLIA":
        d3.select("#svg-pfd").attr("data", "assets/svg/TLIA.svg")
        this.translatepfdTitle = "data.L00892";    
        this.translatepfdgraphTitle = "data.L00904";    
        break;
      case "LYG":
        d3.select("#svg-pfd").attr("data", "assets/svg/LYG.svg")
        this.translatepfdTitle = "data.L00896";    
        this.translatepfdgraphTitle = "data.L00907";    
        break;
      case "QD":
        d3.select("#svg-pfd").attr("data", "assets/svg/QiDong.svg")
        this.translatepfdTitle = "data.L00897";    
        this.translatepfdgraphTitle = "data.L00908";    
        break;
      case "QSW":
        d3.select("#svg-pfd").attr("data", "assets/svg/Qinzhou.svg")
        this.translatepfdTitle = "data.L00899";    
        this.translatepfdgraphTitle = "data.L00910";    
      break;
      case "NCIP":
        d3.select("#svg-pfd").attr("data", "assets/svg/NCIP.svg")
        this.translatepfdTitle = "data.L00894";    
        this.translatepfdgraphTitle = "data.L00915";    
        break;
      case "NSS1":
        d3.select("#svg-pfd").attr("data", "assets/svg/NSS.svg")
        this.translatepfdTitle = "data.L00893";    
        this.translatepfdgraphTitle = "data.L00905";    
        break;
      case "NSS2":
        d3.select("#svg-pfd").attr("data", "assets/svg/NSS2.svg")
        this.translatepfdTitle = "data.L00893";    
        this.translatepfdgraphTitle = "data.L00905";    
        break;
      case "ZJG":
        d3.select("#svg-pfd").attr("data", "assets/svg/ZJGSimplify.svg")
        d3.select("#svgnew-pfd").attr("data", "assets/svg/ZJGPath.svg")
        this.translatepfdTitle = "data.L00895";    
        this.translatepfdgraphTitle = "data.L00906";    
        break;
    }


    /*
    ** ADDITIONAL CODE FOR PFD GRAPHS
    */

    this.pfdDataService.getPFDGraphs(this.countryId, this.cityId, this.plantId).subscribe(
      data => {
        this.tagData = data;
        if (this.tagData.status != "success") {
          console.log("Some error occured");
          return;
        }

        if (this.tagData.data) {
          this.labels = [];
          this.label = [[], [], [], []];
          this.tagData = this.tagData.data;
          this.tags = {};
          this.allTagValues = {};
          if (this.tagData.country && this.tagData.country.city && this.tagData.country.city.plant) {
            for (let i = 0; i < this.tagData.country.city.plant.tags.length; i++) {
                            
                /**
                 * Code for Predictions in PFD graphs
                 */
                if(this.predStartIndex === undefined || this.predStartIndex === -1) {
                  this.predStartIndex = this.tagData.country.city.plant.tags[i].plots.onDate.findIndex( date => {
                    return this.today === this.pipe.transform(date, 'dd/MMM/yy');
                  });
                  if(this.predStartIndex !== -1) {
                     /**
                      * ***************** PIKACHU'S WISDOM *****************
                      * The second -1 in the statement below is because the date values in the response contain two occurences of the current date,
                      * one for the actual value, and the other for the predicted value
                      * but since they are both for the same date, we have to discard one from the total dates count
                      */
                    this.numPredictions = this.tagData.country.city.plant.tags[i].plots.onDate.length - this.predStartIndex - 1 - 1;
                  }
                }
              if (this.labels.length == 0) {

                // Setting the labels for the X-axis
                for (let j = 0; j < this.tagData.country.city.plant.tags[i].plots.onDate.length; j++) {
                  this.labels.push(this.pipe.transform(this.tagData.country.city.plant.tags[i].plots.onDate[j], 'dd/MMM/yy'));
                }

                /**
                 * To see the reason for next line, see PIKACHU's WISDOM above
                 */
                this.labels.splice(this.predStartIndex, 1);


                let count = this.labels.length;

                // Setting the starting point for the dates to be shown for the current range
                const startIndex = count < (this.currentRange[0] + this.numPredictions) ? 0 : count - (this.currentRange[0] + this.numPredictions);
                for (let j = 0; j < this.currentRange[0] + this.numPredictions && j < count; j++) { // currentRange initially is 7
                  this.label[0].push(this.labels[startIndex + j]);
                  this.label[1].push(this.labels[startIndex + j]);
                  this.label[2].push(this.labels[startIndex + j]);
                  this.label[3].push(this.labels[startIndex + j]);
                }
              }
              let type = this.tagData.country.city.plant.tags[i].type;
              // Storing all the tag values
              this.allTagValues[this.tagData.country.city.plant.tags[i].type] = [];
              this.allTagValues[this.tagData.country.city.plant.tags[i].type].push(
                {
                  data: [this.tagData.country.city.plant.tags[i].plots.plotValue, this.tagData.country.city.plant.tags[i].plots.onDate]
                }
              );


              // Setting the initial tag values
              let length = this.predStartIndex + 1;
              let startIndex = length - this.currentRange[0];
              if (startIndex < 0) { startIndex = 0; }
              this.tags[type] = [];
              var row = this.createRow(i, false);
              this.tags[type].push(row);
              this.tags[type][0]["data"][0] = this.allTagValues[type][0]["data"][0].slice(startIndex, this.predStartIndex + 1);

              /**
               * Entering data in new prediction tag
               */
              if(type.toLowerCase().indexOf('influent') === -1) {
                  row = this.createRow(i, true);
                  this.tags[type].push(row);
                  this.tags[type][1]["data"][0] = [];
                  // tslint:disable-next-line: max-line-length
                  this.tags[type][1]["data"][0] = this.allTagValues[type][0]["data"][0].slice(this.predStartIndex + 1);
                  for(var p = 0; p < this.currentRange[0] - 1; p++) {
                    this.tags[type][1]["data"][0].unshift(null);
                  }
              }
            }
            // if (this.tags["Influent Flow"]) {
            //   this.tags["Influent Flow"][0]["data"][1] = this.label[0];
            // }
          }
        }
        this.ready = true;
        this.setColors();
      }
    )
  }

  /*
  ** Function to change the range of values displayed in the chart
  */
  changeRange(range, graphIndex) {

    let startingDateIndex = this.predStartIndex - range;
    this.label[graphIndex] = [];
    this.label[graphIndex].length = 0;
    if (startingDateIndex < 0) {
      console.log("Not enough data present for ", range, " days.");
      startingDateIndex = 0;
      // return;
    }

    switch (graphIndex) {
      case 0:
        if (this.allTagValues["Influent Flow"]) {
          let type = "Influent Flow";
          this.changeValues(type, range, startingDateIndex);
        }
        break;
      case 1:
        if (this.allTagValues["Influent NH4"]) {
          let type = "Influent NH4";
          this.changeValues(type, range, startingDateIndex);
        }
        if (this.allTagValues["Effluent NH4"]) {
          let type = "Effluent NH4";
          this.changeValues(type, range, startingDateIndex);
        }
        break;
      case 2:
        if (this.allTagValues["Influent COD"]) {
          let type = "Influent COD";
          this.changeValues(type, range, startingDateIndex);
        }
        if (this.allTagValues['Effluent COD']) {
          let type = "Effluent COD";
          this.changeValues(type, range, startingDateIndex);
        }
        break;
      case 3:
        if (this.allTagValues["Influent TP"]) {
          let type = "Influent TP";
          this.changeValues(type, range, startingDateIndex);
        }
        if (this.allTagValues["Effluent TP"]) {
          let type = "Effluent TP";
          this.changeValues(type, range, startingDateIndex);
        }
        break;
    }

    for (let i = startingDateIndex; i < this.labels.length; i++) {
      this.label[graphIndex].push(this.labels[i]);
    }
  }

  public changeValues(type, range, startingDateIndex) {
    this.tags[type][0]["data"][0] = this.allTagValues[type][0]["data"][0].slice(startingDateIndex, this.predStartIndex + 1);
    if(this.tags[type][1]) {
      this.tags[type][1]["data"][0] = this.allTagValues[type][0]["data"][0].slice(this.predStartIndex + 1);
      for(var p = 0; p < range; p++) {
        this.tags[type][1]["data"][0].unshift(null);
      }
    }
  }
  
  public createRow(i, isPrediction) {
    return {
      id: isPrediction ? this.tagData.country.city.plant.tags[i].tagId + '_Prediction' : this.tagData.country.city.plant.tags[i].tagId,
      tagTypeId: this.tagData.country.city.plant.tags[i].tagtypeid,
      // tslint:disable-next-line: max-line-length
      tagName: isPrediction ? this.tagData.country.city.plant.tags[i].tagname + '_Prediction' : this.tagData.country.city.plant.tags[i].tagname,
      label: isPrediction ? this.tagData.country.city.plant.tags[i].type + '_Prediction' : this.tagData.country.city.plant.tags[i].type,
      countryId: this.tagData.country.id,
      cityId: this.tagData.country.city.id,
      plantId: this.tagData.country.city.plant.id,
      data: [this.tagData.country.city.plant.tags[i].plots.plotValue, this.tagData.country.city.plant.tags[i].plots.onDate],
      originalData: [this.tagData.country.city.plant.tags[i].plots.plotValue,
       this.tagData.country.city.plant.tags[i].plots.onDate],
      dotted: isPrediction ? true : false,
      isPrediction: isPrediction
    }
  }

  public setColors() {
    const keys = Object.keys(this.tags);
    keys.forEach(key => {
      let isInfluent = key.toLowerCase().indexOf('influent');
        if(isInfluent !== -1) {
          this.tags[key][0]['color'] = 'brown';
        } else {
          this.tags[key][0]['color'] = 'blue';
          this.tags[key][1]['color'] = 'purple';
        }
    });
  }

  public svg_update(dp, gid) {
    const svg = document.getElementById("svg-pfd") as HTMLObjectElement;
    const svgDoc = svg.contentDocument;

    const svgnew = document.getElementById("svgnew-pfd") as HTMLObjectElement;
    const svgDocnew = svgnew.contentDocument;

    let str = "";

    dp.forEach(elem => {
      if (elem.source_type === ("LABT" || "Lab")) {
        elem.display_options.forEach(val => {
          switch (val.display_option.toUpperCase()) {
            case "STATIC":
              let arrstr = [];
              val.display_detail.forEach(value => {
                arrstr.push(value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"])
              });

              let static_id_present = svgDoc.getElementById("s_" + gid)

              if (static_id_present) {
                var text_x = d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").attr('x')
                d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").attr("font-weight","bolder").text("LAB")
                arrstr.forEach(x => {
                  d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").text(x)
                })
              }

             
              let static_id_present_new = svgDocnew.getElementById("s_" + gid)
              if (static_id_present_new) {
                var text_x = d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").attr('x')
                d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").attr("font-weight","bolder").text("LAB")
                arrstr.forEach(x => {
                  d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").text(x)
                })
              }

              break;

            case "MOUSEOVER":
              let mo_id_present = svgDoc.getElementById("m_" + gid)
              if (mo_id_present) {
                let str_pre = d3.select(svgDoc).select("svg").select("g#m_" + gid).select("title").text();
                let str_sen = ''
                str_pre.length > 0 ? str_sen += "\n LAB \n----\n" : str_sen += "LAB \n----\n"
                val.display_detail.forEach(value => {
                  str_sen += value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"] + "\n"
                });
                str_pre += str_sen
                d3.select(svgDoc).select("svg").select("g#m_" + gid).select("title").text(str_pre);
              }

              let mo_id_present_new = svgDocnew.getElementById("m_" + gid)
              if (mo_id_present_new) {
                let str_pre = d3.select(svgDocnew).select("svg").select("g#m_" + gid).select("title").text();
                let str_sen = ''
                str_pre.length > 0 ? str_sen += "\n LAB \n----\n" : str_sen += "LAB \n----\n"
                val.display_detail.forEach(value => {
                  str_sen += value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"] + "\n"
                });
                str_pre += str_sen
                d3.select(svgDocnew).select("svg").select("g#m_" + gid).select("title").text(str_pre);
              }

              break;

            case "ANIMATION, MOUSEOVER":
              switch (gid) {

              }
            case "COLOUR: RED":

              break;
          }
        });
      } else if (elem.source_type === ("OPST" || "Ops")) {
        elem.display_options.forEach(val => {

          switch (val.display_option.toUpperCase()) {
            case "STATIC":
              let arrstr = [];
              val.display_detail.forEach(value => {
                arrstr.push(value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"])
              });

              let static_id_present = svgDoc.getElementById("s_" + gid)

              if (static_id_present) {
                var text_x = d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").attr('x')
                d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").attr("font-weight","bolder").text("OPS")
                arrstr.forEach(x => {
                  d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").text(x)
                })
              }
              break;

            case "MOUSEOVER":
              let mo_id_present = svgDoc.getElementById("m_" + gid)
              if (mo_id_present) {
                let str_pre = d3.select(svgDoc).select("svg").select("g#m_" + gid).select("title").text();
                let str_sen = ''
                str_pre.length > 0 ? str_sen += "\nOPS \n---\n" : str_sen += "OPS \n---\n"
                val.display_detail.forEach(value => {
                  str_sen += value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"] + "\n"
                });
                str_pre += str_sen
                d3.select(svgDoc).select("svg").select("g#m_" + gid).select("title").text(str_pre);
              }

              break;

            case "ANIMATION, MOUSEOVER":

              break;
            case "COLOUR: RED":

              break;
          }
        });
      } else if (elem.source_type === ("SEST" || "Sensor")) {
        elem.display_options.forEach(val => {

          switch (val.display_option.toUpperCase()) {
            case "STATIC":
              let arrstr = [];
              val.display_detail.forEach(value => {
                arrstr.push(value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"])
              });

              let static_id_present = svgDoc.getElementById("s_" + gid)
              if (static_id_present) {
                var text_x = d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").attr('x')
                d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").attr("font-weight","bolder").text("SENSOR")
                arrstr.forEach(x => {
                  d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").text(x)
                })
              }

              let static_id_present_new = svgDocnew.getElementById("s_" + gid)
              if (static_id_present_new) {
                var text_x = d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").attr('x')
                d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").attr("font-weight","bolder").text("SENSOR")
                arrstr.forEach(x => {
                  d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").text(x)
                })
              }

              break;

            case "MOUSEOVER":
              let mo_id_present = svgDoc.getElementById("m_" + gid)
              if (mo_id_present) {
                let str_pre = d3.select(svgDoc).select("svg").select("g#m_" + gid).select("title").text();
                let str_sen = ''
                str_pre.length > 0 ? str_sen += "\nSENSOR \n---------\n" : str_sen += "SENSOR \n---------\n"
                val.display_detail.forEach(value => {
                  str_sen += value["description"] + ":" + " " + value["pfdtagvalue"] + " " + value["units"] + "\n"
                });
                str_pre += str_sen
                d3.select(svgDoc).select("svg").select("g#m_" + gid).select("title").text(str_pre)
              }

              let mo_id_present_new = svgDocnew.getElementById("m_" + gid)
              if (mo_id_present_new) {
                let str_pre = d3.select(svgDocnew).select("svg").select("g#m_" + gid).select("title").text();
                let str_sen = ''
                str_pre.length > 0 ? str_sen += "\nSENSOR \n---------\n" : str += "SENSOR \n---------\n"
                val.display_detail.forEach(value => {
                  str_sen += value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"] + "\n"
                });
                str_pre += str_sen
                d3.select(svgDocnew).select("svg").select("g#m_" + gid).select("title").text(str_pre);
              }

            break;

            case "ANIMATION, MOUSEOVER":
              let mo_present = svgDoc.getElementById("m_" + gid)
              let mo_present_new = svgDocnew.getElementById("m_" + gid)

              switch (gid) {
                // Yanjio Animation Start --------------------------------------------
                case "clean_water_tank_1":
                  let path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2
                    let percentage_val = 597.19 - percentage;
                    let path_d = "M0 597.19 L68.03 597.19 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 597.19 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "water_tank_east":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9596
                    let percentage_val = 597.19 - percentage;
                    let path_d = "M0 597.19 L68.03 597.19 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 597.19 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;
                // Yanjio Animation End --------------------------------------------

                case "NaClO Storage Tank (for all)":
                  path_d = d3.select(svgDoc).select("svg").select("g#m_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2
                    let percentage_val = 1146.75 - percentage;
                    let path_d = "M0 1146.75 L96.94 1146.75 L96.94 " + percentage_val + " L0 " + percentage_val + " L0 1146.75 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                // ZJGSimplify & ZJGPath Sensor Tank Calculations ----------------------------
                case "t-1221":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;


                case "t-1221-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d')
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1222":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + " L4.5," + percentage_val + "Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1222-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + " L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + ":" + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1201":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  
                  break;

                case "t-1201-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + ":" + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1203":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage)
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M90.5," + percentage_val + "L90.5,66.428  L166.884,66.428 L166.884," + percentage_val + "L90.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1203-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage)
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M90.5," + percentage_val + "L90.5,66.428  L166.884,66.428 L166.884," + percentage_val + "L90.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1302":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')

                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage)
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  
                  break;

                case "t-1302-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage)
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1303":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1303-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1304":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1304-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1306":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;


                case "t-1306-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;


                case "t-1521":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1521-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;


                case "t-1504":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1504-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;


                case "t-1301a":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1301a-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1301b":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1301b-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-1301c":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1301c-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;


                case "t-1301d":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-1301d-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-8106":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M90.5," + percentage_val + "L90.5,66.428  L166.884,66.428 L166.884," + percentage_val + "L90.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                    }

                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-8106-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M90.5," + percentage_val + "L90.5,66.428  L166.884,66.428 L166.884," + percentage_val + "L90.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#27A3E0").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-8107":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-8107-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-8108a":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#55D871").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-8108b":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#55D871").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-8108a-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#55D871").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;

                case "t-8108b-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#55D871").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDocnew, gid, val.display_detail[0])
                  }
                  break;


                case "t-8109":
                  path_d = d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    percentage = Math.max(0, percentage);
                    let percentage_val = 66.428 - percentage
                    if (percentage_val) {
                      let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                      let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                case "t-8109-path":
                  if (svgDocnew) {
                    path_d = d3.select(svgDocnew).select("svg").select("path#am_" + gid)
                    if (path_d) {
                      let percentage = val.display_detail[0].pfdtagvalue / 1.60
                      percentage = Math.max(0, percentage);
                      let percentage_val = 66.428 - percentage
                      if (percentage_val) {
                        let path_d = "M4.5," + percentage_val + "L4.5,66.428  L83.884,66.428 L83.884," + percentage_val + "L4.5," + percentage_val + "Z"
                        let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                        d3.select(svgDocnew).select("svg").select("path#am_" + gid).attr('d', path_d).attr("fill", "#F7A254").append("title").text(str)
                      }
                    }
                  }

                  if (mo_present_new){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  // ZJGSimplify & ZJGPath Sensor Tank Animations End ----------------------------

                  // ZJGWR Sensor Tank Animations Start ------------------------------------------
                  case "t-2001a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }

                  break;

                  case "t-2001b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }

                  break;

                  case "t-2002a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2002b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2003":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L60.1 1541.69 L60.1 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2004":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L60.1 1541.69 L60.1 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2005a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L68.03 1541.69 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2005b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L68.03 1541.69 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2006":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.47
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L69.34 1541.69 L69.34 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2007":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 4.12
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L43.94 1541.69 L43.94 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2008":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.47
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L35.79 1541.69 L35.79 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2009a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L51.02 1541.69 L51.02 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2009b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L51.02 1541.69 L51.02 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2011":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2017":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 4.12
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L43.94 1541.69 L43.94 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2019a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L51.02 1541.69 L51.02 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2019b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L51.02 1541.69 L51.02 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2021":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.60
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L68.03 1541.69 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2029":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L51.02 1541.69 L51.02 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-2031":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.50
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L68.03 1541.69 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  
                  case "t-2039":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L51.02 1541.69 L51.02 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  
                  case "t-2049":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L51.02 1541.69 L51.02 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  
                  case "t-2059":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.94
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L51.02 1541.69 L51.02 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;


                  case "t-3004":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-3005":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-3006":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str =val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-3007":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-3008":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L56.69 1541.69 L56.69 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-3009a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L69.34 1541.69 L69.34 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-3009b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L69.34 1541.69 L69.34 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-3019a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L69.34 1541.69 L69.34 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-3019b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.35
                    let percentage_val = 1541.69 - percentage;
                    let path_d = "M0 1541.69 L69.34 1541.69 L69.34 " + percentage_val + " L0 " + percentage_val + " L0 1541.69 Z"                  
                    let str = val.display_detail[0].description + " " + ":" + " "  + val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;
                  // ZJGWR Sensor Tank Animations End ------------------------------------------

                  // TLIA Sensor Tank Animation Start ------------------------------------------
                  case "t-101a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.63
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L81.5 946.32 L81.5 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-101b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.63
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L81.5 946.32 L81.5 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-102a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.63
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L81.5 946.32 L81.5 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-102b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.63
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L81.5 946.32 L81.5 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-103a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.63
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L120.9 946.32 L120.9 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-103b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                    let percentage = val.display_detail[0].pfdtagvalue / 1.63
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L120.9 946.32 L120.9 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-104a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                    let percentage = val.display_detail[0].pfdtagvalue / 1.27
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L122.81 946.32 L122.81 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }                  
                  break;

                  case "t-104b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                      let percentage = val.display_detail[0].pfdtagvalue / 1.2729
                      let percentage_val = 946.32 - percentage;
                      let path_d = "M0 946.32 L122.81 946.32 L122.81 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                      let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                      d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;


                  case "t-107a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                    let percentage = val.display_detail[0].pfdtagvalue / 2.475
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L53.86 946.32 L53.86 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-107b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                    let percentage = val.display_detail[0].pfdtagvalue / 2.475
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L53.86 946.32 L53.86 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-106a":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                    let percentage = val.display_detail[0].pfdtagvalue / 1.46
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L68.03 946.32 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-106b":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                    let percentage = val.display_detail[0].pfdtagvalue / 1.46
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L68.03 946.32 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-109":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                    let percentage = val.display_detail[0].pfdtagvalue / 1.56
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L131.1 946.32 L131.1 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-108":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    if (val.display_detail[0].pfdtagvalue > 0 ){
                    let percentage = val.display_detail[0].pfdtagvalue / 2.32
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L57.26 946.32 L57.26 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                    }
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-113":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 4.07
                    let percentage_val = 946.32 - percentage;
                    let path_d = "M0 946.32 L49.07 946.32 L49.07 " + percentage_val + " L0 " + percentage_val + " L0 946.32 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  // TLIA Sensor Tank Animation End ------------------------------------------

                  // LYG Sensor Tank Animation Start ------------------------------------------
                  case "t-1102a_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.58
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L252.99 1950.25 L252.99 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1102b_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.77
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L252.99 1950.25 L252.99 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1103a_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.94
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L174.33 1950.25 L174.33 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1103b_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.96
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L136.06 1950.25 L136.06 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1103c_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.96
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L136.06 1950.25 L136.06 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1103d_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.42
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L136.06 1950.25 L136.06 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1104_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.175
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L113.39 1950.25 L113.39 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1304a_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.6161
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L148.01 1950.25 L148.01 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1304b_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.6494
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L153.37 1950.25 L153.37 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1304c_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.6161
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L148.01 1950.25 L148.01 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1304d_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.6494
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L153.37 1950.25 L153.37 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1306_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.4596
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L290.1 1950.25 L290.1 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1401_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.6344
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L125.29 1950.25 L125.29 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1403_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.5520
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L175.48 1950.25 L175.48 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1405_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.3065
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L68.03 1950.25 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1501_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.9407
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L120.47 1950.25 L120.47 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-1601_lyg":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.6106
                    let percentage_val = 1950.25 - percentage;
                    let path_d = "M0 1950.25 L82.2 1950.25 L82.2 " + percentage_val + " L0 " + percentage_val + " L0 1950.25 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;
                  // LYG Sensor Tank Animation End ------------------------------------------

                  // QiDOng Sensor Tank Animation Start ------------------------------------------
                  case "tk-1002_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.96
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-1002_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.96
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-101a_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-101b_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-102a_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-102b_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-204a_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-204b_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-204a_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-204b_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-302a_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-302b_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-303a_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-303b_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-401a_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-401b_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-702_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 3.135
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L42.52 645.79 L42.52 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-702-effluent-tank_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "tk-703_qd":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.96
                    let percentage_val = 645.79 - percentage;
                    let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;
                  // QiDong Sensor Tank Animation End ------------------------------------------
                  
                  // QSW (Qinzhou) Sensor Tank Animation Start ----------------------------------------
                  case "t-101_qsw":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.147
                    let percentage_val = 785.65 - percentage;
                    let path_d = "M0 785.65 L134.65 785.65 L134.65 " + percentage_val + " L0 " + percentage_val + " L0 785.65 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  // case "t-102_qsw":
                  // am_id_present = svgDoc.getElementById("am_" + gid)
                  // path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  // if (path_d) {
                  //   let percentage = val.display_detail[0].pfdtagvalue / 1.96
                  //   let percentage_val = 645.79 - percentage;
                  //   let path_d = "M0 645.79 L68.03 645.79 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 645.79 Z"                  
                  //   let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                  //   d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  // }
                  // break;

                  case "t-103_qsw":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.205
                    let percentage_val = 785.65 - percentage;
                    let path_d = "M0 785.65 L68.03 785.65 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 785.65 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-107a_qsw":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.4699
                    let percentage_val = 785.65  - percentage;
                    let path_d = "M0 785.65  L79.37 785.65  L79.37 " + percentage_val + " L0 " + percentage_val + " L0 785.65 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-109_qsw":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.469  
                    let percentage_val = 785.65 - percentage;
                    let path_d = "M0 785.65 L158.74 785.65 L158.74 " + percentage_val + " L0 " + percentage_val + " L0 785.65 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "t-110_qsw":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.205
                    let percentage_val = 785.65 - percentage;
                    let path_d = "M0 785.65 L68.03 785.65 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 785.65 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }

                  break;

                  case "t-113_qsw":

                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.96
                    let percentage_val = 785.65 - percentage;
                    let path_d = "M0 785.65 L68.03 785.65 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 785.65 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }

                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }

                  break;
                  // QSW (Qinzhou) Sensor Tank Animation End ------------------------------------------

                  // NCIP Sensor Tank Animation Start ------------------------------------------
                  case "1a_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "1b_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "2a_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "2b_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "3a_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "3b_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "4a_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){
                    this.tank_update(svgDoc, gid, val.display_detail[0])
                  }
                  break;

                  case "4b_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "5a_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1166.55 + percentage;
                    let path_d = "M0 1166.55 L68.03 1166.55 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1166.55 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "5b_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1166.55 + percentage;
                    let path_d = "M0 1166.55 L68.03 1166.55 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1166.55 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "6a_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1165.42 + percentage;
                    let path_d = "M0 1165.42 L68.03 1165.42 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1165.42 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "6b_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1165.42 + percentage;
                    let path_d = "M0 1165.42 L68.03 1165.42 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1165.42 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "7a_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1165.42 + percentage;
                    let path_d = "M0 1165.42 L68.03 1165.42 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1165.42 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "7b_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1165.42 + percentage;
                    let path_d = "M0 1165.42 L68.03 1165.42 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1165.42 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "8a_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1165.42 + percentage;
                    let path_d = "M0 1165.42 L68.03 1165.42 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1165.42 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "8b_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.004
                    let percentage_val = 1165.42 + percentage;
                    let path_d = "M0 1165.42 L68.03 1165.42 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1165.42 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "alum_storage_tank_1_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.216
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L96 1216.44 L96 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"                  
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "alum_storage_tank_2_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.216
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L96 1216.44 L96 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "clean_water_tank_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.216
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L77.95 1216.44 L77.95 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "effluent_water_well_1_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.007
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L121.89 1216.44 L121.89 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "effluent_water_well_2_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.007
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L121.89 1216.44 L121.89 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "regulating_tank_1_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.093
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L121.89 1216.44 L121.89 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "regulating_tank_2_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.093
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L121.89 1216.44 L121.89 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "regulating_tank_3_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.093
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L121.89 1216.44 L121.89 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "regulating_tank_4_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.093
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L121.89 1216.44 L121.89 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "sludge_eq_tank_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 0.8510
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L156.66 1216.44 L156.66 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "solution_tank_1_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "solution_tank_2_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "solution_tank_3_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "solution_tank_4_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L68.03 1216.44 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "sludge_concentation_tank_ncip":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.1968
                    let percentage_val = 1216.44 - percentage;
                    let path_d = "M0 1216.44 L111.4 1216.44 L111.4 " + percentage_val + " L0 " + percentage_val + " L0 1216.44 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;
                  // NCIP Sensor Tank Animation End ------------------------------------------

                  // NSS Sensor Tank Animation Start -----------------------------------------
                  case "t1a04_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1a05_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1a11_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1a13_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b01a_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b01b_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b01c_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b01d_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b02a_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b03a_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b04a_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L79.37 1170.01 L79.37 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b04b_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L79.37 1170.01 L79.37 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b05a_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b05b_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t1b06_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.3066
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L102.05 1170.01 L102.05 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t2001_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t2002_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t2006_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 1.9600
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L79.37 1170.01 L79.37 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  case "t2009_nss":
                  path_d = d3.select(svgDoc).select("svg").select("g#am_" + gid).select("path").attr('d')
                  if (path_d) {
                    let percentage = val.display_detail[0].pfdtagvalue / 2.2050
                    let percentage_val = 1170.01 - percentage;
                    let path_d = "M0 1170.01 L68.03 1170.01 L68.03 " + percentage_val + " L0 " + percentage_val + " L0 1170.01 Z"
                    let str = val.display_detail[0].description + ":" +val.display_detail[0].pfdtagvalue + " " + val.display_detail[0].units
                    d3.select(svgDoc).select("svg").select("g#am_" + gid).append("path").attr("d", path_d).attr("fill", "skyblue").append("title").text(str)
                  }
                  if (mo_present){ this.tank_update(svgDoc, gid, val.display_detail[0]) }
                  break;

                  // NSS Sensor Tank Animation End -------------------------------------------
              }

              case "COLOUR: RED":
              let co_id_present = svgDoc.getElementById("c_" + gid)
              if (co_id_present) {
                if (val.display_detail[0]['pfdtagvalue'] === 0){
                  d3.select(svgDoc).select("svg").select("path#c_" + gid).attr("fill", "#F00")
                }
                else if (val.display_detail[0]['pfdtagvalue'] === 1){
                  d3.select(svgDoc).select("svg").select("path#c_" + gid).attr("fill", "#080")
                }
              }
              break;

              case "COLOUR: GREEN":
              let co_present = svgDoc.getElementById("c_" + gid)
              if (co_present) {
                if (val.display_detail[0]['pfdtagvalue'] === 0){
                  d3.select(svgDoc).select("svg").select("path#c_" + gid).attr("fill", "#080")
                }
                else if (val.display_detail[0]['pfdtagvalue'] === 1){
                  d3.select(svgDoc).select("svg").select("path#c_" + gid).attr("fill", "#F00")
                }
              }
              break;

          }
        });
      } else if (elem.source_type === ("PRED")){
        elem.display_options.forEach(val => {
          switch (val.display_option.toUpperCase()) {
            case "STATIC":
            let arrstr = [];
            val.display_detail.forEach(value => {
              arrstr.push(value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"])
            });

            let static_id_present = svgDoc.getElementById("s_" + gid)

            const pipe = new DatePipe('en-gb');
            const predtmrw = pipe.transform(Date.now() + 1*24*60*60*1000, '(dd -MMM)');
            if (static_id_present) {
              var text_x = d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").attr('x')
              d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").attr("font-weight","bolder").text("PREDICTION" + predtmrw)
              arrstr.forEach(x => {
                d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").text(x)
              })
            }

            let static_id_present_new = svgDocnew.getElementById("s_" + gid)
            if (static_id_present_new) {
              var text_x = d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").attr('x')
              d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").attr("font-weight","bolder").text("PREDICTION" + predtmrw)
              arrstr.forEach(x => {
                d3.select(svgDocnew).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").text(x)
              })
            }

            break;
          }
        })
      } 
      else if (elem.source_type === ("EQUP" || "Equipment")) {
        elem.display_options.forEach(val => {

          switch (val.display_option.toUpperCase()) {
            case "STATIC":
              let arrstr = [];
              val.display_detail.forEach(value => {
                arrstr.push(value["description"] + ":" + " " + value["pfdtagvalue"] + " " + value["units"])
              });

              let static_id_present = svgDoc.getElementById("s_" + gid)

              if (static_id_present) {
                var text_x = d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").attr('x')
                d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").attr("font-weight","bolder").text("EQUIPMENT")
                arrstr.forEach(x => {
                  d3.select(svgDoc).select("svg").select("g#s_" + gid).select("text").append("tspan").attr("x", text_x).attr("dy", "1.2em").text(x)
                })
              }
              break;

            case "MOUSEOVER":
              let mo_id_present = svgDoc.getElementById("m_" + gid)
              if (mo_id_present) {
                let str_sen = ''
                str_sen += "EQUIPMENT \n---------------\n"
                val.display_detail.forEach(value => {
                  str_sen += value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"] + "\n"
                });
                d3.select(svgDoc).select("svg").select("g#m_" + gid).select("title").text(str_sen);
              }

              let mo_id_present_new = svgDocnew.getElementById("m_" + gid)
              if (mo_id_present_new) {
                let str_sen = ''
                str_sen += "EQUIPMENT \n---------------\n"
                val.display_detail.forEach(value => {
                  str_sen += value["description"] + " " + ":" + " " + value["pfdtagvalue"] + " " + value["units"] + "\n"
                });
                d3.select(svgDocnew).select("svg").select("g#m_" + gid).select("title").text(str_sen);
              }
              
              break;

            case "ANIMATION, MOUSEOVER":
              break;


            case "COLOUR: RED":
              let co_id_present = svgDoc.getElementById("c_" + gid)
              if (co_id_present) {
                if (val.display_detail[0]['pfdtagvalue'] === 0){
                  d3.select(svgDoc).select("svg").select("path#c_" + gid).attr("fill", "#F00")
                }
                else {
                  d3.select(svgDoc).select("svg").select("path#c_" + gid).attr("fill", "#080")
                }
              }
            break;
          }
        });
      }

    });
  }

  public tank_update(svgd, id, disp_detail ){
    let title = d3.select(svgd).select("svg").select("g#m_" + id).select("title");
    if (title._groups[0][0]) { 
      let str = d3.select(svgd).select("svg").select("g#m_" + id).select("title").text();
      let tank_str = disp_detail.description + " " + ":" + " "  + disp_detail.pfdtagvalue + " " + disp_detail.units + "\n" + "\n"
      tank_str += str
      d3.select(svgd).select("svg").select("g#m_" + id).select("title").text(tank_str); 
    } else { 
    }
  }



  ngAfterViewInit() {
    document.getElementById("svg-pfd").addEventListener("load", () => {
      const svg = document.getElementById("svg-pfd") as HTMLObjectElement;
      const svgDoc = svg.contentDocument;

      let locations: any;
      let dpo: any;
      let id: any;
      
      switch (this.data.pfdDetails.acronym) {
        case 'QTH':
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, QTHhash[element.location])
            }
          })

          let svgPanZoomqth: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomqth.getZoom()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomqth.zoom(PfdComponent.prototype.zoomRate)
          } 

          break;

        case 'SY':
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, SYhash[element.location])
            }
          })

          let svgPanZoomsy: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomsy.getZoom()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomsy.zoom(PfdComponent.prototype.zoomRate)
          } 
          break;

        case "YJ":
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, YJhash[element.location])
            }
          })

          let svgPanZoomyj: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomyj.getZoom()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomyj.zoom(PfdComponent.prototype.zoomRate)
          } 
          
          break;

        case "TLIA":
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, TLIAHash[element.location])
            }
          })

          let svgPanZoomtlia: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomtlia.getZoom()
            },
            onPan: function(){
              PfdComponent.prototype.panRate = svgPanZoomtlia.getPan()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomtlia.zoom(PfdComponent.prototype.zoomRate)
          } 

          if (PfdComponent.prototype.panRate){
            svgPanZoomtlia.pan(PfdComponent.prototype.panRate)
          } 

          break;

          case "ZJGWR":
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, ZJGWRHash[element.location])
            }
          })

          let svgPanZoomzjgwr: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomzjgwr.getZoom()
            },
            onPan: function(){
              PfdComponent.prototype.panRate = svgPanZoomzjgwr.getPan()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomzjgwr.zoom(PfdComponent.prototype.zoomRate)
          } 

          if (PfdComponent.prototype.panRate){
            svgPanZoomzjgwr.pan(PfdComponent.prototype.panRate)
          } 
          break;

          case "LYG":
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, LYGHash[element.location])
            }
          })

          let svgPanZoomlyg: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomlyg.getZoom()
            },
            onPan: function(){
              PfdComponent.prototype.panRate = svgPanZoomlyg.getPan()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomlyg.zoom(PfdComponent.prototype.zoomRate)
          } 

          if (PfdComponent.prototype.panRate){
            svgPanZoomlyg.pan(PfdComponent.prototype.panRate)
          } 
          break;

          case "QD":
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, QDHash[element.location])
            }
          })

          let svgPanZoomqd: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomqd.getZoom()
            },
            onPan: function(){
              PfdComponent.prototype.panRate = svgPanZoomqd.getPan()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomqd.zoom(PfdComponent.prototype.zoomRate)
          } 

          if (PfdComponent.prototype.panRate){
            svgPanZoomqd.pan(PfdComponent.prototype.panRate)
          }
          break;

          case "QSW":
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, QSWHash[element.location])
            }
          })

          let svgPanZoomqsw: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomqsw.getZoom()
            },
            onPan: function(){
              PfdComponent.prototype.panRate = svgPanZoomqsw.getPan()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomqsw.zoom(PfdComponent.prototype.zoomRate)
          } 

          if (PfdComponent.prototype.panRate){
            svgPanZoomqsw.pan(PfdComponent.prototype.panRate)
          }
          break;

        case "NCIP":
        locations = this.data.pfdDetails.locations;
        locations.forEach(element => {
          if (element.location) {
            dpo = element.types
            this.svg_update(dpo, NCIPHash[element.location])
          }
        })

        let svgPanZoomncip: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
          controlIconsEnabled: true,
          center: true,
          onZoom: function () {
            PfdComponent.prototype.zoomRate = svgPanZoomncip.getZoom()
          },
          onPan: function(){
            PfdComponent.prototype.panRate = svgPanZoomncip.getPan()
          }
        });

        if (PfdComponent.prototype.zoomRate){
          svgPanZoomncip.zoom(PfdComponent.prototype.zoomRate)
        } 

        if (PfdComponent.prototype.panRate){
          svgPanZoomncip.pan(PfdComponent.prototype.panRate)
        }
        break;

        case "NSS1":
        locations = this.data.pfdDetails.locations;
        locations.forEach(element => {
          if (element.location) {
            dpo = element.types
            this.svg_update(dpo, NSSHash[element.location])
          }
        })

        let svgPanZoomnss: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
          controlIconsEnabled: true,
          center: true,
          onZoom: function () {
            PfdComponent.prototype.zoomRate = svgPanZoomnss.getZoom()
          },
          onPan: function(){
            PfdComponent.prototype.panRate = svgPanZoomnss.getPan()
          }
        });

        if (PfdComponent.prototype.zoomRate){
          svgPanZoomnss.zoom(PfdComponent.prototype.zoomRate)
        } 

        if (PfdComponent.prototype.panRate){
          svgPanZoomnss.pan(PfdComponent.prototype.panRate)
        }
        break;

        case "CZ":
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, CZHash[element.location])
            }
          })

          let svgPanZoomcz: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
            center: true,
            onZoom: function () {
              PfdComponent.prototype.zoomRate = svgPanZoomcz.getZoom()
            },
            onPan: function(){
              PfdComponent.prototype.panRate = svgPanZoomcz.getPan()
            }
          });

          if (PfdComponent.prototype.zoomRate){
            svgPanZoomcz.zoom(PfdComponent.prototype.zoomRate)
          } 

          if (PfdComponent.prototype.panRate){
            svgPanZoomcz.pan(PfdComponent.prototype.panRate)
          }
          break;

        case "ZJG":
          locations = this.data.pfdDetails.locations;
          locations.forEach(element => {
            if (element.location) {
              dpo = element.types
              this.svg_update(dpo, ZJGHash[element.location])
            }
          })


          let svgpfd = document.getElementById('svg-pfd')
          let svgnewpfd = document.getElementById('svgnew-pfd')
          let loadfirsttimeonly = false;

          let svgPanZoom: SvgPanZoom.Instance = SvgPanZoom('#svg-pfd', {
            controlIconsEnabled: true,
          })
          
          svgPanZoom.zoom(1)
          svgPanZoom.setOnZoom(function () {
              if (svgPanZoom.getZoom() > 3) {
                svgpfd.setAttribute("style", "visibility:hidden;width: 0 !important; height: 0 !important");
                svgnewpfd.setAttribute("style", "visibility:visible;width: 100% !important;height: 100% !important");

                var x = document.getElementById("svgnew-pfd");
                if (window.getComputedStyle(x).visibility === "visible") {

                  if (loadfirsttimeonly == false) {
                    locations.forEach(element => {
                      if (element.location) {
                        dpo = element.types
                        PfdDialog.prototype.svg_update(dpo, ZJGPathHash[element.location])
                      }
                    })
                    loadfirsttimeonly = true;
                  }

                  let svgPanZoom1: SvgPanZoom.Instance = SvgPanZoom('#svgnew-pfd', {
                    controlIconsEnabled: true,
                    onZoom: function () {
                      if (svgPanZoom1.getZoom() < 1) {
                        svgnewpfd.setAttribute("style", "visibility:hidden;width: 0 !important;height: 0 !important");
                        svgpfd.setAttribute("style", "visibility:visible;width: 100% !important; height: 100% !important");
                      }
                    }
                  })
                }
              }
          })
        break;
      }
    });
  }
}


/**
 * SINGLE LINE CHART FOR PFD GRAPHS
 */

import * as Chart from 'chart.js';


@Component({
  selector: 'app-pfd-single-linechart',
  template: `<div class="wrapper data-analysisscr">
                  <canvas id="{{ elementId }}" class="chart"></canvas>
             </div>`,
  styleUrls: ['../multi-axes-chart/multi-axes-chart.component.css']
})
export class PfdSingleLineChartComponent implements AfterViewInit {

  @Input() data: any;
  @Input() elementId: string;
  @Input() color: string;
  @Input() name: string;
  @Input() labels: any[];

  lineChart;
  canvas: any;
  ctx: any;
  label: string; // The label/title/name for the dataset
  // labels: any[]; // The x-axis values
  values: {};
  datasets = [];
  options = {};
  scales = {};

  constructor() { }

  ngOnInit() {

    // if(this.data === undefined) return;
    this.scales = {
      xAxes: [{
        ticks: {
          autoSkip: true
        }
      }],
    };

    // Setting up the chart parameters
    this.options = {
      elements: {
        point: {
          radius: 2
        }
      },
      legend: {
        position: 'bottom'
      },
      scales: this.scales,
      responsive: true,
      display: true,
      maintainAspectRatio: false,
      onAnimationComplete: function() {}
    };
    this.fillValues();

  }
  ngAfterViewInit() {
 
    this.canvas = document.getElementById(this.elementId);
    if(this.canvas == null) return;
    this.ctx = this.canvas.getContext('2d');
    this.lineChart = new Chart(this.ctx, {
      type: 'line',
      data: {
        labels: this.labels,
        datasets: this.datasets
      },
      options: this.options
    })
  }
  ngOnChanges(changes) {
    // Updating the graph on any changes in the labels
    if(changes && changes.labels && !changes.labels.firstChange) {
      this.lineChart.data.labels = this.labels;
      this.updateValues();
      this.lineChart.update();
    }

    // Updating the graph on any changes in the data

    if( changes && changes.data ) {
      if( changes.data.firstChange ) return;
      this.updateValues();
    }
  }

  fillValues() {

    //Mapping the Y1 dataset values to the Y1 axis
    if(this.data !== undefined)
    for(let i = 0; i < this.data.length; i++) {
      // Creating one data group
      this.values = {
        label: this.data[i].label, // The label / title / name for the dataset,
        data: this.data[i].data[0], // The values of the dataset,
        fill: false,
        backgroundColor: this.data[i].color,
        borderColor: this.data[i].color,
        pointHitRadius: 20,
        borderWidth: this.data[i].dotted ? 1 : 2,
        borderDash: this.data[i].dotted ? [10, 6] : [],
        radius: this.data[i].dotted ? 0 : 2
      };

      // Assigning the color to the tag if it already didn't have it
      this.data[i]["color"] = this.values["backgroundColor"];
      // this.colorIndex = (this.colorIndex + 1) % 10;

      // Insert this data into the chart dataset
      this.datasets.push(this.values);

      // Resetting "values". Not required as it will be written over, but making sure doing manually
      this.values = {};
    }
  }

  updateValues() {
    this.datasets = [];
    this.fillValues();
    this.lineChart.data.datasets = this.datasets;
    this.lineChart.data.labels = this.labels;
    this.lineChart.update();
  }

  
}
