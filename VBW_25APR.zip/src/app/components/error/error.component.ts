import { Component, Inject, EventEmitter, Output  } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from '../../services/common.service';


@Component ( {
  templateUrl: './error.component.html',
  styleUrls: ['./error.dialog.css']
})
export class ErrorDialogComponent {

 @Output() errorokcallback = new EventEmitter<any>(true);
  ok = true;
  isLogged = false;
  constructor(
      public dialogRef: MatDialogRef<ErrorDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any, commonservice: CommonService) {
        this.isLogged = commonservice.isLogged();
       }

  closeDialog(): void {
      this.dialogRef.close();
  }
  deleteworksheet() {
    this.errorokcallback.emit(this.ok);
  }
}
