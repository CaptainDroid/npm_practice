import { Component, OnInit, Inject, HostListener, EventEmitter, Output } from '@angular/core';
import { OpsworksheetService } from '../../../services/opsworksheet.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { Router,ActivatedRoute } from '@angular/router';
import { SubmitopsworksheetComponent } from './editopsworksheet/submitopsworksheet/submitopsworksheet.component';
import { DialogComponent } from '../../common/dialog/dialog.component';
import { CommonService } from '../../../services/common.service';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-opsworksheet',
  templateUrl: './opsworksheet.component.html',
  styleUrls: ['./opsworksheet.component.css']
})
export class OpsworksheetComponent implements OnInit {

  worksheetresponse: any;
  opsworksheets = [];
  position = 'after';
  errorMessage: any;

  sworksheetresonse: any;
  sworksheetData: any;

  plantsresponse: any;
  plants = [];
  selectedplant = 0;
  selectedPlantObj: any;

  submitworksheetResponse: any;

  pageaccess = environment.role.ops;

  isEdit = false;

  constructor(
    public router: Router, public route: ActivatedRoute,
    public commonservice: CommonService,
    private worksheetService: OpsworksheetService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog, @Inject(DOCUMENT) document) {
      this.isEdit = this.commonservice.isAccess(this.pageaccess.edit);
    }

  ngOnInit() {
    this.selectedPlantObj = { acronym: '' };
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedplant = 0;
        this.getplants(this.selectedplant);
      } else {
        this.selectedplant = parseInt(params.plantid, 10);
        this.getplants(this.selectedplant);
      }
    });
  }

  getplants(plantId: any) {
    this.worksheetService.getplants().subscribe(
      data => {
        this.plantsresponse = data;
        this.plants = [];
        if (this.plantsresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantsresponse.status, statusText: this.plantsresponse.message });
        } else {
          for (let i = 0; i < this.plantsresponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantsresponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantsresponse.data.countries[i].cities[j].plants.length; k++) {
                const plantobj = this.plantsresponse.data.countries[i].cities[j].plants[k];
                plantobj.countryId = this.plantsresponse.data.countries[i].id;
                plantobj.citiId = this.plantsresponse.data.countries[i].cities[j].id;
                this.plants.push(plantobj);
              }
            }
          }
          if (plantId === 0) {
            this.opsworksheets = [];
            this.selectedplant = 0;
            if (this.plants.length > 0) {
                this.getWorksheets(this.plants[0]);
              }
          } else {
            const plantobj = this.plants.filter(plnt => {
              return plnt.id === plantId;
            });
            this.selectedplant = plantId;
            if (plantobj[0]) {
              this.getWorksheets(plantobj[0]);
            }
          }
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'data.L00235';
      }
    );
  }

  getWorksheets(plantobj: any) {
    this.selectedplant = plantobj.id;
    this.selectedPlantObj = plantobj;
    this.opsworksheets = [];
    const info = {
      'countryId': plantobj.countryId,
      'citiId': plantobj.citiId,
      'plantacro': plantobj.acronym
    };
    this.worksheetService.setworksheetUserinfo(info);
    if (plantobj.id === 0) {
      this.opsworksheets = [];
    } else {
      this.worksheetService.worksheets(plantobj.id).subscribe(
        data => {
          this.worksheetresponse = data;
          if (this.worksheetresponse.status !== 'success') {
            this.errorservice.showerror(
              {
                status: this.worksheetresponse.errorCode,
                statusText: this.worksheetresponse.message
              });
          } else {
            for (let i = 0; i < this.worksheetresponse.data.country.city.plant.worksheets.length; i++) {
            const worksheetobj = this.worksheetresponse.data.country.city.plant.worksheets[i];
            if (worksheetobj.worksheetStatus) {
              worksheetobj.worksheetStatus = worksheetobj.worksheetStatus.toLowerCase();
              if (worksheetobj.worksheetStatus === 'new') {
                worksheetobj.displayStatus = 'data.L00007';
              } else if (worksheetobj.worksheetStatus === 'active') {
                worksheetobj.displayStatus = 'data.L00008';
              } else if (worksheetobj.worksheetStatus === 'unlocked') {
                worksheetobj.displayStatus = 'data.L00010';
              } else if (worksheetobj.worksheetStatus === 'locked') {
                worksheetobj.displayStatus = 'data.L00011';
              }
            }
              this.opsworksheets.push(worksheetobj);
            }
          }
        },
        (err: any) => {
          this.errorMessage = 'data.L00235';
        }
      );

    }

  }

  opensubmitopsworksheetDialog(worksheet) {
    const worksheetInfo = {
        'plantid': this.selectedplant,
        'worksheetid': worksheet.id
    };
    this.worksheetService.editworksheetdata(worksheetInfo).subscribe(
        data => {
            this.sworksheetresonse = data;
            this.sworksheetData = this.sworksheetresonse.data.country.city.plant.worksheet;

            const dialogRef = this.dialog.open(SubmitopsworksheetComponent, {
                width: '90%',
                data: { 'mode': 'submit', 'locations': this.sworksheetData.locations }
            });
            const sub = dialogRef.componentInstance.submitopsworksheetcallback.subscribe(result => {
                dialogRef.componentInstance.closeDialog();
                this.submitws();
            });

        },
        (err: any) => {
            this.errorMessage = err;
        }
    );
}

submitws() {
  const requestObj = this.preparereqobj(this.sworksheetData);
  requestObj.action = 'Submit-MSUB';
  this.worksheetService.submitworksheet(requestObj, this.sworksheetresonse).subscribe(
      data => {
          this.submitworksheetResponse = data;
          if (this.submitworksheetResponse.status !== 'success') {
              this.errorservice.showerror(
                { status: this.submitworksheetResponse.errorCode,
                  statusText: this.submitworksheetResponse.message
                });
          } else {
              this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00221' });
              this.getplants(this.selectedplant);
          }
      },
      (err: any) => {
          this.errorMessage = err;
      }
  );
}

preparereqobj(data) {
  const reqObj = {
    'action': '',
    'id':  data.id,
    'templateId': 0,
    'worksheetName': data.worksheetName,
    'worksheetType': '',
    'worksheetDate': '',
    'reason': '',
    'remarks': (data.remarks) ? data.remarks : '' ,
    'locations': []
  };
  if  (data.locations.length > 0) {
      reqObj.locations = [];
      for (let i = 0; i < data.locations.length; i++ ) {
      if (data.locations[i].hasOwnProperty('dotexpand') === true) {
          delete data.locations[i].dotexpand;
      }
      if (data.locations[i].hasOwnProperty('isShow') === true) {
          delete data.locations[i].isShow;
      }
      reqObj.locations.push(data.locations[i]);
      }
  }
  return reqObj;
}


/* multiuseralert(emailid: any, plantid: any, worksheetid: any) {
    const multiuserMsg = emailid + ' ' + this.commonservice.gettranslate('data.L00578');
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      data: {
        'type': 'yesno',
        'title': 'data.L00224',
      'message': multiuserMsg
      }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      const worksheetUrl = 'opsworksheet/' + plantid + '/' + worksheetid;
      this.router.navigate([worksheetUrl]);
    });
  } */
}
