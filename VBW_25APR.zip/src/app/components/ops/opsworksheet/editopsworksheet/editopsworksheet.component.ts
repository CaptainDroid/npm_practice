import { Component, OnInit, Inject, HostListener, ElementRef, OnDestroy} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { MatDialog } from '@angular/material';
import { OpsworksheetService } from 'src/app/services/opsworksheet.service';
import { AddlocationpointComponent } from './addlocationpoint/addlocationpoint.component';
import { UnlockopsworksheetComponent } from './unlockopsworksheet/unlockopsworksheet.component';
import { AdditemComponent } from './additem/additem.component';
import { PlantdataentryComponent } from './plantdataentry/plantdataentry.component';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { SubmitopsworksheetComponent } from './submitopsworksheet/submitopsworksheet.component';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';
import { CommonService } from '../../../../services/common.service';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-editopsworksheet',
  templateUrl: './editopsworksheet.component.html',
  styleUrls: ['./editopsworksheet.component.css'],
  // tslint:disable-next-line:use-host-property-decorator
  host: {
    '(document:click)': 'onClick($event)',
  }
})
export class EditopsworksheetComponent implements OnInit, OnDestroy {

  worksheetParams: any;
  worksheetResponse: any;
  worksheetData: any;
  worksheetLocations = [];

  hidedata = false;

  user: any;

  plantId: any;

  alllocationpoints: any;
  alllocationpointResponse: any;
  alllocationomispoints: any;
  alllocationomisResponse: any;

  allitems: any;
  allitemResponse: any;

  allplantdata: any;
  plantdataentries = [];
  // allplantdataResponse: any;

  selectedLocationPoint = 0;
  filterlocationpoint = '';
  filteritems: any;
  selectedItems = 0;
  filteritemname = '';
  omifilters: any;

  currentLocation: any;

 // reasons = [{ name: 'Human errors', value: 1 }];
  reasons: any;
  reasontypes: any;
  selectedreason = 0;

  errorMessage: any;
  saveworksheetResponse: any;
  unlockwsResponse: any;
  submitwsResponse: any;
  reorderwsResponse: any;

  saveplantdataentryRes: any;

  disableunlock = false;
  plantacronym: any;

  reorder = false;
  reorderparent = false;
  reorderchild = false;
  reorderchilddata: any;
  stickheaderID = 'editworksheetheader';

  deleteItemData: any;
  showDeleteitem = false;
  resultedValue: any;

  uomresponse: any;
  uoms: any;
  selectedlang = 'EN';
  bc = 'opsworksheet';
  plantDataEntryObj: any;

  pageaccess = environment.role.ops;
  restrictplantdataentry = false;
  isEdit = false; // ROle restriction

  endworksheetSessionResponse: any;



  constructor(
    public translate: TranslateService,
    public dialog: MatDialog, private worksheetService: OpsworksheetService,
    private errorservice: ErrorserviceService, private route: ActivatedRoute, public commonservice: CommonService,
    @Inject(DOCUMENT) document, private router: Router, private _eref: ElementRef) {
      this.route.params.subscribe(params => {
        this.worksheetParams = params;
        this.plantId = this.worksheetParams.plantid;
      });
      this.route.queryParams.subscribe(params => {
        this.bc = params['bc'] || 'opsworksheet';
      });
       if (this.translate.currentLang) {
        const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
       if (parseInt(language.lang,10) === 1) {
         this.selectedlang = 'EN';
       } else {
          this.selectedlang = 'CN';
       }
    });
    this.isEdit = this.commonservice.isAccess(this.pageaccess.edit);
    this.restrictplantdataentry = this.commonservice.isAccess(environment.role.ops.plantdataentry);
  }

  ngOnInit() {
    this.worksheetData = {};
    this.worksheetData.remarks = '';
    this.worksheetData.remarkTypeId = '';
    this.getopsWorksheetData('init');
    this.getalllocationomis();
    this.getuoms();
    this.getreasons();
    const currentuser = this.commonservice.getUser();
    this.user = currentuser.prn.toLowerCase();
    this.user = this.user.replace(/\s/g, '');
  }

  getreasons() {
    this.reasontypes = [];
    this.commonservice.getreasons('ops').subscribe(
      data => {
        this.reasons = data;
        if (this.reasons.status !== 'success') {
          this.errorservice.showerror({status: this.reasons.status, statusText: this.reasons.message});
        } else {
          for (let i = 0; i < this.reasons.data.length; i++) {
            this.reasontypes.push(this.reasons.data[i]);
          }
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  getopsWorksheetData(calltype: any) {
    this.filteritems = [];
    this.omifilters = [];
    const pageparams = this.worksheetService.getworksheetUserInfo();
    this.plantacronym = pageparams.plantacro;

    if (pageparams.countryId !== '' && pageparams.citiId !== '' && this.worksheetParams.plantid && this.worksheetParams.worksheetid) {
      this.worksheetService.editworksheetdata(this.worksheetParams).subscribe(
        data => {
          this.worksheetResponse = data;
          if (this.worksheetResponse.status !== 'success') {
            this.errorservice.showerror({status: this.worksheetResponse.errorCode, statusText: this.worksheetResponse.message});
          } else {
            this.worksheetData = this.worksheetResponse.data.country.city.plant.worksheet;
            if (this.worksheetData.isReadOnly === true) {
              this.multiuserprompt(this.plantId, this.worksheetData.id, this.worksheetData.sessionUser);
            }
            if (this.worksheetData.remarkTypeId == null) {
              this.worksheetData.remarkTypeId = 0;
            }
            this.plantId = this.worksheetResponse.data.country.city.plant.id;
            this.worksheetLocations = this.worksheetResponse.data.country.city.plant.worksheet.locations;
            if (this.worksheetData.worksheetStatus) {
              this.worksheetData.worksheetStatus = this.worksheetData.worksheetStatus.toUpperCase();
            }
          for (let i = 0; i < this.worksheetLocations.length; i++) {
            this.worksheetLocations[i].isShow = true;
            if (this.worksheetLocations[i].omis !== null) {
            for (let j = 0; j < this.worksheetLocations[i].omis.length; j++) {
              this.worksheetLocations[i].omis[j].timeInterval = this.commonservice.getTime();
              this.hidetimeonload(this.worksheetLocations[i].omis[j].omiRecords, this.worksheetLocations[i].omis[j].timeInterval);
              const omiIndex =  this.omifilters.indexOf(this.worksheetLocations[i].omis[j]);
                  if (omiIndex < 0) {
                    this.omifilters.push(this.worksheetLocations[i].omis[j]);
                  }
                }
              } else {
                this.worksheetLocations[i].omis = [];
            }
          }
          this.omifilters = this.removeDuplicates(this.omifilters, 'id');
          /* if (calltype === 'init') {
            this.getalllocationomis();
          } */
        }
        },
        (err: any) => {
          this.errorMessage = err;
        }
      );
    } else {
       this.errorservice.showerror({status: '', statusText: 'data.L00170'});
    }
  }

  multiuserprompt(plantid: any, worksheetid: any, sessionuser: any) {
    const multiuserMsg = sessionuser + ' ' + this.commonservice.gettranslate('data.L00578');
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '500px',
      disableClose: true,
      data: {
        'type': 'yesno',
        'title': 'data.L00224',
        'message': multiuserMsg
      }
    });
    dialogRef.componentInstance.cancelCallback.subscribe(result => {
      let worksheetlistUrl = 'opsworksheets/' + plantid;
      if (this.bc === 'opsrecords') {
        worksheetlistUrl = 'opsrecords/' + plantid;
      }
      this.router.navigate([worksheetlistUrl]);
    });

    dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
    });
  }

  removeDuplicates( arr, prop ) {
    const obj = {};
    return Object.keys(arr.reduce((prev, next) => {
      if (!obj[next[prop]]) {
        obj[next[prop]] = next;
       }
      return obj;
    }, obj)).map((i) => obj[i]);
  }

  getalllocationomis() {
    this.alllocationpoints = [];
    this.worksheetService.alllocationomis(this.worksheetParams.plantid).subscribe(
      data => {
        this.alllocationomisResponse = data;
        if (this.alllocationomisResponse.status !== 'success') {
          this.errorservice.showerror({status: this.alllocationomisResponse.errorCode, statusText: this.alllocationomisResponse.message});
        } else {
          this.alllocationpoints = this.alllocationomisResponse.data.country.city.plant.locations;
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

  }

  gettime(date: any) {
    const testhours = new Date(date);
    return ('0' + testhours.getUTCHours()).slice(-2) + ':' + ('0' + testhours.getUTCMinutes()).slice(-2);
  }

  toggledot(model: any) {
    this.worksheetLocations.map(location => (location.dotexpand = false));
    if (!model.dotexpand) {
      model.dotexpand = true;
      this.hidedata = true;
    } else {
      model.dotexpand = false;
    }
  }

  onClick(event) {
     if (event.target.id === 'ellipsesbtn') {
        this.hidedata = true;
    } else {
       this.hidedata = false;
    }

   }

   addplantentryDialog(): void {
     const dialogRef = this.dialog.open(PlantdataentryComponent, {
       width: '450px',
       data: {'plantacro': this.plantacronym }
     });
     const sub = dialogRef.componentInstance.addplantdataentry.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
        this.postplantdataentry(result);
     });
   }

   getuoms () {
    this.worksheetService.alluoms().subscribe(
      data => {
        this.uomresponse = data;
        this.uoms = [];
        if (this.uomresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.uomresponse.status, statusText: this.uomresponse.message });
        } else {
          this.uoms = this.uomresponse.data;
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'data.L00228';
      }
    );
  }

  postplantdataentry(data: any) {
    this.plantDataEntryObj = this.plantdataFinalObj(data);
    this.worksheetService.saveplantdataentry(this.plantDataEntryObj, this.worksheetParams.plantid).subscribe(
      response => {
        this.saveplantdataentryRes = response;
        if (this.saveplantdataentryRes.status !== 'success') {
          this.errorservice.showerror({status: this.saveplantdataentryRes.errorCode, statusText: this.saveplantdataentryRes.message});
        } else {
          this.errorservice.showerror({type: 'Info', status: '', statusText: 'data.L00218'});
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
   }

   plantdataFinalObj(data) {
     const reqObj = {
      'action': data.action,
      'powerConsumption': null,
      'chemicalConsumption': null,
      'sludgeGeneration': null
     };
     if (data.powerConsumption.entryValue !== '') {
       reqObj.powerConsumption = {};
       reqObj.powerConsumption.entryValue = Number(data.powerConsumption.entryValue);
       reqObj.powerConsumption.entryUOM = 43;
     }
     if (data.chemicalConsumption.entryValue !== '') {
       reqObj.chemicalConsumption = {};
       reqObj.chemicalConsumption.entryValue = Number(data.chemicalConsumption.entryValue);
       reqObj.chemicalConsumption.entryUOM = 93;
     }
     if (data.sludgeGeneration.entryValue !== '') {
       reqObj.sludgeGeneration = {};
       reqObj.sludgeGeneration.entryValue = Number(data.sludgeGeneration.entryValue);
       reqObj.sludgeGeneration.entryUOM = 142;
     }
     return reqObj;
   }

   checkoutofrange(test, records, model) {
    let modelvalue = null;
    let outofrange = false;
    modelvalue = parseFloat(model);
    let minIsrange = true;
    let maxIsrange = true;
    if (modelvalue === null || modelvalue === '') {
       outofrange = false;
    }
    if (test.minValue !== null) {
           minIsrange = (test.minValue <= modelvalue) ? true : false;
     }
    if (test.maxValue !== null) {
               maxIsrange = (test.maxValue >= modelvalue) ? true : false;
     }
     if (test.minValue === null && test.maxValue === null) {
      records.outOfRange = false;
     } else {
      if (minIsrange && maxIsrange) {
        records.outOfRange = false;
      } else {
        records.outOfRange = true;
      }
     }
 }

   updateplantdata(model: any) {
     model.push();
   }

   openlocationpointDialog(): void {

    const dialogRef = this.dialog.open(AddlocationpointComponent, {
        width: '400px',
        data: this.alllocationpoints
    });
    const sub = dialogRef.componentInstance.addlocationpoint.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.addlocationpoint(result);
    });
  }

  addlocationpoint(newlocationpoint: any) {
    this.allitems = [];
    const newlocationpointObj = {
       'id': newlocationpoint.id,
       'name': newlocationpoint.name,
       'displayName':newlocationpoint.displayName,
       'deleteFromUI': true,
       'omis': []
    };
    this.allitems = newlocationpoint.omis;
    const locationObj = this.worksheetLocations.filter(location => {
      return newlocationpointObj.id === location.id;
    });
    if (locationObj.length < 1) {
      this.worksheetLocations.push(newlocationpointObj);
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00211'});
    }
  }

  reorderworksheet(reorderflag: any) {
    if (this.worksheetLocations.length > 1) {
      window.scroll(0, 0);
      this.reorder = true;
      this.stickheaderID = (reorderflag) ? '' : 'editworksheetheader';
      this.reorderparent = reorderflag;
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00209'});
    }
  }

  reorderitems(flag: any, data: any) {
    if (data.omis.length > 1) {
      this.reorder = true;
      window.scroll(0, 0);
      this.stickheaderID = (flag) ? '' : 'editworksheetheader';
      this.reorderchild = flag;
      this.reorderchilddata = data;
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00208'});
    }
  }

  validateTestData() {
    for (let i = 0; i < this.worksheetData.locations.length; i++) {
      if (this.worksheetData.locations[i].omis.length > 0) {
        for (let j = 0; j < this.worksheetData.locations[i].omis.length; j++) {
          for (let k = 0; k < this.worksheetData.locations[i].omis[j].omiRecords.length; k++) {

            let checktestvalue = this.worksheetData.locations[i].omis[j].omiRecords[k].testValue;
            // tslint:disable-next-line:prefer-const
            let checktestremark = this.worksheetData.locations[i].omis[j].omiRecords[k].testRemark;
            // tslint:disable-next-line:prefer-const
            let checktesttime = this.worksheetData.locations[i].omis[j].omiRecords[k].testTime;
            if (checktestvalue !== '' && checktestvalue !== null) {
               checktestvalue = checktestvalue.toString().replace(/\s/g, '');
               this.worksheetData.locations[i].omis[j].omiRecords[k].testValue =  checktestvalue;
            }

            if (checktestvalue !== '' && checktestvalue !== null && /^[-+]?[0-9]*\.?[0-9]+$/.test(checktestvalue) ===  false){
              return this.resultedValue = 'data.L00229';
            } else {
            if (((checktestvalue === '' && checktestremark === '') && checktesttime !== 0) ||
            (checktestvalue !== '' && checktesttime === 0 ) || (checktestremark !== '' && checktesttime === 0) ||
            (checktestvalue === '' && checktesttime === 0) || (checktestremark === '' && checktesttime === 0)) {
              return this.resultedValue = 'data.L00229';
          }
        }
        }
      }
      } else {
        return this.resultedValue = 'data.L00230';
      }
    }
    return this.resultedValue = true;
}

  confirmreorder(flag: any) {
    this.stickheaderID = (flag) ? '' : 'editworksheetheader';
    this.reorder = false;
    this.reorderchild = flag;
    this.reorderparent = flag;
    const requestObj = this.preparereorderObj(this.worksheetLocations);
    requestObj.action = 'Save';
    requestObj.opsWsTemplateId = this.worksheetData.opsWstemplateId;
    this.worksheetService.saveuserpreferencews(requestObj, this.worksheetResponse).subscribe(
      data => {
          this.reorderwsResponse = data;
          if (this.reorderwsResponse.status !== 'success') {
            this.errorservice.showerror({status: this.reorderwsResponse.errorCode, statusText: this.reorderwsResponse.message});
          } else {
            this.refreshOrder(requestObj);
          }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  refreshOrder(requestObj: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {title: 'Info', message: 'data.L00231'}
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
    });
  }

  preparereorderObj(data: any) {
    const reqObj = {
      'action': '',
      'opsWsTemplateId': '',
      'assocIds': []
    };
    if (data.length > 0) {
      for (let i = 0; i < data.length; i++ ) {
        for (let j = 0; j < data[i].omis.length; j++) {
          reqObj.assocIds.push({'locMiassocId': data[i].omis[j].assocId});
      }
      }
    }
    return reqObj;
  }

  cancelreorder() {
    this.reorder = false;
    this.getopsWorksheetData('refresh');
  }

  saveworksheet() {
    const requestObj = this.preparereqobj(this.worksheetData);
    const validateResult =  this.validateTestData();
    if(validateResult !== true) {
      this.errorservice.showerror({status: '', statusText: validateResult});
    } else {
    requestObj.action = 'Save';
    if (requestObj.remarkTypeId == null) {
      requestObj.remarks = '';
    }
    this.worksheetService.saveworksheet(requestObj, this.worksheetResponse).subscribe(
      data => {
        this.saveworksheetResponse = data;
        if(this.saveworksheetResponse.status !== 'success') {
          this.errorservice.showerror({status:this.saveworksheetResponse.errorCode, statusText:this.saveworksheetResponse.message});
        } else {
          this.worksheetData.lastUpdated = this.saveworksheetResponse.data.userUpdateDT;
          this.worksheetData.updatedBy = this.saveworksheetResponse.data.userName;
          this.refreshworksheet('data.L00219');
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
    }

  }

  refreshworksheet(dialogMsg: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {title: 'Info', message: dialogMsg}
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
     // this.getopsWorksheetData('refresh');
    });
  }

  preparereqobj(data) {
    // tslint:disable-next-line:prefer-const
    let records = [];
    const reqObj = {
      'action': '',
      'id': data.id,
      'templateId': 0,
      'worksheetName': data.worksheetName,
      'worksheetType': 'REGR',
      'worksheetDate':  '',
      'reason': '',
      'allowRemark': data.allowRemark,
      'remarks': (data.remarks) ? data.remarks : '',
      'remarkTypeId': (data.remarkTypeId !== 0) ? data.remarkTypeId : null,
      'assocs': []
    };
    if (data.locations.length > 0) {
      reqObj.assocs = [];
      for (let i = 0; i < data.locations.length; i++ ) {

      if (data.locations[i].hasOwnProperty('dotexpand') === true) {
          delete data.locations[i].dotexpand;
      }
      if (data.locations[i].hasOwnProperty('isShow') === true) {
          delete data.locations[i].isShow;
      }

      if (data.locations[i].omis.length > 0){
        for (let j = 0; j < data.locations[i].omis.length; j++){
          reqObj.assocs.push({'id': data.locations[i].omis[j].assocId, 'records': data.locations[i].omis[j].omiRecords});
        }
      }
      }
    }
    return reqObj;
  }

  openunlockworksheetDialog(): void {
    if (this.disableunlock === false) {
      const dialogRef = this.dialog.open(UnlockopsworksheetComponent, {
        width: '400px',
        data: []
    });
    const sub = dialogRef.componentInstance.unlockopsworksheetCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.unlockws(result);
    });
    } else {
      this.errorservice.showerror({type: 'Info', status: '', statusText:'data.L00171'});
    }

  }

  unlockws(unlockinfo: any) {
    if (unlockinfo.reason) {
      this.worksheetData.reason = unlockinfo.reason;
    }
    if (unlockinfo.remarks) {
      this.worksheetData.remarks = unlockinfo.remarks;
    }
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'RFUL';

    this.worksheetService.unlockworksheet(this.worksheetResponse, requestObj).subscribe(
      data => {
        this.unlockwsResponse = data;
        if (this.unlockwsResponse.status !== 'success') {
          this.errorservice.showerror({status: this.unlockwsResponse.errorCode, statusText: this.unlockwsResponse.message});
        } else {
          this.disableunlock = true;
         // this.errorservice.showerror({type: 'Info', status: '', statusText: 'data.L00220'});
         this.refreshworksheet('data.L00220');
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

   }


  additementry(model: any) {
    model.push({ id: '', testValue: '', testTime: 0, isFinal: false, outOfRange: false, testRemark: ''});
  }

  openadditemDialog(locationpoint: any) {
    this.currentLocation = locationpoint;
    this.openItemDialog();
  }

  openItemDialog(): void {
    const locationData = this.alllocationpoints.filter( location  => {
      return location.id === this.currentLocation.id;
    });
    if (locationData.length > 0 ) {
        if (locationData[0]) {
            if (locationData[0].omis.length > 0) {
              const dialogRef = this.dialog.open(AdditemComponent, {
                width: '400px',
                data:  locationData[0].omis
      });
      const sub = dialogRef.componentInstance.additemcallback.subscribe(result => {
        dialogRef.componentInstance.closeDialog();
        this.additem(result);
        });
      } else {
        this.errorservice.showerror({status: '', statusText: 'data.L00237'});
      }
    }
  } else {
    this.errorservice.showerror({status: '', statusText: 'data.L00237'});
  }
}

additem(newomi: any) {
    const newomiobj = {
        'id' : newomi.id,
        'assocId': newomi.assocId,
        'name' : newomi.name,
        'omiType': (newomi.omiType) ? newomi.omiType.toLowerCase() : newomi.omiType,
        'uom': newomi.uom,
        'minValue': (newomi.minValue !== null) ? newomi.minValue : null,
        'maxValue': (newomi.maxValue !== null) ? newomi.maxValue : null,
        'deleteFromUI': true,
        'timeInterval': this.commonservice.getTime(),
        'omiRecords' : []
      };
      const omiObj = this.currentLocation.omis.filter(omi => {
        return newomiobj.id === omi.id;
      });
      if (omiObj.length < 1) {
        this.currentLocation.omis.push(newomiobj);
      } else {
        this.errorservice.showerror({status: '', statusText: 'data.L00212'});
      }

    /* const filteromi = this.filteritems.filter(filteritem => {
        return filteritem.id === newomiobj.id;
      });
      if (filteromi.length < 1) {
        this.filteritems.push(newomiobj);
      }*/
   }

   deleteitem(deleteitem: any) {
    this.showDeleteitem = true;
    this.deleteItemData = deleteitem  ;
    window.scroll(0, 0);
 }

 closedeletepopup() {
  this.showDeleteitem = false;
 }

 deletelocationpoint(deleteItem: any) {
  const dialogRef = this.dialog.open(DialogComponent, {
    width: '400px',
    data: {type: 'yesno', title: 'data.L00187', message: 'data.L00226'}
  });
  const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
    const index = this.worksheetLocations.indexOf(deleteItem);
    if (index > -1) {
      this.worksheetLocations.splice(index, 1);
      this.closedeletepopup();
    }
    dialogRef.componentInstance.closeDialog();
  });
}

deleteomiitem(omiitem: any) {
  const dialogRef = this.dialog.open(DialogComponent, {
    width: '400px',
    data: {type: 'yesno', title: 'data.L00188', message: 'data.L00226'}
  });
  const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
    const index = this.deleteItemData.omis.indexOf(omiitem);
    if (index > -1) {
      this.deleteItemData.omis.splice(index, 1);
    }

    const findItems = [];
      for (let i = 0; i < this.worksheetLocations.length; i++) {
        const omis = this.worksheetLocations[i].omis.filter( item => {
          return item.id === omiitem.id;
        });
        if (omis.length > 0) {
          findItems.push(omis[0]);
        }
      }
      if (findItems.length < 1) {
        this.filteritems.splice(index, 1);
      }

    dialogRef.componentInstance.closeDialog();
  });
}

deleteitemvalues(omiItem, itemvalue: any) {
  const dialogRef = this.dialog.open(DialogComponent, {
    width: '400px',
    data: {type: 'yesno', title: 'data.L00232', message: 'data.L00226'}
  });
  const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
  const index = omiItem.indexOf(itemvalue);
  if (index > -1) {
    omiItem.splice(index, 1);
  }
  dialogRef.componentInstance.closeDialog();
});
}

filterlocationdata(locationobj:any, locationname: any) {
  this.filterlocationpoint = locationname;
  this.filteritemname = '';
  if (locationname !== '' && locationname !== undefined){
    this.omifilters = [];
    this.omifilters = locationobj.omis;
    this.selectedItems = 0;
  } else {
    this.omifilters = [];
    for ( let i = 0; i < this.worksheetLocations.length; i++ ) {
      if (this.worksheetLocations[i].omis !== null) {
        for ( let j = 0; j < this.worksheetLocations[i].omis.length; j++ ) {
          const omiIndex =  this.omifilters.indexOf(this.worksheetLocations[i].omis[j]);
          if (omiIndex < 0) {
            this.omifilters.push(this.worksheetLocations[i].omis[j]);
          }
        }
      }
    }
   this.selectedItems = 0;
   this.omifilters = this.removeDuplicates(this.omifilters, 'id');
}
}

filteritemdata(itemname: any) {
  this.filteritemname = itemname;
}

submitworksheetDialog() {
  const validateResult =  this.validateTestData();
  if(validateResult !== true) {
    this.errorservice.showerror({status: '', statusText: validateResult});
  } else {
     const dialogRef = this.dialog.open(SubmitopsworksheetComponent, {
      width: '90%',
      data: { 'mode': 'submit', 'locations': this.worksheetLocations, 'omis': this.allitems}
    });
    const sub = dialogRef.componentInstance.submitopsworksheetcallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.submitws();
    });
  }
}

submitws() {
  const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'Submit-MSUB';
    if(requestObj.remarkTypeId == null){
      requestObj.remarks = '';
    }
    this.worksheetService.submitworksheet(requestObj, this.worksheetResponse).subscribe(
      data => {
        this.submitwsResponse = data;
        if (this.submitwsResponse.status !== 'success') {
          this.errorservice.showerror({status: this.submitwsResponse.errorCode, statusText: this.submitwsResponse.message});
        } else {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00221' });
          const info = {
            'countryId': this.worksheetResponse.data.country.id,
            'citiId': this.worksheetResponse.data.country.city.id
          };
          this.worksheetService.setworksheetUserinfo(info);
          this.router.navigate(['/opsworksheets/' + this.worksheetResponse.data.country.city.plant.id]);
        }
        },
      (err: any) => {
        this.errorMessage = err;
      }
    );
}

checktimeexist(index: any, collection: any , model: any) {
  const testdataCollection = [];
  for (let  i = 0; i < collection.length; i++) {
    if (i !== index) {
    testdataCollection.push(collection[i]);
    }
  }
  const checkexist = testdataCollection.filter(testdata => {
    return testdata.testTime === model;
  });
  if (checkexist.length > 0) {
    setTimeout(function() {
      collection[index].testTime = '';
    }, 500);
    this.errorservice.showerror({status: '', statusText: 'data.L00222'});
  }
}

hideexisttime(omirecords: any, timecollection: any, timeobj: any) {
  timeobj.isShow = false;
  const testtimeCollection = [];
  omirecords.filter(omirecord => {
    testtimeCollection.push(omirecord.testTime);
  });
  timecollection.filter(timecoll => {
     if (testtimeCollection.indexOf(timecoll.time) > -1){
      timecoll.isShow = false;
     } else {
      timecoll.isShow = true;
     }
  });
}

hidetimeonload(omirecords: any, timecollection: any) {
  const testtimeCollection = [];
  omirecords.filter(omirecord => {
    testtimeCollection.push(omirecord.testTime);
  });
  timecollection.filter(timecoll => {
     if (testtimeCollection.indexOf(timecoll.time) > -1) {
      timecoll.isShow = false;
     } else {
      timecoll.isShow = true;
     }
  });
}

ngOnDestroy() {
  const endworksheetSession = {
    module: 'Ops',
    worksheetid: this.worksheetParams.worksheetid
  };
  this.commonservice.endworksheetsession(endworksheetSession).subscribe(
    data => {
      this.endworksheetSessionResponse = data;
      if (this.endworksheetSessionResponse.status !== 'success') {
        /* this.errorservice.showerror({
            status: this.endworksheetSessionResponse.errorCode,
            statusText: this.endworksheetSessionResponse.message}); */
        console.log(this.endworksheetSessionResponse.message);
      }
    },
    (err: any) => {
      this.errorMessage = err;
    }
  );
}

// Angular material drag and drop

dropLocations(event: CdkDragDrop<string[]>) {
  moveItemInArray(this.worksheetLocations, event.previousIndex, event.currentIndex);
}

dropItems(event: CdkDragDrop<string[]>) {
  moveItemInArray(this.reorderchilddata.omis, event.previousIndex, event.currentIndex);
}

}
