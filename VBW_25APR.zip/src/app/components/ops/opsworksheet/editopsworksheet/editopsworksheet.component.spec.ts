import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditopsworksheetComponent } from './editopsworksheet.component';

describe('EditopsworksheetComponent', () => {
  let component: EditopsworksheetComponent;
  let fixture: ComponentFixture<EditopsworksheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditopsworksheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditopsworksheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
