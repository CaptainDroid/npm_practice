import { Component, Inject, EventEmitter, Output  } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface UnlockopsworksheetData {
  value: any;
  name: string;
}

@Component({
  selector: 'app-unlockopsworksheet',
  templateUrl: './unlockopsworksheet.component.html',
  styleUrls: ['./unlockopsworksheet.component.css']
})
export class UnlockopsworksheetComponent {

  @Output() unlockopsworksheetCallback = new EventEmitter<any>(true);

  selectedreason = 0 ;
  remarks = '';
  unlockopsworksheetData: any;
  constructor(
      public dialogRef: MatDialogRef<UnlockopsworksheetComponent>,
      @Inject(MAT_DIALOG_DATA) public data: UnlockopsworksheetData) { }

  closeDialog(): void {
      this.dialogRef.close();
  }
  unlockworksheet() {
    this.unlockopsworksheetCallback.emit({remarks: this.remarks});
  }
}
