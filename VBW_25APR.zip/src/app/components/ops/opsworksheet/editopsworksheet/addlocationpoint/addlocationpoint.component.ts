import { Component, OnInit, Inject, EventEmitter, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface AddlocationpointData {
  id: any;
  name: string;
}
@Component({
  selector: 'app-addlocationpoint',
  templateUrl: './addlocationpoint.component.html',
  styleUrls: ['./addlocationpoint.component.css']
})
export class AddlocationpointComponent {
  @Output() addlocationpoint = new EventEmitter<any>(true);
  selectedlocationpoint: any;
  searchitempoint: any;
  constructor(
    public dialogRef: MatDialogRef<AddlocationpointComponent>,
    @Inject(MAT_DIALOG_DATA) public data: AddlocationpointData){ }

  closeDialog(): void {
    this.dialogRef.close();
  }

  selectlocationpoint(selectedpoint: any){
    this.selectedlocationpoint = selectedpoint;
  }

  addlocation(){
    this.addlocationpoint.emit(this.selectedlocationpoint);
  }
}