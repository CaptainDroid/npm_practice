import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddlocationpointComponent } from './addlocationpoint.component';

describe('AddlocationpointComponent', () => {
  let component: AddlocationpointComponent;
  let fixture: ComponentFixture<AddlocationpointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddlocationpointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddlocationpointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
