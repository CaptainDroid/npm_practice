import { Component, Inject, EventEmitter, Output } from '@angular/core';
import { OpsworksheetService } from 'src/app/services/opsworksheet.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ErrorserviceService } from 'src/app/services/errorservice.service';

@Component({
  selector: 'app-plantdataentry',
  templateUrl: './plantdataentry.component.html',
  styleUrls: ['./plantdataentry.component.css']
})
export class PlantdataentryComponent {

  uomresponse: any;
  uoms: any;
  errorMessage: any;
  plantDataEntryReqObj = {
    'action': 'Create',
    'powerConsumption': {
      'entryValue': '',
      'entryUOM': ''
    },
    'chemicalConsumption': {
      'entryValue': '',
      'entryUOM': ''
    },
    'sludgeGeneration': {
      'entryValue': '',
      'entryUOM': ''
    }
  };

  @Output() addplantdataentry = new EventEmitter<any>(true);
  constructor(
    public dialogRef: MatDialogRef<PlantdataentryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private errorservice: ErrorserviceService,
    private worksheetService: OpsworksheetService) {}

  closeDialog(): void {
    this.dialogRef.close();
  }

  updateplantdata() {
    this.addplantdataentry.emit(this.plantDataEntryReqObj);
  }
  
}
