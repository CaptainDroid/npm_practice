import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlantdataentryComponent } from './plantdataentry.component';

describe('PlantdataentryComponent', () => {
  let component: PlantdataentryComponent;
  let fixture: ComponentFixture<PlantdataentryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlantdataentryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlantdataentryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
