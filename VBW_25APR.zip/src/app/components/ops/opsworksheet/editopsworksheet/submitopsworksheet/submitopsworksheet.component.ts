import { Component, Inject, EventEmitter, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-submitopsworksheet',
  templateUrl: './submitopsworksheet.component.html',
  styleUrls: ['./submitopsworksheet.component.css']
})
export class SubmitopsworksheetComponent {
  @Output() submitopsworksheetcallback = new EventEmitter<any>(true);
  mode: any;
  omis: any;
  locations: any;
  constructor(
    public dialogRef: MatDialogRef<SubmitopsworksheetComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.mode = data.mode;
    this.omis = [];
    this.locations = [];
    for (let i = 0; i < data.locations.length; i++) {
      if (this.locations.indexOf(data.locations[i].name) < 0) {
        this.locations.push(data.locations[i].name);
      }
      if (data.locations[i].omis) {
        for (let j = 0; j < data.locations[i].omis.length; j++) {
          if (this.omis.indexOf(data.locations[i].omis[j].name) < 0) {
            this.omis.push(data.locations[i].omis[j].name);
          }
        }
      }

    }
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  getitemrecords(location, item) {
    let itemdata = [];
    if (location.omis) {
      for (let i = 0; i < location.omis.length; i++) {
        if (item === location.omis[i].name) {
          itemdata = location.omis[i].omiRecords;
        }
      }
    }
    return itemdata;
  }
  gettime(date: any) {
    let testhours = new Date(date);
    return ('0' + testhours.getUTCHours()).slice(-2) + ':' + ('0' + testhours.getUTCMinutes()).slice(-2);
  }

  submitworksheet() {
    this.submitopsworksheetcallback.emit(this.mode);
  }

}
