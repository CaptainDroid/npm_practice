import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmitopsworksheetComponent } from './submitopsworksheet.component';

describe('SubmitopsworksheetComponent', () => {
  let component: SubmitopsworksheetComponent;
  let fixture: ComponentFixture<SubmitopsworksheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmitopsworksheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmitopsworksheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
