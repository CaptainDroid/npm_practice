import { Component, Inject, EventEmitter, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface AdditemData {
  id: any;
  name: string;
}

@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent {

  @Output() additemcallback = new EventEmitter<any>(true);
  selecteditem: any;
  searchitem: any;
  constructor(
      public dialogRef: MatDialogRef<AdditemComponent>,
      @Inject(MAT_DIALOG_DATA) public data: AdditemComponent) { }

  closeDialog(): void {
      this.dialogRef.close();
  }

  selectitem(selectitem: any) {
      this.selecteditem = selectitem;
  }
  additem() {
    this.additemcallback.emit(this.selecteditem);
  }

  

}
