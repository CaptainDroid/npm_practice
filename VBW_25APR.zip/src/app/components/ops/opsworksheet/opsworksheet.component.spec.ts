import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpsworksheetComponent } from './opsworksheet.component';

describe('OpsworksheetComponent', () => {
  let component: OpsworksheetComponent;
  let fixture: ComponentFixture<OpsworksheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpsworksheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpsworksheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
