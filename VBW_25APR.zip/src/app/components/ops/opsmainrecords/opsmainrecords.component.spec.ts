import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpsmainrecordsComponent } from './opsmainrecords.component';

describe('OpsmainrecordsComponent', () => {
  let component: OpsmainrecordsComponent;
  let fixture: ComponentFixture<OpsmainrecordsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpsmainrecordsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpsmainrecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
