import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpsrecordsComponent } from './opsrecords.component';

describe('OpsrecordsComponent', () => {
  let component: OpsrecordsComponent;
  let fixture: ComponentFixture<OpsrecordsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpsrecordsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpsrecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
