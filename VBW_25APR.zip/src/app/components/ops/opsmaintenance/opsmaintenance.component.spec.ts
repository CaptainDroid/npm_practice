import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpsmaintenanceComponent } from './opsmaintenance.component';

describe('OpsmaintenanceComponent', () => {
  let component: OpsmaintenanceComponent;
  let fixture: ComponentFixture<OpsmaintenanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpsmaintenanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpsmaintenanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
