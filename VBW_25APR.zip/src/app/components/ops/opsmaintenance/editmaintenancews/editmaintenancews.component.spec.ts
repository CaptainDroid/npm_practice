import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditmaintenancewsComponent } from './editmaintenancews.component';

describe('EditmaintenancewsComponent', () => {
  let component: EditmaintenancewsComponent;
  let fixture: ComponentFixture<EditmaintenancewsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditmaintenancewsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditmaintenancewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
