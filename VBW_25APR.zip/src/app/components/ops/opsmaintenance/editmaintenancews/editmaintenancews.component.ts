import { Component, OnInit, Inject, HostListener, ElementRef, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { MatDialog } from '@angular/material';
import { OpsworksheetService } from 'src/app/services/opsworksheet.service';
import { ErrorserviceService } from '../../../../services/errorservice.service';
import { AddnonroutineactComponent } from './addnonroutineact/addnonroutineact.component';
import { SubmitmaintenancewsComponent } from './submitmaintenancews/submitmaintenancews.component';
import { UnlockmaintenancewsComponent } from './unlockmaintenancews/unlockmaintenancews.component';
import { CommonService } from '../../../../services/common.service';
import { DialogComponent } from '../../../common/dialog/dialog.component';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';
import { TranslateService } from '@ngx-translate/core';

import { environment } from '../../../../../environments/environment';
@Component({
  selector: 'app-editmaintenancews',
  templateUrl: './editmaintenancews.component.html',
  styleUrls: ['./editmaintenancews.component.css'],
  // tslint:disable-next-line:use-host-property-decorator
  host: {
    '(document:click)': 'onClick($event)',
  }
})
export class EditmaintenancewsComponent implements OnInit, OnDestroy {

  worksheetParams: any;
  worksheetResponse: any;
  worksheetData: any;
  worksheetActivities = [];

  hidedata = false;

  deleteItemData: any;
  showDeleteitem = false;

  plantId: any;
  plantacronym: any;

  saveworksheetResponse: any;

  allactivities: any;
  allactivityResponse: any;

  selectedActivityPoint = 0;
  filterActivity = '';

  reasons: any;
  reasontypes: any;
  selectedreason = 0;

  errorMessage: any;

  allEquipmentActivities = [];
  allEquipments = [];
  equipmentNames = [];
  equipmentDesc = [];

  reorder = false;
  reorderparent = false;
  reorderchild = false;
  reorderchilddata: any;
  reorderwsResponse: any;
  stickheaderID = 'editworksheetheader';

  nonroutineActivitiesResponse: any;
  nonroutineActivities: any;

  equipmentlistResponse: any;
  equipmentlist: any;

  submitwsResponse: any;
  unlockwsResponse: any;

  disableunlock = false;
  selectedlang = 'EN';
  bc = 'opsmaintenance';

  pageaccess = environment.role.maintenance;
  isHide = false;
  saveMode: any;
  endworksheetSessionResponse: any;

  constructor(public dialog: MatDialog, private worksheetService: OpsworksheetService,
    public translate: TranslateService, private errorservice: ErrorserviceService,
    public commonservice: CommonService, private route: ActivatedRoute, @Inject(DOCUMENT) document,
    private router: Router, private _eref: ElementRef) {
      this.route.params.subscribe(params => {
        this.worksheetParams = params;
        this.plantId = this.worksheetParams.plantid;
      });
      this.route.queryParams.subscribe(params => {
        this.bc = params['bc'] || 'opsmaintenance';
      });
    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
      if (parseInt(language.lang, 10) === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    });

    this.isHide = this.commonservice.isAccess(this.pageaccess.edit);
}

  ngOnInit() {
    this.worksheetData = {};
    this.worksheetData.remarks = '';
    this.worksheetData.remarkTypeId = '';
    this.getMaintenancewsdata('init');
    this.getallEquipmentactivities();
    this.getreasons();
  }

   getreasons() {
    this.reasontypes = [];
    this.commonservice.getreasons('mat').subscribe(
      data => {
        this.reasons = data;
        if (this.reasons.status !== 'success') {
          this.errorservice.showerror({status: this.reasons.status, statusText: this.reasons.message});
        } else {
          for (let i = 0; i < this.reasons.data.length; i++) {
            this.reasontypes.push(this.reasons.data[i]);
          }
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  getMaintenancewsdata(calltype: any) {
    const activityList = [];
    const pageparams = this.worksheetService.getworksheetUserInfo();
    this.plantacronym = pageparams.plantacro;

    if (pageparams.countryId !== '' && pageparams.citiId !== '' && this.worksheetParams.plantid && this.worksheetParams.worksheetid) {
      this.worksheetService.editmaintenancewsdata(this.worksheetParams).subscribe(
        data => {
          this.worksheetResponse = data;
          if (this.worksheetResponse.status !== 'success') {
            this.errorservice.showerror({status: this.worksheetResponse.errorCode, statusText: this.worksheetResponse.message});
          } else {
            this.worksheetData = this.worksheetResponse.data.country.city.plant.worksheet;
            if (this.worksheetData.remarkTypeId == null) {
              this.worksheetData.remarkTypeId = 0;
            }
            if (this.worksheetData.isReadOnly === true) {
              this.multiuserprompt(this.plantId, this.worksheetData.id, this.worksheetData.sessionUser);
            }
            this.plantId = this.worksheetResponse.data.country.city.plant.id;
            this.worksheetActivities = this.worksheetResponse.data.country.city.plant.worksheet.maintRecords;
            if (this.worksheetData.worksheetStatus) {
              this.worksheetData.worksheetStatus = this.worksheetData.worksheetStatus.toUpperCase();
            }
            for (let i = 0; i < this.worksheetActivities.length; i++) {
              this.worksheetActivities[i].isShow = true;
            }
            this.worksheetActivities.forEach( activity => {
              if(activityList.indexOf(activity.activityName) < 0) {
                activityList.push(activity.activityName);
                 activity.isVisible = true;
              } else {
                activity.isVisible = false;
              }
           });
        }
        },
        (err: any) => {
          this.errorMessage = err;
        }
      );
    } else {
       this.errorservice.showerror({status: '', statusText: 'data.L00170'});
    }
  }

  getallEquipmentactivities() {
    this.allEquipmentActivities = [];
    this.allactivities = [];
    this.nonroutineActivities = [];
   // this.equipmentNames = [];
    this.equipmentDesc = [];

    this.worksheetService.allactivities(this.worksheetParams.plantid).subscribe(
      data => {
        this.allactivityResponse = data;
        if (this.allactivityResponse.status !== 'success') {
          this.errorservice.showerror({status: this.allactivityResponse.errorCode, statusText:this.allactivityResponse.message});
        } else {
          this.allEquipmentActivities = this.allactivityResponse.data.country.city.plant.equipments;
          for (let i = 0; i < this.allEquipmentActivities.length; i++) {
            if (this.allEquipmentActivities[i].activities.length > 0) {
              for (let j = 0; j < this.allEquipmentActivities[i].activities.length; j++) {
                this.allactivities.push(this.allEquipmentActivities[i].activities[j]);
                if (this.allEquipmentActivities[i].activities[j].isRoutine !== true) {
                  this.nonroutineActivities.push(this.allEquipmentActivities[i].activities[j]);
                 }
              }
            }
          }
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

  }

  filteractivitydata(activityname: any) {
    this.filterActivity = activityname;
  }

  ngOnDestroy() {
    const endworksheetSession = {
      module: 'Maint',
      worksheetid: this.worksheetParams.worksheetid
    };
    this.commonservice.endworksheetsession(endworksheetSession).subscribe(
      data => {
        this.endworksheetSessionResponse = data;
        if (this.endworksheetSessionResponse.status !== 'success') {
          /* this.errorservice.showerror({
              status: this.endworksheetSessionResponse.errorCode,
              statusText: this.endworksheetSessionResponse.message}); */
          console.log(this.endworksheetSessionResponse.message);
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  gettime(date: any) {
    const testhours = new Date(date);
    return ('0' + testhours.getUTCHours()).slice(-2) + ':' + ('0' + testhours.getUTCMinutes()).slice(-2);
  }

  reorderActivity(flag: any, data: any) {
    if (data.activity.length > 1) {
      this.reorder = true;
      window.scroll(0, 0);
      this.stickheaderID = (flag) ? '' : 'editworksheetheader';
      this.reorderchild = flag;
      this.reorderchilddata = data;
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00210'});
    }
  }

  reorderparentActivity(flag: any) {
    if (this.worksheetActivities.length < 2) {
      this.errorservice.showerror({status: '', statusText: 'data.L00210'});
    } else  {
      this.reorderparent = flag;
      this.reorder = true;
    }
  }

  savemaintworksheet() {
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'Save';
    requestObj.recordStatus = 'Update';
    if(requestObj.remarkTypeId == null){
      requestObj.remarks = '';
    }
    this.worksheetService.savemaintworksheet(requestObj, this.worksheetResponse).subscribe(
      data => {
        this.saveworksheetResponse = data;
        if (this.saveworksheetResponse.status !== 'success') {
          this.errorservice.showerror({status: this.saveworksheetResponse.errorCode, statusText:this.saveworksheetResponse.message});
        } else {
         // this.errorservice.showerror({type:'Info', status:'', statusText:'data.L00219'});
        // this.worksheetData.lastUpdated = this.saveworksheetResponse.data.userUpdateDT;
        // this.worksheetData.updatedBy = this.saveworksheetResponse.data.userName;
          this.refreshworksheet('data.L00219');
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  preparereqobj(data: any) {
    let maintFinalRecords: any;
    const reqObj = {
      'action': '',
      'id': data.id,
      'allowRemark': data.allowRemark,
      'remarks': (data.remarks) ? data.remarks : '',
      'remarkTypeId': (data.remarkTypeId !== 0) ? data.remarkTypeId : null,
      'reason': '',
      'recordStatus':'',
      'maintRecords': []
    };
    if (data.maintRecords.length > 0) {
      reqObj.maintRecords = [];
      for (let i = 0; i < data.maintRecords.length; i++ ) {
      if (data.maintRecords[i].hasOwnProperty('dotexpand') === true) {
          delete data.maintRecords[i].dotexpand;
      }
      if (data.maintRecords[i].hasOwnProperty('isShow')===true) {
          delete data.maintRecords[i].isShow;
      }
      if (data.maintRecords[i].testRemark !== '') {
        // tslint:disable-next-line:max-line-length
        maintFinalRecords = { opsMAAssocId: data.maintRecords[i].opsMAAssocId, testRemark: data.maintRecords[i].testRemark, allowEdit: data.maintRecords[i].allowEdit};
        reqObj.maintRecords.push(maintFinalRecords);
      }
    }
  }
    return reqObj;
  }

  toggledot(model: any) {
    this.worksheetActivities.map(activity => (activity.dotexpand = false));
    if (!model.dotexpand) {
      model.dotexpand = true;
      this.hidedata = true;
    } else {
      model.dotexpand = false;
    }
  }

  onClick(event: any) {
     if (event.target.id === 'ellipsesbtn') {
        this.hidedata = true;
    } else {
       this.hidedata = false;
    }

   }

   openNonRoutineDialog () {
      if (this.nonroutineActivities.length > 0 ) {
       const dialogRef = this.dialog.open(AddnonroutineactComponent, {
         width: '500px',
         data: { activities: this.nonroutineActivities }
       });
       const sub = dialogRef.componentInstance.addnonroutinecallback.subscribe(result => {
         if(result.activity === undefined || result.equipment === undefined || result.activityDetail === "") {
           this.errorservice.showerror({status: '', statusText: 'data.L00233'});
         } else {
          dialogRef.componentInstance.closeDialog();
          this.addnonroutineact(result);
         }
       });
      } else {
       this.errorservice.showerror({status: '', statusText: 'data.L00234'});
      }
  }

   addnonroutineact (data: any) {
    const nonRoutineActivity =  {
      'orderId': 0,
      'allowEdit': true,
      'opsMAAssocId': data.activity.id,
      'id': data.activity.id,
      'activityName': data.activity.activityName,
      'activityDisplayName': data.activity.activityDisplayName,
      'equipmentDisplayName': data.activity.equipmentDisplayName,
      'testRemark': data.activityDetail,
      'equipmentName': data.equipment.equipmentName,
      'isRoutine': false
    };

    const isActivityexist = this.worksheetActivities.filter(activity => {
      return (nonRoutineActivity.opsMAAssocId === activity.opsMAAssocId && nonRoutineActivity.equipmentName === activity.equipmentName);
    });

    if (isActivityexist.length < 1) {
      this.worksheetActivities.push(nonRoutineActivity);
      this.saveMode = 'New';
      this.savenonroutineactivity(nonRoutineActivity);
    } else {
      this.errorservice.showerror({status: '', statusText: 'data.L00213'});
    }
   }

   deleteNonRoutine(deleteactivity: any) {
    this.showDeleteitem = true;
    this.deleteItemData = deleteactivity;
    window.scroll(0, 0);
 }

 deleteActivity(deleteActivity: any) {
  this.saveMode = 'Delete';
  this.savenonroutineactivity(deleteActivity);
  const index = this.worksheetActivities.indexOf(deleteActivity);
  if (index > -1) {
    this.worksheetActivities.splice(index, 1);
    this.closedeletepopup();
  }

}

 closedeletepopup() {
  this.showDeleteitem = false;
 }

   savenonroutineactivity(nonRoutineActivity: any) {
    const requestObj = this.preparenonroutineobj(nonRoutineActivity);
    requestObj.action = 'Save';
    requestObj.recordStatus = this.saveMode;
    if(requestObj.remarkTypeId == null) {
      requestObj.remarks = '';
    }
    this.worksheetService.savemaintworksheet(requestObj, this.worksheetResponse).subscribe(
      data => {
        this.saveworksheetResponse = data;
        if (this.saveworksheetResponse.status !== 'success') {
          this.errorservice.showerror({status: this.saveworksheetResponse.errorCode, statusText:this.saveworksheetResponse.message});
        } else {
         // this.errorservice.showerror({type:'Info', status:'', statusText:'data.L00219'});
          if(this.saveMode === 'New') {
            this.refreshworksheet('data.L00722');
          } else if(this.saveMode === 'Delete') {
            this.refreshworksheet('data.L00723');
          }
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
   }

   preparenonroutineobj(nonRoutineActivity: any) {
    let maintFinalRecords: any;
    const reqObj = {
      'action': '',
      'id': this.worksheetData.id,
      'allowRemark': this.worksheetData.allowRemark,
      'remarks': (this.worksheetData.remarks) ? this.worksheetData.remarks : '',
      'remarkTypeId': (this.worksheetData.remarkTypeId !== 0) ? this.worksheetData.remarkTypeId : null,
      'reason': '',
      'recordStatus': '',
      'maintRecords': []
    };
    // tslint:disable-next-line:max-line-length
    maintFinalRecords = { opsMAAssocId: nonRoutineActivity.opsMAAssocId, testRemark: nonRoutineActivity.testRemark, allowEdit: nonRoutineActivity.allowEdit};
    reqObj.maintRecords.push(maintFinalRecords);
    return reqObj;

   }

   confirmreorder(flag: any) {
    this.stickheaderID = (flag) ? '' : 'editworksheetheader';
    this.reorder = false;
    this.reorderchild = flag;
    this.reorderparent = flag;
    const requestObj = this.preparereorderObj(this.worksheetActivities);
    requestObj.action = 'Save';
    this.worksheetService.savemaintuserpreferencews(requestObj, this.worksheetResponse).subscribe(
      data => {
          this.reorderwsResponse = data;
          if(this.reorderwsResponse.status !== 'success') {
            this.errorservice.showerror({status: this.reorderwsResponse.errorCode, statusText: this.reorderwsResponse.message});
          } else {
            this.refreshOrder(requestObj);
          }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }

  refreshOrder(requestObj: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {title: 'Info', message: 'data.L00231'}
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
    });
  }

  preparereorderObj(data: any) {
    const reqObj = {
      'action': '',
      'assocIds': []
    };
    if(data.length > 0) {
      for (let i = 0; i < data.length; i++ ) {
          reqObj.assocIds.push({'assocId': data[i].opsMAAssocId});
      }
    }
    return reqObj;
  }

  cancelreorder() {
    this.reorder = false;
   // this.getMaintenancewsdata('refresh');
  }

  submitmaintworksheetDialog() {
    const dialogRef = this.dialog.open(SubmitmaintenancewsComponent, {
      width: '90%',
      data: { 'mode': 'submit', 'maintRecords': this.worksheetData.maintRecords}
    });
    const sub = dialogRef.componentInstance.submitmaintenancewscallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.submitmaintenancews();
    });
   }

   submitmaintenancews() {
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'Submit-MSUB';
    requestObj.recordStatus = 'Update';
    if(requestObj.remarkTypeId == null) {
      requestObj.remarks = '';
    }
    this.worksheetService.submitmaintenancews(requestObj, this.worksheetResponse).subscribe(
      data => {
        this.submitwsResponse = data;
        if (this.submitwsResponse.status !== 'success') {
          this.errorservice.showerror({status: this.submitwsResponse.errorCode, statusText: this.submitwsResponse.message});
        } else {
          this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00221' });
          const info = {
            'countryId': this.worksheetResponse.data.country.id,
            'citiId': this.worksheetResponse.data.country.city.id
          };
          this.worksheetService.setworksheetUserinfo(info);
          this.router.navigate(['/opsmaintenance/' + this.worksheetResponse.data.country.city.plant.id]);
        }
        },
      (err: any) => {
        this.errorMessage = err;
      }
    );
   }

   openunlockworksheetDialog(): void {
    if (this.disableunlock === false) {
      const dialogRef = this.dialog.open(UnlockmaintenancewsComponent, {
        width: '400px',
        data: []
    });
    const sub = dialogRef.componentInstance.unlockmaintenanceCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.unlockws(result);
    });
    } else {
     this.errorservice.showerror({type: 'Info', status: '', statusText:'data.L00171'});
    }

  }

  unlockws(unlockinfo: any) {
    if (unlockinfo.reason) {
      this.worksheetData.reason = unlockinfo.reason;
    }
    if (unlockinfo.remarks) {
      this.worksheetData.remarks = unlockinfo.remarks;
    }
    const requestObj = this.preparereqobj(this.worksheetData);
    requestObj.action = 'RFUL';
    requestObj.recordStatus = 'Update';

    this.worksheetService.unlockmaintenancews(this.worksheetResponse, requestObj).subscribe(
      data => {
        this.unlockwsResponse = data;
        if (this.unlockwsResponse.status !== 'success') {
          this.errorservice.showerror({status: this.unlockwsResponse.errorCode, statusText: this.unlockwsResponse.message});
        } else {
          this.disableunlock = true;
         // this.errorservice.showerror({type: 'Info', status: '', statusText: 'data.L00220'});
         this.refreshworksheet('data.L00220');
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );

   }

   refreshworksheet(dialogMsg: any) {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      data: {title: 'Info', message: dialogMsg}
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
     // this.getMaintenancewsdata('refresh');
    });
  }

   // Angular material drag and drop

dropActivities(event: CdkDragDrop<string[]>) {
  moveItemInArray(this.worksheetActivities, event.previousIndex, event.currentIndex);
}

multiuserprompt(plantid: any, worksheetid: any, sessionuser: any) {
  const multiuserMsg = sessionuser + ' ' + this.commonservice.gettranslate('data.L00578');
  const dialogRef = this.dialog.open(DialogComponent, {
    width: '500px',
    disableClose: true,
    data: {
      'type': 'yesno',
      'title': 'data.L00224',
      'message': multiuserMsg
    }
  });
  dialogRef.componentInstance.cancelCallback.subscribe(result => {
    let worksheetlistUrl = 'opsmaintenance/' + plantid;
    if (this.bc === 'opsmainrecords') {
      worksheetlistUrl = 'opsmainrecords/' + plantid;
    }
    this.router.navigate([worksheetlistUrl]);
  });

  dialogRef.componentInstance.okCallback.subscribe(result => {
    dialogRef.componentInstance.closeDialog();
  });
}

}
