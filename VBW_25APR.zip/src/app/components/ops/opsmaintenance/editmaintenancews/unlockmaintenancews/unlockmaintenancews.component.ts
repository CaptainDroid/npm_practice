import { Component, Inject, EventEmitter, Output  } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface UnlockmaintenancewsData {
  value: any;
  name: string;
}

@Component({
  selector: 'app-unlockmaintenancews',
  templateUrl: './unlockmaintenancews.component.html',
  styleUrls: ['./unlockmaintenancews.component.css']
})
export class UnlockmaintenancewsComponent {

  @Output() unlockmaintenanceCallback = new EventEmitter<any>(true);

  selectedreason = 0 ;
  remarks = '';
  unlockmaintenancewsData: any;
  constructor(
      public dialogRef: MatDialogRef<UnlockmaintenancewsComponent>,
      @Inject(MAT_DIALOG_DATA) public data: UnlockmaintenancewsData) { }

  closeDialog(): void {
      this.dialogRef.close();
  }
  unlockworksheet() {
    this.unlockmaintenanceCallback.emit({remarks: this.remarks});
  }
}
