import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnlockmaintenancewsComponent } from './unlockmaintenancews.component';

describe('UnlockmaintenancewsComponent', () => {
  let component: UnlockmaintenancewsComponent;
  let fixture: ComponentFixture<UnlockmaintenancewsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnlockmaintenancewsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnlockmaintenancewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
