import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmitmaintenancewsComponent } from './submitmaintenancews.component';

describe('SubmitmaintenancewsComponent', () => {
  let component: SubmitmaintenancewsComponent;
  let fixture: ComponentFixture<SubmitmaintenancewsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmitmaintenancewsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmitmaintenancewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
