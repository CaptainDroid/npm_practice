import { Component, Inject, EventEmitter, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-submitmaintenancews',
  templateUrl: './submitmaintenancews.component.html',
  styleUrls: ['./submitmaintenancews.component.css']
})
export class SubmitmaintenancewsComponent {
  @Output() submitmaintenancewscallback = new EventEmitter<any>(true);
  mode: any;
  maintRecords: any;
  constructor(
    public dialogRef: MatDialogRef<SubmitmaintenancewsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.mode = data.mode;
    this.maintRecords = [];
    for (let i = 0; i < data.maintRecords.length; i++) {
      if (this.maintRecords.indexOf(data.maintRecords[i].activityName) < 0) {
        this.maintRecords.push(data.maintRecords[i].activityName);
      }    
    }
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
  
 /* gettime(date: any) {
    let testhours = new Date(date);
    return ('0' + testhours.getUTCHours()).slice(-2) + ':' + ('0' + testhours.getUTCMinutes()).slice(-2);
  }*/

  submitworksheet() {
    this.submitmaintenancewscallback.emit(this.mode);
  }
}
