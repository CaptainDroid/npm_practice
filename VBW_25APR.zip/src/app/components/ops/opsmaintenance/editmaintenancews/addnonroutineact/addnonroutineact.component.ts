import { Component, OnInit, Inject, EventEmitter, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-addnonroutineact',
  templateUrl: './addnonroutineact.component.html',
  styleUrls: ['./addnonroutineact.component.css']
})
export class AddnonroutineactComponent implements OnInit {
  selectedEquipment: any;
  selectedActivity: any;
  activityDisplayName: any;
  activityDetail = '';
  equipmentDisplayName: any;
  activityDesc: any;
  selectedlang = 'EN';
  nonroutinedata: any;
  activityList: any;

  @Output() addnonroutinecallback = new EventEmitter<any>(true);
  constructor(public dialogRef: MatDialogRef<AddnonroutineactComponent>,
    public translate: TranslateService,
    @Inject(MAT_DIALOG_DATA) public data: any) { 
      this.nonroutinedata = data;
     if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
        if (currentLang === 1) {
          this.selectedlang = 'EN';
        } else {
          this.selectedlang = 'CN';
        }
      }
      this.translate.onLangChange.subscribe((language) => {
         if(parseInt(language.lang,10) === 1) {
           this.selectedlang = 'EN';
         } else {
            this.selectedlang = 'CN';
         }
      });
     }

  ngOnInit() { 

    const equipmentlist = [];
    this.nonroutinedata.activities.forEach( equipment => {
       if(equipmentlist.indexOf(equipment.equipmentName) < 0) {
          equipmentlist.push(equipment.equipmentName);
          equipment.isVisible = true;
       } else {
          equipment.isVisible = false;
       }
    });

   // console.log(this.nonroutinedata.activities);

  }  

  closeDialog(): void {
    this.dialogRef.close();
  }

  selectEquipment(item: any) {
    this.activityDetail = "";
    this.activityDesc = "";
    this.selectedEquipment = item;
  }

  selectActivity(item: any) {
    this.selectedActivity = item;
  }

  activityChange(event, activity) {    
    let activityId= event.value;        

    for(let i=0; i<activity.length; i++){
      if(activity[i].id === activityId) {
         this.activityDesc = activity[i].activityDisplayName[this.selectedlang];
         this.activityDisplayName = activity[i].activityDisplayName;
         this.equipmentDisplayName = activity[i].equipmentDisplayName;
      //this.activityDesc = activity[i].description.EN;
      }
    }
    return this.activityDesc;
  }

  equipmentChange(event, equipment) {
    let equipmentName= event.value;
    this.activityList = [];

    for(let i=0; i<equipment.length; i++){
      if(equipment[i].equipmentName === equipmentName) {
        this.activityList.push(equipment[i]);
      }
    }
  }

  addnonroutineactivity() {
    const obj = {      
      activity: this.selectedActivity,
      equipment: this.selectedEquipment,
      activityDisplayName: this.activityDisplayName,
      equipmentDisplayName: this.equipmentDisplayName,
      activityDetail: this.activityDetail
    };
    
    this.addnonroutinecallback.emit(obj);
   
  }

}
