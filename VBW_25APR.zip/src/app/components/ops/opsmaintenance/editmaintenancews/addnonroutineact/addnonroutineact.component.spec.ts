import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddnonroutineactComponent } from './addnonroutineact.component';

describe('AddnonroutineactComponent', () => {
  let component: AddnonroutineactComponent;
  let fixture: ComponentFixture<AddnonroutineactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddnonroutineactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddnonroutineactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
