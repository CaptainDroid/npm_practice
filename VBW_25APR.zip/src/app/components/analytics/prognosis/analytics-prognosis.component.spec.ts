import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsPrognosisComponent } from './analytics-prognosis.component';

describe('AnalyticsPrognosisComponent', () => {
  let component: AnalyticsPrognosisComponent;
  let fixture: ComponentFixture<AnalyticsPrognosisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalyticsPrognosisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsPrognosisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
