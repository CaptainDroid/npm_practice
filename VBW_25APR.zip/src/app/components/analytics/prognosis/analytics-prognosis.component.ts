import { Component, OnInit, Inject, HostListener, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { interval } from "rxjs/internal/observable/interval";
import { Observable, Subject, of, Subscription } from 'rxjs';
import { switchMap, delay, startWith, tap, concatMap } from 'rxjs/operators';
import { LoaderService } from '../../../services/loader.service';

interface IPrognosisTag {
    action: string;
    prognosisTags: any;
}
@Component({
    selector: 'app-analytics-prognosis',
    templateUrl: './analytics-prognosis.component.html',
    styleUrls: ['./analytics-prognosis.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class AnalyticsPrognosisComponent implements OnInit {

    errorMessage: any;
    max = 100;
    min = 0;
    value = 50;
    thumbLabel = true;
    subjectdataextract = new Subject();
    subjectsimulation = new Subject();
    subscriptions:Subscription[] = [];
    formData: any;
    displayedColumns = ['test', 'before', 'after'];
    dataSource = [
        { test: 'COD', before: '400', after: '700' },
        { test: 'NOH', before: '200', after: '400' }
    ];

    runId: any;

    plants = [];
    selectedPlant: any;
    processresponse: any;
    processes = [];
    processesByPlant = [];
    selectedProcess: any;
    loadingMessage: any;
    simulationresponse: any;
    prognosistags = [];
    prognosiseffluentvalues = [];
    effluentdisplayedColumns = ['name', 'beforeValue', 'afterValue'];
    dateObjectBefore: any;
    dateObjectAfter: any;
    simulationoutputresponse: any;
    runsimulationresponse: any;
    dataextractoutputresponse: any;
    rundataextractresponse: any;
    pollingcountsimulation = 0;
    pollingcountdataextract = 0;
    constructor(public route: ActivatedRoute,
        private commonService: CommonService,
        private loaderService: LoaderService,
        private analyticsService: AnalyticsService,
        private errorservice: ErrorserviceService,
        public dialog: MatDialog, @Inject(DOCUMENT) document) { }

    ngOnInit() {
        this.getprocesses();
        // this.dataextractoutputresponse = {
        //     status: "failed",
        //     message: "Polling count exceeded"
        // }
        // this.simulationoutputresponse = {
        //     status: "failed",
        //     message: "Polling count exceeded"
        // }
        
    }
    reloadProcess(plantobj: any) {
        this.selectedPlant = plantobj;
        console.log("The selected plant is" + plantobj.id);
        this.processesByPlant = this.processes.filter(
            process => process.plantId === plantobj.id);
    }
    getprocesses() {
        const processType = 'prognosis';
        this.subscriptions.push(this.analyticsService.getPlantProcesses(processType).subscribe(
            data => {
                this.processresponse = data;
                this.processes = [];
                this.plants = [];
                if (this.processresponse.status !== 'success') {
                    this.errorservice.showerror({ status: this.processresponse.status, statusText: this.processresponse.message });
                } else {
                    for (let i = 0; i < this.processresponse.data.countries.length; i++) {
                        for (let j = 0; j < this.processresponse.data.countries[i].cities.length; j++) {
                            for (let k = 0; k < this.processresponse.data.countries[i].cities[j].plants.length; k++) {
                                let plantobj: {
                                    id: any, acronym: any, countryId: any, cityId: any
                                };
                                plantobj = {
                                    id: this.processresponse.data.countries[i].cities[j].plants[k].id,
                                    acronym: this.processresponse.data.countries[i].cities[j].plants[k].acronym,
                                    countryId: this.processresponse.data.countries[i].id,
                                    cityId: this.processresponse.data.countries[i].cities[j].id
                                };
                                this.plants.push(plantobj);
                                for (let l = 0; l < this.processresponse.data.countries[i].cities[j].plants[k].processes.length; l++) {
                                    let processobj: {
                                        id: any, plantId: any, processName: any
                                    };
                                    processobj = {
                                        id: this.processresponse.data.countries[i].cities[j].plants[k].processes[l].id,
                                        plantId: this.processresponse.data.countries[i].cities[j].plants[k].id,
                                        processName: this.processresponse.data.countries[i].cities[j].plants[k].processes[l].process
                                    };
                                    this.processes.push(processobj);

                                }
                            }
                        }
                    }
                }
            },
            (err: any) => {
                console.log(err);
                this.errorMessage = 'There are no processes pulled from the server!';
            }
        ));
    }
    runPrognosisDataExtract(processobj: any) {
        this.selectedProcess = processobj;
        let reqobj = [];
        let plantobj = this.selectedPlant;
        this.subscriptions.push(this.analyticsService.runNowPrognosisDataExtract(this.selectedPlant, this.selectedProcess, reqobj).subscribe(
            data => {
                this.rundataextractresponse = data;
                if (this.rundataextractresponse.status !== 'success') {
                    this.errorservice.showerror({ status: this.rundataextractresponse.status, statusText: this.processresponse.message });
                } else {
                    this.runId = this.rundataextractresponse.data.runId;
                    this.loadingMessage = 'data.L01000';
                    setTimeout(() => { this.loaderService.show(this.loadingMessage); }, 5);
                    this.pollingcountdataextract = 0;
                    this.subjectdataextract = new Subject();
                    this.dataextractoutputresponse = '';
                    if (this.runId > 0) {
                        this.subjectdataextract.pipe(
                            startWith({}),
                            concatMap(() => this.analyticsService.getOutputPrognosisDataExtract(plantobj, processobj, this.runId, this.loadingMessage)),
                            tap(() => this.checktheresponseforrepolling(this.dataextractoutputresponse, this.pollingcountdataextract, this.subjectdataextract)),
                        ).subscribe(data => {
                            // this.subscriptions.push(this.analyticsService.getOutputPrognosisDataExtract(plantobj, processobj, this.runId).subscribe(
                            // data => {
                                this.prognosistags = [];
                                this.prognosiseffluentvalues = [];
                                this.dataextractoutputresponse = data;
                                this.loadingMessage = this.dataextractoutputresponse.message ? this.dataextractoutputresponse.message : this.loadingMessage;
                                if (this.dataextractoutputresponse.status !== 'success') {
                                    this.pollingcountdataextract++;
                                    // this.errorservice.showerror({ status: this.dataextractoutputresponse.status, statusText: this.dataextractoutputresponse.message });
                                } else {
                                    setTimeout(() => { this.loaderService.hide(); }, 5);
                                    for (let i = 0; i < this.dataextractoutputresponse.data.country.city.plant.prognosis.tags.length; i++) {
                                        const tagsobj = this.dataextractoutputresponse.data.country.city.plant.prognosis.tags[i];
                                        tagsobj.newValue = tagsobj.currentValue;
                                        tagsobj.minValue = (tagsobj.minValue === null) ? (tagsobj.currentValue - Math.abs(tagsobj.currentValue)) : tagsobj.minValue;
                                        tagsobj.maxValue = (tagsobj.maxValue === null) ? (tagsobj.currentValue + Math.abs(tagsobj.currentValue)) : tagsobj.maxValue;
                                        this.prognosistags.push(tagsobj);
                                    }
                                    for (let i = 0; i < this.dataextractoutputresponse.data.country.city.plant.prognosis.effluentValues.length; i++) {
                                        const efflobj = this.dataextractoutputresponse.data.country.city.plant.prognosis.effluentValues[i];
                                        this.prognosiseffluentvalues.push(efflobj);
                                    }
                                    this.dateObjectBefore = new Date();
                                    this.subjectdataextract.unsubscribe();
                                }
                            },
                            (err: any) => {
                                console.log(err);
                                this.errorMessage = 'There are no run Id pulled from the server!';
                            });
                    }
                }
            },
            (err: any) => {
                console.log(err);
                this.errorMessage = 'There are no run Id pulled from the server!';
            }
        ));
    }
    runPrognosisSimulation(processobj: any) {
        // this.selectedProcess = processobj;
        let processObj = this.selectedProcess;
        let reqobj = this.prognosistags;
        let plantobj = this.selectedPlant;
        const prognosisTagsArray = [];
        reqobj.forEach(object => {
            prognosisTagsArray.push({
                tagName: object.tagName,
                newValue: object.newValue,
                maxPG: object.maxValue,
                minPG: object.minValue
            });
        });
        this.formData = {
            action: 'create',
            prognosisTags: prognosisTagsArray,
        };
        this.subscriptions.push(this.analyticsService.runNowPrognosisSimulation(this.selectedPlant, this.selectedProcess, this.formData).subscribe(
            data => {
                this.runsimulationresponse = data;
                if (this.runsimulationresponse.status !== 'success') {
                    this.errorservice.showerror({ status: this.runsimulationresponse.status, statusText: this.runsimulationresponse.message });
                } else {
                    this.runId = this.runsimulationresponse.data.runId;
                    this.loadingMessage = 'data.L01000';
                    setTimeout(() => { this.loaderService.show(this.loadingMessage); }, 5);
                    this.pollingcountsimulation = 0;
                    this.subjectsimulation = new Subject();
                    this.simulationoutputresponse = '';
                    if (this.runId > 0) {
                        this.subjectsimulation.pipe(
                            startWith({}),
                            concatMap(() => this.analyticsService.getOutputPrognosisSimulation(plantobj, processObj, this.runId, this.loadingMessage)),
                            tap(() => this.checktheresponseforrepolling(this.simulationoutputresponse, this.pollingcountsimulation, this.subjectsimulation)),
                        ).subscribe(data => {
                            // this.subscriptions.push(this.analyticsService.getOutputPrognosisSimulation(plantobj, processObj, this.runId).subscribe(
                            // data => {
                                this.simulationoutputresponse = data;
                                this.loadingMessage = this.simulationoutputresponse.message ? this.simulationoutputresponse.message : this.loadingMessage;
                                if (this.simulationoutputresponse.status !== 'success') {
                                    this.pollingcountsimulation++;
                                    // this.errorservice.showerror({ status: this.simulationoutputresponse.status, statusText: this.processresponse.message });
                                } else {
                                    setTimeout(() => { this.loaderService.hide(); }, 5);
                                    for (let i = 0; i < this.simulationoutputresponse.data.country.city.plant.effluentValues.final_output.length; i++) {
                                        const efflobj = this.simulationoutputresponse.data.country.city.plant.effluentValues.final_output[i];
                                        if (this.prognosiseffluentvalues[i].tagName === efflobj.tagName) {
                                            this.prognosiseffluentvalues[i].after_val = efflobj.after_val;
                                            this.prognosiseffluentvalues[i].after_Date = efflobj.Date;
                                        }
                                    }
                                    this.dateObjectAfter = new Date();
                                    this.subjectsimulation.unsubscribe();
                                }
                            },
                            (err: any) => {
                                console.log(err);
                                this.errorMessage = 'There are no run Id pulled from the server!';
                            });
                    }
                }
            },
            (err: any) => {
                console.log(err);
                this.errorMessage = 'There are no run Id pulled from the server!';
            }
        ));
    }
    checktheresponseforrepolling(responseobj: any, pollingcountobj: any, subjectobj: any) {
        setTimeout(() => { this.loaderService.show(this.loadingMessage); }, 5);
        if (responseobj.status !== 'success') {
            if (pollingcountobj > 5) {
                setTimeout(() => { this.loaderService.hide(); }, 5);
                this.errorservice.showerror({ status: responseobj.status, statusText: responseobj.message });
            } else {
                this.delay(10000).then(any => {
                    return subjectobj.closed ? null : subjectobj.next();
                 });
            }
        }
        return null;
    };

    async delay(ms: number) {
        await new Promise(resolve => setTimeout(() => resolve(), ms)).then(() => console.log("fired getOutput"));
    }
    ngOnDestroy() {
        this.subscriptions.forEach(s => s.unsubscribe());
        this.subjectdataextract.unsubscribe();
        this.subjectsimulation.unsubscribe();
    }
}
