import { Component, OnInit, Inject } from "@angular/core";
import { FormControl, FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { AnalyticsService } from "src/app/services/analytics.service";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { AnalyticsCancelConfirmationDialogComponent } from "../confirmation-dialog/cancel-confirmation-dialog";
import { ErrorserviceService } from "src/app/services/errorservice.service";
import { CommonService } from "src/app/services/common.service";
import { p } from "@angular/core/src/render3";
import { DialogComponent } from "../../common/dialog/dialog.component";
interface ITagDesc{
  en: string;
  cn: string;
}
interface IPredictTag {
  action: string;
  plantId: string;
  tagName: string;
  uomid: string;
  tagDescription: ITagDesc;
}

@Component({
  selector: "app-add-edit-predict-tag",
  templateUrl: "./add-edit-predict-tag.component.html",
  styleUrls: [
    "./add-edit-predict-tag.component.css",
    "../../../../assets/css/events.css"]
})
export class AnalyticsAddEditPredictTagComponent implements OnInit {
  addeditPredictTagForm: FormGroup;
  plant: any = '';
  isEditPredictTag: boolean = false;
  predictTagAction: string;
  formData: IPredictTag;
  predictTagData: any;
  selectedPlantObj: any;
  plants = [];
  selectedPlant: any;
  tags = [];
  uoms = [];
  errorMessage: any;
  predictTag: any;
  plantresponse: any;
  tagsresponse: any;
  uomresponse: any;
  constructor(
    private formBuilder: FormBuilder,
    private analyticsService: AnalyticsService,
    private commonService: CommonService,
    private router: Router,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private errorservice: ErrorserviceService,
  ) {
    this.listPlants();

      this.listUOMs();
      /**
       * Form Data
       */
      this.addeditPredictTagForm = this.formBuilder.group({
        plant: ['', Validators.required],
        tagName: ['', Validators.required],
        tagNamedefault: [''],
        UOM: ['', Validators.required],
        tagDescEn: ['', Validators.required],
        tagDescCn: ['', Validators.required]
      });

      this.isEditPredictTag = false;

      if (this.route.params['value'].hasOwnProperty('predictTagId')) {
        this.isEditPredictTag=true;
        this.predictTag={
          id: this.route.params['value'].predictTagId,
          countryId: this.route.params['value'].countryId,
          cityId: this.route.params['value'].cityId,
          plantId: this.route.params['value'].plantId,
        }

        this.selectedPlant={
          countryId: this.route.params['value'].countryId,
          cityId: this.route.params['value'].cityId,
          id: this.route.params['value'].plantId,
        }


        this.getPredictTagDetails(this.selectedPlant,this.predictTag);
      }
  }

  getPredictTagDetails(plantobj:any,predictTag:any){
    let getPredictTagResponse: any;
    this.analyticsService.getPredictTagDetails(plantobj,predictTag).subscribe(
      data => {
        getPredictTagResponse = data;
        this.predictTagData = {};
        if (getPredictTagResponse.status !== 'success') {
          this.errorservice.showerror({ status: getPredictTagResponse.status, statusText: getPredictTagResponse.message });
        } else {
          this.predictTagData = {
            id: getPredictTagResponse.data.country.city.plant.analyticsProcess.predictTag.id,
            plantId: getPredictTagResponse.data.country.city.plant.id,
            tagName: getPredictTagResponse.data.country.city.plant.analyticsProcess.predictTag.tagName,
            UOM: getPredictTagResponse.data.country.city.plant.analyticsProcess.predictTag.UOM,
            tagDescEn: getPredictTagResponse.data.country.city.plant.analyticsProcess.predictTag.tagDesc.en,
            tagDescCn: getPredictTagResponse.data.country.city.plant.analyticsProcess.predictTag.tagDesc.cn
          };
          this.addeditPredictTagForm.setValue({
            plant: this.predictTagData.plantId,
            tagName: this.predictTagData.tagName,
            UOM: this.predictTagData.UOM,
            tagDescEn: this.predictTagData.tagDesc.en,
            tagDescCn: this.predictTagData.tagDesc.cn
          });

        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no tags pulled from the server!';
      }
    );
  }
  listUOMs() {
    this.commonService.getuoms().subscribe(
      data => {
        this.uomresponse = data;
        this.uoms = [];
        if (this.uomresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.uomresponse.status, statusText: this.plantresponse.message });
        } else {
          for (let i = 0; i < this.uomresponse.data.length; i++) {
                let uomobj: {
                  id: any, uomName: any
                };
                uomobj = {
                  id: this.uomresponse.data[i].uomid,
                  uomName: this.uomresponse.data[i].uomdesc
                };
                this.uoms.push(uomobj);
              }
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no uoms pulled from the server!';
      }
    );

  }
  listPlants() {
    /**
     * For listing Plant and Process
     */
    this.commonService.getplants().subscribe(
      data => {
        this.plantresponse = data;
        this.plants = [];
        if (this.plantresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.plantresponse.status, statusText: this.plantresponse.message });
        } else {
          for (let i = 0; i < this.plantresponse.data.countries.length; i++) {
            for (let j = 0; j < this.plantresponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.plantresponse.data.countries[i].cities[j].plants.length; k++) {
                let plantobj: {
                  id: any, acronym: any, countryId: any, cityId: any
                };
                plantobj = {
                  id: this.plantresponse.data.countries[i].cities[j].plants[k].id,
                  acronym: this.plantresponse.data.countries[i].cities[j].plants[k].acronym,
                  countryId: this.plantresponse.data.countries[i].id,
                  cityId: this.plantresponse.data.countries[i].cities[j].id
                };
                this.plants.push(plantobj);
              }
            }
          }
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no plants pulled from the server!';
      }
    );
  }

  ngOnInit() { }

  onSelectingPlant(plantobj: any) {
    this.plant = plantobj;
    this.constructTagNamePrefix(plantobj);
  }

  constructTagNamePrefix(plantobj: any) {
    this.addeditPredictTagForm.setValue({
      plant:   this.addeditPredictTagForm.value.plant,
      tagNamedefault: 'CN_' + plantobj.acronym + '_Prediction_',
      tagName: this.addeditPredictTagForm.value.tagName,
      UOM: this.addeditPredictTagForm.value.UOM,
      tagDescEn: this.addeditPredictTagForm.value.tagDescEn,
      tagDescCn:this.addeditPredictTagForm.value.tagDescCn
    });
  }
  /**
   * Cancel Confirmation Dialog
   */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(AnalyticsCancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'analytics-tags-list/predict/0' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  /**
   * Form Submit
   */
  addPredictTag() {
    if (this.addeditPredictTagForm.valid) {
      const formValue = this.addeditPredictTagForm.value;
      this.predictTagAction = 'create';
      if (this.isEditPredictTag) {
        this.predictTagAction = 'update';
      }
      this.predictTagData = formValue;
      let eventMessageObj = {
        'en': formValue.tagDescEn,
        'cn': formValue.tagDescCn
      };
      this.formData = {
        action: this.predictTagAction,
        plantId: formValue.plant,
        tagName: formValue.tagNamedefault + formValue.tagName ,
        uomid: formValue.UOM,
        tagDescription: eventMessageObj
      };
      /**
       * Add/Edit Form Data - POST
       */
      this.analyticsService.savePredictTag(this.plant, this.formData).subscribe(
        (data: any) => {
          if (data.status === 'success') {
            const dialogRef = this.dialog.open(DialogComponent, {
              width: '400px',
              disableClose: true,
              data: {title: 'data.L00224', message: 'Record saved successfully' }
            });
            const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
              this.router.navigate(['/analytics-tags-list/predict/' + this.plant.id]);
            });
            
          } else {
            this.errorservice.showerror({ status: data.status, statusText: data.message });
          }
        },
        (err: any) => {
          console.log('Failed');
        }
      );
    }
  }

}
