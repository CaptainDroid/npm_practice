import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsAddEditPredictTagComponent } from './add-edit-predict-tag.component';

describe('AddEventCategoryComponent', () => {
  let component: AnalyticsAddEditPredictTagComponent;
  let fixture: ComponentFixture<AnalyticsAddEditPredictTagComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalyticsAddEditPredictTagComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsAddEditPredictTagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
