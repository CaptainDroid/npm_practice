import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PredictionMessageListComponent } from './prediction-message-list.component';

describe('PredictionMessageListComponent', () => {
  let component: PredictionMessageListComponent;
  let fixture: ComponentFixture<PredictionMessageListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PredictionMessageListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PredictionMessageListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
