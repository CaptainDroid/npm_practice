import { Component, OnInit, ViewChild, Inject, HostListener, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { CommonService } from '../../../services/common.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';
import { DialogComponent } from '../../common/dialog/dialog.component';

@Component({
  selector: 'app-prediction-message-list',
  templateUrl: './prediction-message-list.component.html',
  styleUrls: ['./prediction-message-list.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class PredictionMessageListComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  displayedColumns = ['tagName', 'condition', 'message', 'action'];
  dataSource: any;
  pageInputs: any;
  serverresponse: any;
  recommendationmessages: any;
  messageslist: any;

  predicttaginfo: any;
  selectedlang = 'EN';

  constructor(public route: ActivatedRoute,
    public router: Router,
    private commonService: CommonService,
    private analyticsService: AnalyticsService,
    private errorservice: ErrorserviceService,
    public translate: TranslateService,
    public dialog: MatDialog, @Inject(DOCUMENT) document) {
    this.pageInputs = {};
    this.messageslist = [];
    this.predicttaginfo = {
      plant: '',
      tagname: '',
      process: '',
      description: {
        EN: '',
        CN: ''
      }
    };
    if (this.route.params['value'].hasOwnProperty('predictionTagId')) {
      this.pageInputs = this.route.params['value'];
      this.dataSource = [];
      this.getpredictionmessagelist();
    }
    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
      if (parseInt(language.lang, 10) === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    });

    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
      if (parseInt(language.lang, 10) === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    });
  }

  ngOnInit() { }

  getpredictionmessagelist() {
    this.messageslist = [];
    this.dataSource = [];
    this.analyticsService.getrecommendationmsglist(this.pageInputs).subscribe(
      data => {
        this.serverresponse = data;
        if (this.serverresponse.status !== 'success') {
          this.errorservice.showerror({
            type: 'error',
            status: this.serverresponse.status,
            statusText: this.serverresponse.message
          });
        } else {
          this.recommendationmessages = this.serverresponse.data.country.city.plant.analyticsProcess;
          this.predicttaginfo.plant = this.serverresponse.data.country.city.plant.acronym;
          if (this.recommendationmessages.predictionTagMessage) {
            this.predicttaginfo.tagname = this.recommendationmessages.predictionTagMessage.tagName;
            this.predicttaginfo.process = this.recommendationmessages.process;
            if (this.recommendationmessages.predictionTagMessage.tagDescription !== null &&
              this.recommendationmessages.predictionTagMessage.tagDescription !== '') {
              this.predicttaginfo.description = this.recommendationmessages.predictionTagMessage.tagDescription;
            } else {
              this.predicttaginfo.description = {
                'EN': '',
                'CN': ''
              };
            }
            if (this.recommendationmessages.predictionTagMessage.messagetags) {
              if (this.recommendationmessages.predictionTagMessage.messagetags.length > 0) {
                this.messageslist = this.recommendationmessages.predictionTagMessage.messagetags;
                this.dataSource = new MatTableDataSource(this.messageslist);
                this.dataSource.paginator = this.paginator;
              }
            }
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  editmsg(tagname: any) {
    this.analyticsService.setrecommendationmsg(this.predicttaginfo);
    // tslint:disable-next-line: max-line-length
    const paramUrl = this.pageInputs.countryId + '/' + this.pageInputs.cityId + '/' + this.pageInputs.plantId + '/' + this.pageInputs.processId + '/' + this.pageInputs.predictionTagId + '/' + tagname;
    this.router.navigate(['edit-analytics-rcmsg/' + paramUrl]);
  }

  addmsg() {
    this.analyticsService.setrecommendationmsg(this.predicttaginfo);
    // tslint:disable-next-line: max-line-length
    const paramUrl = this.pageInputs.countryId + '/' + this.pageInputs.cityId + '/' + this.pageInputs.plantId + '/' + this.pageInputs.processId + '/' + this.pageInputs.predictionTagId;
    this.router.navigate(['add-analytics-rcmsg/' + paramUrl]);
  }

  navback() {
    // tslint:disable-next-line: max-line-length
    const paramUrl = this.pageInputs.countryId + '/' + this.pageInputs.cityId + '/' + this.pageInputs.plantId + '/' + this.pageInputs.processId + '/' + this.pageInputs.predictionTagId;
    this.router.navigate(['edit-prediction-tag/' + paramUrl]);
  }
}

// ADD - EDIT Message list component

@Component({
  selector: 'app-add-edit-msg-component',
  templateUrl: 'add-edit-message-list.html',
  styleUrls: ['./prediction-message-list.component.css']
})

export class AddeEditRCMsgComponent implements OnInit {

  addeditmsgData: any;
  pageInputs: any;
  predittaginfo: any;
  selectedlang = 'EN';
  alltags: any;
  alltagsresponse: any;
  mode: any;
  savetemplateresponse: any;
  edittemplteresponse: any;
  conditionsResponse: any;
  conditions: any;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    public commonservice: CommonService,
    public translate: TranslateService,
    public analyticsservice: AnalyticsService,
    public dialog: MatDialog, @Inject(DOCUMENT) document,
    public errorservice: ErrorserviceService) {
    this.pageInputs = {};
    this.addeditmsgData = {};
    this.addeditmsgData = this.prepareobj();
    if (this.route.params['value'].hasOwnProperty('predictionTagId')) {
      this.pageInputs = this.route.params['value'];
      this.mode = 'new';
    }
    if (this.route.params['value'].hasOwnProperty('msgid')) {
      this.mode = 'edit';
      this.addeditmsgData.tag = this.pageInputs.msgid;
    }
    this.getalltags();
    if (this.mode === 'edit') {
      this.editmsgtemplate();
    }
    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
      if (parseInt(language.lang, 10) === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    });

    if (this.translate.currentLang) {
      const currentLang = parseInt(this.translate.currentLang, 10);
      if (currentLang === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    }
    this.translate.onLangChange.subscribe((language) => {
      if (parseInt(language.lang, 10) === 1) {
        this.selectedlang = 'EN';
      } else {
        this.selectedlang = 'CN';
      }
    });

    this.predittaginfo = this.analyticsservice.getrecommendationmsg();
    console.log(this.predittaginfo);
  }
  ngOnInit() {
    this.getrmconditions();
  }

  getalltags() {
    this.analyticsservice.getalltags(this.pageInputs.plantId).subscribe(
      data => {
        this.alltagsresponse = data;
        if (this.alltagsresponse.status !== 'success') {
          this.errorservice.showerror({
            type: 'error',
            status: this.alltagsresponse.status,
            statusText: this.alltagsresponse.message
          });
        } else {
          this.alltags = this.alltagsresponse.data.tags.filter(tag => {
            const plantId = parseInt(this.pageInputs.plantId, 10);
            return tag.plantId === plantId;
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  getrmconditions() {
    this.conditions = [];
    this.analyticsservice.getconditions().subscribe(
      data => {
        this.conditionsResponse = data;
        if (this.conditionsResponse.status !== 'success') {
          this.errorservice.showerror({
            type: 'error',
            status: this.conditionsResponse.status,
            statusText: this.conditionsResponse.message
          });
        } else {
          this.conditions = this.conditionsResponse.data.parameters;
          this.conditions.forEach(con => {
            con.isHide = false;
          });
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  selectcondition() {
    const conditionlist = [];
    if (this.conditions && this.addeditmsgData.messages) {
      this.addeditmsgData.messages.forEach(con => {
        conditionlist.push(con.condition);
      });
      this.conditions.forEach(cond => {
        if (conditionlist.indexOf(cond.paramVal) > -1) {
          cond.isHide = true;
        } else {
          cond.isHide = false;
        }
      });
    }
  }

  editmsgtemplate() {
    this.analyticsservice.getmsgtemplatebyid(this.pageInputs).subscribe(
      data => {
        this.edittemplteresponse = data;
        if (this.edittemplteresponse.status !== 'success') {
          this.errorservice.showerror({
            type: 'error',
            status: this.edittemplteresponse.status,
            statusText: this.edittemplteresponse.message
          });
        } else {
          this.addeditmsgData.messages = [];
          if (this.edittemplteresponse.data.country.city.plant.analyticsProcess.predictionTagMessage.messagetags) {
            if (this.edittemplteresponse.data.country.city.plant.analyticsProcess.predictionTagMessage.messagetags.length > 0) {
              this.edittemplteresponse.data.country.city.plant.analyticsProcess.predictionTagMessage.messagetags.forEach(tag => {
                tag.conditionMessageTemplates.forEach(cond => {
                  this.addeditmsgData.messages.push(cond);
                });
              });
              this.selectcondition();
            } else {
              this.addeditmsgData.messages = [];
            }
          }
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  }

  addmsg() {
    const obj = {
      'messageId': 0,
      'condition': 'selectcon',
      'message': ''
    };
    this.addeditmsgData.messages.push(obj);
  }

  removemsg(collection: any, msg: any) {
    const index = collection.indexOf(msg);
    if (collection.length > 1) {
      collection.splice(index, 1);
      this.selectcondition();
    }
  }

  createmsgtemplate() {
    this.addeditmsgData.preditionTagId = parseInt(this.pageInputs.predictionTagId, 10);
    if (this.mode === 'edit') {
      this.addeditmsgData.action = 'update';
    }
    let isValid = true;
    this.addeditmsgData.messages.forEach(msgcon => {
      if (msgcon.message === '' ||
        msgcon.message === null ||
        msgcon.condition === 'selectcon' || msgcon.condition === null) {
        isValid = false;
      }
    });
    if (isValid === true) {
      this.analyticsservice.createrctemplate(this.pageInputs, this.addeditmsgData).subscribe(
        data => {
          this.savetemplateresponse = data;
          if (this.savetemplateresponse.status !== 'success') {
            this.errorservice.showerror(
              {
                type: 'error',
                status: this.savetemplateresponse.errorCode,
                statusText: this.savetemplateresponse.message
              });
          } else {
            const dialogRef = this.dialog.open(DialogComponent, {
              width: '400px',
              disableClose: true,
              data: { title: 'data.L00224', message: 'data.L00488' }
            });
            const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
              // tslint:disable-next-line: max-line-length
              const paramUrl = this.pageInputs.countryId + '/' + this.pageInputs.cityId + '/' + this.pageInputs.plantId + '/' + this.pageInputs.processId + '/' + this.pageInputs.predictionTagId;
              this.router.navigate(['prediction-message-list/' + paramUrl]);
            });
          }
        },
        (err: any) => {
          console.log(err);
        }
      );
    } else {
      this.errorservice.showerror({ type: 'error', status: '', statusText: 'data.L00229' });
      return false;
    }
  }

  cancel() {
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: { type: 'yesno', title: 'data.L00224', message: 'data.L00366' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      // tslint:disable-next-line: max-line-length
      const paramUrl = this.pageInputs.countryId + '/' + this.pageInputs.cityId + '/' + this.pageInputs.plantId + '/' + this.pageInputs.processId + '/' + this.pageInputs.predictionTagId;
      this.router.navigate(['prediction-message-list/' + paramUrl]);
    });
  }

  navback() {
    // tslint:disable-next-line: max-line-length
    const paramUrl = this.pageInputs.countryId + '/' + this.pageInputs.cityId + '/' + this.pageInputs.plantId + '/' + this.pageInputs.processId + '/' + this.pageInputs.predictionTagId;
    this.router.navigate(['prediction-message-list/' + paramUrl]);
  }
  navtagsetup() {
    // tslint:disable-next-line: max-line-length
    const paramUrl = this.pageInputs.countryId + '/' + this.pageInputs.cityId + '/' + this.pageInputs.plantId + '/' + this.pageInputs.processId + '/' + this.pageInputs.predictionTagId;
    this.router.navigate(['edit-prediction-tag/' + paramUrl]);
  }

  showmsgcarboninfo() {
    // tslint:disable-next-line: no-use-before-declare
    const dialogRef = this.dialog.open(MsgcarbonrefDialogComponent, {
      width: '80%',
      disableClose: true,
    });
  }

  prepareobj() {
    return {
      'action': 'create',
      'preditionTagId': this.pageInputs.predictionTagId,
      'tag': 'selecttag',
      'messages': [
        {
          'messageId': 0,
          'condition': 'selectcon',
          'message': ''
        }
      ]
    };
  }
}

// message_carbon Reference Dialog Component

@Component({
  selector: 'app-msgcarbonref-dialog-component',
  templateUrl: 'msgcarbon-ref.dialog.html',
  styleUrls: ['./prediction-message-list.component.css']
})

export class MsgcarbonrefDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<MsgcarbonrefDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
