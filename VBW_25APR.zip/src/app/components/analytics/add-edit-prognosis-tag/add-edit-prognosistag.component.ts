import { Component, OnInit, Inject } from "@angular/core";
import { FormControl, FormGroup, FormBuilder, Validators, FormGroupDirective, NgForm} from "@angular/forms";
import {ErrorStateMatcher} from '@angular/material';
import { Router, ActivatedRoute } from "@angular/router";
import { AnalyticsService } from "src/app/services/analytics.service";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { AnalyticsCancelConfirmationDialogComponent } from "../confirmation-dialog/cancel-confirmation-dialog";
import { ErrorserviceService } from "src/app/services/errorservice.service";
import { CommonService } from "src/app/services/common.service";
import { p } from "@angular/core/src/render3";
import { DialogComponent } from "../../common/dialog/dialog.component";
interface ITagDesc{
  en: string;
  cn: string;
}
interface IPrognosisTag {
  action: string;
  prognosisTagId: string;
  tagName: string;
  minValue: number;
  maxValue: number;
  uomid: string;
  tagDescription: ITagDesc;
}
class CrossFieldErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    return control.dirty && form.invalid;
  }
}
@Component({
  selector: "app-add-edit-prognosistag",
  templateUrl: "./add-edit-prognosistag.component.html",
  styleUrls: [
    "./add-edit-prognosistag.component.css",
    "../../../../assets/css/events.css"]
})
export class AnalyticsAddEditPrognosisTagComponent implements OnInit {
  addeditPrognosisTagForm: FormGroup;
  errorMatcher = new CrossFieldErrorMatcher();
  eventType = new FormControl();
  eventTypeList: string[] = [];
  plant: any = '';
  process: any = '';
  isEditPrognosisTag: boolean = false;
  isEditPredictTag = false;
  prognosisTagAction: string;
  formData: IPrognosisTag;
  prognosisTagData: any;
  selectedPlantObj: any;
  plants = [];
  selectedPlant: any;
  processresponse: any;
  processes = [];
  tags = [];
  uomresponse: any;
  uoms = [];
  processesByPlant = [];
  selectedProcess: any;
  errorMessage: any;
  tagsresponse: any;
  prognosisTag: any;
  constructor(
    private formBuilder: FormBuilder,
    private analyticsService: AnalyticsService,
    private commonService: CommonService,
    private router: Router,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private errorservice: ErrorserviceService,
  ) {
    console.log("inside constructor");

    this.listPlantAndProcess();
    this.listUOMs();
    /**
     * Form Data
     */
    this.addeditPrognosisTagForm = this.formBuilder.group({
      plant: [{ value: '', disabled: this.isEditPrognosisTag }, Validators.required],
      process: [{ value: '', disabled: this.isEditPrognosisTag }, Validators.required],
      tag: [{ value: '', disabled: this.isEditPrognosisTag }, Validators.required],
      min: [''],
      max: ['', Validators.compose([Validators.required, Validators.pattern(/^\d{1,9}([\.,](\d{1,3})?)?$/)])],
      UOM: [''],
      tagDescEn: [''],
      tagDescCn: ['']
    },{
      validator: this.minmaxValidator
    });

    this.isEditPrognosisTag = false;

    if (this.route.params['value'].hasOwnProperty("prognosisTagId")) {
      this.isEditPrognosisTag = true;
      this.prognosisTag = {
        id: this.route.params['value'].prognosisTagId,
        countryId: this.route.params['value'].countryId,
        cityId: this.route.params['value'].cityId,
        plantId: this.route.params['value'].plantId,
      }

      this.selectedPlant = {
        countryId: this.route.params['value'].countryId,
        cityId: this.route.params['value'].cityId,
        id: this.route.params['value'].plantId,
      }

      this.selectedProcess = {
        id: this.route.params['value'].processId
      }
      this.getAllTagsinPlant(this.selectedPlant);

      this.getPrognosisTagDetails(this.selectedPlant, this.selectedProcess, this.prognosisTag);
    }
  }
  minmaxValidator(form: FormGroup) {
    const minVal = form.get('min').value;
    const maxVal = form.get('max').value;
    const regex=/^\d{1,9}([\.,](\d{1,3})?)?$/;
    if(minVal && !regex.test(minVal)){
      return { minValtValidationFlag: true}
    }else{
      return minVal > maxVal ? { minmaxNotmatched: true} : null;
    }
  }
  getPrognosisTagDetails(plantobj: any, processobj: any, prognosisTag: any) {
    let getPrognosisTagResponse: any;
    this.analyticsService.getPrognosisTag(plantobj, processobj, prognosisTag).subscribe(
      data => {
        getPrognosisTagResponse = data;
        this.prognosisTagData = {};
        if (getPrognosisTagResponse.status !== 'success') {
          this.errorservice.showerror({ status: getPrognosisTagResponse.status, statusText: getPrognosisTagResponse.message });
        } else {
          let description = getPrognosisTagResponse.data.country.city.plant.analyticsProcess.prognosisTag.tagDescription;
          // let uomValue = this.uoms.filter(t => t.uomName === getPrognosisTagResponse.data.country.city.plant.analyticsProcess.prognosisTag.uomDesc)[0];
          this.prognosisTagData = {
            id: getPrognosisTagResponse.data.country.city.plant.analyticsProcess.prognosisTag.id,
            plantId: getPrognosisTagResponse.data.country.city.plant.id,
            processId: getPrognosisTagResponse.data.country.city.plant.analyticsProcess.id,
            tagName: getPrognosisTagResponse.data.country.city.plant.analyticsProcess.prognosisTag.tagName,
            min: getPrognosisTagResponse.data.country.city.plant.analyticsProcess.prognosisTag.minValue,
            max: getPrognosisTagResponse.data.country.city.plant.analyticsProcess.prognosisTag.maxValue,
            UOM: getPrognosisTagResponse.data.country.city.plant.analyticsProcess.prognosisTag.uomDesc,
            tagDescEn: description && description.en ? description.en : '',
            tagDescCn: description && description.cn ? description.cn : ''
          };

          // this.addeditPrognosisTagForm.setValue({
          //   plant: this.prognosisTagData.plantId,
          //   process: null,
          //   tag: null,
          //   min: this.prognosisTagData.min,
          //   max: this.prognosisTagData.max
          // });


          // this.addeditPrognosisTagForm = this.formBuilder.group({
          //   plant: [{ value: this.prognosisTagData.plantId }, Validators.required],
          //   process: [{ value: '', disabled: this.isEditPrognosisTag }, Validators.required],
          //   tag: [{ value: '', disabled: this.isEditPrognosisTag }, Validators.required],
          //   min: [this.prognosisTagData.min],
          //   max: [this.prognosisTagData.max, Validators.required]
          // });

          console.log('addeditPrognosisTagForm:' + this.addeditPrognosisTagForm);

          this.addeditPrognosisTagForm.setValue({
            plant: this.prognosisTagData.plantId,
            process: this.prognosisTagData.processId,
            tag: this.prognosisTagData.tagName,
            min: this.prognosisTagData.min,
            max: this.prognosisTagData.max,
            UOM: this.prognosisTagData.UOM,
            tagDescEn: this.prognosisTagData.tagDescEn,
            tagDescCn: this.prognosisTagData.tagDescCn
          });

        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no tags pulled from the server!';
      }
    );
  }
  listUOMs(){
    console.log("Inside listUOMs of AddEditPredictTags");
    this.commonService.getuoms().subscribe(
      data => {
        this.uomresponse = data;
        this.uoms = [];
        if (this.uomresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.uomresponse.status, statusText: this.processresponse.message });
        } else {
          for (let i = 0; i < this.uomresponse.data.length; i++) {
                let uomobj: {
                  id: any, uomName: any
                };
                uomobj = {
                  id: this.uomresponse.data[i].uomid,
                  uomName: this.uomresponse.data[i].uomdesc
                };
                this.uoms.push(uomobj);
              }
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no uoms pulled from the server!';
      }
    );

  }
  listPlantAndProcess() {
    console.log("Inside list Plant And Process");
    /**
     * For listing Plant and Process
     */
    const processType = 'prognosis';
    this.analyticsService.getPlantProcesses(processType).subscribe(
      data => {
        this.processresponse = data;
        this.processes = [];
        this.plants = [];
        if (this.processresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.processresponse.status, statusText: this.processresponse.message });
        } else {
          for (let i = 0; i < this.processresponse.data.countries.length; i++) {
            for (let j = 0; j < this.processresponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.processresponse.data.countries[i].cities[j].plants.length; k++) {
                let plantobj: {
                  id: any, acronym: any, countryId: any, cityId: any
                };
                plantobj = {
                  id: this.processresponse.data.countries[i].cities[j].plants[k].id,
                  acronym: this.processresponse.data.countries[i].cities[j].plants[k].acronym,
                  countryId: this.processresponse.data.countries[i].id,
                  cityId: this.processresponse.data.countries[i].cities[j].id
                };
                this.plants.push(plantobj);
                for (let l = 0; l < this.processresponse.data.countries[i].cities[j].plants[k].processes.length; l++) {
                  let processobj: {
                    id: any, plantId: any, processName: any
                  };
                  processobj = {
                    id: this.processresponse.data.countries[i].cities[j].plants[k].processes[l].id,
                    plantId: this.processresponse.data.countries[i].cities[j].plants[k].id,
                    processName: this.processresponse.data.countries[i].cities[j].plants[k].processes[l].process
                  };
                  this.processes.push(processobj);

                }
              }
            }
          }
          this.processesByPlant = Object.assign([], this.processes);
          // tslint:disable-next-line:radix
          this.plant = this.plants.filter(t => t.id === parseInt(this.route.params['value'].plantId))[0];
          // tslint:disable-next-line:radix
          this.process = this.processes.filter(t => t.id === parseInt(this.route.params['value'].processId))[0];
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no processes pulled from the server!';
      }
    );

  }

  ngOnInit() {



  }

  reloadProcess(plantobj: any) {
    this.selectedPlant = plantobj;
    if (this.processes.length > 0) {
      this.processesByPlant = this.processes.filter(
        process => process.plantId === plantobj.id);
    }
    this.onSelectingTag({})
  }
  onSelectingPlant(plantobj: any) {
    this.plant = plantobj;
    this.reloadProcess(plantobj);
    this.getAllTagsinPlant(plantobj);
  }
  onSelectingTag(tagobj:any){
    // let uomVal = this.uoms.filter(t => t.uomName === tagobj.uomDesc)[0];
    // let uomValue = uomVal ? uomVal.id : '';
    this.addeditPrognosisTagForm.controls['tagDescEn'].setValue(tagobj.tagDescEn);
    this.addeditPrognosisTagForm.controls['tagDescCn'].setValue(tagobj.tagDescCn);
    this.addeditPrognosisTagForm.controls['UOM'].setValue(tagobj.uomDesc);
  }
  onSelectingProcess(processobj: any) {
    this.process = processobj;
  }
  getAllTagsinPlant(plantobj: any) {
    this.commonService.getalltags(plantobj.id).subscribe(
      data => {
        this.tagsresponse = data;
        this.tags = [];
        if (this.tagsresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.tagsresponse.status, statusText: this.tagsresponse.message });
        } else {
          for (let m = 0; m < this.tagsresponse.data.tags.length; m++) {
            let tagobj: {
              tagName: any, tagDescEn: any, tagDescCn: any, uomDesc: any
            };
            tagobj = {
              tagName: this.tagsresponse.data.tags[m].tagname,
              tagDescEn: this.tagsresponse.data.tags[m].tagDesc.en,
              tagDescCn: this.tagsresponse.data.tags[m].tagDesc.cn,
              uomDesc: this.tagsresponse.data.tags[m].uomDesc
            };
            this.tags.push(tagobj);
          }
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no tags pulled from the server!';
      }
    );
  }

  /**
   * Cancel Confirmation Dialog
   */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(AnalyticsCancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'analytics-tags-list/prognosis/0' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  /**
   * Form Submit
   */
  addUpdatePrognosisRecord() {
    if (this.addeditPrognosisTagForm.valid) {
      const formValue = this.addeditPrognosisTagForm.value;
      this.prognosisTagAction = "create";
      if (this.isEditPrognosisTag) {
        this.prognosisTagAction = "update";
      }
      // this.prognosisTagData = formValue;
      let eventMessageObj = {
        "en": formValue.tagDescEn,
        "cn": formValue.tagDescCn
      }
      let uomValue = this.uoms.filter(t => t.uomName === formValue.UOM)[0];
      this.formData = {
        action: this.prognosisTagAction,
        prognosisTagId: this.prognosisTagData ? this.prognosisTagData.id : 0,
        tagName: formValue.tag,
        minValue: formValue.min,
        maxValue: formValue.max,
        tagDescription: eventMessageObj,
        uomid: uomValue ? uomValue.id : null
      };
      /**
       * Add/Edit Form Data - POST
       */
      this.analyticsService.savePrognosisTag(this.plant, this.process, this.formData).subscribe(
        (data: any) => {
          if (data.status === 'success') {
            const dialogRef = this.dialog.open(DialogComponent, {
              width: '400px',
              disableClose: true,
              data: {title: 'data.L00224', message: 'Record saved successfully' }
            });
            const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
              this.router.navigate(['/analytics-tags-list/prognosis/' + this.plant.id]);
            });
          }
          else {
            this.errorservice.showerror({ status: data.status, statusText: data.message });
          }
        },
        (err: any) => {
          console.log('Failed');
        }
      );
    }
  }
  deletePrognosisRecordConfirmation(){
    const dialogRef = this.dialog.open(DialogComponent, {
      width: '400px',
      disableClose: true,
      data: { type: 'yesno', title: 'data.L00037', message: 'data.L00226' }
    });
    const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
      dialogRef.componentInstance.closeDialog();
      this.deletePrognosisRecord();
    });
  }
  deletePrognosisRecord(){
    let deleteObj = {
      action: 'delete',
      prognosisTagId: this.prognosisTagData.id
    };
    this.analyticsService.savePrognosisTag(this.plant, this.process, deleteObj).subscribe(
      (data: any) => {
        if (data.status === 'success') {
          const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            disableClose: true,
            data: {title: 'data.L00224', message: 'Record deleted successfully' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
            this.router.navigate(['/analytics-tags-list/prognosis/' + this.plant.id]);
          });
          
        }
        else {
          this.errorservice.showerror({ status: data.status, statusText: data.message });
        }
      },
      (err: any) => {
        console.log('Failed');
      }
    );
  }
}
