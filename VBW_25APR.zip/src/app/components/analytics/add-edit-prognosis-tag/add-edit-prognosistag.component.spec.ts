import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsAddEditPrognosisTagComponent } from './add-edit-prognosistag.component';

describe('AddEventCategoryComponent', () => {
  let component: AnalyticsAddEditPrognosisTagComponent;
  let fixture: ComponentFixture<AnalyticsAddEditPrognosisTagComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalyticsAddEditPrognosisTagComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsAddEditPrognosisTagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
