import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsTroubleshootingComponent } from './analytics-troubleshooting.component';

describe('AnalyticsPrognosisComponent', () => {
  let component: AnalyticsTroubleshootingComponent;
  let fixture: ComponentFixture<AnalyticsTroubleshootingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalyticsTroubleshootingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsTroubleshootingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
