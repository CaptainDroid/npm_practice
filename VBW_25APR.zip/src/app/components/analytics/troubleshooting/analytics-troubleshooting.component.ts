import { Component, OnInit, ViewChild, Inject, HostListener, EventEmitter, Output, ViewEncapsulation } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { MatPaginator, MatSort, MatTableDataSource } from "@angular/material";
import { ErrorserviceService } from '../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DOCUMENT } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { interval } from "rxjs/internal/observable/interval";
import { Observable, Subject, of, Subscription } from 'rxjs';
import { switchMap, delay, startWith, tap, concatMap } from 'rxjs/operators';
import { FormControl, FormGroup, FormBuilder, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material';
import { LoaderService } from '../../../services/loader.service';

export interface Tag {
    tagName: string;
    recommendationText: string;
}
export interface Recommendation {
    no: number;
    tags: Array<Tag>;
    cost: number;
    effluent: number;
}

export interface RecommendationPeriodicElement {
    slno: number;
    no: number;
    tagName: string;
    recommendationText: string;
    cost: number;
    effluent: number;
    costUnit : string;
    codUnit : string;
}
class CrossFieldErrorMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
      return control.dirty && form.invalid;
    }
  }
@Component({
    selector: 'app-analytics-troubleshooting',
    templateUrl: './analytics-troubleshooting.component.html',
    styleUrls: ['./analytics-troubleshooting.component.css',
        "../../../../assets/css/events.css"],
    encapsulation: ViewEncapsulation.None
})

export class AnalyticsTroubleshootingComponent implements OnInit {
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    troubleShootingForm: FormGroup;
    errorMatcher = new CrossFieldErrorMatcher();
    errorMessage: any;
    max = 100;
    min = 0;
    value = 50;
    thumbLabel = true;
    subjectsimulation = new Subject();
    subscriptions:Subscription[] = [];
    spans = [];
    runId: any;
    selectedPlantObj: any;
    loadingMessage: any;
    selectedProcessObj: any;
    selectedTagObj: any;
    plants = [];
    selectedPlant: any;
    processresponse: any;
    processes = [];
    processesByPlant = [];
    selectedProcess = 0;
    formData: any;
    simulationresponse: any;
    prognosistags = [];
    prognosiseffluentvalues = [];
    effluentdisplayedColumns = ['name', 'beforeValue', 'afterValue'];
    disableButton: boolean = true;
    simulationoutputresponse: any;
    costUnitGlobal: any;
    runsimulationresponse: any;
    dataextractoutputresponse: any;
    rundataextractresponse: any;
    pollingcountsimulation = 0;
    pollingcountdataextract = 0;
    floatValidate: boolean = false;
    minValue: any;
    thresholdValue: any;
    rcas = [];
    recommendations = [];
    recommendationData = [];
    tagsresponse: any;
    tags = [];
    dataSourceRCAs: any;
    dataSourceRecommendations: any;
    displayedColumnsRCA: string[] = ["tagName", "tagDescription", "median", "UOM"];
    displayedColumnsRecommendation: string[] = ["no", "tagName", "recommendationText", "cost", "effluent"];


    constructor(public route: ActivatedRoute,
        private commonService: CommonService,
        private formBuilder: FormBuilder,
        private loaderService: LoaderService,
        private analyticsService: AnalyticsService,
        private errorservice: ErrorserviceService,
        public dialog: MatDialog, @Inject(DOCUMENT) document) { 
            this.troubleShootingForm = this.formBuilder.group({
                plant: [{ value: ''}, Validators.required],
                process: [{ value: ''}, Validators.required],
                tag: [{ value: ''}, Validators.required],
                min: [''],
                threshold: ['', Validators.required],
                predictionVal: [''],
                projectedValue: ['', Validators.required]
              }, {
                validator: this.floatValidation
              });
        }

    ngOnInit() {
        this.getprocesses();
        this.dataextractoutputresponse = {
            status: "failed",
            message: "Polling count exceeded"
        }
        this.simulationoutputresponse = {
            status: "failed",
            message: "Polling count exceeded"
        }
    }
    floatValidation(form: FormGroup) {
        const regex = /^\d{1,3}([\.,](\d{1,2})?)?$/;
        const projectedVal = form.get('projectedValue').value;
        const thresholdVal = form.get('threshold').value;
        if (!regex.test(projectedVal) && projectedVal) {
            return { floatValidationFlag: true };
        } else {
            if (thresholdVal < projectedVal) {
                return { projectedValueFlag: true };
            } else {
                return null;
            }
        }
    }
    reloadProcess(plantobj: any) {
        this.disableButton = true;
        this.selectedPlant = plantobj;
        this.processesByPlant = this.processes.filter(process => process.plantId === plantobj.id);
        this.tags = [];
        this.refreshTable();
        this.resetformfields();
    }
    refreshTable(){
        this.dataSourceRCAs = new MatTableDataSource([]);
        this.recommendationData = [];
    }
    getprocesses() {
        const processType = 'troubleshooting';
        this.subscriptions.push(this.analyticsService.getPlantProcesses(processType).subscribe(
            data => {
                this.processresponse = data;
                this.processes = [];
                this.plants = [];
                if (this.processresponse.status !== 'success') {
                    this.errorservice.showerror({ status: this.processresponse.status, statusText: this.processresponse.message });
                } else {
                    for (let i = 0; i < this.processresponse.data.countries.length; i++) {
                        for (let j = 0; j < this.processresponse.data.countries[i].cities.length; j++) {
                            for (let k = 0; k < this.processresponse.data.countries[i].cities[j].plants.length; k++) {
                                let plantobj: {
                                    id: any, acronym: any, countryId: any, cityId: any
                                };
                                plantobj = {
                                    id: this.processresponse.data.countries[i].cities[j].plants[k].id,
                                    acronym: this.processresponse.data.countries[i].cities[j].plants[k].acronym,
                                    countryId: this.processresponse.data.countries[i].id,
                                    cityId: this.processresponse.data.countries[i].cities[j].id
                                };
                                this.plants.push(plantobj);
                                for (let l = 0; l < this.processresponse.data.countries[i].cities[j].plants[k].processes.length; l++) {
                                    let processobj: {
                                        id: any, plantId: any, processName: any
                                    };
                                    processobj = {
                                        id: this.processresponse.data.countries[i].cities[j].plants[k].processes[l].id,
                                        plantId: this.processresponse.data.countries[i].cities[j].plants[k].id,
                                        processName: this.processresponse.data.countries[i].cities[j].plants[k].processes[l].process
                                    };
                                    this.processes.push(processobj);

                                }
                            }
                        }
                    }
                }
            },
            (err: any) => {
                console.log(err);
                this.errorMessage = 'There are no processes pulled from the server!';
            }
        ));
    }


    getPredictionTags(processobj: any) {
        this.onSelectingProcess(processobj);
        this.selectedProcessObj = processobj;
        this.resetformfields();

        let plantobj = this.selectedPlant;
        this.subscriptions.push(this.analyticsService.getPredictionTagsForProcess(plantobj, processobj).subscribe(
            data => {
                this.tagsresponse = data;
                this.tags = [];
                if (this.tagsresponse.status !== 'success') {
                    this.errorservice.showerror({ status: this.tagsresponse.status, statusText: this.tagsresponse.message });
                } else {
                    for (let m = 0; m < this.tagsresponse.data.tags.length; m++) {
                        let tagobj: {
                            tagName: any, min: any, threshold: any, predictionVal: any
                        };
                        tagobj = {
                            tagName: this.tagsresponse.data.tags[m].tag,
                            min: this.tagsresponse.data.tags[m].minValue,
                            threshold: this.tagsresponse.data.tags[m].thresholdValue,
                            predictionVal: this.tagsresponse.data.tags[m].curValue
                        };
                        this.tags.push(tagobj);
                    }
                }
            },
            (err: any) => {
                console.log(err);
                this.errorMessage = 'There are no tags pulled from the server!';
            }
        ));
    }
    onSelectingProcess(processobj: any) {
        this.selectedProcessObj = processobj;
    }
    resetformfields(){
        this.troubleShootingForm.controls['min'].setValue('');
        this.troubleShootingForm.controls['threshold'].setValue('');
        this.troubleShootingForm.controls['projectedValue'].setValue('');
        this.troubleShootingForm.controls['predictionVal'].setValue('');
    }
    setMinMaxValues(tagobj: any) {
        this.resetformfields()
        this.selectedTagObj = tagobj;
        this.disableButton = this.selectedTagObj ? false : true;
        // this.minValue = tagobj.min;
        // this.thresholdValue = tagobj.threshold;
        this.troubleShootingForm.controls['min'].setValue(tagobj.min);
        this.troubleShootingForm.controls['threshold'].setValue(tagobj.threshold);
        this.troubleShootingForm.controls['predictionVal'].setValue(tagobj.predictionVal);
    }
    runTroubleshootingSimulation() {
        const formValue = this.troubleShootingForm.value;
        if (this.troubleShootingForm.valid) {
        this.refreshTable();
        this.formData = {
            action: 'create',
            projectedeffluentvalue: {
                thresholdValue: formValue.threshold,
                tagName: formValue.tag,
                projectValue: formValue.projectedValue
            }
        };
        this.selectedPlantObj = this.selectedPlant;
        this.subscriptions.push(this.analyticsService.runNowTroubleshootingSimulation(this.selectedPlantObj, this.selectedProcessObj, this.formData).subscribe(
            data => {
                this.runsimulationresponse = data;
                if (this.runsimulationresponse.status !== 'success') {
                    this.errorservice.showerror({ status: this.runsimulationresponse.status, statusText: this.runsimulationresponse.message });
                } else {
                    this.runId = this.runsimulationresponse.data.runId;
                    this.loadingMessage = 'data.L01000';
                    setTimeout(() => { this.loaderService.show(this.loadingMessage); }, 5);
                    this.pollingcountsimulation =0;
                    this.simulationoutputresponse = '';
                    this.subjectsimulation = new Subject();
                    if (this.runId > 0) {
                        this.subjectsimulation.pipe(
                            startWith({}),
                            concatMap(() =>  this.analyticsService.getOutputTroubleshootingSimulation(this.selectedPlantObj, this.selectedProcessObj, this.runId, this.loadingMessage)),
                            tap(() => this.checktheresponseforrepolling(this.simulationoutputresponse,this.pollingcountsimulation,this.subjectsimulation)),
                          ).subscribe( data => {
                            // this.subscriptions.push(this.analyticsService.getOutputTroubleshootingSimulation(this.selectedPlantObj, this.selectedProcessObj, this.runId).subscribe(
                            // data => {
                                this.simulationoutputresponse = data;
                                this.loadingMessage = this.simulationoutputresponse.message ? this.simulationoutputresponse.message : this.loadingMessage;
                                if (this.simulationoutputresponse.status !== 'success') {
                                      this.pollingcountsimulation++;
                                    // this.errorservice.showerror({ status: this.simulationoutputresponse.status, statusText: this.simulationoutputresponse.message });
                                } else {
                                    setTimeout(() => { this.loaderService.hide(); }, 5);
                                    this.rcas = [];
                                    this.recommendations = [];
                                    this.costUnitGlobal = this.simulationoutputresponse.data.country.city.plant.analyticsProcess.costUnit;
                                    if(this.simulationoutputresponse.data.country.city.plant.analyticsProcess.rcA_Details){
                                        for (let i = 0; i < this.simulationoutputresponse.data.country.city.plant.analyticsProcess.rcA_Details.length; i++) {
                                            let rca = this.simulationoutputresponse.data.country.city.plant.analyticsProcess.rcA_Details[i];
                                            this.rcas.push(rca);
                                        }
                                    }
                                    if(this.simulationoutputresponse.data.country.city.plant.analyticsProcess.all_Recommendations){
                                        for (let i = 0; i < this.simulationoutputresponse.data.country.city.plant.analyticsProcess.all_Recommendations.length; i++) {
                                            let recommendation = this.simulationoutputresponse.data.country.city.plant.analyticsProcess.all_Recommendations[i];
                                            this.recommendations.push(recommendation);
                                        }
                                    }

                                    this.dataSourceRCAs = new MatTableDataSource(this.rcas);
                                    if (this.dataSourceRCAs) {
                                        this.dataSourceRCAs.paginator = this.paginator;
                                    }
                                    this.reduceRecommendationData();
                                    this.cacheSpan('no', d => d);
                                    this.cacheSpan('cost', d => d);
                                    this.cacheSpan('effluent', d => d);

                                    this.dataSourceRecommendations = new MatTableDataSource(this.recommendationData);
                                    if (this.dataSourceRecommendations) {
                                        this.dataSourceRecommendations.paginator = this.paginator;
                                    }
                                    this.subjectsimulation.unsubscribe();
                                }
                            },
                            (err: any) => {
                                console.log(err);
                                this.errorMessage = 'There are no run Id pulled from the server!';
                            });
                    }
                }
            },
            (err: any) => {
                console.log(err);
                this.errorMessage = 'There are no run Id pulled from the server!';
            }
        ));
        }
    }
    checktheresponseforrepolling(responseobj:any, pollingcountobj:any, subjectobj:any){
        setTimeout(() => { this.loaderService.show(this.loadingMessage); }, 5);
        if (responseobj.status !== 'success') {
            if (pollingcountobj > 5) {
                setTimeout(() => { this.loaderService.hide(); }, 5);
               this.errorservice.showerror({ status: responseobj.status, statusText: responseobj.message });
           }else{
            this.delay(10000).then(any => {
                return subjectobj.closed ? null : subjectobj.next();
            });
           }
        }
        return null;
    };

    async delay(ms: number) {
        await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>console.log("fired getOutput"));
    }
    ngOnDestroy() {
        this.subscriptions.forEach(s => s.unsubscribe());
        this.subjectsimulation.unsubscribe();
    }

    getRowSpan(col, index) {
        if (this.spans[index] === undefined) {
            return 0;
        } else {
            return this.spans[index] && this.spans[index][col];
        }
    }

    reduceRecommendationData() {
        let slno = 0;
        this.recommendationData = this.recommendations.reduce((current, next) => {
            next.tags.forEach(tagobj => {
                current.push({
                    slno: slno++,
                    no: next.recommendation,
                    tagName: tagobj.tag_Name,
                    recommendationText: tagobj.dsRecommendationMessage,
                    cost: next.cost,
                    effluent: next.effluent,
                    costUnit: next.costUnit,
                    codUnit: next.codUnit
                })
            });
            return current;
        }, []);
    }

    // cacheSpan(key, accessor) {
    //     for (let i = 0; i < this.recommendationData.length;) {
    //         let currentValue = accessor(this.recommendationData[i]);
    //         let count = 1;

    //         // Iterate through the remaining rows to see how many match
    //         // the current value as retrieved through the accessor.
    //         for (let j = i + 1; j < this.recommendationData.length; j++) {
    //             if (currentValue != accessor(this.recommendationData[j])) {
    //                 break;
    //             }
    //             count++;
    //         }
    //         if (!this.spans[i] || this.spans[i] === undefined) {
    //             this.spans[i] = {};
    //         }
    //         // Store the number of similar values that were found (the span)
    //         // and skip i to the next unique row.
    //         this.spans[i][key] = count;
    //         i += count;
    //     }

    //     console.log("spans" + JSON.stringify(this.spans));
    // }
    cacheSpan(key, accessor) {
        for (let i = 0; i < this.recommendationData.length;) {
          let currentValue = accessor(this.recommendationData[i])[key];
          let count = 1;
          let currentNo = accessor(this.recommendationData[i]).no;
    
          // Iterate through the remaining rows to see how many match
          // the current value as retrieved through the accessor.
          for (let j = i + 1; j < this.recommendationData.length; j++) {
            if (currentValue == accessor(this.recommendationData[j])[key] && accessor(this.recommendationData[j])["no"] == currentNo) {
            count++;
            }
          }
          if (!this.spans[i]) {
            this.spans[i] = {};
          }
          // Store the number of similar values that were found (the span)
          // and skip i to the next unique row.
          this.spans[i][key] = count;
          i += count;
        }
      }
}
