import { Component, Inject } from "@angular/core";
import { Router } from "@angular/router";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
    selector: 'cancel-confirmation-dialog',
    templateUrl: '../confirmation-dialog/cancel-confirmation-dialog.html',
    styleUrls: ['../../../../assets/css/events.css']
})
export class AnalyticsCancelConfirmationDialogComponent {

    constructor(
        private router: Router,
        public dialogRef: MatDialogRef<AnalyticsCancelConfirmationDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data) {
    }

    onNoClick(): void {
        this.dialogRef.close();
    }
    onYesClick(): void {
        this.dialogRef.close();
        this.router.navigate(["/" + this.data.route]);
    }
}