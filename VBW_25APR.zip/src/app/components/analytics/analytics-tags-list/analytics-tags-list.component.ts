import {
  Component, OnInit, ViewChild, ViewChildren, Inject,
  HostListener, EventEmitter, Output, ViewEncapsulation, QueryList
} from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { CommonService } from '../../../services/common.service';
import { AnalyticsService } from '../../../services/analytics.service';
import { ErrorserviceService } from '../../../services/errorservice.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatTabGroup } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/common';

interface IPrognosisTag {
  id: any;
  countryId: any;
  cityId: any;
  plantId: any;
  processId: any;
  plant: any;
  process: any;
  tag: any;
  min: number;
  max: number;
}

interface IPredictionTag {
  id: string;
  countryId: string;
  cityId: string;
  plantId: string;
  processId: string;
  plant: string;
  process: string;
  tag: string;
  min: number;
  threshold: number;
}

@Component({
  selector: 'app-analytics-tags-list',
  templateUrl: './analytics-tags-list.component.html',
  styleUrls: ['./analytics-tags-list.component.css', '../../../../assets/css/events.css'],
  encapsulation: ViewEncapsulation.None,
})
export class AnalyticsTagsListComponent implements OnInit {
  @ViewChildren(MatPaginator) paginator = new QueryList<MatPaginator>();
  @ViewChildren(MatSort) sort = new QueryList<MatSort>();
  @ViewChild('tabGroup') tabGroup: MatTabGroup;
  displayedColumnsPrognosis: string[] = ['plant', 'process', 'tag', 'min', 'max', 'action'];
  displayedColumnsPrediction: string[] = ['plant', 'process', 'tag', 'min', 'threshold', 'action'];
  prognosisTags: IPrognosisTag[] = [];
  predictionTags: IPredictionTag[] = [];
  predictionTagNames = [];
  plantobj: any;
  processobj: any;
  dataSourcePrognosisTags: any;
  dataSourcePredictionTags: any;
  errorMessage: any;
  selectedTab: any;
  processes = [];
  plants = [];
  selectedPlant = 0;
  processresponse: any;
  selectedPlantPrediction: any;
  selectedPlantPrognosis: any;

  constructor(public route: ActivatedRoute,
    private commonService: CommonService,
    private router: Router,
    private analyticsService: AnalyticsService,
    private errorservice: ErrorserviceService,
    public dialog: MatDialog, @Inject(DOCUMENT) document) {
    this.selectedTab = 0;
    if (this.route.params['value'].hasOwnProperty('type')) {
      if (this.route.params['value'].type === 'prognosis') {
        this.selectedTab = 1;
      } else {
        this.selectedTab = 0;
      }

    }
  }

  ngOnInit() {
    this.tabGroup.selectedIndex = this.selectedTab;
    this.plants = [];
    this.route.params.subscribe(params => {
      if (!params.plantid) {
        this.selectedPlant = 0;
        this.listPlantAndProcess(this.selectedPlant);
      } else {
        this.selectedPlant = parseInt(params.plantid, 10);
        this.listPlantAndProcess(this.selectedPlant);
      }
    });
  }

  listPlantAndProcess(plantId: any) {
    /**
     * For listing Plant and Process
     */
    const processType = '';
    this.analyticsService.getPlantProcesses(processType).subscribe(
      data => {
        this.processresponse = data;
        this.processes = [];
        this.plants = [];
        if (this.processresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.processresponse.status, statusText: this.processresponse.message });
        } else {
          for (let i = 0; i < this.processresponse.data.countries.length; i++) {
            for (let j = 0; j < this.processresponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.processresponse.data.countries[i].cities[j].plants.length; k++) {
                let plantobj: {
                  id: any, acronym: any, countryId: any, cityId: any
                };
                plantobj = {
                  id: this.processresponse.data.countries[i].cities[j].plants[k].id,
                  acronym: this.processresponse.data.countries[i].cities[j].plants[k].acronym,
                  countryId: this.processresponse.data.countries[i].id,
                  cityId: this.processresponse.data.countries[i].cities[j].id
                };
                this.plants.push(plantobj);
              }
            }
          }
          if (plantId === 0) {
            this.selectedPlant = 0;
            if (this.plants.length > 0) {
              this.tabGroup.selectedIndex === 0 ? this.getPredictionTags(this.plants[0]) : this.getPrognosisTags(this.plants[0]);
            }
          } else {
            const plantobj = this.plants.filter(plant => {
              return plant.id === plantId;
            });
            this.selectedPlant = plantId;
            if (plantobj[0]) {
              // this.getPredictionTags(plantobj[0]);
              this.tabGroup.selectedIndex === 0 ? this.getPredictionTags(plantobj[0]) : this.getPrognosisTags(plantobj[0]);
            }
          }
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no plants pulled from the server!';
      }
    );
  }


  getPrognosisTags(plantobj: any) {
    /**
     * Get Prognosis Tags List
     */
    this.prognosisTags = [];
    this.selectedPlant = plantobj.id;
    this.analyticsService.getPrognosisTags(plantobj).subscribe(
      (data: any) => {
        if(data.data != null){
          const plantAcronym = data.data.country.city.plant.acronym;
        for (let j = 0; j < data.data.country.city.plant.analyticsProcesses.length; j++) {
          const processName = data.data.country.city.plant.analyticsProcesses[j].name;
          for (let i = 0; i < data.data.country.city.plant.analyticsProcesses[j].prognosisTags.length; i++) {
            const prognosistag: IPrognosisTag = {
              id: data.data.country.city.plant.analyticsProcesses[j].prognosisTags[i].id,
              countryId: data.data.country.id,
              cityId: data.data.country.city.id,
              plantId: data.data.country.city.plant.id,
              processId: data.data.country.city.plant.analyticsProcesses[j].id,
              plant: plantAcronym,
              process: processName,
              tag: data.data.country.city.plant.analyticsProcesses[j].prognosisTags[i].tagName,
              min: data.data.country.city.plant.analyticsProcesses[j].prognosisTags[i].minValue,
              max: data.data.country.city.plant.analyticsProcesses[j].prognosisTags[i].maxValue
            };
            this.prognosisTags.push(prognosistag);
          }
        }
        }
        
        this.dataSourcePrognosisTags = new MatTableDataSource(this.prognosisTags);
        this.dataSourcePrognosisTags.filterPredicate = function (data: any, filter: string): boolean {
          return data.process.toLowerCase().includes(filter) ||
          data.plant.toString().toLowerCase().includes(filter) ||
          data.tag.toString().toLowerCase().includes(filter) ||
          (data.min !== null ? data.min.toString().toLowerCase().includes(filter) : null) ||
          (data.max !== null ? data.max.toString().toLowerCase().includes(filter) : null);
        };
        if (this.dataSourcePrognosisTags) {
          this.dataSourcePrognosisTags.paginator = this.paginator.toArray()[1];
        }
      },
      (err: any) => {
        this.errorMessage = err;
      }
    );
  }
  assignThresholdTags(){
      const plantobj = this.plants.filter(plant => {
        return plant.id === this.selectedPlant;
      });
    let planId = plantobj[0].id;
    this.commonService.setPredictionTags(this.predictionTagNames);
    this.router.navigate(['/add-prediction-tag/' + planId]);
  }
  getPredictionTags(plantobj: any) {
    /**
     * Get Prognosis Tags List
     */
    this.predictionTagNames = [];
    this.predictionTags = [];
    this.selectedPlant = plantobj.id;
    this.analyticsService.getPredictionTags(plantobj).subscribe(
      (data: any) => {

        const plantAcronym = data.data.country.city.plant.acronym;
        for (let j = 0; j < data.data.country.city.plant.analyticsProcesses.length; j++) {
          const processName = data.data.country.city.plant.analyticsProcesses[j].name;
          for (let i = 0; i < data.data.country.city.plant.analyticsProcesses[j].predictionTags.length; i++) {
            const predictionTag: IPredictionTag = {
              id: data.data.country.city.plant.analyticsProcesses[j].predictionTags[i].id,
              countryId: data.data.country.id,
              cityId: data.data.country.city.id,
              plantId: data.data.country.city.plant.id,
              processId: data.data.country.city.plant.analyticsProcesses[j].id,
              plant: plantAcronym,
              process: processName,
              tag: data.data.country.city.plant.analyticsProcesses[j].predictionTags[i].tagName,
              min: data.data.country.city.plant.analyticsProcesses[j].predictionTags[i].minValue,
              threshold: data.data.country.city.plant.analyticsProcesses[j].predictionTags[i].maxValue
            };
            this.predictionTags.push(predictionTag);
            this.predictionTagNames.push(predictionTag.tag);
          }
        }
        this.dataSourcePredictionTags = new MatTableDataSource(this.predictionTags);
        this.dataSourcePredictionTags.filterPredicate = function (data: any, filter: string): boolean {
          return data.process.toLowerCase().includes(filter) ||
          data.plant.toString().toLowerCase().includes(filter) ||
          data.tag.toString().toLowerCase().includes(filter) ||
          (data.min !== null ? data.min.toString().toLowerCase().includes(filter) : null) ||
          (data.threshold !== null ? data.threshold.toString().toLowerCase().includes(filter) : null);
        };
        if (this.dataSourcePredictionTags) {
          this.dataSourcePredictionTags.paginator = this.paginator.toArray()[0];
        }
      },
      (err: any) => {
        console.log('Prediction Tags Listing Failed');
        this.errorMessage = err;
      }
    );
  }

  onSelectedIndexChange(e) {
    this.selectedTab = this.tabGroup.selectedIndex;
    if (this.selectedTab === 0) {
      this.router.navigate(['/analytics-tags-list/prediction/0']);
    }
    if (this.selectedTab === 1) {
      this.router.navigate(['/analytics-tags-list/prognosis/0']);
    }
  }
  /**
   * Event Search
   */
  applyFilter(filterValue: string) {
    if (this.dataSourcePredictionTags) {
      this.dataSourcePredictionTags.filter = filterValue.trim().toLowerCase();
    }
    if (this.dataSourcePrognosisTags) {
      this.dataSourcePrognosisTags.filter = filterValue.trim().toLowerCase();
    }
  }

}
