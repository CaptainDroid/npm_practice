import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsTagsListComponent } from './analytics-tags-list.component';

describe('AnalyticsTagsListComponent', () => {
  let component: AnalyticsTagsListComponent;
  let fixture: ComponentFixture<AnalyticsTagsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalyticsTagsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsTagsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
