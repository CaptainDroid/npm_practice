import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalyticsAddEditPredictionTagComponent } from './add-edit-predictiontag.component';

describe('AddEventCategoryComponent', () => {
  let component: AnalyticsAddEditPredictionTagComponent;
  let fixture: ComponentFixture<AnalyticsAddEditPredictionTagComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalyticsAddEditPredictionTagComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalyticsAddEditPredictionTagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
