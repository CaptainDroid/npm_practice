import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AnalyticsService } from 'src/app/services/analytics.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AnalyticsCancelConfirmationDialogComponent } from '../confirmation-dialog/cancel-confirmation-dialog';
import { ErrorserviceService } from 'src/app/services/errorservice.service';
import { CommonService } from 'src/app/services/common.service';
import { p } from '@angular/core/src/render3';
import { DialogComponent } from '../../common/dialog/dialog.component';

class CrossFieldErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    return control.dirty && form.invalid;
  }
}
@Component({
  selector: 'app-add-edit-predictiontag',
  templateUrl: './add-edit-predictiontag.component.html',
  styleUrls: [
    './add-edit-predictiontag.component.css',
    '../../../../assets/css/events.css']
})
export class AnalyticsAddEditPredictionTagComponent implements OnInit {
  addeditPredictionTagForm: FormGroup;
  errorMatcher = new CrossFieldErrorMatcher();
  eventType = new FormControl();
  eventTypeList: string[] = [];
  plant: any = '';
  process: any = '';
  isEditPredictionTag: boolean = false;
  predictionTagAction: string;
  formData: any;
  predictionTagData: any;
  selectedPlantObj: any;
  predictionTagNames: any;
  plants = [];
  plantsForSelection = [];
  selectedPlant: any;
  processresponse: any;
  processes = [];
  tags = [];
  processesByPlant = [];
  selectedProcess: any;
  errorMessage: any;
  tagsresponse: any;
  predictionTag: any;
  predictionTagId: any;
  tagdescription_en: any = null;
  uom: any = null;
  tagdescription_cn: any = null;

  constructor(
    private formBuilder: FormBuilder,
    private analyticsService: AnalyticsService,
    private commonService: CommonService,
    private router: Router,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private errorservice: ErrorserviceService,
  ) {
      
      /**
       * Form Data
       */
      this.addeditPredictionTagForm = this.formBuilder.group({
        plant: [{ value: '0'}, Validators.required],
        process: [{ value: '0'}, Validators.required],
        tag: [{ value: '0'}, Validators.required],
        min: [''],
        threshold: ['', Validators.compose([Validators.required, Validators.pattern(/^\d{1,9}([\.,](\d{1,3})?)?$/)])],
        tagDescEn: [''],
        tagDescCn: [''],
        uom: [''],
        eventMessageEn: [''],
        eventMessageCn: ['']
      }, {
        validator: this.minmaxValidator
      });
      this.listPlantAndProcess();
      this.isEditPredictionTag = false;
      this.predictionTagNames = this.commonService.getPredictionTags();
      if (this.route.params['value'].hasOwnProperty('predictionTagId')) {
        this.isEditPredictionTag = true;
        this.predictionTag = {
          id: this.route.params['value'].predictionTagId,
          countryId: this.route.params['value'].countryId,
          cityId: this.route.params['value'].cityId,
          plantId: this.route.params['value'].plantId,
        };

        this.selectedPlant = {
          countryId: this.route.params['value'].countryId,
          cityId: this.route.params['value'].cityId,
          id: this.route.params['value'].plantId,
        };

        this.selectedProcess = {
          id: this.route.params['value'].processId
        };
        this.getAllTagsinPlant(this.selectedPlant);
        this.getPredictionTagDetails(this.selectedPlant, this.selectedProcess, this.predictionTag);
      }
      
  }

  getPredictionTagDetails(plantobj: any, processobj: any, predictionTag: any) {
    let getPredictionTagResponse: any;
    this.analyticsService.getPredictionTag(plantobj, processobj, predictionTag).subscribe(
      data => {
        getPredictionTagResponse = data;
        this.predictionTagData = {};
        if (getPredictionTagResponse.status !== 'success') {
          this.errorservice.showerror({ status: getPredictionTagResponse.status, statusText: getPredictionTagResponse.message });
        } else {
          this.predictionTagData = {
            id: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.id,
            plantId: getPredictionTagResponse.data.country.city.plant.id,
            processId: getPredictionTagResponse.data.country.city.plant.analyticsProcess.id,
            tagName: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.tagName,
            tagDescEn: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.tagDescription.EN,
            tagDescCn: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.tagDescription.CN,
            uom: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.uom,
            min: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.minValue,
            threshold: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.maxValue,
            eventMessageEn: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.eventMessage.EN || '',
            eventMessageCn: getPredictionTagResponse.data.country.city.plant.analyticsProcess.predictionTag.eventMessage.CN || ''
          };

          // this.addeditPredictionTagForm.setValue({
          //   plant: this.predictionTagData.plantId,
          //   process: null,
          //   tag: null,
          //   min: this.predictionTagData.min,
          //   threshold: this.predictionTagData.threshold,
          //   tagDescEn: this.predictionTagData.tagDescEn,
          //   tagDescCn: this.predictionTagData.tagDescCn,
          //   uom: this.predictionTagData.uom,
          //   eventMessageEn: this.predictionTagData.eventMessageEn,
          //   eventMessageCn: this.predictionTagData.eventMessageCn
          // });

          this.addeditPredictionTagForm.setValue({
            plant: this.predictionTagData.plantId,
            process: this.predictionTagData.processId,
            tag: this.predictionTagData.tagName,
            min: this.predictionTagData.min,
            threshold: this.predictionTagData.threshold,
            tagDescEn: this.predictionTagData.tagDescEn,
            tagDescCn: this.predictionTagData.tagDescCn,
            uom: this.predictionTagData.uom,
            eventMessageEn: this.predictionTagData.eventMessageEn,
            eventMessageCn: this.predictionTagData.eventMessageCn
          });

        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no tags pulled from the server!';
      }
    );
  }
  minmaxValidator(form: FormGroup) {
    const minVal = form.get('min').value;
    const maxVal = form.get('threshold').value;
    const regex=/^\d{1,9}([\.,](\d{1,3})?)?$/;
    if(minVal && !regex.test(minVal)){
      return { minValtValidationFlag: true}
    }else{
      return minVal > maxVal ? { minmaxNotmatched: true} : null;
    }
  }
  listPlantAndProcess() {
    /**
     * For listing Plant and Process
     */
    const processType = 'prediction';
    this.analyticsService.getPlantProcesses(processType).subscribe(
      data => {
        this.processresponse = data;
        this.processes = [];
        this.plants = [];
        if (this.processresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.processresponse.status, statusText: this.processresponse.message });
        } else {
          for (let i = 0; i < this.processresponse.data.countries.length; i++) {
            for (let j = 0; j < this.processresponse.data.countries[i].cities.length; j++) {
              for (let k = 0; k < this.processresponse.data.countries[i].cities[j].plants.length; k++) {
                let plantobj: {
                  id: any, acronym: any, countryId: any, cityId: any
                };
                plantobj = {
                  id: this.processresponse.data.countries[i].cities[j].plants[k].id,
                  acronym: this.processresponse.data.countries[i].cities[j].plants[k].acronym,
                  countryId: this.processresponse.data.countries[i].id,
                  cityId: this.processresponse.data.countries[i].cities[j].id
                };
                this.plants.push(plantobj);
                for (let l = 0; l < this.processresponse.data.countries[i].cities[j].plants[k].processes.length; l++) {
                  let processobj: {
                    id: any, plantId: any, processName: any
                  };
                  processobj = {
                    id: this.processresponse.data.countries[i].cities[j].plants[k].processes[l].id,
                    plantId: this.processresponse.data.countries[i].cities[j].plants[k].id,
                    processName: this.processresponse.data.countries[i].cities[j].plants[k].processes[l].process
                  };
                  this.processes.push(processobj);

                }
              }
            }
          }
          this.processesByPlant  = Object.assign([], this.processes);
          // tslint:disable-next-line:radix
          this.plant = this.plants.filter( t => t.id === parseInt(this.route.params['value'].plantId))[0];
          // tslint:disable-next-line:radix
          this.process = this.processes.filter( t => t.id === parseInt(this.route.params['value'].processId))[0];
          if (this.route.params['value'].hasOwnProperty('plantid')) {
            let selectedPlant = this.route.params['value'].plantid;
            this.addeditPredictionTagForm.setValue({
              plant: parseInt(selectedPlant),
              process: '',
              tag: '',
              min: '',
              threshold: '',
              tagDescEn: '',
              tagDescCn: '',
              uom: '',
              eventMessageEn: '',
              eventMessageCn: ''
            });
            let selectedPlantObj = this.plants.filter( t => t.id === parseInt(selectedPlant))[0];
            this.onSelectingPlant(selectedPlantObj);
          }
        }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no processes pulled from the server!';
      }
    );
    
  }

  ngOnInit() {



  }

  reloadProcess(plantobj: any) {
    this.selectedPlant = plantobj;
    if (this.processes.length > 0) {
    this.processesByPlant = this.processes.filter(
        process => process.plantId === plantobj.id);
    }
  }
  onSelectingPlant(plantobj: any) {
    this.plant = plantobj;
    this.reloadProcess(plantobj);
    this.getAllTagsinPlant(plantobj);
  }

  onSelectingProcess(processobj: any) {
    this.process = processobj;
  }

  onSelectingTag(tagobj: any) {
    this.addeditPredictionTagForm.controls['tagDescEn'].setValue(tagobj.tagDescEn);
    this.addeditPredictionTagForm.controls['tagDescCn'].setValue(tagobj.tagDescCn);
    this.addeditPredictionTagForm.controls['uom'].setValue(tagobj.uom);
  }

  getAllTagsinPlant(plantobj: any) {
    /**
    * For listing tags in the selected plant
    */
    this.analyticsService.getPredictTags(plantobj).subscribe(
      data => {
        this.tagsresponse = data;
        this.tags = [];
        if (this.tagsresponse.status !== 'success') {
          this.errorservice.showerror({ status: this.tagsresponse.status, statusText: this.tagsresponse.message });
        } else {
                for (let m = 0; m < this.tagsresponse.data.country.city.plant.predicTags.length; m++) {

                  let tagobj = {
                    id: this.tagsresponse.data.country.city.plant.predicTags[m].id,
                    tagName: this.tagsresponse.data.country.city.plant.predicTags[m].tagName,
                    tagDescEn: this.tagsresponse.data.country.city.plant.predicTags[m].tagDescription.EN,
                    tagDescCn: this.tagsresponse.data.country.city.plant.predicTags[m].tagDescription.CN,
                    uom: this.tagsresponse.data.country.city.plant.predicTags[m].uom,
                    isHide: false
                  };
                  if (this.predictionTagNames && this.predictionTagNames.indexOf(tagobj.tagName) > -1) {
                    tagobj.isHide = true;
                  } else {
                    tagobj.isHide = false;
                  }
                  this.tags.push(tagobj);
                }
              }
      },
      (err: any) => {
        console.log(err);
        this.errorMessage = 'There are no tags pulled from the server!';
      }
    );
  }

  /**
   * Cancel Confirmation Dialog
   */
  openConfirmationDialog() {
    const dialogRef = this.dialog.open(AnalyticsCancelConfirmationDialogComponent, {
      width: '400px',
      data: { route: 'analytics-tags-list/prediction/0' }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log('The dialog was closed');
    });
  }

  /**
   * Form Submit
   */
  addEditPredictionRecord() {
    if (this.addeditPredictionTagForm.valid) {
      const formValue = this.addeditPredictionTagForm.value;
      this.predictionTagAction = 'create';
      if (this.isEditPredictionTag) {
        this.predictionTagAction = 'update';
      }
      this.predictionTagData = formValue;
      this.predictionTagId = null;
      let eventMessageObj = {
        'en': formValue.eventMessageEn,
        'cn': formValue.eventMessageCn
      };

      this.formData = {
        action: this.predictionTagAction,
        tagName: formValue.tag,
        minValue: formValue.min,
        maxValue: formValue.threshold,
        processId: formValue.process,
        eventMessage: eventMessageObj
      };

      if (this.predictionTag && this.predictionTag.id !== null) {
        // tslint:disable-next-line:radix
        this.formData.predictionTagId = parseInt(this.predictionTag.id);
      }
      /**
       * Add/Edit Form Data - POST
       */
      this.analyticsService.savePredictionTag(this.plant, this.process, this.formData).subscribe(
        (data: any) => {
          if (data.status === 'success') {
            const dialogRef = this.dialog.open(DialogComponent, {
              width: '400px',
              disableClose: true,
              data: {title: 'data.L00224', message: 'Record saved successfully' }
            });
            const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
              dialogRef.componentInstance.closeDialog();
              this.router.navigate(['/analytics-tags-list/prediction/' + this.plant.id]);
            });
          } else {
            this.errorservice.showerror({ status: data.status, statusText: data.message });
          }
        },
        (err: any) => {
          console.log('Failed');
        }
      );
    }
  }

  navtopredictionmessage() {
    // tslint:disable-next-line: max-line-length
    const paramendpoint = this.selectedPlant.countryId + '/' + this.selectedPlant.cityId + '/' + this.selectedPlant.id + '/' + this.selectedProcess.id + '/' + this.predictionTag.id;
    this.router.navigate(['prediction-message-list/' + paramendpoint]);
  }
}
