import { Component, Inject, EventEmitter, Output, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog  } from '@angular/material';
import { CommonService } from '../../services/common.service';
import { AdminService } from '../../services/admin.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ErrorserviceService } from '../../services/errorservice.service';
import { DialogComponent } from '../../components/common/dialog/dialog.component';
import { AuthenticationService } from '../../services/authentication.service';
import { AdalService } from 'adal-angular4';

@Component({
  templateUrl: './changepassword.dialog.component.html',
  styleUrls: ['./changepassword.dialog.css', '../../../assets/css/events.css']
})
export class ChangePasswordDialogComponent implements OnInit {

  @Output() errorokcallback = new EventEmitter<any>(true);

  currentPassword: any;
  newPassword: any;
  confirmPassword: any;
  changePasswordForm: any;
  newUser: any = true;
  hidenewpwd: any = true;
  hidecurpwd: any = true;
  hideconpwd: any = true;
  currentUser: any;
  constructor(
    public dialogRef: MatDialogRef<ChangePasswordDialogComponent>,
    public adminService: AdminService,
    public commonService: CommonService,
    public errorservice: ErrorserviceService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.newUser = data.newUser;
    this.currentUser =  this.commonService.getUser();
      this.changePasswordForm = new FormGroup({
        currentPasswordControl: new FormControl('', Validators.required),
        newPasswordControl: new FormControl('', Validators.required),
        confirmPasswordControl: new FormControl('', Validators.required)
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.changePasswordForm.controls; }

  ngOnInit() {

  }
  closeDialog(): void {
    this.dialogRef.close();
  }
  cancel() {
    this.dialogRef.close();
    this.commonService.cancelChangepwd = true;
  }
  deleteworksheet() {
    this.errorokcallback.emit(true);
  }

  checkPasswords(group: FormGroup) {
    const pass = this.changePasswordForm.value.newPasswordControl;
    const confirmPass = this.changePasswordForm.value.confirmPasswordControl;

    return pass === confirmPass ? null : { notSame: true };
  }
  onSubmit() {
    if (this.changePasswordForm.invalid) {
      return;
    } else {
      if (this.checkPasswords(this.changePasswordForm)) {
        this.errorservice.showerror({ type: 'Error', status: '', statusText: 'data.L00829'});
        return;
      }
      const userInfo = this.commonService.getUser();
      let dataArray = {};
        dataArray = {
          'action': 'update',
          'userName': userInfo.sub,
          'password': this.changePasswordForm.value.currentPasswordControl,
          'newPassword': this.changePasswordForm.value.newPasswordControl,
          'confirmPassword': this.changePasswordForm.value.confirmPasswordControl
        };
      this.adminService.postChangePassword(dataArray)
        .subscribe((response: any) => {
          if (response.status === 'Failed') {
            this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
            return;
          } else {
            this.errorservice.showerror({ type: 'Info', status: '', statusText: 'data.L00827' });
            this.closeDialog();
            userInfo.UserStatus = 'Active';
            this.commonService.setUser(userInfo);
          }
        });
    }

  }

}
// Change passsword page
@Component({
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.dialog.css', '../../../assets/css/events.css']
})
export class ChangepasswordComponent implements OnInit {
  changepdfields = {
    curpd: '',
    newpd: '',
    conpd: ''
  };
  loading = false;
  constructor(
    public adminService: AdminService,
    public commonService: CommonService,
    public dialog: MatDialog,
    public adal: AdalService,
    public authservice: AuthenticationService,
    public errorservice: ErrorserviceService) { }

  ngOnInit() {}

  changepassword() {
      if (this.adal.userInfo.authenticated === true) {
        this.errorservice.showerror({ status: '', statusText: 'data.L00236' });
        return;
      }
      this.loading = true;
      const userInfo = this.commonService.getUser();
      let reqobj = {};
      reqobj = {
          'action': 'update',
          'userName': userInfo.sub,
          'password': this.changepdfields.curpd,
          'newPassword': this.changepdfields.newpd,
          'confirmPassword': this.changepdfields.conpd
      };
      this.adminService.postChangePassword(reqobj)
        .subscribe((response: any) => {
          this.loading = false;
          if (response.status !== 'success') {
            this.errorservice.showerror({ status: response['status'], statusText: response['message'] });
            return;
          } else {
           const dialogRef = this.dialog.open(DialogComponent, {
            width: '400px',
            disableClose: true,
            data: { title: 'data.L00224', message: 'data.L00827' }
          });
          const sub = dialogRef.componentInstance.okCallback.subscribe(result => {
            dialogRef.componentInstance.closeDialog();
            this.authservice.logout();
          });
          }
        });
    }
}

