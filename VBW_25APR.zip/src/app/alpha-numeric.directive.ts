import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appAlphaNumericDirective]'
})
export class AlphaNumericDirective {
   // Allow decimal numbers and negative values
   private regex: RegExp = new RegExp(/^[a-zA-Z0-9-_\.]*$/g);
   // Allow key codes for special events. Reflect :
   // Backspace, tab, end, home
   private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home'];

   constructor(private el: ElementRef) {
   }
   @HostListener('keydown', ['$event'])
   onKeyDown(event: KeyboardEvent) {
     // console.log(this.el.nativeElement.value);
     // Allow Backspace, tab, end, and home keys
     if (this.specialKeys.indexOf(event.key) !== -1) {
       return;
     }
     const current: string = this.el.nativeElement.value;
     const next: string = current.concat(event.key);
     const charCode = (event.which) ? event.which : event.keyCode;
     if (charCode === 110 && current.indexOf('.') !== -1) {
       event.preventDefault();
     }
     if (next && (charCode !== 110) && !String(next).match(this.regex)) {
       event.preventDefault();
     }
   }
}
