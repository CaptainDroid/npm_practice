import { LabsComponent } from './components/labs/labs.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './components/login/auth.guard';
import { EditworksheetComponent } from './components/labs/worksheets/editworksheet/editworksheet.component';
import { HomeComponent } from './components/home/home.component';
import { CityviewComponent } from './components/cityview/cityview.component';
import { PlantviewComponent } from './components/plantview/plantview.component';
import { RecordsComponent } from './components/labs/records/records.component';
import { RecordviewComponent } from './components/labs/records/recordview/recordview.component';
import { OpsComponent } from './components/ops/ops.component';
import { EditopsworksheetComponent } from './components/ops/opsworksheet/editopsworksheet/editopsworksheet.component';
import { OpsmaintenanceComponent } from './components/ops/opsmaintenance/opsmaintenance.component';
import { EditmaintenancewsComponent } from './components/ops/opsmaintenance/editmaintenancews/editmaintenancews.component';
import { OpsrecordsComponent } from './components/ops/opsrecords/opsrecords.component';
import { OpsmainrecordsComponent } from './components/ops/opsmainrecords/opsmainrecords.component';
import { ReportsComponent, AdhocTemplateComponent } from './components/reports/reports.component';
import { PfdComponent } from 'src/app/components/pfd/pfd.component';
import { AuthCallbackComponent } from './components/login/authcallback/auth-callback.component';
// tslint:disable-next-line:max-line-length
import { RemoteMonitoringCheckListComponent } from './components/events-and-alerts/remote-monitoring/remote-monitoring-check-list/remote-monitoring-check-list.component';
// tslint:disable-next-line:max-line-length
import { AddRemoteMonitoringCheckComponent } from './components/events-and-alerts/remote-monitoring/add-remote-monitoring-check/add-remote-monitoring-check.component';
import { ViewAnEventComponent } from './components/events-and-alerts/view-an-event/view-an-event.component';
// tslint:disable-next-line:max-line-length
import { SensorFailureCheckListComponent } from './components/events-and-alerts/sensor-failure-check-list/sensor-failure-check-list.component';
import { AddSensorFailureCheckComponent } from './components/events-and-alerts/add-sensor-failure-check/add-sensor-failure-check.component';
import { EventMessageListComponent } from './components/events-and-alerts/event-message-list/event-message-list.component';
import { AddEditEventMessageComponent } from './components/events-and-alerts/add-edit-event-message/add-edit-event-message.component';
import { EventCategoryListComponent } from './components/events-and-alerts/event-category-list/event-category-list.component';
import { AddEventCategoryComponent } from './components/events-and-alerts/add-event-category/add-event-category.component';
// tslint:disable-next-line:max-line-length
import { EventEscalationEmailAlertSettingsListComponent } from './components/events-and-alerts/event-escalation-email-alert-settings-list/event-escalation-email-alert-settings-list.component';
// tslint:disable-next-line:max-line-length
import { AddEditEventEscalationEmailSettingsComponent } from './components/events-and-alerts/add-edit-event-escalation-email-settings/add-edit-event-escalation-email-settings.component';
import { EventTypeListComponent } from './components/events-and-alerts/event-type-list/event-type-list.component';
import { NewEventComponent } from './components/events-and-alerts/new-event/new-event.component';

import { CustomerContractComponent } from './components/commercial/customer-contract/customer-contract.component';
import { ContractSpecificationsComponent } from './components/commercial/contract-specifications/contract-specifications.component';
// tslint:disable-next-line:max-line-length
import { EditCustomerContractComponent } from './components/commercial/renew-contract/edit-customer-contract/edit-customer-contract.component';
// import { EditContractSpecComponent } from './components/commercial/renew-contract/edit-contract-spec/edit-contract-spec.component';
import { AddCustomerDetailsComponent } from './components/admin/add-customer-details/add-customer-details.component';
import { CustomerListComponent } from './components/admin/customer-list/customer-list.component';
import { EditCustomerComponent } from './components/admin/edit-customer/edit-customer.component';
import { CreateNewEventComponent } from './components/events-and-alerts/events-categories/create-new-event/create-new-event.component';
// tslint:disable-next-line:max-line-length
import { ViewAllEventsCategoriesComponent } from './components/events-and-alerts/events-categories/view-all-events-categories/view-all-events-categories.component';
import { CommercialComponent } from './components/commercial/commercial.component';
import { CustomerDetailsComponent } from './components/commercial/customer-details/customer-details.component';
import { DataAnalysisComponent } from './components/data-analysis/data-analysis.component';
import { SchedulereportComponent } from './components/reports/schedulereport/schedulereport.component';
import { CreatestandardreportComponent } from './components/reports/createstandardreport/createstandardreport.component';
// import { EmailGroupListComponent } from './components/admin/email-group/email-group-list/email-group-list.component';
// import { AddEditEmailGroupComponent } from './components/admin/email-group/add-edit-email-group/add-edit-email-group.component';
import { AuditComponent, CloneAuditDialogComponent } from './components/audit/audit.component';
import { ScheduleauditComponent } from './components/audit/scheduleaudit/scheduleaudit.component';
import { CreateauditpointComponent } from './components/audit/createauditpoint/createauditpoint.component';
import { StatusauditComponent } from './components/audit/statusaudit/statusaudit.component';
import { EmailGroupListComponent } from './components/admin/email-group/email-group-list/email-group-list.component';
import { AddEditEmailGroupComponent } from './components/admin/email-group/add-edit-email-group/add-edit-email-group.component';
import { RoleListComponent } from './components/admin/role/role-list/role-list.component';
import { AddEditRoleComponent } from './components/admin/role/add-edit-role/add-edit-role.component';
import { UserListComponent } from './components/admin/user/user-list/user-list.component';
import { AddEditUserComponent } from './components/admin/user/add-edit-user/add-edit-user.component';
import { PlantListComponent } from './components/admin/plant/plant-list/plant-list.component';
import { AddUpdatePlantComponent } from './components/admin/plant/add-update-plant/add-update-plant.component';
import { AnalyticsPrognosisComponent } from './components/analytics/prognosis/analytics-prognosis.component';
import { AnalyticsTroubleshootingComponent } from './components/analytics/troubleshooting/analytics-troubleshooting.component';
import { AnalyticsTagsListComponent } from './components/analytics/analytics-tags-list/analytics-tags-list.component';
import { AnalyticsAddEditPrognosisTagComponent } from './components/analytics/add-edit-prognosis-tag/add-edit-prognosistag.component';
import { AnalyticsAddEditPredictionTagComponent } from './components/analytics/add-edit-prediction-tag/add-edit-predictiontag.component';
import { AnalyticsAddEditPredictTagComponent } from './components/analytics/add-edit-predict-tag/add-edit-predict-tag.component';
import { PredictionMessageListComponent,
  AddeEditRCMsgComponent } from './components/analytics/prediction-message-list/prediction-message-list.component';
import { UnlockRequestListComponent } from './components/admin/unlock-a-worksheet/unlock-request-list.component';
import { WaitForSaveComponent } from './components/wait-for-save/wait-for-save.component';
import { CityListComponent } from './components/admin/city/city-list/city-list.component';
import { AddEditCityComponent } from './components/admin/city/add-edit-city/add-edit-city.component';
import { OpsLocationComponent, AddOpsLocationComponent } from './components/admin/ops/ops-location.component';
import { OpsmeasurementComponent, AddOpsMeasurementComponent } from './components/admin/ops/opsmeasurement/opsmeasurement.component';
import { AssignopsmiComponent } from './components/admin/ops/assignopsmi/assignopsmi.component';
import { SetupWSComponent } from './components/admin/ops/setup-ws/setup-ws.component';
import { EquipmentComponent, AddEquipmentComponent } from './components/admin/maintenance/equipment/equipment.component';
import { ActivityComponent, AddActivityComponent } from './components/admin/maintenance/activity/activity.component';
import { AddLabSampleComponent } from './components/admin/lab-sample/add-lab-sample/add-lab-sample.component';
import { LabSampleListComponent } from './components/admin/lab-sample/lab-sample-list/lab-sample-list.component';
import { WorksheetTemplatesComponent } from './components/admin/worksheet-templates/worksheet-templates.component';
// tslint:disable-next-line:max-line-length
import { SetupRegularLabTemplateComponent, SetupTPartyLabTemplateComponent } from './components/admin/worksheet-templates/setup-lab-template/setup-lab-template.component';
import { LabTestComponent } from './components/admin/lab-test/lab-test.component';
import { AddLabTestComponent } from './components/admin/lab-test/add-lab-test/add-lab-test.component';
// import { SampleTestComponent } from './components/admin/sample-test/sample-test.component';
import { SampleTestComponent } from './components/admin/sample-test/sample-test.component';
import { ChangepasswordComponent } from './components/changepassword/changepassword.component';
import { TagsComponent } from './components/admin/tags/tags.component';
import { EventslistComponent } from './components/events-and-alerts/eventslist/eventslist.component';

const routes: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    component: DashboardComponent,
    children: [
      { path: '', component: HomeComponent },
      { path: 'worksheets/:plantid', component: LabsComponent },
      { path: 'worksheets', component: LabsComponent },
      { path: 'worksheet/:plantid/:worksheetid', component: EditworksheetComponent },
      { path: 'records', component: RecordsComponent },
      { path: 'records/:plantid', component: RecordsComponent },
      { path: 'viewworksheet/:plantid/:worksheetid', component: RecordviewComponent },
      { path: 'cityView/:countryId/city', component: CityviewComponent },
      { path: 'plantView/:countryId/:cityId/plant', component: PlantviewComponent },
      { path: 'commercial/:plantId', component: CommercialComponent },
      { path: 'commercial', component: CommercialComponent },
      { path: 'customerDetails', component: CustomerDetailsComponent },
      { path: 'dataAnalysis', component: DataAnalysisComponent },
      { path: 'opsworksheets/:plantid', component: OpsComponent },
      { path: 'opsworksheets', component: OpsComponent },
      { path: 'opsworksheet/:plantid/:worksheetid', component: EditopsworksheetComponent },

      { path: 'opsmaintenance/:plantid', component: OpsmaintenanceComponent },
      { path: 'opsmaintenance', component: OpsmaintenanceComponent },
      { path: 'opsmaintenance/:plantid/:worksheetid', component: EditmaintenancewsComponent },

      { path: 'opsrecords', component: OpsrecordsComponent },
      { path: 'opsrecords/:plantid', component: OpsrecordsComponent },
      { path: 'opsmainrecords', component: OpsmainrecordsComponent },
      { path: 'opsmainrecords/:plantid', component: OpsmainrecordsComponent },

      { path: 'reports/:plantid', component: ReportsComponent },
      { path: 'reports', component: ReportsComponent },
      { path: 'schedulereport/:plantid/:templateid', component: SchedulereportComponent },
      { path: 'createstdreport/:plantid', component: CreatestandardreportComponent},
      { path: 'editstdreport/:plantid/:templateid', component: CreatestandardreportComponent},
      { path: 'createadhoctemplate/:plantid' , component: AdhocTemplateComponent },
      { path: 'editffreport/:plantid/:templateid', component: AdhocTemplateComponent},

      { path: 'pfd', component: PfdComponent },
      { path: 'prognosis', component: AnalyticsPrognosisComponent },
      { path: 'troubleshooting', component: AnalyticsTroubleshootingComponent },

      { path: 'remote-monitoring-check-list', component: RemoteMonitoringCheckListComponent },
      { path: 'remote-monitoring-check-list/:plantid', component: RemoteMonitoringCheckListComponent },
      { path: 'add-remote-monitoring-check/:plantid', component: AddRemoteMonitoringCheckComponent },
      { path: 'edit-remote-monitoring-check/:checkValueId/:plantid', component: AddRemoteMonitoringCheckComponent },
      { path: 'view-event/:eventId/:action', component: ViewAnEventComponent },
      { path: 'sensor-failure', component: SensorFailureCheckListComponent },
      { path: 'sensor-failure/:plantid', component: SensorFailureCheckListComponent },
      { path: 'add-sensor-failure-check/:plantid', component: AddSensorFailureCheckComponent },
      { path: 'edit-sensor-failure-check/:id/:plantid', component: AddSensorFailureCheckComponent },
      { path: 'event-message', component: EventMessageListComponent },
      { path: 'add-event-message', component: AddEditEventMessageComponent },
      { path: 'edit-event-message/:id', component: AddEditEventMessageComponent },
      { path: 'event-category-list', component: EventCategoryListComponent },
      { path: 'add-event-category', component: AddEventCategoryComponent },
      { path: 'edit-event-category/:eventCategoryId', component: AddEventCategoryComponent },
      { path: 'event-escalation-email-alert-settings-list', component: EventEscalationEmailAlertSettingsListComponent },
      { path: 'add-event-escalation-email-settings', component: AddEditEventEscalationEmailSettingsComponent },
      { path: 'edit-event-escalation-email-settings/:eventEmailSettingId', component: AddEditEventEscalationEmailSettingsComponent },
      { path: 'event-type', component: EventTypeListComponent },
      { path: 'newevent', component: NewEventComponent },
      { path: 'editevent/:id', component: NewEventComponent },
      { path: 'customer-contract', component: CustomerContractComponent },
      { path: 'contract-specification', component: ContractSpecificationsComponent },
      { path: 'edit-contract/:id', component: CustomerContractComponent },
      { path: 'edit-contract-spec/:id', component: ContractSpecificationsComponent },
      { path: 'edit-customer-contract/:id', component: EditCustomerContractComponent },
      // { path: 'edit-customer-contract-spec/:id', component: EditContractSpecComponent },
      { path: 'customerList', component: CustomerListComponent },
      { path: 'addCustomer', component: AddCustomerDetailsComponent },
      { path: 'editCustomer/:id', component: EditCustomerComponent },
      { path: 'view-all-events-categories/plant/:plantAcronym', component: ViewAllEventsCategoriesComponent },
      { path: 'view-all-events-categories', component: ViewAllEventsCategoriesComponent },
      { path: 'view-all-events-categories/:eventType', component: ViewAllEventsCategoriesComponent },
      { path: 'create-new-event/:plantAcronym', component: CreateNewEventComponent },
      { path: 'create-new-event', component: CreateNewEventComponent },


      { path: 'email-groups' , component: EmailGroupListComponent },
      { path: 'add-email-group' , component: AddEditEmailGroupComponent },
      { path: 'edit-email-group/:id' , component: AddEditEmailGroupComponent },
      { path: 'audit' , component: AuditComponent },
      { path: 'audit/:plantid', component: AuditComponent },
      { path: 'scheduleaudit/:plantid/:auditid', component: ScheduleauditComponent },
      { path: 'createauditpoint', component: CreateauditpointComponent },
      { path: 'createauditpoint/:plantid', component: CreateauditpointComponent },
      { path: 'editauditpoint/:plantid/:auditid', component: CreateauditpointComponent},
      { path: 'viewauditpoint/:plantid/:auditid/:actionType', component: CreateauditpointComponent},
      { path: 'statusaudit', component: StatusauditComponent },
      { path: 'statusaudit/:plantid', component: StatusauditComponent },
      { path: 'dataAnalysis', component: DataAnalysisComponent },
      { path: 'roles' , component: RoleListComponent },
      { path: 'add-role' , component: AddEditRoleComponent },
      { path: 'edit-role/:id' , component: AddEditRoleComponent },
      { path: 'user-list' , component: UserListComponent },
      { path: 'user-list/:plantid' , component: UserListComponent },
      { path: 'add-user/:plantid' , component: AddEditUserComponent },
      { path: 'edit-user/:id/:plantid' , component: AddEditUserComponent },
      { path: 'plants' , component: PlantListComponent },
      { path: 'add-plant' , component: AddUpdatePlantComponent },
      { path: 'edit-plant/:id' , component: AddUpdatePlantComponent },
      { path: 'troubleshooting', component: AnalyticsTroubleshootingComponent },
      { path: 'analytics-tags-list/:type/:plantid', component: AnalyticsTagsListComponent },
      { path: 'add-prognosis-tag', component: AnalyticsAddEditPrognosisTagComponent},
      { path: 'edit-prognosis-tag/:countryId/:cityId/:plantId/:processId/:prognosisTagId',
      component: AnalyticsAddEditPrognosisTagComponent},
      { path: 'add-prediction-tag/:plantid', component: AnalyticsAddEditPredictionTagComponent},
      { path: 'edit-prediction-tag/:countryId/:cityId/:plantId/:processId/:predictionTagId',
      component: AnalyticsAddEditPredictionTagComponent},
      { path: 'add-predict-tag', component: AnalyticsAddEditPredictTagComponent},
      { path: 'prediction-message-list/:countryId/:cityId/:plantId/:processId/:predictionTagId', component: PredictionMessageListComponent},
      { path: 'add-analytics-rcmsg/:countryId/:cityId/:plantId/:processId/:predictionTagId', component: AddeEditRCMsgComponent},
      { path: 'edit-analytics-rcmsg/:countryId/:cityId/:plantId/:processId/:predictionTagId/:msgid', component: AddeEditRCMsgComponent},
      {path: 'unlock-worksheets' , component: UnlockRequestListComponent},
      {path: 'wait' , component: WaitForSaveComponent},
      {path: 'cities' , component: CityListComponent},
      {path: 'edit-city/:id', component: AddEditCityComponent},
      {path: 'add-city', component: AddEditCityComponent},
      {path: 'ops-location', component: OpsLocationComponent},
      {path: 'ops-location/:plantid', component: OpsLocationComponent},
      {path: 'addopslocation/:plantid', component: AddOpsLocationComponent},
      {path: 'editLocation/:plantid/:locationid', component: AddOpsLocationComponent},
      {path: 'ops-measurement', component: OpsmeasurementComponent},
      {path: 'ops-measurement/:plantid', component: OpsmeasurementComponent},
      {path: 'addopsmeasurement/:plantid', component: AddOpsMeasurementComponent},
      {path: 'editMeasurement/:plantid/:measurementid', component: AddOpsMeasurementComponent},
      {path: 'ops-assign', component: AssignopsmiComponent},
      {path: 'ops-setup', component: SetupWSComponent},
      {path: 'equipmentlist', component: EquipmentComponent},
      {path: 'equipmentlist/:plantid', component: EquipmentComponent},
      {path: 'addequipment/:plantid', component: AddEquipmentComponent},
      {path: 'editEquipment/:plantid/:equipmentId', component: AddEquipmentComponent},
      {path: 'activitylist', component: ActivityComponent},
      {path: 'activitylist/:plantid', component: ActivityComponent},
      {path: 'addactivity/:plantid', component: AddActivityComponent},
      {path: 'editActivity/:plantid/:activityId', component: AddActivityComponent},
      {path: 'add-lab-sample/:plantid', component: AddLabSampleComponent},
      {path: 'edit-lab-sample/:plantid/:id', component: AddLabSampleComponent},
      {path: 'lab-sample-list', component: LabSampleListComponent},
      {path: 'lab-sample-list/:plantid', component: LabSampleListComponent},
      {path: 'lab-test-list', component: LabTestComponent},
      {path: 'lab-test-list/:plantid', component: LabTestComponent},
      {path: 'edit-lab-test/:labTestId/:plantId', component: AddLabTestComponent},
      {path: 'add-lab-test/:plantid', component: AddLabTestComponent},
      {path: 'worksheet-templates-list', component: WorksheetTemplatesComponent},
      {path: 'worksheet-templates-list/:plantid', component: WorksheetTemplatesComponent},
      {path: 'setup-reg-lab-template/:plantid', component: SetupRegularLabTemplateComponent},
      {path: 'setup-tparty-lab-template/:plantid', component: SetupTPartyLabTemplateComponent},
      {path: 'sample-test', component: SampleTestComponent},
      {path: 'changepassword', component: ChangepasswordComponent },
      {path: 'tags', component: TagsComponent },
      {path: 'eventslist', component: EventslistComponent }
    ]
  },
  { path: 'login', component: LoginComponent },
  { path: 'signin-oidc', component: AuthCallbackComponent },
  { path: 'dashboard',
    canActivate: [AuthGuard],
    component: DashboardComponent,
    children: [
      { path: '', component: HomeComponent },
      { path: 'worksheets/:plantid', component: LabsComponent },
      { path: 'worksheets', component: LabsComponent },
      { path: 'worksheet/:plantid/:worksheetid', component: EditworksheetComponent },
      { path: 'viewworksheet/:plantid/:worksheetid', component: RecordviewComponent },
      { path: 'records', component: RecordsComponent },
      { path: 'cityView/:countryId/city', component: CityviewComponent },
      { path: 'plantView/:countryId/:cityId/plant', component: PlantviewComponent },
      { path: 'opsworksheets/:plantid', component: OpsComponent },
      { path: 'opsworksheets', component: OpsComponent },
      { path: 'opsworksheet/:plantid/:worksheetid', component: EditopsworksheetComponent },
      { path: 'opsmaintenance/:plantid', component: OpsmaintenanceComponent },
      { path: 'opsmaintenance', component: OpsmaintenanceComponent },
      { path: 'opsmaintenance/:plantid/:worksheetid', component: EditmaintenancewsComponent },
      { path: 'opsrecords', component: OpsrecordsComponent },
      { path: 'opsmainrecords', component: OpsmainrecordsComponent },
      { path: 'reports', component: ReportsComponent },
      { path: 'pfd', component: PfdComponent },
      { path: 'prognosis', component: AnalyticsPrognosisComponent },
      { path: 'troubleshooting', component: AnalyticsTroubleshootingComponent },
      { path: 'analytics-tags-list/:type/:plantid', component: AnalyticsTagsListComponent },
      { path: 'add-prognosis-tag', component: AnalyticsAddEditPrognosisTagComponent},
      { path: 'edit-prognosis-tag/:countryId/:cityId/:plantId/:processId/:prognosisTagId',
      component: AnalyticsAddEditPrognosisTagComponent},
      { path: 'add-prediction-tag/:plantid', component: AnalyticsAddEditPredictionTagComponent},
      { path: 'edit-prediction-tag/:countryId/:cityId/:plantId/:processId/:predictionTagId',
      component: AnalyticsAddEditPredictionTagComponent},
      { path: 'add-predict-tag', component: AnalyticsAddEditPredictTagComponent}
    ]
  },
  { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {scrollPositionRestoration: 'enabled'})],
  exports: [RouterModule]
})
export class AppRoutingModule {}
