import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { AuthenticationService } from '../services/authentication.service';
import {ErrorserviceService} from '../services/errorservice.service';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    constructor(private authenticationService: AuthenticationService, private errorservice: ErrorserviceService) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            console.log(err);
            if (err.status === 401) {
                // auto logout if 401 response returned from api
               // this.authenticationService.logout();
                // location.reload(true);
            }
            let message = '';
            if (err.error) {
                if (err.error.message) {
                    message = err.error.message;
                } else if (err.error.userMessage) {
                    message = err.error.userMessage;
                }
            } else {
                message = err.statusText;
            }
            this.errorservice.showerror({status: err.status, statusText: message});
            return throwError(message);
        }));
    }
}
