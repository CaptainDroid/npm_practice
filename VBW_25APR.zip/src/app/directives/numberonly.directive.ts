import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
 // tslint:disable-next-line:directive-selector
 selector: '[myNumberOnly]'
})
export class NumberOnlyDirective {
 // Allow decimal numbers and negative values
 //private regex: RegExp = new RegExp(/^[+-]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/);
 // Allow key codes for special events. Reflect :
 // Backspace, tab, end, home
 //private specialKeys: Array<string> = [ 'Backspace', 'Tab', 'End', 'Home', '-' , 'Delete', 'ArrowRight', 'ArrowLeft'];

constructor(private el: ElementRef) {
 }
 /*@HostListener('keyup', ['$event'])
 onKeyUp(event: KeyboardEvent) {
  if (this.el.nativeElement.value.match(/[\u4E00-\u9FFF\u3400-\u4DFF\uF900-\uFAFF]+/g)) {
    event.preventDefault();
  }
}*/
 @HostListener('keydown', [ '$event' ])
 onKeyDown(event: KeyboardEvent) {
  if (
    // Allow: Delete, Backspace, Tab, Escape, Enter
    [46, 8, 9, 27, 13].indexOf(event.keyCode) !== -1 ||
    (event.keyCode === 65 && event.ctrlKey === true) || // Allow: Ctrl+A
    (event.keyCode === 67 && event.ctrlKey === true) || // Allow: Ctrl+C
    (event.keyCode === 86 && event.ctrlKey === true) || // Allow: Ctrl+V
    (event.keyCode === 88 && event.ctrlKey === true) || // Allow: Ctrl+X
    (event.keyCode === 65 && event.metaKey === true) || // Cmd+A (Mac)
    (event.keyCode === 67 && event.metaKey === true) || // Cmd+C (Mac)
    (event.keyCode === 86 && event.metaKey === true) || // Cmd+V (Mac)
    (event.keyCode === 88 && event.metaKey === true) || // Cmd+X (Mac)
    (event.keyCode >= 35 && event.keyCode <= 39) || // Home, End, Left, Right
    (!event.shiftKey && (event.keyCode === 189 || event.keyCode === 109 ) && (this.el.nativeElement.value === '' || (this.el.nativeElement.value.split('-').length ===1 && this.el.nativeElement.value.split('').indexOf('-') < 0 ))) ||
    // tslint:disable-next-line:max-line-length
    (!event.shiftKey && (event.keyCode === 46 || event.keyCode === 190 || event.keyCode === 110 ) && this.el.nativeElement.value.split('.').length < 2)
  ) {
    return;  // let it happen, don't do anything
  }

  // Ensure that it is a number and stop the keypress
const isNumber = (event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105);
if (isNumber === false || event.shiftKey || (event.keyCode === 189 || event.keyCode === 109 )) {
  event.preventDefault();
}
  /*if (
    (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57)) &&
    (event.keyCode < 96 || event.keyCode > 105) || (event.keyCode > 31 && (event.keyCode < 45 || event.keyCode > 57 ))
  ) {
    event.preventDefault();
  }*/

}


}
