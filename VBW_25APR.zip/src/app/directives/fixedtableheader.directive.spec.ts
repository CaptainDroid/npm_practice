import { FixedtableheaderDirective } from './fixedtableheader.directive';

describe('FixedtableheaderDirective', () => {
  it('should create an instance', () => {
    const directive = new FixedtableheaderDirective();
    expect(directive).toBeTruthy();
  });
});
