import { Directive, ElementRef, HostListener, Input, Output, EventEmitter } from '@angular/core';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: 'input[digitOnlyZero]'
})
export class DigitDirectiveZero {

  constructor(private _el: ElementRef) { }
  @Output() ngModelChange: EventEmitter<any> = new EventEmitter();
  @HostListener('input', ['$event']) onInputChange(event) {
    const initalValue = this._el.nativeElement.value;
    this._el.nativeElement.value = initalValue.replace(/[^0-9]*/g, '');
    if ( initalValue !== this._el.nativeElement.value) {
      this.ngModelChange.emit('');
      event.stopPropagation();
    } else {
      // tslint:disable-next-line:radix
      if (parseInt(this._el.nativeElement.value) < 1) {
        this.ngModelChange.emit('');
      }
    }
  }
}