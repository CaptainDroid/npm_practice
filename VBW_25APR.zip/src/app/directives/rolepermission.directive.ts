import {
  Directive,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewContainerRef,
  TemplateRef,
  Input,
  Output
} from '@angular/core';
import { Subject } from 'rxjs';
import { CommonService } from '../services/common.service';

@Directive({
  selector: '[appHasRole]'
})
export class HasRoleDirective implements OnInit, OnDestroy {
  // the role the user must have
  @Input() appHasRole: string;

  stop$ = new Subject();

  isVisible = false;
  roles = [];
  userInfo: any;
  currentUserRole: any;

  /**
   * @param {ViewContainerRef} viewContainerRef
   * 	-- the location where we need to render the templateRef
   * @param {TemplateRef<any>} templateRef
   *   -- the templateRef to be potentially rendered
   */
  constructor(
    private viewContainerRef: ViewContainerRef,
    private templateRef: TemplateRef<any>,
    private commonservice: CommonService
  ) {}

  ngOnInit() {
       this.userInfo = this.commonservice.getUser();
       if(this.userInfo.prn) {
         const role = this.userInfo.prn;
         this.currentUserRole = role.toLowerCase();
         this.currentUserRole = this.currentUserRole.replace(/\s/g, '');
       }

      if(this.appHasRole) {
        let roleCollection = [];
        roleCollection = this.appHasRole.split(',');
        for (let i = 0; i < roleCollection.length; i++) {
          let role = roleCollection[i].toLowerCase();
          role = role.replace(/\s/g, '');
          this.roles.push(role);
        }
      }
      if (this.roles.length > 0) {
        if (this.roles.indexOf(this.currentUserRole) < 0) {
          this.viewContainerRef.clear();
        } else {
          this.viewContainerRef.createEmbeddedView(this.templateRef);
        }
      } else {
        this.viewContainerRef.createEmbeddedView(this.templateRef);
      }
  }

  ngOnDestroy() {
    this.stop$.next();
  }
}
