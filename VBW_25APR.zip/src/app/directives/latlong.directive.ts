import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[latLongOnly]'
})
export class LatLongDirective {
  // Allow decimal numbers and negative values
  private regex: RegExp = new RegExp(/^[-]{0,1}[0-9]{0,3}(\.[0-9]{1,13})?$/g);
  //  private regex: RegExp = new RegExp(/^(\+|-)?(?:180(?:(?:\.0{1,6})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,6})?))$/g);

   // Allow key codes for special events. Reflect :
   // Backspace, tab, end, home
   private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home'];

   constructor(private el: ElementRef) {
   }
   ctrlDown = false;

   @HostListener('keydown', ['$event'])
   onKeyDown(event: KeyboardEvent) {
     // Allow Backspace, tab, end, and home keys
     if (this.specialKeys.indexOf(event.key) !== -1) {
       return;
     }
     const current: string = this.el.nativeElement.value;
     const next: string = current.concat(event.key);
     const charCode = (event.which) ? event.which : event.keyCode;
     const ctrlKey = 17,
     cmdKey = 91,
     vKey = 86,
     cKey = 67;
     if (charCode === ctrlKey || charCode === cmdKey) {
       this.ctrlDown = true;
     }
     if (this.ctrlDown && (charCode === vKey || charCode === cKey)) {
       return;
     }
    //  if(charCode == 46 || charCode == 39 || charCode == 37){
    //     return;
    //  }
     if (charCode === 110 && current.indexOf('.') !== -1) {
       event.preventDefault();
     }

     if (charCode === 190 && current.indexOf('.') !== -1) {
      event.preventDefault();
     }

     if (charCode === 109 && ((current.length !== 0) || (current.indexOf('-') !== -1))) {
       event.preventDefault();
     }

     if (next && (charCode !== 110) && (charCode !== 190) && (charCode !== 109) && !String(next).match(this.regex)) {
       event.preventDefault();
     }
   }
}
