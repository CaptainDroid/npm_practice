import {
  Directive,
  Renderer2,
  HostListener,
  ElementRef,
  AfterViewInit
} from '@angular/core';

@Directive({
  selector: '[appFixedtableheader]'
})
export class FixedtableheaderDirective  implements AfterViewInit {

  // @HostListener('window:scroll', ['$event'])
  // public windowScrolled($event) {
    // this.windowScrollEventContent($event);
  // }
  leftHeaders: any;
  topHeaders: any;
  crossHeaders: any;
  constructor(private el: ElementRef, private renderer: Renderer2) { }

  ngAfterViewInit() {
    this.activate();
  }

  activate() {
    const container = this.el.nativeElement;
    this.applyClasses('thead tr', 'cross', 'th');
    this.applyClasses('tbody tr', 'fixed-cell', 'td');
    this.leftHeaders = [].concat.apply([], container.querySelectorAll('tbody td.fixed-cell'));
    this.topHeaders = [].concat.apply([], container.querySelectorAll('thead th'));
    this.crossHeaders = [].concat.apply([], container.querySelectorAll('thead th.cross'));
    console.log('line before setting up event handler');
  }
  applyClasses(selector: any, newClass: any, cell: any) {
    const container = this.el.nativeElement;
    const arrayItems = [].concat.apply([], container.querySelectorAll(selector));
    if (arrayItems) {
      arrayItems.forEach(function (row, i) {
        let numFixedColumns = 1;
        for (let j = 0; j < numFixedColumns; j++) {
            const currentElement = row.querySelector(cell);
            currentElement.classList.add(newClass);

            if (currentElement.hasAttribute('colspan')) {
                const colspan = currentElement.getAttribute('colspan');
                numFixedColumns -= (parseInt(colspan, 10) - 1);
            }
        }
        });
    }
  }

  @HostListener('scroll', ['$event'])
  public onListenerTriggered($event): void {
    console.log('scroll event handler hit');
    const container = this.el.nativeElement;
    const x = container.scrollLeft;
    const y = container.scrollTop;

    // Update the left header positions when the container is scrolled
    this.leftHeaders.forEach(function (leftHeader) {
        const yaxix = 0;
        leftHeader.style.transform = 'translate(' + x + 'px, ' + yaxix + 'px)';
    });

    // Update the top header positions when the container is scrolled
    this.topHeaders.forEach(function (topHeader) {
      const xaxis = 0;
      topHeader.style.transform = 'translate(' + xaxis + 'px, ' + y + 'px)';
    });

    // Update headers that are part of the header and the left column
    this.crossHeaders.forEach(function (crossHeader) {
        crossHeader.style.transform =  'translate(' + x + 'px, ' + y + 'px)';
    });
  }
}
