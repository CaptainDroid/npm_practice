import {
  Directive,
  Renderer2,
  HostListener,
  Input,
  ElementRef
} from '@angular/core';

@Directive({
  selector: '[appStickyHeader]'
})
export class StickyHeaderDirective {
  @Input() public topOffset = 0;
  @Input() isContent = false;

  @HostListener('window:scroll', ['$event'])
  public windowScrolled($event) {
    if (this.isContent) {
      this.windowScrollEventContent($event);
    } else {
      this.windowScrollEvent($event);
    }
  }
  constructor(private el: ElementRef, private renderer: Renderer2) {}

  windowScrollEventContent($event) {
    // const isReachingTop = this.getTop() > this.topOffset;
    const scrollpercentage = this.getscrollpercentage();
    if (isNaN(scrollpercentage) === false) {
        const isReachingTop = scrollpercentage > this.topOffset; // Percenctage
        if (isReachingTop) {
        this.renderer.setStyle(this.el.nativeElement, 'margin-top', '50px');
      } else {
        // this.renderer.setStyle(this.el.nativeElement, 'margin-top', 'initial');
        this.renderer.setStyle(this.el.nativeElement, 'margin-bottom', '50px');
      }
    }
  }

  windowScrollEvent($event) {
    // const isReachingTop = this.getTop() > this.topOffset;
    const scrollpercentage = this.getscrollpercentage();
    if (isNaN(scrollpercentage) === false) {
      const isReachingTop = scrollpercentage > this.topOffset; // Percenctage
      if (isReachingTop) {
        this.renderer.setStyle(this.el.nativeElement, 'position', 'fixed');
        this.renderer.setStyle(this.el.nativeElement, 'top', '0');
        this.renderer.addClass(this.el.nativeElement, 'stickyheader');
      } else {
        this.renderer.setStyle(this.el.nativeElement, 'position', 'relative');
        this.renderer.removeClass(this.el.nativeElement, 'stickyheader');
      }
    }
  }

  getTop() {
    return (
      window.pageYOffset ||
      document.documentElement.scrollTop ||
      document.body.scrollTop ||
      0
    );
  }

  getscrollpercentage() {
    const h = document.documentElement,
        b = document.body,
        st = 'scrollTop',
        sh = 'scrollHeight';
    return (h[st] || b[st]) / ((h[sh] || b[sh]) - h.clientHeight) * 100;
  }
}
